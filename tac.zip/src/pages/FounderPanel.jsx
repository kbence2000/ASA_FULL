import React, { useState, useEffect, useRef } from 'react';
import { Crown, Loader2, AlertTriangle, CheckCircle2, XCircle, Activity, Zap, Shield, Flame, Sparkles, Target, Box, Orbit, Radio, Infinity as InfinityIcon, Eye } from 'lucide-react';

const MODULES = [
  { id: "paradox", label: "Paradox", icon: Flame, color: "#32e67c" },
  { id: "shadow-architect", label: "Shadow", icon: Shield, color: "#8b5cf6" },
  { id: "hallucinator", label: "Halluc", icon: Sparkles, color: "#ec4899" },
  { id: "distorted-synergy", label: "Distort", icon: Zap, color: "#dc2626" },
  { id: "dark-energy", label: "Dark E", icon: Zap, color: "#4b0082" },
  { id: "anti-1998", label: "Anti98", icon: Radio, color: "#8b008b" },
  { id: "nq-fice", label: "NQFICE", icon: Box, color: "#7cf5ff" },
  { id: "infinity-expansion", label: "Infnty", icon: InfinityIcon, color: "#ffdb7c" },
  { id: "endless-mind-symphony", label: "Symphony", icon: Eye, color: "#f59e0b" }
];

export default function FounderPanel() {
  const [autoRunning, setAutoRunning] = useState(false);
  const [matrixData, setMatrixData] = useState([]);
  const [pending, setPending] = useState([]);
  const [metaReflector, setMetaReflector] = useState(null);
  const [error, setError] = useState(null);
  const canvasRef = useRef(null);

  // Animated background
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    let rotation = 0;

    let animationId;
    const animate = () => {
      ctx.fillStyle = 'rgba(2, 3, 9, 0.15)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      rotation += 0.002;

      // Draw rotating grid lines
      ctx.strokeStyle = 'rgba(124, 245, 255, 0.1)';
      ctx.lineWidth = 1;

      for (let i = -5; i <= 5; i++) {
        const offset = i * 80;
        
        // Horizontal lines
        ctx.beginPath();
        ctx.moveTo(0, centerY + offset + Math.sin(rotation + i) * 20);
        ctx.lineTo(canvas.width, centerY + offset + Math.sin(rotation + i + 1) * 20);
        ctx.stroke();

        // Vertical lines
        ctx.beginPath();
        ctx.moveTo(centerX + offset + Math.cos(rotation + i) * 20, 0);
        ctx.lineTo(centerX + offset + Math.cos(rotation + i + 1) * 20, canvas.height);
        ctx.stroke();
      }

      animationId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  // Fetch state every 5 seconds
  useEffect(() => {
    refreshState();
    const interval = setInterval(refreshState, 5000);
    return () => clearInterval(interval);
  }, []);

  const refreshState = async () => {
    try {
      const [stateRes, pendingRes, metaRes] = await Promise.all([
        fetch('http://localhost:9922/api/orch/state').then(r => r.json()),
        fetch('http://localhost:9922/api/founder/pending').then(r => r.json()),
        fetch('http://localhost:9922/api/orch/meta-reflector').then(r => r.json())
      ]);

      if (stateRes.status === 'ok') {
        setAutoRunning(stateRes.autoRunning || false);
        setMatrixData(stateRes.matrix || []);
      }

      if (pendingRes.status === 'ok') {
        setPending(pendingRes.pending || []);
      }

      if (metaRes.status === 'ok' || metaRes.summary) {
        setMetaReflector(metaRes);
      }

      setError(null);
    } catch (err) {
      console.error('State refresh error:', err);
      setError(err.message);
    }
  };

  const toggleAuto = async () => {
    try {
      const response = await fetch('http://localhost:9922/api/orch/auto', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: !autoRunning })
      });

      if (response.ok) {
        await refreshState();
      }
    } catch (err) {
      console.error('Auto toggle error:', err);
      setError(err.message);
    }
  };

  const handleDecision = async (id, decision) => {
    try {
      await fetch('http://localhost:9922/api/founder/decide', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, decision })
      });

      await refreshState();
    } catch (err) {
      console.error('Decision error:', err);
      setError(err.message);
    }
  };

  const getIntensityColor = (avgBreakthrough) => {
    if (avgBreakthrough > 0.6) return { bg: '#ffdb7c', shadow: 'rgba(255, 219, 124, 0.8)' };
    if (avgBreakthrough > 0.25) return { bg: '#7cf5ff', shadow: 'rgba(124, 245, 255, 0.6)' };
    return { bg: '#76ffa8', shadow: 'rgba(118, 255, 168, 0.5)' };
  };

  return (
    <div className="relative min-h-screen overflow-hidden" style={{
      background: 'radial-gradient(circle at top, #050608 0%, #020308 40%, #000 100%)'
    }}>
      <style>{`
        @keyframes founderPulse {
          0%, 100% { opacity: 0.9; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.05); }
        }

        @keyframes matrixGlow {
          0%, 100% { box-shadow: 0 0 20px rgba(124, 245, 255, 0.6); }
          50% { box-shadow: 0 0 40px rgba(124, 245, 255, 0.9); }
        }

        .founder-badge {
          animation: founderPulse 3s ease-in-out infinite;
        }

        .matrix-center-core {
          animation: matrixGlow 2s ease-in-out infinite;
        }

        .matrix-node {
          transition: all 0.3s ease-out;
        }

        .matrix-node:hover {
          transform: translate(-50%, -50%) scale(1.15);
        }
      `}</style>

      {/* Animated Background Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ opacity: 0.3 }}
      />

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Header */}
        <header className="sticky top-0 z-20 px-6 py-4 border-b backdrop-blur-xl"
          style={{
            background: 'rgba(0, 0, 0, 0.6)',
            borderColor: 'rgba(255, 255, 255, 0.08)'
          }}
        >
          <div className="max-w-[1800px] mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Crown className="w-6 h-6 text-yellow-400 founder-badge" />
              <div className="text-xs tracking-widest uppercase font-bold text-green-300">
                TAC · ORCHESTRATOR
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-xs text-gray-400">
                AUTO: <strong className={autoRunning ? 'text-green-400' : 'text-gray-500'}>
                  {autoRunning ? 'ON' : 'OFF'}
                </strong>
              </span>
              <button
                onClick={toggleAuto}
                className="px-4 py-2 rounded-full text-xs font-semibold uppercase tracking-wider transition-all"
                style={{
                  background: autoRunning 
                    ? 'linear-gradient(90deg, #32e67c, #7cf5ff)' 
                    : 'transparent',
                  color: autoRunning ? '#020309' : '#7cf5ff',
                  border: autoRunning ? 'none' : '1px solid rgba(124, 245, 255, 0.4)'
                }}
              >
                Toggle Auto
              </button>
            </div>
          </div>
        </header>

        {/* Error Display */}
        {error && (
          <div className="max-w-[1800px] mx-auto px-6 mt-4">
            <div className="p-4 rounded-xl border border-red-500/50 bg-red-900/20 flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
              <div>
                <div className="text-sm font-bold text-red-400">Backend Connection Error</div>
                <div className="text-xs text-gray-300 mt-1">{error}</div>
                <div className="text-xs text-gray-400 mt-2">
                  Backend: <code className="bg-black/40 px-2 py-0.5 rounded">http://localhost:9922</code>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Main Grid */}
        <main className="flex-1 max-w-[1800px] mx-auto w-full px-6 py-6">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            {/* Left: Matrix Visualization */}
            <div className="lg:col-span-2">
              <div className="rounded-2xl border p-6"
                style={{
                  background: 'radial-gradient(circle at top, rgba(124, 245, 255, 0.06), rgba(10, 12, 18, 0.9))',
                  borderColor: 'rgba(255, 255, 255, 0.04)',
                  boxShadow: '0 0 30px rgba(0, 0, 0, 0.7)'
                }}
              >
                <h2 className="text-sm tracking-widest uppercase text-purple-400 mb-6">
                  Matrix · Live Module Map
                </h2>

                {/* Matrix Visualization */}
                <div className="relative aspect-square max-w-[420px] mx-auto">
                  {/* Center Core */}
                  <div 
                    className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-9 h-9 rounded-full matrix-center-core"
                    style={{
                      background: 'radial-gradient(circle, #7cf5ff, #32e67c 60%, transparent)',
                      boxShadow: '0 0 40px rgba(124, 245, 255, 0.9)'
                    }}
                  />

                  {/* Module Nodes */}
                  {matrixData.map((module, idx) => {
                    const angle = (idx / matrixData.length) * Math.PI * 2;
                    const radius = 38; // percentage
                    const x = 50 + radius * Math.cos(angle);
                    const y = 50 + radius * Math.sin(angle);

                    const moduleConfig = MODULES.find(m => m.id === module.module);
                    const Icon = moduleConfig?.icon || Activity;
                    const intensityColor = getIntensityColor(module.avgBreakthrough || 0);

                    return (
                      <div
                        key={module.module}
                        className="matrix-node absolute"
                        style={{
                          left: `${x}%`,
                          top: `${y}%`,
                          transform: 'translate(-50%, -50%)',
                          width: '32px',
                          height: '32px',
                          borderRadius: '50%',
                          background: `radial-gradient(circle, ${intensityColor.bg}, ${intensityColor.bg}99, transparent)`,
                          boxShadow: `0 0 16px ${intensityColor.shadow}`,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}
                        title={`${moduleConfig?.label || module.module}: ${((module.avgBreakthrough || 0) * 100).toFixed(1)}%`}
                      >
                        <Icon className="w-4 h-4 text-black" />
                      </div>
                    );
                  })}
                </div>

                {/* Legend */}
                <div className="mt-6 flex items-center justify-center gap-4 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ background: '#76ffa8' }} />
                    <span className="text-gray-400">Low (&lt;25%)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ background: '#7cf5ff' }} />
                    <span className="text-gray-400">Mid (25-60%)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ background: '#ffdb7c' }} />
                    <span className="text-gray-400">High (&gt;60%)</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Pending Approvals + Meta */}
            <div className="lg:col-span-3 space-y-6">
              {/* Pending Approvals */}
              <div className="rounded-2xl border p-6"
                style={{
                  background: 'radial-gradient(circle at top, rgba(124, 245, 255, 0.06), rgba(10, 12, 18, 0.9))',
                  borderColor: 'rgba(255, 255, 255, 0.04)',
                  boxShadow: '0 0 30px rgba(0, 0, 0, 0.7)'
                }}
              >
                <h2 className="text-sm tracking-widest uppercase text-purple-400 mb-4">
                  Founder Approval · Pending Upgrades
                </h2>

                <div className="space-y-3 max-h-[420px] overflow-y-auto pr-2">
                  {pending.length === 0 ? (
                    <div className="text-center py-8 text-xs text-gray-500">
                      No pending approvals – modules are self-evolving.
                    </div>
                  ) : (
                    pending.map((item, idx) => {
                      const moduleConfig = MODULES.find(m => m.id === item.module);
                      return (
                        <div 
                          key={item.id || idx}
                          className="rounded-xl border p-4"
                          style={{
                            background: 'rgba(3, 8, 18, 0.9)',
                            borderColor: 'rgba(124, 245, 255, 0.1)'
                          }}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              {moduleConfig?.icon && React.createElement(moduleConfig.icon, {
                                className: "w-4 h-4",
                                style: { color: moduleConfig.color }
                              })}
                              <span className="text-xs text-purple-300 font-semibold">
                                {moduleConfig?.label || item.module}
                              </span>
                            </div>
                            <span className="text-xs px-2 py-0.5 rounded-full"
                              style={{
                                background: 'rgba(124, 245, 255, 0.2)',
                                border: '1px solid rgba(124, 245, 255, 0.4)',
                                color: '#7cf5ff'
                              }}
                            >
                              {((item.breakthrough || 0) * 100).toFixed(1)}%
                            </span>
                          </div>

                          <div className="text-sm text-white mb-3">
                            {item.idea}
                          </div>

                          <div className="flex items-center justify-between text-xs mb-3">
                            <span className="text-gray-400">
                              Risk: <strong className="text-red-400">{(item.best?.risk || 0).toFixed(3)}</strong>
                            </span>
                            <span className="text-gray-400">
                              Impro: <strong className="text-green-400">{(item.best?.improvement || item.best?.impro || 0).toFixed(3)}</strong>
                            </span>
                          </div>

                          <div className="flex gap-2 justify-end">
                            <button
                              onClick={() => handleDecision(item.id, 'approve')}
                              className="px-3 py-1.5 rounded-full text-xs font-semibold uppercase tracking-wider transition-all hover:scale-105"
                              style={{
                                background: 'linear-gradient(90deg, #32e67c, #7cf5ff)',
                                color: '#020309'
                              }}
                            >
                              <CheckCircle2 className="w-3 h-3 inline mr-1" />
                              Approve
                            </button>
                            <button
                              onClick={() => handleDecision(item.id, 'reject')}
                              className="px-3 py-1.5 rounded-full text-xs font-semibold uppercase tracking-wider transition-all hover:scale-105"
                              style={{
                                background: 'transparent',
                                color: '#fca5a5',
                                border: '1px solid rgba(252, 165, 165, 0.6)'
                              }}
                            >
                              <XCircle className="w-3 h-3 inline mr-1" />
                              Reject
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Meta-Reflector */}
              <div className="rounded-2xl border p-6"
                style={{
                  background: 'radial-gradient(circle at top, rgba(124, 245, 255, 0.06), rgba(10, 12, 18, 0.9))',
                  borderColor: 'rgba(255, 255, 255, 0.04)',
                  boxShadow: '0 0 30px rgba(0, 0, 0, 0.7)'
                }}
              >
                <h3 className="text-sm tracking-widest uppercase text-cyan-400 mb-3">
                  Paradox Meta-Reflector
                </h3>

                {metaReflector ? (
                  <div className="space-y-3">
                    <div className="text-xs text-gray-300 leading-relaxed">
                      {metaReflector.summary || 'Loading meta-analysis...'}
                    </div>

                    {metaReflector.founderWarnings && metaReflector.founderWarnings.length > 0 && (
                      <div className="mt-4 pt-3 border-t" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
                        <div className="text-xs font-bold text-yellow-400 mb-2 uppercase tracking-wider">
                          Founder Warnings
                        </div>
                        <ul className="space-y-1 pl-4">
                          {metaReflector.founderWarnings.map((warning, idx) => (
                            <li key={idx} className="text-xs text-gray-400">
                              {warning}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-xs text-gray-500">
                    No meta-analysis yet.
                  </div>
                )}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}