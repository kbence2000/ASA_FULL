import React, { useState } from 'react';
import { Calculator, Zap, Activity, CheckCircle2, AlertTriangle, Shield, TrendingUp, Infinity } from 'lucide-react';

export default function MathMindClone() {
  const [activeTab, setActiveTab] = useState('paradox');
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  // Paradox Engine
  const [exprA, setExprA] = useState('2 + 2');
  const [exprB, setExprB] = useState('2 * 2');

  // Number Guardian
  const [guardInput, setGuardInput] = useState('42');

  // Evolution Engine
  const [evolveInput, setEvolveInput] = useState('3.14159');

  // Infinity Math
  const [infinityInput, setInfinityInput] = useState('123456789012345678901234567890');

  const tabs = [
    { id: 'paradox', name: 'Paradox Engine', icon: AlertTriangle, color: '#ff6ec7' },
    { id: 'guardian', name: 'Number Guardian', icon: Shield, color: '#4eff8b' },
    { id: 'evolution', name: 'Numeric Evolution', icon: TrendingUp, color: '#24e4ff' },
    { id: 'infinity', name: 'InfinityMath', icon: Infinity, color: '#b788ff' }
  ];

  const handleParadoxCheck = async () => {
    setIsProcessing(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('http://localhost:3000/math/paradox', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ exprA, exprB })
      });

      if (!response.ok) throw new Error('Paradox check failed');
      const data = await response.json();
      setResult(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleGuardNumber = async () => {
    setIsProcessing(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('http://localhost:3000/math/guard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input: guardInput })
      });

      if (!response.ok) throw new Error('Guard failed');
      const data = await response.json();
      setResult(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleEvolve = async () => {
    setIsProcessing(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('http://localhost:3000/math/evolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input: evolveInput })
      });

      if (!response.ok) throw new Error('Evolution failed');
      const data = await response.json();
      setResult(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleInfinity = async () => {
    setIsProcessing(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('http://localhost:3000/math/infinity', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input: infinityInput })
      });

      if (!response.ok) throw new Error('Infinity view failed');
      const data = await response.json();
      setResult(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const getDecisionColor = (decision) => {
    switch (decision) {
      case 'allow': return { bg: '#4eff8b', text: '#4eff8b', glow: 'rgba(78, 255, 139, 0.4)' };
      case 'review': return { bg: '#ffcc4b', text: '#ffcc4b', glow: 'rgba(255, 204, 75, 0.4)' };
      case 'block': return { bg: '#ff4b81', text: '#ff4b81', glow: 'rgba(255, 75, 129, 0.4)' };
      default: return { bg: '#9094b2', text: '#9094b2', glow: 'rgba(144, 148, 178, 0.4)' };
    }
  };

  return (
    <div className="min-h-screen p-4" style={{
      background: 'radial-gradient(circle at top, #0a0a14 0, #030306 55%)'
    }}>
      <style>{`
        .math-panel {
          background: #0a0a12;
          border: 1px solid #1a1a26;
        }

        .tab-button {
          transition: all 0.2s ease-out;
          cursor: pointer;
        }

        .tab-button.active {
          box-shadow: 0 0 0 2px currentColor;
        }

        .result-panel {
          background: #05050d;
          border: 1px solid #1a1a26;
        }

        .info-card {
          background: #060612;
          border: 1px solid #1a1a26;
        }
      `}</style>

      <div className="max-w-[1400px] mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: 'radial-gradient(circle at 20% 0, #ffffff, #b788ff 40%, #6b0f6f)',
                boxShadow: '0 0 30px rgba(183, 136, 255, 0.6)'
              }}
            >
              <Calculator className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="text-xl font-bold text-white tracking-wide">
                MATH MIND CLONE
              </div>
              <div className="text-xs text-gray-400 tracking-wider">
                4 Meta-Engine • Paradox • Guardian • Evolution • Infinity
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full" style={{
            background: 'rgba(183, 136, 255, 0.12)',
            border: '1px solid rgba(183, 136, 255, 0.6)'
          }}>
            <div className="w-2 h-2 rounded-full pulse-dot" style={{ background: '#b788ff' }} />
            <span className="text-xs font-semibold" style={{ color: '#b788ff' }}>
              ACTIVE
            </span>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-4 p-3 rounded-xl border border-red-500/50 bg-red-900/10 flex items-center gap-3">
            <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Error</div>
              <div className="text-xs text-gray-300 mt-0.5">{error}</div>
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-2 mb-4 overflow-x-auto">
          {tabs.map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id);
                  setResult(null);
                  setError(null);
                }}
                className={`tab-button px-4 py-2 rounded-xl border flex items-center gap-2 whitespace-nowrap ${
                  isActive ? 'active' : ''
                }`}
                style={{
                  background: isActive ? 'rgba(255, 255, 255, 0.03)' : '#060612',
                  borderColor: isActive ? tab.color : 'transparent',
                  color: isActive ? tab.color : '#9094b2'
                }}
              >
                <Icon className="w-4 h-4" />
                <span className="text-xs font-semibold">{tab.name}</span>
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left: Input */}
          <div className="lg:col-span-5 space-y-4">
            {activeTab === 'paradox' && (
              <div className="math-panel rounded-2xl p-4">
                <div className="mb-3">
                  <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                    Mathematical Paradox Engine
                  </div>
                  <div className="text-[10px] text-gray-500">
                    Check if two expressions contradict each other
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <div className="text-xs text-gray-400 mb-1">Expression A</div>
                    <input
                      type="text"
                      value={exprA}
                      onChange={(e) => setExprA(e.target.value)}
                      className="w-full rounded-xl px-4 py-2 text-sm font-mono"
                      style={{
                        background: '#05050d',
                        border: '1px solid #1a1a26',
                        color: '#a3a7cf'
                      }}
                      placeholder="2 + 2"
                    />
                  </div>

                  <div>
                    <div className="text-xs text-gray-400 mb-1">Expression B</div>
                    <input
                      type="text"
                      value={exprB}
                      onChange={(e) => setExprB(e.target.value)}
                      className="w-full rounded-xl px-4 py-2 text-sm font-mono"
                      style={{
                        background: '#05050d',
                        border: '1px solid #1a1a26',
                        color: '#a3a7cf'
                      }}
                      placeholder="2 * 2"
                    />
                  </div>
                </div>

                <button
                  onClick={handleParadoxCheck}
                  disabled={isProcessing}
                  className="w-full mt-4 px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                  style={{
                    background: 'radial-gradient(circle at 20% 0, #ffffff, #ff6ec7 40%, #b8004f 70%)',
                    color: '#020206',
                    boxShadow: isProcessing ? 'none' : '0 8px 24px rgba(255, 110, 199, 0.6)'
                  }}
                >
                  {isProcessing ? (
                    <>
                      <Activity className="w-4 h-4 animate-spin" />
                      CHECKING...
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4" />
                      CHECK PARADOX
                    </>
                  )}
                </button>
              </div>
            )}

            {activeTab === 'guardian' && (
              <div className="math-panel rounded-2xl p-4">
                <div className="mb-3">
                  <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                    Number AI Guardian
                  </div>
                  <div className="text-[10px] text-gray-500">
                    Complete protection shield around a number
                  </div>
                </div>

                <input
                  type="text"
                  value={guardInput}
                  onChange={(e) => setGuardInput(e.target.value)}
                  className="w-full rounded-xl px-4 py-2 text-sm font-mono"
                  style={{
                    background: '#05050d',
                    border: '1px solid #1a1a26',
                    color: '#a3a7cf'
                  }}
                  placeholder="Enter number to guard"
                />

                <button
                  onClick={handleGuardNumber}
                  disabled={isProcessing}
                  className="w-full mt-4 px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                  style={{
                    background: 'radial-gradient(circle at 20% 0, #ffffff, #4eff8b 40%, #0b6b4f 70%)',
                    color: '#020206',
                    boxShadow: isProcessing ? 'none' : '0 8px 24px rgba(78, 255, 139, 0.6)'
                  }}
                >
                  {isProcessing ? (
                    <>
                      <Activity className="w-4 h-4 animate-spin" />
                      GUARDING...
                    </>
                  ) : (
                    <>
                      <Shield className="w-4 h-4" />
                      GUARD NUMBER
                    </>
                  )}
                </button>
              </div>
            )}

            {activeTab === 'evolution' && (
              <div className="math-panel rounded-2xl p-4">
                <div className="mb-3">
                  <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                    Numeric Evolution Engine
                  </div>
                  <div className="text-[10px] text-gray-500">
                    Get best format suggestions for a number
                  </div>
                </div>

                <input
                  type="text"
                  value={evolveInput}
                  onChange={(e) => setEvolveInput(e.target.value)}
                  className="w-full rounded-xl px-4 py-2 text-sm font-mono"
                  style={{
                    background: '#05050d',
                    border: '1px solid #1a1a26',
                    color: '#a3a7cf'
                  }}
                  placeholder="Enter number to evolve"
                />

                <button
                  onClick={handleEvolve}
                  disabled={isProcessing}
                  className="w-full mt-4 px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                  style={{
                    background: 'radial-gradient(circle at 20% 0, #ffffff, #24e4ff 40%, #08b8b8 70%)',
                    color: '#020206',
                    boxShadow: isProcessing ? 'none' : '0 8px 24px rgba(36, 228, 255, 0.6)'
                  }}
                >
                  {isProcessing ? (
                    <>
                      <Activity className="w-4 h-4 animate-spin" />
                      EVOLVING...
                    </>
                  ) : (
                    <>
                      <TrendingUp className="w-4 h-4" />
                      EVOLVE FORMAT
                    </>
                  )}
                </button>
              </div>
            )}

            {activeTab === 'infinity' && (
              <div className="math-panel rounded-2xl p-4">
                <div className="mb-3">
                  <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                    InfinityMath Core
                  </div>
                  <div className="text-[10px] text-gray-500">
                    BigInt or Float64 view with scientific notation
                  </div>
                </div>

                <textarea
                  value={infinityInput}
                  onChange={(e) => setInfinityInput(e.target.value)}
                  className="w-full h-[100px] rounded-xl p-4 text-xs font-mono resize-none"
                  style={{
                    background: '#05050d',
                    border: '1px solid #1a1a26',
                    color: '#a3a7cf'
                  }}
                  placeholder="Enter very large number or float"
                />

                <button
                  onClick={handleInfinity}
                  disabled={isProcessing}
                  className="w-full mt-4 px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                  style={{
                    background: 'radial-gradient(circle at 20% 0, #ffffff, #b788ff 40%, #8800ff 70%)',
                    color: '#020206',
                    boxShadow: isProcessing ? 'none' : '0 8px 24px rgba(183, 136, 255, 0.6)'
                  }}
                >
                  {isProcessing ? (
                    <>
                      <Activity className="w-4 h-4 animate-spin" />
                      PROCESSING...
                    </>
                  ) : (
                    <>
                      <Infinity className="w-4 h-4" />
                      INFINITY VIEW
                    </>
                  )}
                </button>
              </div>
            )}
          </div>

          {/* Right: Results */}
          <div className="lg:col-span-7 space-y-4">
            {!result ? (
              <div className="math-panel rounded-2xl p-6 h-full flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <Calculator className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <div className="text-sm font-semibold">No Results Yet</div>
                  <div className="text-xs mt-1">Process a number to see output</div>
                </div>
              </div>
            ) : (
              <>
                {/* Paradox Results */}
                {activeTab === 'paradox' && result.ok && (
                  <>
                    <div className="math-panel rounded-2xl p-4">
                      <div className="flex items-center justify-between">
                        <div className="text-xs text-gray-400 uppercase tracking-wider">Paradox Status</div>
                        <div 
                          className="px-6 py-2 rounded-full text-sm font-bold uppercase tracking-wider"
                          style={{
                            background: result.paradox ? 'rgba(255, 75, 129, 0.2)' : 'rgba(78, 255, 139, 0.2)',
                            color: result.paradox ? '#ff4b81' : '#4eff8b',
                            border: `2px solid ${result.paradox ? '#ff4b81' : '#4eff8b'}`
                          }}
                        >
                          {result.paradox ? 'PARADOX DETECTED' : 'CONSISTENT'}
                        </div>
                      </div>
                    </div>

                    <div className="math-panel rounded-2xl p-4">
                      <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
                        Evaluation
                      </div>

                      <div className="space-y-3">
                        <div className="info-card rounded-xl p-3">
                          <div className="text-[10px] text-gray-500 mb-1">Expression A</div>
                          <div className="text-sm font-mono text-white mb-1">{result.exprA}</div>
                          <div className="text-xs text-cyan-400">= {result.valA}</div>
                        </div>

                        <div className="info-card rounded-xl p-3">
                          <div className="text-[10px] text-gray-500 mb-1">Expression B</div>
                          <div className="text-sm font-mono text-white mb-1">{result.exprB}</div>
                          <div className="text-xs text-cyan-400">= {result.valB}</div>
                        </div>

                        <div className="result-panel rounded-xl p-3">
                          <div className="text-xs text-gray-300">{result.note}</div>
                        </div>
                      </div>
                    </div>
                  </>
                )}

                {/* Guardian Results */}
                {activeTab === 'guardian' && result.decision && (
                  <>
                    <div className="math-panel rounded-2xl p-4">
                      <div className="flex items-center justify-between">
                        <div className="text-xs text-gray-400 uppercase tracking-wider">Guardian Decision</div>
                        <div 
                          className="px-6 py-2 rounded-full text-sm font-bold uppercase tracking-wider"
                          style={{
                            background: `${getDecisionColor(result.decision).glow}`,
                            color: getDecisionColor(result.decision).text,
                            border: `2px solid ${getDecisionColor(result.decision).text}`
                          }}
                        >
                          {result.decision}
                        </div>
                      </div>
                    </div>

                    {result.quantumView?.ok && (
                      <div className="math-panel rounded-2xl p-4">
                        <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
                          Quantum Views
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="info-card rounded-xl p-3">
                            <div className="text-[10px] text-gray-500 mb-1">Float64</div>
                            <div className="text-xs font-mono text-white">{result.quantumView.float64}</div>
                          </div>
                          <div className="info-card rounded-xl p-3">
                            <div className="text-[10px] text-gray-500 mb-1">Int32</div>
                            <div className="text-xs font-mono text-white">{result.quantumView.int32}</div>
                          </div>
                          <div className="info-card rounded-xl p-3">
                            <div className="text-[10px] text-gray-500 mb-1">Hex</div>
                            <div className="text-xs font-mono text-cyan-400">{result.quantumView.hex}</div>
                          </div>
                          <div className="info-card rounded-xl p-3">
                            <div className="text-[10px] text-gray-500 mb-1">Scientific</div>
                            <div className="text-xs font-mono text-purple-400">{result.quantumView.scientific}</div>
                          </div>
                          <div className="info-card rounded-xl p-3 col-span-2">
                            <div className="text-[10px] text-gray-500 mb-1">Binary</div>
                            <div className="text-xs font-mono text-green-400 break-all">{result.quantumView.binary}</div>
                          </div>
                        </div>
                      </div>
                    )}

                    {result.cn && (
                      <div className="math-panel rounded-2xl p-4">
                        <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
                          C/N Analysis
                        </div>

                        <div className="grid grid-cols-3 gap-3">
                          <div className="info-card rounded-xl p-3">
                            <div className="text-[10px] text-gray-500 mb-1">Complexity</div>
                            <div className="text-lg font-bold text-white">{result.cn.complexity}</div>
                          </div>
                          <div className="info-card rounded-xl p-3">
                            <div className="text-[10px] text-gray-500 mb-1">Noise</div>
                            <div className="text-lg font-bold text-white">{result.cn.noise}</div>
                          </div>
                          <div className="info-card rounded-xl p-3">
                            <div className="text-[10px] text-gray-500 mb-1">Ratio</div>
                            <div className="text-lg font-bold text-cyan-400">{result.cn.ratio?.toFixed(2)}</div>
                          </div>
                        </div>
                      </div>
                    )}
                  </>
                )}

                {/* Evolution Results */}
                {activeTab === 'evolution' && result.ok && (
                  <>
                    {result.fie?.recommendedFormat && (
                      <div className="math-panel rounded-2xl p-4">
                        <div className="flex items-center justify-between">
                          <div className="text-xs text-gray-400 uppercase tracking-wider">Recommended Format</div>
                          <div 
                            className="px-8 py-3 rounded-full text-2xl font-mono font-bold"
                            style={{
                              background: 'rgba(36, 228, 255, 0.2)',
                              color: '#24e4ff',
                              border: '2px solid #24e4ff'
                            }}
                          >
                            {result.fie.recommendedFormat}
                          </div>
                        </div>
                      </div>
                    )}

                    {result.suggestions && result.suggestions.length > 0 && (
                      <div className="math-panel rounded-2xl p-4">
                        <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
                          Evolution Suggestions
                        </div>

                        <div className="space-y-2">
                          {result.suggestions.map((suggestion, idx) => (
                            <div key={idx} className="info-card rounded-xl p-3 flex items-start gap-2">
                              <CheckCircle2 className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
                              <div className="text-xs text-gray-300">{suggestion}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {result.quantum?.ok && (
                      <div className="math-panel rounded-2xl p-4">
                        <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
                          Multi-Format View
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="info-card rounded-xl p-3">
                            <div className="text-[10px] text-gray-500 mb-1">Hex</div>
                            <div className="text-xs font-mono text-cyan-400">{result.quantum.hex}</div>
                          </div>
                          <div className="info-card rounded-xl p-3">
                            <div className="text-[10px] text-gray-500 mb-1">Scientific</div>
                            <div className="text-xs font-mono text-purple-400">{result.quantum.scientific}</div>
                          </div>
                        </div>
                      </div>
                    )}
                  </>
                )}

                {/* Infinity Results */}
                {activeTab === 'infinity' && result.ok && (
                  <>
                    <div className="math-panel rounded-2xl p-4">
                      <div className="flex items-center justify-between">
                        <div className="text-xs text-gray-400 uppercase tracking-wider">Mode</div>
                        <div 
                          className="px-6 py-2 rounded-full text-sm font-bold uppercase tracking-wider"
                          style={{
                            background: result.mode === 'BigInt' ? 'rgba(183, 136, 255, 0.2)' : 'rgba(36, 228, 255, 0.2)',
                            color: result.mode === 'BigInt' ? '#b788ff' : '#24e4ff',
                            border: `2px solid ${result.mode === 'BigInt' ? '#b788ff' : '#24e4ff'}`
                          }}
                        >
                          {result.mode}
                        </div>
                      </div>
                    </div>

                    <div className="math-panel rounded-2xl p-4">
                      <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
                        Infinity View
                      </div>

                      <div className="space-y-3">
                        <div className="info-card rounded-xl p-3">
                          <div className="text-[10px] text-gray-500 mb-1">Original</div>
                          <div className="text-xs font-mono text-gray-300 break-all">{result.original}</div>
                        </div>

                        {result.bigInt && (
                          <div className="info-card rounded-xl p-3">
                            <div className="text-[10px] text-gray-500 mb-1">BigInt</div>
                            <div className="text-sm font-mono text-purple-400 break-all">{result.bigInt}</div>
                          </div>
                        )}

                        {result.value !== undefined && (
                          <div className="info-card rounded-xl p-3">
                            <div className="text-[10px] text-gray-500 mb-1">Float64 Value</div>
                            <div className="text-sm font-mono text-cyan-400">{result.value}</div>
                          </div>
                        )}

                        {result.scientific && (
                          <div className="info-card rounded-xl p-3">
                            <div className="text-[10px] text-gray-500 mb-1">Scientific Notation</div>
                            <div className="text-sm font-mono text-green-400">{result.scientific}</div>
                          </div>
                        )}
                      </div>
                    </div>
                  </>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}