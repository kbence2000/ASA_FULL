import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Sparkles, Trophy, Target, CheckCircle2,
  Clock, User, FileText, TrendingUp, Award,
  BookOpen, Zap
} from "lucide-react";
import { toast } from "sonner";

const MENTORING_API = import.meta.env.VITE_MENTORING_BACKEND_URL || "http://localhost:4000";

const STATUS_CONFIG = {
  pending: { label: "In Queue", color: "text-yellow-400", bg: "bg-yellow-600/20" },
  selected: { label: "Selected", color: "text-green-400", bg: "bg-green-600/20" },
  mentoring: { label: "Active Mentoring", color: "text-cyan-400", bg: "bg-cyan-600/20" },
  completed: { label: "Graduated", color: "text-purple-400", bg: "bg-purple-600/20" }
};

const TASK_STATUS_CONFIG = {
  open: { label: "To Do", color: "text-gray-400" },
  "in-progress": { label: "In Progress", color: "text-blue-400" },
  completed: { label: "Done", color: "text-green-400" }
};

export default function TalentDashboard() {
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: talent, isLoading } = useQuery({
    queryKey: ['talent', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const res = await fetch(`${MENTORING_API}/mentoring/talent/${user.email}`);
      if (!res.ok) return null;
      return res.json();
    },
    enabled: !!user?.email,
    refetchInterval: 10000,
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ taskId, status }) => {
      const res = await fetch(`${MENTORING_API}/mentoring/talent/task`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.email, taskId, status })
      });
      if (!res.ok) throw new Error('Update failed');
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['talent'] });
      toast.success("Task updated!");
    }
  });

  const handleTaskStatusChange = (taskId, newStatus) => {
    updateTaskMutation.mutate({ taskId, status: newStatus });
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0A0E14] flex items-center justify-center">
        <Card className="border-[#1a1f2e] bg-[#0f1419] p-8 text-center">
          <User className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Login Required</h2>
          <Button onClick={() => base44.auth.redirectToLogin()}>
            Sign In
          </Button>
        </Card>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0A0E14] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!talent) {
    return (
      <div className="min-h-screen bg-[#0A0E14]">
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <Sparkles className="w-20 h-20 text-gray-600 mx-auto mb-6" />
          <h1 className="text-4xl font-black text-white mb-4">Not Yet Discovered</h1>
          <p className="text-gray-400 mb-8 max-w-xl mx-auto">
            Compete in Innovation PvP battles, win matches, and rank high to get discovered by our AI talent detection system. Demigod-level performers get personal mentoring!
          </p>
          <div className="grid md:grid-cols-3 gap-4 max-w-2xl mx-auto">
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-4">
              <Trophy className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
              <div className="text-sm font-bold text-white">Win PvP Matches</div>
              <div className="text-xs text-gray-400">2+ wins recommended</div>
            </Card>
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-4">
              <Target className="w-8 h-8 text-purple-400 mx-auto mb-2" />
              <div className="text-sm font-bold text-white">Innovation Index</div>
              <div className="text-xs text-gray-400">80+ score target</div>
            </Card>
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-4">
              <Award className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
              <div className="text-sm font-bold text-white">Battle Rank</div>
              <div className="text-xs text-gray-400">Top 3 finish</div>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  const statusCfg = STATUS_CONFIG[talent.status] || STATUS_CONFIG.pending;

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#1a1f2e] bg-[#0f1419] mb-4">
            <Sparkles className="w-4 h-4 text-purple-500" />
            <span className="text-sm text-gray-400 uppercase tracking-wider">Talent Development Program</span>
          </div>
          <h1 className="text-5xl font-black mb-4" style={{
            background: "linear-gradient(135deg, #a855f7, #ec4899)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}>
            The World Is Yours
          </h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            AI-detected talent. Personal mentoring. Demigod certification path.
          </p>
        </div>

        {/* Status Banner */}
        <Card className="border-[#1a1f2e] bg-[#0f1419] p-6 mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-white mb-1">
                Welcome, {talent.username}!
              </h2>
              <p className="text-sm text-gray-400">
                You've been identified as high-potential talent
              </p>
            </div>
            <Badge className={`${statusCfg.bg} ${statusCfg.color} border border-${statusCfg.color}/30 text-lg px-4 py-2`}>
              {statusCfg.label}
            </Badge>
          </div>
        </Card>

        <div className="grid lg:grid-cols-[1.2fr_1fr] gap-8">
          {/* Left Column */}
          <div className="space-y-6">
            {/* Performance Stats */}
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-cyan-400" />
                Performance Metrics
              </h3>
              
              <div className="grid grid-cols-3 gap-3 mb-4">
                <div className="p-3 rounded-lg bg-[#141923] border border-[#1a1f2e] text-center">
                  <div className="text-2xl font-bold text-purple-400">
                    {talent.scoreTrend?.innovationIndex || 0}
                  </div>
                  <div className="text-xs text-gray-400">Innovation Index</div>
                </div>

                <div className="p-3 rounded-lg bg-[#141923] border border-[#1a1f2e] text-center">
                  <div className="text-2xl font-bold text-yellow-400">
                    {talent.scoreTrend?.pvpWins || 0}
                  </div>
                  <div className="text-xs text-gray-400">PvP Wins</div>
                </div>

                <div className="p-3 rounded-lg bg-[#141923] border border-[#1a1f2e] text-center">
                  <div className="text-2xl font-bold text-cyan-400">
                    #{talent.scoreTrend?.battleRank || "N/A"}
                  </div>
                  <div className="text-xs text-gray-400">Battle Rank</div>
                </div>
              </div>

              <div className="p-4 rounded-lg bg-gradient-to-br from-purple-600/10 to-pink-600/10 border border-purple-600/30">
                <div className="flex items-start gap-2">
                  <Trophy className="w-4 h-4 text-yellow-400 flex-shrink-0 mt-0.5" />
                  <div className="text-xs text-purple-200">
                    <strong>AI Detection:</strong> You qualified for talent mentoring based on consistent high innovation scores, multiple PvP victories, and top battle rankings.
                  </div>
                </div>
              </div>
            </Card>

            {/* Assigned Tasks */}
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <Target className="w-5 h-5 text-green-400" />
                Mentor Tasks
              </h3>

              {talent.assignedTasks && talent.assignedTasks.length > 0 ? (
                <div className="space-y-3">
                  {talent.assignedTasks.map((task) => {
                    const taskCfg = TASK_STATUS_CONFIG[task.status] || TASK_STATUS_CONFIG.open;
                    
                    return (
                      <div key={task.id} className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <h4 className="font-semibold text-white mb-1">{task.title}</h4>
                            <p className="text-sm text-gray-400">{task.desc}</p>
                          </div>
                          <Badge className={`${taskCfg.color} bg-[#0a0a0f] border-[#1a1f2e]`}>
                            {taskCfg.label}
                          </Badge>
                        </div>

                        <div className="flex gap-2 mt-3">
                          {task.status !== "in-progress" && (
                            <Button
                              onClick={() => handleTaskStatusChange(task.id, "in-progress")}
                              size="sm"
                              variant="outline"
                              className="border-blue-600/30 text-blue-400"
                            >
                              Start Task
                            </Button>
                          )}
                          {task.status !== "completed" && (
                            <Button
                              onClick={() => handleTaskStatusChange(task.id, "completed")}
                              size="sm"
                              className="bg-green-600 hover:bg-green-700"
                            >
                              <CheckCircle2 className="w-4 h-4 mr-1" />
                              Mark Done
                            </Button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500 text-sm">
                  No tasks assigned yet. Your mentor will add tasks soon.
                </div>
              )}
            </Card>

            {/* Mentor Notes */}
            {talent.notes && talent.notes.length > 0 && (
              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-blue-400" />
                  Mentor Notes
                </h3>
                <div className="space-y-2">
                  {talent.notes.map((note, idx) => (
                    <div key={idx} className="p-3 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                      <p className="text-sm text-gray-300">{note}</p>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Mentor Info */}
            {talent.mentorId && (
              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <User className="w-5 h-5 text-purple-400" />
                  Your Mentor
                </h3>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                    <User className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <div className="font-semibold text-white">Demigod Mentor</div>
                    <div className="text-xs text-gray-400">Assigned to you</div>
                  </div>
                </div>
                <Badge className="bg-purple-600/20 text-purple-400 border-purple-600/30">
                  <Award className="w-3 h-3 mr-1" />
                  R6+ Certified
                </Badge>
              </Card>
            )}

            {/* Growth Plan */}
            {talent.growthPlan && (
              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-yellow-400" />
                  AI Growth Plan
                </h3>
                <div className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                  <pre className="text-xs text-gray-300 whitespace-pre-wrap font-mono leading-relaxed">
                    {talent.growthPlan}
                  </pre>
                </div>
              </Card>
            )}

            {/* Next Steps */}
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <Zap className="w-5 h-5 text-cyan-400" />
                Next Steps
              </h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <div className="text-white font-medium">Complete mentor tasks</div>
                    <div className="text-xs text-gray-400">Follow your personalized roadmap</div>
                  </div>
                </div>

                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <div className="text-white font-medium">Keep competing in PvP</div>
                    <div className="text-xs text-gray-400">Maintain high innovation scores</div>
                  </div>
                </div>

                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <div className="text-white font-medium">Target R6 Demigod rank</div>
                    <div className="text-xs text-gray-400">Ultimate certification goal</div>
                  </div>
                </div>
              </div>
            </Card>

            {/* Program Benefits */}
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-lg font-bold text-white mb-4">Program Benefits</h3>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-start gap-2">
                  <span className="text-purple-400">•</span>
                  <span>1-on-1 mentoring from R6+ developers</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-400">•</span>
                  <span>Personalized AI growth roadmap</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-400">•</span>
                  <span>Priority access to enterprise projects</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-400">•</span>
                  <span>Fast-track to Demigod certification</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-400">•</span>
                  <span>Exclusive networking events</span>
                </li>
              </ul>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}