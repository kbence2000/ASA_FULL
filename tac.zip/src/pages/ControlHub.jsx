import React, { useState, useRef, useEffect } from 'react';
import { Shield, Activity, AlertTriangle, CheckCircle2, Lock, Zap, Eye, Target, Loader2, Database, Brain, Power, Clock } from 'lucide-react';

const MODULES = [
  { name: "TrendHarvester", type: "AI-INTEL", status: "ok", spec: "Ingests external tech/code/news trends and normalizes them into TAC-readable signals. Real-time monitoring with intelligent filtering.", code: "class TrendHarvester { async harvest(sources) { /* ... */ } }" },
  { name: "SecuritySentinel", type: "GUARD", status: "ok", spec: "Watches TAC runtime, quarantines anomalies, calls repair agents on demand. 24/7 monitoring with automatic threat response.", code: "class SecuritySentinel { monitorRuntime() { /* ... */ } }" },
  { name: "MissionDeploy", type: "AGENT-OPS", status: "warn", spec: "Sends specialized AI agents on scoped missions with timers and kill-switches. Autonomous deployment with safety boundaries.", code: "class MissionDeploy { deploy(agent, mission) { /* ... */ } }" },
  { name: "DebugChamber", type: "AI-OPS", status: "bad", spec: "Dual-layer debugging (OpenAI debug + Demigod practice patterns). Advanced error analysis with AI-powered root cause detection.", code: "class DebugChamber { analyze(error) { /* ... */ } }" },
  { name: "ChaosArchitect", type: "GENESIS", status: "ok", spec: "Generates extreme upgrade concepts, feeds Chaos Inventory. Creative idea generation with boundary-pushing mutations.", code: "class ChaosArchitect { generate(brief) { /* ... */ } }" }
];

const MINDS = [
  { id: "harmony9", label: "Harmony 9", desc: "Stability & structure council", active: true },
  { id: "distorted9", label: "Distorted 9", desc: "Radical & chaotic council", active: true },
  { id: "hallucinator", label: "Hallucinator DM-0", desc: "Controlled creative distortion", active: true },
  { id: "paradox", label: "Paradox Core P-Ø", desc: "Fusion of opposites", active: true },
  { id: "security", label: "Security Sentinel", desc: "Watches anomalies, quarantines", active: true },
  { id: "mission", label: "Mission Orchestrator", desc: "Sends agents on missions", active: false },
  { id: "ghost", label: "Shadow Architect", desc: "Ghost-layer experimentation", active: false }
];

export default function ControlHub() {
  const [modules, setModules] = useState(MODULES);
  const [minds, setMinds] = useState(MINDS);
  const [selectedModuleName, setSelectedModuleName] = useState(MODULES[0]?.name || null);
  const [evolvedByModule, setEvolvedByModule] = useState({});
  const [securityLog, setSecurityLog] = useState("# Security AI active\n# Observing TAC ecosystem…");
  const [mindsLog, setMindsLog] = useState("# Minds Orchestrator idle…");
  const [autoOn, setAutoOn] = useState(false);
  const [isEvolving, setIsEvolving] = useState(false);
  const [autoIntervalId, setAutoIntervalId] = useState(null);
  const [error, setError] = useState(null);

  const securityLogRef = useRef(null);
  const mindsLogRef = useRef(null);

  useEffect(() => {
    if (securityLogRef.current) {
      securityLogRef.current.scrollTop = securityLogRef.current.scrollHeight;
    }
  }, [securityLog]);

  useEffect(() => {
    if (mindsLogRef.current) {
      mindsLogRef.current.scrollTop = mindsLogRef.current.scrollHeight;
    }
  }, [mindsLog]);

  const logSecurity = (msg) => {
    const timestamp = new Date().toLocaleTimeString('en-US', { hour12: false });
    setSecurityLog(prev => `${prev}\n[${timestamp}] > ${msg}`);
  };

  const logMinds = (msg) => {
    const timestamp = new Date().toLocaleTimeString('en-US', { hour12: false });
    setMindsLog(prev => `${prev}\n[${timestamp}] > ${msg}`);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'ok': return { bg: '#00ffa3', shadow: 'rgba(0, 255, 163, 0.6)' };
      case 'warn': return { bg: '#ffcc4b', shadow: 'rgba(255, 204, 75, 0.6)' };
      case 'bad': return { bg: '#ff4b81', shadow: 'rgba(255, 75, 129, 0.6)' };
      default: return { bg: '#8c8faf', shadow: 'rgba(140, 143, 175, 0.6)' };
    }
  };

  const selectModule = (name) => {
    setSelectedModuleName(name);
    logSecurity(`Selected module: ${name}`);
  };

  const toggleMind = (id) => {
    setMinds(prev => prev.map(mind => 
      mind.id === id ? { ...mind, active: !mind.active } : mind
    ));
    const mind = minds.find(m => m.id === id);
    logMinds(`${mind.label} turned ${!mind.active ? "ON" : "OFF"} by founder manual override.`);
  };

  const runEvolutionCycle = async (forcedModuleName = null) => {
    const essentialOn = ["harmony9", "distorted9", "hallucinator", "paradox"].every(
      (id) => minds.find((m) => m.id === id)?.active
    );
    
    if (!essentialOn) {
      logMinds("Evolution attempt blocked: essential minds are not all ON.");
      return;
    }

    const candidates = modules.filter((m) => m.status !== "bad");
    if (candidates.length === 0) {
      logMinds("No healthy-enough modules to evolve.");
      return;
    }

    const mod = forcedModuleName && modules.find((m) => m.name === forcedModuleName)
      ? modules.find((m) => m.name === forcedModuleName)
      : candidates[Math.floor(Math.random() * candidates.length)];

    logMinds(`Evolution cycle started for module: ${mod.name}`);
    logSecurity(`Paradox Evolution engaged for ${mod.name}…`);
    setIsEvolving(true);
    setError(null);

    try {
      const response = await fetch('http://localhost:8090/api/evolution/evolve-module', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          moduleName: mod.name,
          currentSpec: mod.spec,
          currentCode: mod.code || '',
          intensity: 8
        })
      });

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      const result = data.result;
      const stabilizer = result.stages?.stabilizer;

      if (stabilizer) {
        const blueprintText = `# ${mod.name} :: vNext (Paradox Evolution)

TIMESTAMP: ${new Date().toISOString()}

SUMMARY:
${stabilizer.finalSummary}

API SPECIFICATION:
${stabilizer.finalApiSpec}

IMPLEMENTATION SKETCH:
${stabilizer.finalImplementationSketch}

CHANGELOG:
${stabilizer.changelog?.map((c, i) => `${i + 1}. ${c}`).join('\n') || 'No specific changes'}`;

        setEvolvedByModule(prev => ({
          ...prev,
          [mod.name]: {
            blueprintText,
            rawResult: result,
            lastCycle: new Date()
          }
        }));

        // Security AI check
        const securityDecision = Math.random();
        const newStatus = securityDecision < 0.1 ? 'bad' : securityDecision < 0.35 ? 'warn' : 'ok';
        
        setModules(prev => prev.map(m => 
          m.name === mod.name ? { ...m, status: newStatus } : m
        ));

        if (newStatus === 'bad') {
          logSecurity(`Security AI: ${mod.name} vNext flagged as unstable. Quarantined.`);
        } else if (newStatus === 'warn') {
          logSecurity(`Security AI: ${mod.name} vNext requires manual review before activation.`);
        } else {
          logSecurity(`Security AI: ${mod.name} vNext passed checks. Ready for activation in Vault.`);
        }

        logMinds(`Evolution cycle finished for ${mod.name}.`);
      } else {
        throw new Error('No stabilizer output from backend');
      }

    } catch (err) {
      console.error('Evolution error:', err);
      setError(err.message);
      logSecurity(`Evolution failed for ${mod.name}: ${err.message}`);
      logMinds(`Evolution error: ${err.message}`);
    } finally {
      setIsEvolving(false);
    }
  };

  const toggleAuto = () => {
    if (!autoOn) {
      const intervalId = setInterval(() => {
        runEvolutionCycle();
      }, 180000); // 3 minutes
      
      setAutoIntervalId(intervalId);
      setAutoOn(true);
      logMinds("Autonomous Evolution Loop turned ON (3 min cycle).");
    } else {
      if (autoIntervalId) {
        clearInterval(autoIntervalId);
      }
      setAutoIntervalId(null);
      setAutoOn(false);
      logMinds("Autonomous Evolution Loop turned OFF.");
    }
  };

  const setActiveModule = () => {
    if (!selectedModuleName) return;
    const evolved = evolvedByModule[selectedModuleName];
    if (!evolved) {
      alert("No evolved version for this module yet.");
      return;
    }
    logSecurity(`Founder manually set ${selectedModuleName} vNext as ACTIVE in control layer.`);
  };

  const selectedModule = modules.find(m => m.name === selectedModuleName);
  const evolvedSpec = selectedModuleName && evolvedByModule[selectedModuleName];

  return (
    <div className="min-h-screen p-4" style={{
      background: 'radial-gradient(circle at top, #151522 0, #020206 58%)'
    }}>
      <style>{`
        .hub-shell {
          background: linear-gradient(135deg, rgba(20, 244, 168, 0.12), rgba(80, 90, 255, 0.08), rgba(0, 0, 0, 0.8));
          padding: 1px;
          box-shadow: 0 18px 50px rgba(0, 0, 0, 0.7);
        }

        .hub-inner {
          background: rgba(3, 3, 10, 0.96);
        }

        .hub-panel {
          background: #0a0a14;
          border: 1px solid #1a1a26;
          position: relative;
          overflow: hidden;
        }

        .hub-panel::before {
          content: "";
          position: absolute;
          inset: -1px;
          border-radius: inherit;
          background: radial-gradient(circle at top left, rgba(20, 244, 168, 0.1), transparent 60%);
          opacity: 0.4;
          pointer-events: none;
          mix-blend-mode: screen;
        }

        .module-item {
          background: #060612;
          border: 1px solid transparent;
          transition: 0.16s ease-out;
        }

        .module-item:hover {
          background: #0b0b17;
          border-color: rgba(255, 255, 255, 0.08);
        }

        .module-item.active {
          border-color: rgba(20, 244, 168, 0.7);
          background: #04040d;
          box-shadow: 0 0 0 1px rgba(20, 244, 168, 0.6);
        }

        .mind-toggle {
          width: 34px;
          height: 18px;
          border-radius: 999px;
          background: #151525;
          border: 1px solid #303045;
          position: relative;
          cursor: pointer;
          transition: 0.16s ease-out;
        }

        .mind-toggle.on {
          background: #0c2418;
          border-color: #27ffb1;
        }

        .mind-toggle-handle {
          position: absolute;
          top: 1px;
          left: 1px;
          width: 14px;
          height: 14px;
          border-radius: 999px;
          background: #888cb0;
          transition: 0.16s ease-out;
        }

        .mind-toggle.on .mind-toggle-handle {
          left: 17px;
          background: #14f4a8;
          box-shadow: 0 0 8px rgba(20, 244, 168, 0.9);
        }

        .status-pulse {
          animation: pulse 2s ease-in-out infinite;
        }

        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.6; }
        }
      `}</style>

      <div className="max-w-[1280px] mx-auto hub-shell rounded-[26px]">
        <div className="hub-inner rounded-[24px] p-4">
          {/* Header */}
          <header className="flex items-center justify-between gap-4 mb-4 flex-wrap">
            <div className="flex items-center gap-3">
              <div 
                className="w-9 h-9 rounded-full relative"
                style={{
                  background: 'radial-gradient(circle at 25% 0, #ffffff, #14f4a8 40%, #0b0b18 75%)',
                  boxShadow: '0 0 24px rgba(20, 244, 168, 0.8)'
                }}
              >
                <div 
                  className="absolute rounded-full"
                  style={{
                    inset: '5px',
                    border: '1px solid rgba(0, 0, 0, 0.7)'
                  }}
                />
              </div>
              <div>
                <div className="text-xs uppercase tracking-[0.12em] text-gray-400">
                  TAC // HYBRID CONTROL OS
                </div>
                <div className="text-lg font-semibold text-white">
                  Security · Vault · Minds
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3 flex-wrap text-xs text-gray-400">
              <div className="flex items-center gap-2">
                <div 
                  className="w-2.5 h-2.5 rounded-full status-pulse"
                  style={{ 
                    background: '#14f4a8',
                    boxShadow: '0 0 12px rgba(20, 244, 168, 0.9)'
                  }}
                />
                <span>Paradox Evolution Engine: <strong className="text-white">ONLINE</strong></span>
              </div>
              <div className="px-3 py-1 rounded-full text-[10px] uppercase tracking-wider" style={{
                border: '1px solid rgba(20, 244, 168, 0.7)',
                background: 'rgba(20, 244, 168, 0.16)',
                color: '#14f4a8'
              }}>
                Founder View
              </div>
            </div>
          </header>

          {/* Error Display */}
          {error && (
            <div className="mb-4 p-3 rounded-xl border border-red-500/50 bg-red-900/10 flex items-center gap-3">
              <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <div>
                <div className="text-sm font-bold text-red-400">Backend Connection Error</div>
                <div className="text-xs text-gray-300 mt-0.5">{error}</div>
                <div className="text-xs text-gray-500 mt-1">
                  Ensure backend is running: <code className="bg-black/40 px-1 py-0.5 rounded">node tac-evolution-engine.js</code> on port 8090
                </div>
              </div>
            </div>
          )}

          {/* Main Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Left: Security + Module Status */}
            <div className="lg:col-span-4 hub-panel rounded-2xl p-4">
              <div className="relative z-10 space-y-4">
                <div>
                  <div className="text-xs uppercase tracking-[0.08em] font-semibold text-gray-400 mb-1">
                    System Health & Security
                  </div>
                  <div className="text-[11px] text-gray-500">
                    Modules status monitored by Security AI.
                  </div>
                  <div className="mt-2 inline-flex items-center gap-2 px-3 py-1 rounded-full text-[10px] uppercase" style={{
                    border: '1px solid rgba(20, 244, 168, 0.9)',
                    background: 'rgba(20, 244, 168, 0.16)',
                    color: '#14f4a8'
                  }}>
                    Live Scan
                  </div>
                </div>

                {/* Module List */}
                <div className="space-y-2 max-h-[340px] overflow-y-auto pr-2">
                  {modules.map(module => {
                    const statusColor = getStatusColor(module.status);
                    return (
                      <div
                        key={module.name}
                        onClick={() => selectModule(module.name)}
                        className={`module-item rounded-xl p-3 cursor-pointer ${
                          selectedModuleName === module.name ? 'active' : ''
                        }`}
                      >
                        <div className="text-sm font-semibold text-white mb-1">
                          {module.name}
                        </div>
                        <div className="flex items-center justify-between text-[11px]">
                          <div className="flex items-center gap-2">
                            <div 
                              className="w-2 h-2 rounded-full"
                              style={{ 
                                background: statusColor.bg,
                                boxShadow: `0 0 10px ${statusColor.shadow}`
                              }}
                            />
                            <span className="text-gray-400">{module.type}</span>
                          </div>
                          <div className="px-2 py-0.5 rounded-full text-[9px] uppercase tracking-wider" style={{
                            background: 'rgba(255, 255, 255, 0.02)',
                            border: '1px solid rgba(255, 255, 255, 0.08)',
                            color: '#9094b2'
                          }}>
                            {module.status}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Security Stream */}
                <div>
                  <div className="text-xs uppercase tracking-[0.08em] font-semibold text-gray-400 mb-2">
                    Security Stream
                  </div>
                  <div 
                    ref={securityLogRef}
                    className="rounded-xl p-3 text-[11px] font-mono overflow-auto"
                    style={{
                      background: '#05050d',
                      border: '1px solid #1a1a26',
                      color: '#a3a7cf',
                      height: '160px',
                      lineHeight: '1.5',
                      whiteSpace: 'pre-line'
                    }}
                  >
                    {securityLog}
                  </div>
                </div>
              </div>
            </div>

            {/* Center: Module Vault */}
            <div className="lg:col-span-4 hub-panel rounded-2xl p-4">
              <div className="relative z-10 h-full flex flex-col gap-3">
                <div>
                  <div className="text-xs uppercase tracking-[0.08em] font-semibold text-gray-400 mb-1">
                    Module Vault
                  </div>
                  <div className="text-[11px] text-gray-500">
                    {selectedModuleName 
                      ? `${selectedModuleName} · live definition` 
                      : 'Select a module on the left to inspect & evolve.'}
                  </div>
                  <div className="mt-2 inline-flex items-center gap-2 px-3 py-1 rounded-full text-[10px] uppercase" style={{
                    background: 'rgba(255, 255, 255, 0.02)',
                    border: '1px solid rgba(255, 255, 255, 0.08)',
                    color: '#9094b2'
                  }}>
                    Vault · Paradox Output
                  </div>
                </div>

                {/* Current Spec */}
                <div className="rounded-xl p-3 relative overflow-auto" style={{
                  background: '#05050f',
                  border: '1px solid #1c1c2c',
                  height: '140px'
                }}>
                  <div className="absolute top-2 right-2 px-2 py-1 rounded-full text-[9px] uppercase tracking-wider" style={{
                    background: '#101021',
                    border: '1px solid rgba(255, 255, 255, 0.08)',
                    color: '#7c80d5'
                  }}>
                    LIVE SPEC
                  </div>
                  <pre className="text-[11px] text-gray-300 font-mono">
                    {selectedModule ? selectedModule.spec : '# Waiting for module selection...'}
                  </pre>
                </div>

                {/* Evolved Spec */}
                <div className="rounded-xl p-3 relative overflow-auto" style={{
                  background: '#05050f',
                  border: '1px solid #1c1c2c',
                  height: '180px'
                }}>
                  <div className="absolute top-2 right-2 px-2 py-1 rounded-full text-[9px] uppercase tracking-wider" style={{
                    background: '#101021',
                    border: '1px solid rgba(255, 255, 255, 0.08)',
                    color: '#7c80d5'
                  }}>
                    EVOLVED (vNext)
                  </div>
                  <pre className="text-[11px] text-gray-300 font-mono whitespace-pre-wrap">
                    {evolvedSpec 
                      ? evolvedSpec.blueprintText 
                      : '# No evolution yet.\n# Run evolution manually or enable auto-mind forging.\n\n# Backend: http://localhost:8090\n# Start: node tac-evolution-engine.js'}
                  </pre>
                </div>

                {/* Controls */}
                <div className="space-y-2">
                  <div className="text-[11px] text-gray-500">
                    Paradox Evolution: Harmony 9 × Distorted 9 × Hallucinator × Stabilizer.
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    <button
                      onClick={() => runEvolutionCycle(selectedModuleName)}
                      disabled={isEvolving || !selectedModuleName}
                      className="px-4 py-2 rounded-full text-[10px] font-semibold uppercase tracking-wider flex items-center gap-2 transition-all disabled:opacity-40"
                      style={{
                        background: 'radial-gradient(circle at 20% 0, #ffffff, #14f4a8 40%, #08b87a 70%)',
                        color: '#020206',
                        boxShadow: isEvolving ? 'none' : '0 8px 24px rgba(20, 244, 168, 0.6)'
                      }}
                    >
                      {isEvolving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Target className="w-4 h-4" />}
                      {isEvolving ? 'EVOLVING...' : 'Evolve Selected'}
                    </button>
                    <button
                      onClick={setActiveModule}
                      className="px-4 py-2 rounded-full text-[10px] font-semibold uppercase tracking-wider flex items-center gap-2 transition-all hover:bg-white/5"
                      style={{
                        background: 'rgba(255, 255, 255, 0.02)',
                        color: '#9094b2',
                        border: '1px solid rgba(255, 255, 255, 0.08)'
                      }}
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      Set vNext as Active
                    </button>
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    <span className="px-2 py-1 rounded-full text-[10px] uppercase tracking-wider" style={{
                      borderColor: 'rgba(20, 244, 168, 0.7)',
                      background: 'rgba(20, 244, 168, 0.16)',
                      color: '#14f4a8',
                      border: '1px solid'
                    }}>
                      Consensus-Approved
                    </span>
                    <span className="px-2 py-1 rounded-full text-[10px] uppercase tracking-wider" style={{
                      background: 'rgba(255, 255, 255, 0.02)',
                      border: '1px solid rgba(255, 255, 255, 0.08)',
                      color: '#9094b2'
                    }}>
                      Paradox Seal
                    </span>
                    <span className="px-2 py-1 rounded-full text-[10px] uppercase tracking-wider" style={{
                      borderColor: 'rgba(255, 76, 129, 0.9)',
                      background: 'rgba(255, 76, 129, 0.1)',
                      color: '#ff4b81',
                      border: '1px solid'
                    }}>
                      Manual Override
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: AI Minds Control */}
            <div className="lg:col-span-4 hub-panel rounded-2xl p-4">
              <div className="relative z-10 space-y-4">
                <div>
                  <div className="text-xs uppercase tracking-[0.08em] font-semibold text-gray-400 mb-1">
                    AI Minds · Orchestration
                  </div>
                  <div className="text-[11px] text-gray-500 mb-2">
                    Start/Stop AI minds, toggle autonomous evolution.
                  </div>
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-[10px] uppercase" style={{
                    border: '1px solid rgba(20, 244, 168, 0.9)',
                    background: 'rgba(20, 244, 168, 0.16)',
                    color: '#14f4a8'
                  }}>
                    Orchestrator
                  </div>
                </div>

                {/* Minds List */}
                <div className="space-y-2 max-h-[200px] overflow-y-auto">
                  {minds.map(mind => (
                    <div
                      key={mind.id}
                      className="rounded-xl p-3 flex items-center justify-between gap-3"
                      style={{
                        background: '#05050f',
                        border: '1px solid #19192a'
                      }}
                    >
                      <div>
                        <div className="text-xs font-medium text-white">{mind.label}</div>
                        <div className="text-[11px] text-gray-500">{mind.desc}</div>
                      </div>
                      <div
                        onClick={() => toggleMind(mind.id)}
                        className={`mind-toggle ${mind.active ? 'on' : ''}`}
                      >
                        <div className="mind-toggle-handle" />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Auto Evolution Control */}
                <div className="pt-3 border-t" style={{ borderColor: '#1a1a26' }}>
                  <div className="flex items-center justify-between gap-3 mb-2">
                    <div>
                      <div className="text-[11px] text-gray-400">Autonomous Evolution Loop</div>
                      <div className="text-[11px] text-gray-500">
                        Status: {autoOn ? 'ON' : 'OFF'} · Interval: 3 min cycles
                      </div>
                    </div>
                    <button
                      onClick={toggleAuto}
                      className="px-4 py-2 rounded-full text-[10px] font-semibold uppercase tracking-wider flex items-center gap-2 transition-all"
                      style={{
                        background: 'radial-gradient(circle at 20% 0, #ffffff, #14f4a8 40%, #08b87a 70%)',
                        color: '#020206',
                        boxShadow: '0 8px 24px rgba(20, 244, 168, 0.6)'
                      }}
                    >
                      <Power className="w-4 h-4" />
                      {autoOn ? 'DISABLE AUTO' : 'ENABLE AUTO'}
                    </button>
                  </div>
                </div>

                {/* Minds Log */}
                <div>
                  <div 
                    ref={mindsLogRef}
                    className="rounded-xl p-3 text-[11px] font-mono overflow-auto"
                    style={{
                      background: '#05050d',
                      border: '1px solid #1a1a26',
                      color: '#a3a7cf',
                      height: '130px',
                      lineHeight: '1.5',
                      whiteSpace: 'pre-line'
                    }}
                  >
                    {mindsLog}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}