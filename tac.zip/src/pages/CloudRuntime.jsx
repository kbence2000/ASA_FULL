import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import CloudRuntimePanel from "../components/CloudRuntimePanel";
import RankBadge from "../components/RankBadge";
import { 
  Zap, Trophy, Code2, Target, TrendingUp,
  Shield, Cpu, Clock, Lock 
} from "lucide-react";

const BACKEND_URL = import.meta.env.VITE_MDC_BACKEND_URL || "http://localhost:3000";

export default function CloudRuntime() {
  const [executionCount, setExecutionCount] = useState(0);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Fetch user's cloud runtime profile
  const { data: runtimeProfile, refetch: refetchProfile } = useQuery({
    queryKey: ['cloudRuntimeProfile', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      try {
        const res = await fetch(`${BACKEND_URL}/api/user/${user.email}`);
        if (!res.ok) {
          // Create user if doesn't exist
          const createRes = await fetch(`${BACKEND_URL}/api/user/create`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              id: user.email,
              username: user.full_name || user.email.split('@')[0]
            })
          });
          if (!createRes.ok) return null;
          return createRes.json();
        }
        return res.json();
      } catch {
        return null;
      }
    },
    enabled: !!user?.email,
  });

  const handleExecutionComplete = (data) => {
    if (data.runtimeResult?.status === "ok") {
      setExecutionCount(prev => prev + 1);
      refetchProfile();
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#1a1f2e] bg-[#0f1419] mb-4">
            <Zap className="w-4 h-4 text-cyan-500" />
            <span className="text-sm text-gray-400 uppercase tracking-wider">Serverless Execution</span>
          </div>
          <h1 className="text-5xl font-black mb-4" style={{
            background: "linear-gradient(135deg, #06B6D4, #3B82F6)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}>
            MDC Cloud Runtime
          </h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Execute JavaScript in AWS Lambda sandbox. Test algorithms, earn runtime score, climb the ranks.
          </p>
        </div>

        <div className="grid lg:grid-cols-[320px_1fr] gap-8">
          {/* Left: Stats & Info */}
          <div className="space-y-6">
            {/* User Stats */}
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <Trophy className="w-5 h-5 text-purple-400" />
                Your Stats
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Session Runs</span>
                  <span className="text-2xl font-bold text-cyan-400">{executionCount}</span>
                </div>
                
                {runtimeProfile && (
                  <>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Runtime Score</span>
                      <span className="text-2xl font-bold text-purple-400">
                        {runtimeProfile.runtime?.runtimeScore || 0}
                      </span>
                    </div>
                    
                    {runtimeProfile.tier && (
                      <div>
                        <span className="text-sm text-gray-400 block mb-2">Current Rank</span>
                        <RankBadge 
                          rank={runtimeProfile.tier.id} 
                          size="sm" 
                          showName 
                        />
                      </div>
                    )}

                    {runtimeProfile.runtime?.lastStatus && (
                      <div className="pt-3 border-t border-[#1a1f2e]">
                        <span className="text-xs text-gray-500 block mb-2">Last Execution</span>
                        <Badge className={
                          runtimeProfile.runtime.lastStatus === "ok" 
                            ? "bg-green-600/20 text-green-400 border-green-600/30"
                            : "bg-red-600/20 text-red-400 border-red-600/30"
                        }>
                          {runtimeProfile.runtime.lastStatus}
                        </Badge>
                      </div>
                    )}
                  </>
                )}
              </div>
            </Card>

            {/* How It Works */}
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-lg font-bold text-white mb-4">How It Works</h3>
              <div className="space-y-3 text-sm text-gray-400">
                <div className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-cyan-600/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-bold text-cyan-400">1</span>
                  </div>
                  <div>
                    <div className="font-semibold text-white">Write Function</div>
                    <div className="text-xs">Define entry point (e.g. <code className="bg-[#141923] px-1 rounded">main()</code>)</div>
                  </div>
                </div>
                
                <div className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-cyan-600/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-bold text-cyan-400">2</span>
                  </div>
                  <div>
                    <div className="font-semibold text-white">Lambda Execution</div>
                    <div className="text-xs">Runs in isolated AWS environment</div>
                  </div>
                </div>
                
                <div className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-cyan-600/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-bold text-cyan-400">3</span>
                  </div>
                  <div>
                    <div className="font-semibold text-white">Score Calculation</div>
                    <div className="text-xs">Speed + success = higher score</div>
                  </div>
                </div>
                
                <div className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-cyan-600/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-bold text-cyan-400">4</span>
                  </div>
                  <div>
                    <div className="font-semibold text-white">Rank Update</div>
                    <div className="text-xs">Contributes 20% to MDC total score</div>
                  </div>
                </div>
              </div>
            </Card>

            {/* Lambda Limits */}
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <Shield className="w-5 h-5 text-amber-400" />
                Sandbox Limits
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-gray-500" />
                    <span className="text-gray-400">Timeout</span>
                  </div>
                  <span className="text-white font-semibold">5000ms</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-gray-500" />
                    <span className="text-gray-400">Memory</span>
                  </div>
                  <span className="text-white font-semibold">128 MB</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Lock className="w-4 h-4 text-gray-500" />
                    <span className="text-gray-400">Network</span>
                  </div>
                  <span className="text-red-400 font-semibold">Disabled</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Lock className="w-4 h-4 text-gray-500" />
                    <span className="text-gray-400">File System</span>
                  </div>
                  <span className="text-red-400 font-semibold">Read-only</span>
                </div>
              </div>
            </Card>

            {/* Score Formula */}
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-lg font-bold text-white mb-3">Score Formula</h3>
              <div className="text-xs text-gray-400 space-y-2 leading-relaxed">
                <div>
                  <strong className="text-white">Success:</strong> 80 base points
                </div>
                <div>
                  <strong className="text-white">Speed Bonus:</strong> +0-10 pts (faster = better)
                </div>
                <div>
                  <strong className="text-white">Clean Run:</strong> +5 pts (no stderr)
                </div>
                <div>
                  <strong className="text-red-400">Timeout:</strong> 40 base points
                </div>
                <div>
                  <strong className="text-red-400">Error:</strong> 30 base points
                </div>
                <div className="pt-2 border-t border-[#1a1f2e] text-purple-400">
                  <strong>Runtime contributes 20%</strong> to total MDC score
                </div>
              </div>
            </Card>
          </div>

          {/* Right: Runtime Panel */}
          <div>
            <CloudRuntimePanel 
              userId={user?.email || 'anonymous'}
              onExecutionComplete={handleExecutionComplete}
            />

            {/* Bottom Info Cards */}
            <div className="grid md:grid-cols-3 gap-6 mt-8">
              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6 text-center">
                <Code2 className="w-8 h-8 text-cyan-400 mx-auto mb-3" />
                <h4 className="text-lg font-bold text-white mb-2">Practice Algorithms</h4>
                <p className="text-sm text-gray-400">
                  Write code, test logic, debug in real-time serverless environment
                </p>
              </Card>

              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6 text-center">
                <Trophy className="w-8 h-8 text-purple-400 mx-auto mb-3" />
                <h4 className="text-lg font-bold text-white mb-2">Earn Runtime Score</h4>
                <p className="text-sm text-gray-400">
                  Successful runs boost your runtime score (20% of total MDC rank)
                </p>
              </Card>

              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6 text-center">
                <Target className="w-8 h-8 text-green-400 mx-auto mb-3" />
                <h4 className="text-lg font-bold text-white mb-2">Showcase Ability</h4>
                <p className="text-sm text-gray-400">
                  Prove coding skills with live execution, impact MostWanted ranking
                </p>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}