import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Link2, Copy, TrendingUp, MousePointerClick, 
  DollarSign, Users, Check, ExternalLink, RefreshCw 
} from "lucide-react";
import { toast } from "sonner";
import { Label } from "@/components/ui/label";

// Generate unique affiliate code
function generateAffiliateCode() {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let code = 'cm';
  for (let i = 0; i < 6; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

export default function AffiliateDashboard() {
  const queryClient = useQueryClient();
  const [copiedLink, setCopiedLink] = useState(null);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: affiliate, isLoading } = useQuery({
    queryKey: ['myAffiliate', user?.email],
    queryFn: async () => {
      if (!user) return null;
      const affiliates = await base44.entities.Affiliate.filter({ user_email: user.email });
      return affiliates[0] || null;
    },
    enabled: !!user,
  });

  const { data: clicks } = useQuery({
    queryKey: ['affiliateClicks', affiliate?.id],
    queryFn: () => base44.entities.AffiliateClick.filter({ affiliate_id: affiliate.id }),
    enabled: !!affiliate?.id,
    initialData: [],
  });

  const { data: transactions } = useQuery({
    queryKey: ['affiliateTransactions', affiliate?.id],
    queryFn: () => base44.entities.Transaction.filter({ affiliate_id: affiliate.id }),
    enabled: !!affiliate?.id,
    initialData: [],
  });

  const createAffiliateMutation = useMutation({
    mutationFn: async () => {
      const code = generateAffiliateCode();
      return await base44.entities.Affiliate.create({
        user_email: user.email,
        code: code,
        commission_rate: 0.10,
        total_clicks: 0,
        total_sales: 0,
        total_commission: 0,
        status: 'active'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myAffiliate'] });
      toast.success("Affiliate fiók aktiválva!");
    },
  });

  const baseUrl = window.location.origin;
  const marketplaceLink = affiliate ? `${baseUrl}/?ref=${affiliate.code}` : '';
  const appDetailLink = (appId) => `${baseUrl}/p/AppDetail?id=${appId}&ref=${affiliate?.code}`;

  const copyToClipboard = (text, label) => {
    navigator.clipboard.writeText(text);
    setCopiedLink(label);
    toast.success("Link másolva!");
    setTimeout(() => setCopiedLink(null), 2000);
  };

  const totalCommission = transactions.reduce((sum, tx) => sum + (tx.affiliate_commission || 0), 0);
  const conversionRate = clicks.length > 0 ? ((transactions.length / clicks.length) * 100).toFixed(1) : 0;

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0A0E14] flex items-center justify-center">
        <Card className="border border-[#1a1f2e] bg-[#0f1419] p-8 text-center">
          <h2 className="text-2xl font-bold text-white mb-2">Jelentkezz be</h2>
          <p className="text-gray-400">Az affiliate programhoz belépés szükséges</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-black text-white mb-2">Affiliate Program</h1>
          <p className="text-gray-400">
            Keress passzív jövedelmet a marketplace promóciójával - 10% jutalék minden eladás után!
          </p>
        </div>

        {!affiliate ? (
          <Card className="border border-[#1a1f2e] bg-[#0f1419] p-8 max-w-2xl mx-auto text-center">
            <div className="mb-6">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-[#00E599] to-[#00B8D4] flex items-center justify-center">
                <TrendingUp className="w-8 h-8 text-black" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">Csatlakozz az Affiliate Programhoz</h2>
              <p className="text-gray-400">
                Kezdd el promózni a marketplace-t és keress 10% jutalékot minden sikeres eladásból.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-4 mb-8">
              <div className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                <DollarSign className="w-6 h-6 text-[#00E599] mx-auto mb-2" />
                <p className="text-sm font-semibold text-white">10% Jutalék</p>
                <p className="text-xs text-gray-400 mt-1">Minden eladás után</p>
              </div>
              <div className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                <RefreshCw className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                <p className="text-sm font-semibold text-white">30 napos cookie</p>
                <p className="text-xs text-gray-400 mt-1">Hosszú tracking idő</p>
              </div>
              <div className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                <Users className="w-6 h-6 text-purple-400 mx-auto mb-2" />
                <p className="text-sm font-semibold text-white">Valós idejű stat</p>
                <p className="text-xs text-gray-400 mt-1">Dashboard tracking</p>
              </div>
            </div>

            <Button
              onClick={() => createAffiliateMutation.mutate()}
              disabled={createAffiliateMutation.isPending}
              className="bg-gradient-to-r from-[#00E599] to-[#00B8D4] text-black font-bold px-8 py-6 text-lg"
            >
              {createAffiliateMutation.isPending ? 'Aktiválás...' : 'Aktiváld az Affiliate Fiókod'}
            </Button>
          </Card>
        ) : (
          <>
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <Card className="border border-[#1a1f2e] bg-[#0f1419] p-6">
                <div className="flex items-center justify-between mb-2">
                  <MousePointerClick className="w-6 h-6 text-blue-400" />
                  <Badge className="bg-blue-600/20 text-blue-400 border-0">Kattintások</Badge>
                </div>
                <p className="text-3xl font-black text-white">{clicks.length}</p>
                <p className="text-sm text-gray-400 mt-1">Összes kattintás</p>
              </Card>

              <Card className="border border-[#1a1f2e] bg-[#0f1419] p-6">
                <div className="flex items-center justify-between mb-2">
                  <TrendingUp className="w-6 h-6 text-purple-400" />
                  <Badge className="bg-purple-600/20 text-purple-400 border-0">Értékesítés</Badge>
                </div>
                <p className="text-3xl font-black text-white">{transactions.length}</p>
                <p className="text-sm text-gray-400 mt-1">Sikeres vásárlások</p>
              </Card>

              <Card className="border border-[#1a1f2e] bg-[#0f1419] p-6">
                <div className="flex items-center justify-between mb-2">
                  <DollarSign className="w-6 h-6 text-[#00E599]" />
                  <Badge className="bg-[#00E599]/20 text-[#00E599] border-0">Jutalék</Badge>
                </div>
                <p className="text-3xl font-black text-white">{totalCommission.toLocaleString()} Ft</p>
                <p className="text-sm text-gray-400 mt-1">Összes keresett</p>
              </Card>

              <Card className="border border-[#1a1f2e] bg-[#0f1419] p-6">
                <div className="flex items-center justify-between mb-2">
                  <Users className="w-6 h-6 text-yellow-400" />
                  <Badge className="bg-yellow-600/20 text-yellow-400 border-0">Konverzió</Badge>
                </div>
                <p className="text-3xl font-black text-white">{conversionRate}%</p>
                <p className="text-sm text-gray-400 mt-1">Konverziós arány</p>
              </Card>
            </div>

            {/* Affiliate Code & Links */}
            <Card className="border border-[#1a1f2e] bg-[#0f1419] p-6 mb-8">
              <div className="flex items-center gap-3 mb-6">
                <Link2 className="w-6 h-6 text-[#00E599]" />
                <div>
                  <h3 className="text-xl font-bold text-white">Affiliate Linkjeid</h3>
                  <p className="text-sm text-gray-400">Oszd meg ezeket a linkeket és keress minden eladás után!</p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <Label className="text-white text-sm mb-2 block">Affiliate kódod:</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      readOnly
                      value={affiliate.code}
                      className="bg-[#141923] border-[#1a1f2e] text-white font-mono text-lg"
                    />
                    <Badge className="bg-[#00E599]/20 text-[#00E599] border-0 px-4 py-2">
                      {Math.round(affiliate.commission_rate * 100)}% jutalék
                    </Badge>
                  </div>
                </div>

                <div>
                  <Label className="text-white text-sm mb-2 block">Főoldal affiliate link:</Label>
                  <div className="flex gap-2">
                    <Input
                      readOnly
                      value={marketplaceLink}
                      className="bg-[#141923] border-[#1a1f2e] text-white font-mono text-sm"
                    />
                    <Button
                      onClick={() => copyToClipboard(marketplaceLink, 'marketplace')}
                      className="bg-[#1a1f2e] hover:bg-[#252a3a]"
                    >
                      {copiedLink === 'marketplace' ? (
                        <Check className="w-4 h-4 text-[#00E599]" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                </div>

                <div className="p-4 rounded-lg bg-blue-600/10 border border-blue-600/30">
                  <p className="text-sm text-blue-200">
                    💡 <span className="font-semibold">Tipp:</span> Adj hozzá <code className="px-2 py-1 rounded bg-blue-900/30">?ref={affiliate.code}</code> bármely app detail oldalhoz!
                  </p>
                </div>
              </div>
            </Card>

            {/* Recent Transactions */}
            {transactions.length > 0 && (
              <Card className="border border-[#1a1f2e] bg-[#0f1419] p-6">
                <h3 className="text-xl font-bold text-white mb-4">Legutóbbi jutalékok</h3>
                <div className="space-y-3">
                  {transactions.slice(0, 5).map(tx => (
                    <div key={tx.id} className="flex items-center justify-between p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                      <div>
                        <p className="text-white font-semibold">{tx.buyer_email}</p>
                        <p className="text-xs text-gray-400">
                          {new Date(tx.created_date).toLocaleDateString('hu-HU', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric'
                          })}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-white font-bold">{tx.amount_paid.toLocaleString()} Ft</p>
                        <p className="text-sm text-[#00E599]">
                          +{(tx.affiliate_commission || 0).toLocaleString()} Ft jutalék
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </>
        )}
      </div>
    </div>
  );
}