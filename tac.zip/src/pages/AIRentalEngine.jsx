import React, { useState } from 'react';
import { Package, Key, Zap, DollarSign, Clock, Activity, CheckCircle2, AlertTriangle, Loader2, TrendingUp, Eye, Shield, Play, Settings, Users, Database } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export default function AIRentalEngine() {
  const [mode, setMode] = useState('client'); // 'admin' or 'client'
  const [backendUrl] = useState('http://localhost:9999');
  const [adminToken, setAdminToken] = useState('DEV_ADMIN_TOKEN_CHANGE_ME');
  const [clientApiKey, setClientApiKey] = useState('');
  
  // Admin states
  const [modules, setModules] = useState([]);
  const [clients, setClients] = useState([]);
  const [adminStats, setAdminStats] = useState(null);
  const [showCreateModule, setShowCreateModule] = useState(false);
  const [showCreateClient, setShowCreateClient] = useState(false);
  
  // Client states
  const [availableModules, setAvailableModules] = useState([]);
  const [myRentals, setMyRentals] = useState([]);
  const [selectedModule, setSelectedModule] = useState(null);
  const [selectedRental, setSelectedRental] = useState(null);
  const [executionPayload, setExecutionPayload] = useState('{}');
  const [executionResult, setExecutionResult] = useState(null);
  
  // Form states
  const [newModule, setNewModule] = useState({
    name: '',
    description: '',
    pricingModel: 'mixed',
    basePriceEur: 9.99,
    tier: 'BASIC',
    modes: ['time_rental', 'pay_per_use']
  });
  
  const [newClient, setNewClient] = useState({
    name: '',
    email: '',
    plan: 'free'
  });
  
  const [rentalForm, setRentalForm] = useState({
    mode: 'time_rental',
    durationMinutes: 60,
    prepaidCredits: 100
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const queryClient = useQueryClient();

  // Fetch AI rentals from database
  const { data: dbRentals = [] } = useQuery({
    queryKey: ['ai-rentals'],
    queryFn: async () => {
      const list = await base44.entities.AIRental.list('-created_date', 50);
      return list;
    },
    refetchInterval: 10000
  });

  // Save rental mutation
  const saveRentalMutation = useMutation({
    mutationFn: async (rentalData) => {
      return await base44.entities.AIRental.create(rentalData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ai-rentals'] });
    }
  });

  // Admin: Fetch modules
  const fetchAdminModules = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(`${backendUrl}/admin/modules`, {
        headers: { 'X-Admin-Token': adminToken }
      });
      if (!response.ok) throw new Error(`Admin error: ${response.status}`);
      const data = await response.json();
      setModules(data.modules || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Admin: Fetch clients
  const fetchAdminClients = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(`${backendUrl}/admin/clients`, {
        headers: { 'X-Admin-Token': adminToken }
      });
      if (!response.ok) throw new Error(`Admin error: ${response.status}`);
      const data = await response.json();
      setClients(data.clients || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Admin: Fetch overview
  const fetchAdminOverview = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(`${backendUrl}/admin/overview`, {
        headers: { 'X-Admin-Token': adminToken }
      });
      if (!response.ok) throw new Error(`Admin error: ${response.status}`);
      const data = await response.json();
      setAdminStats(data.stats);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Admin: Create module
  const createModule = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(`${backendUrl}/admin/modules`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Admin-Token': adminToken
        },
        body: JSON.stringify(newModule)
      });
      if (!response.ok) throw new Error(`Create error: ${response.status}`);
      await fetchAdminModules();
      setShowCreateModule(false);
      setNewModule({
        name: '',
        description: '',
        pricingModel: 'mixed',
        basePriceEur: 9.99,
        tier: 'BASIC',
        modes: ['time_rental', 'pay_per_use']
      });
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Admin: Create client
  const createClient = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(`${backendUrl}/admin/clients`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Admin-Token': adminToken
        },
        body: JSON.stringify(newClient)
      });
      if (!response.ok) throw new Error(`Create error: ${response.status}`);
      const data = await response.json();
      await fetchAdminClients();
      setShowCreateClient(false);
      setNewClient({ name: '', email: '', plan: 'free' });
      
      // Show API key
      alert(`Client created!\nAPI Key: ${data.client.apiKey}\n\nSave this key securely.`);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Client: Fetch available modules
  const fetchClientModules = async () => {
    if (!clientApiKey) {
      setError('Please enter your API key');
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(`${backendUrl}/api/modules`, {
        headers: { 'X-API-Key': clientApiKey }
      });
      if (!response.ok) throw new Error(`Auth error: ${response.status}`);
      const data = await response.json();
      setAvailableModules(data.modules || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Client: Fetch my rentals
  const fetchMyRentals = async () => {
    if (!clientApiKey) return;
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(`${backendUrl}/api/rentals`, {
        headers: { 'X-API-Key': clientApiKey }
      });
      if (!response.ok) throw new Error(`Auth error: ${response.status}`);
      const data = await response.json();
      setMyRentals(data.rentals || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Client: Create rental
  const createRental = async () => {
    if (!selectedModule) return;
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(`${backendUrl}/api/rentals`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-API-Key': clientApiKey
        },
        body: JSON.stringify({
          moduleId: selectedModule.id,
          ...rentalForm
        })
      });
      if (!response.ok) throw new Error(`Rental error: ${response.status}`);
      const data = await response.json();
      
      // Save to database
      await saveRentalMutation.mutateAsync({
        rentalId: data.rental.id,
        moduleId: data.rental.moduleId,
        moduleName: data.rental.moduleName,
        clientId: data.rental.clientId,
        clientName: data.rental.clientName,
        mode: data.rental.mode,
        durationMinutes: rentalForm.mode === 'time_rental' ? rentalForm.durationMinutes : null,
        credits: rentalForm.mode === 'pay_per_use' ? rentalForm.prepaidCredits : null,
        expiresAt: data.rental.expiresAt,
        estimatedPriceEur: data.rental.estimatedPriceEur,
        active: true,
        status: 'active',
        apiKey: clientApiKey,
        usageCount: 0,
        totalChargeEur: 0,
        executionLogs: []
      });
      
      await fetchMyRentals();
      setSelectedModule(null);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Client: Execute module
  const executeModule = async () => {
    if (!selectedRental) return;
    setIsLoading(true);
    setError(null);
    setExecutionResult(null);
    try {
      const payload = JSON.parse(executionPayload);
      const response = await fetch(`${backendUrl}/api/execute`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-API-Key': clientApiKey
        },
        body: JSON.stringify({
          moduleId: selectedRental.moduleId,
          rentalId: selectedRental.id,
          payload
        })
      });
      if (!response.ok) throw new Error(`Execution error: ${response.status}`);
      const data = await response.json();
      setExecutionResult(data);
      await fetchMyRentals();
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const getModeColor = (mode) => {
    return mode === 'time_rental' ? '#24e4ff' : '#a855f7';
  };

  const getTierColor = (tier) => {
    switch (tier) {
      case 'BASIC': return '#4eff8b';
      case 'PRO': return '#24e4ff';
      case 'EXCLUSIVE': return '#ff6ec7';
      default: return '#8c8faf';
    }
  };

  return (
    <div className="min-h-screen p-4" style={{
      background: 'radial-gradient(circle at top, #0a0a14 0, #030306 55%)'
    }}>
      <style>{`
        .rental-card {
          transition: all 0.3s ease-out;
        }
        
        .rental-card:hover {
          transform: translateY(-2px);
        }
      `}</style>

      <div className="max-w-[1600px] mx-auto">
        {/* Header */}
        <div className="mb-6 text-center">
          <div className="flex items-center justify-center gap-3 mb-2">
            <DollarSign className="w-10 h-10 text-green-400" />
            <h1 className="text-3xl md:text-4xl font-black tracking-wider uppercase text-white">
              AI RENTAL & LICENSING ENGINE
            </h1>
            <Key className="w-10 h-10 text-purple-400" />
          </div>
          <p className="text-sm text-gray-400 tracking-wide">
            Time-Based & Credit-Based AI Module Rental System
          </p>
        </div>

        {/* Mode Toggle */}
        <div className="mb-6 flex items-center justify-center gap-3">
          <button
            onClick={() => setMode('admin')}
            className="px-6 py-3 rounded-xl text-sm font-bold tracking-wider uppercase flex items-center gap-2 transition-all"
            style={{
              background: mode === 'admin' ? 'rgba(255, 75, 129, 0.3)' : 'rgba(0, 0, 0, 0.3)',
              border: `1px solid ${mode === 'admin' ? 'rgba(255, 75, 129, 0.6)' : 'rgba(255, 255, 255, 0.1)'}`,
              color: mode === 'admin' ? '#ff4b81' : '#8c8faf'
            }}
          >
            <Shield className="w-5 h-5" />
            ADMIN MODE
          </button>
          <button
            onClick={() => setMode('client')}
            className="px-6 py-3 rounded-xl text-sm font-bold tracking-wider uppercase flex items-center gap-2 transition-all"
            style={{
              background: mode === 'client' ? 'rgba(36, 228, 255, 0.3)' : 'rgba(0, 0, 0, 0.3)',
              border: `1px solid ${mode === 'client' ? 'rgba(36, 228, 255, 0.6)' : 'rgba(255, 255, 255, 0.1)'}`,
              color: mode === 'client' ? '#24e4ff' : '#8c8faf'
            }}
          >
            <Users className="w-5 h-5" />
            CLIENT MODE
          </button>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 rounded-xl border border-red-500/50 bg-red-900/20 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Error</div>
              <div className="text-xs text-gray-300 mt-1">{error}</div>
            </div>
          </div>
        )}

        {/* ADMIN MODE */}
        {mode === 'admin' && (
          <div className="space-y-6">
            {/* Admin Token Input */}
            <div className="rounded-2xl border p-5" style={{
              borderColor: 'rgba(255, 75, 129, 0.4)',
              background: 'rgba(7, 7, 18, 0.95)'
            }}>
              <div className="flex items-center justify-between mb-4">
                <div className="text-xs font-bold text-red-400">ADMIN TOKEN</div>
                <Shield className="w-5 h-5 text-red-400" />
              </div>
              <input
                type="password"
                value={adminToken}
                onChange={(e) => setAdminToken(e.target.value)}
                className="w-full rounded-xl border px-4 py-2 text-sm mb-4"
                style={{
                  borderColor: 'rgba(255, 75, 129, 0.3)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#f6fff6'
                }}
                placeholder="Enter admin token..."
              />
              <div className="flex gap-3">
                <button
                  onClick={fetchAdminOverview}
                  disabled={isLoading}
                  className="px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 transition-all disabled:opacity-40"
                  style={{
                    background: 'rgba(255, 75, 129, 0.2)',
                    border: '1px solid rgba(255, 75, 129, 0.4)',
                    color: '#fff'
                  }}
                >
                  <TrendingUp className="w-4 h-4" />
                  Overview
                </button>
                <button
                  onClick={fetchAdminModules}
                  disabled={isLoading}
                  className="px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 transition-all disabled:opacity-40"
                  style={{
                    background: 'rgba(168, 85, 247, 0.2)',
                    border: '1px solid rgba(168, 85, 247, 0.4)',
                    color: '#fff'
                  }}
                >
                  <Package className="w-4 h-4" />
                  Modules
                </button>
                <button
                  onClick={fetchAdminClients}
                  disabled={isLoading}
                  className="px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 transition-all disabled:opacity-40"
                  style={{
                    background: 'rgba(36, 228, 255, 0.2)',
                    border: '1px solid rgba(36, 228, 255, 0.4)',
                    color: '#fff'
                  }}
                >
                  <Users className="w-4 h-4" />
                  Clients
                </button>
              </div>
            </div>

            {/* Admin Stats */}
            {adminStats && (
              <div className="rounded-2xl border p-5" style={{
                borderColor: 'rgba(78, 255, 139, 0.4)',
                background: 'rgba(7, 7, 18, 0.95)'
              }}>
                <div className="text-xs font-bold text-green-400 mb-4">PLATFORM OVERVIEW</div>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                  <div className="p-3 rounded-xl text-center" style={{
                    background: 'rgba(168, 85, 247, 0.1)',
                    border: '1px solid rgba(168, 85, 247, 0.3)'
                  }}>
                    <div className="text-xs text-gray-400 mb-1">Modules</div>
                    <div className="text-2xl font-bold text-purple-400">{adminStats.moduleCount}</div>
                  </div>
                  <div className="p-3 rounded-xl text-center" style={{
                    background: 'rgba(36, 228, 255, 0.1)',
                    border: '1px solid rgba(36, 228, 255, 0.3)'
                  }}>
                    <div className="text-xs text-gray-400 mb-1">Clients</div>
                    <div className="text-2xl font-bold text-cyan-400">{adminStats.clientCount}</div>
                  </div>
                  <div className="p-3 rounded-xl text-center" style={{
                    background: 'rgba(255, 219, 124, 0.1)',
                    border: '1px solid rgba(255, 219, 124, 0.3)'
                  }}>
                    <div className="text-xs text-gray-400 mb-1">Rentals</div>
                    <div className="text-2xl font-bold text-yellow-400">{adminStats.rentalCount}</div>
                  </div>
                  <div className="p-3 rounded-xl text-center" style={{
                    background: 'rgba(255, 110, 199, 0.1)',
                    border: '1px solid rgba(255, 110, 199, 0.3)'
                  }}>
                    <div className="text-xs text-gray-400 mb-1">Usage</div>
                    <div className="text-2xl font-bold text-pink-400">{adminStats.totalUsage}</div>
                  </div>
                  <div className="p-3 rounded-xl text-center" style={{
                    background: 'rgba(78, 255, 139, 0.1)',
                    border: '1px solid rgba(78, 255, 139, 0.3)'
                  }}>
                    <div className="text-xs text-gray-400 mb-1">Revenue</div>
                    <div className="text-xl font-bold text-green-400">€{adminStats.estimatedRevenueEur}</div>
                  </div>
                </div>
              </div>
            )}

            {/* Modules Management */}
            {modules.length > 0 && (
              <div className="rounded-2xl border p-5" style={{
                borderColor: 'rgba(168, 85, 247, 0.4)',
                background: 'rgba(7, 7, 18, 0.95)'
              }}>
                <div className="flex items-center justify-between mb-4">
                  <div className="text-xs font-bold text-purple-400">AI MODULES ({modules.length})</div>
                  <button
                    onClick={() => setShowCreateModule(!showCreateModule)}
                    className="px-3 py-1 rounded-lg text-xs font-semibold"
                    style={{
                      background: 'rgba(168, 85, 247, 0.2)',
                      border: '1px solid rgba(168, 85, 247, 0.4)',
                      color: '#a855f7'
                    }}
                  >
                    + Create Module
                  </button>
                </div>

                {showCreateModule && (
                  <div className="mb-4 p-4 rounded-xl" style={{
                    background: 'rgba(0, 0, 0, 0.4)',
                    border: '1px solid rgba(168, 85, 247, 0.3)'
                  }}>
                    <div className="grid grid-cols-2 gap-3 mb-3">
                      <input
                        type="text"
                        value={newModule.name}
                        onChange={(e) => setNewModule({...newModule, name: e.target.value})}
                        placeholder="Module name"
                        className="w-full rounded-lg border px-3 py-2 text-sm"
                        style={{
                          borderColor: 'rgba(168, 85, 247, 0.3)',
                          background: 'rgba(2, 0, 12, 0.9)',
                          color: '#f6fff6'
                        }}
                      />
                      <input
                        type="number"
                        value={newModule.basePriceEur}
                        onChange={(e) => setNewModule({...newModule, basePriceEur: parseFloat(e.target.value)})}
                        placeholder="Base price (EUR)"
                        className="w-full rounded-lg border px-3 py-2 text-sm"
                        style={{
                          borderColor: 'rgba(168, 85, 247, 0.3)',
                          background: 'rgba(2, 0, 12, 0.9)',
                          color: '#f6fff6'
                        }}
                      />
                    </div>
                    <textarea
                      value={newModule.description}
                      onChange={(e) => setNewModule({...newModule, description: e.target.value})}
                      placeholder="Description"
                      rows={2}
                      className="w-full rounded-lg border px-3 py-2 text-sm resize-none mb-3"
                      style={{
                        borderColor: 'rgba(168, 85, 247, 0.3)',
                        background: 'rgba(2, 0, 12, 0.9)',
                        color: '#f6fff6'
                      }}
                    />
                    <button
                      onClick={createModule}
                      disabled={isLoading}
                      className="w-full px-4 py-2 rounded-lg text-sm font-bold flex items-center justify-center gap-2 disabled:opacity-40"
                      style={{
                        background: 'linear-gradient(135deg, #a855f7, #ff6ec7)',
                        color: '#fff'
                      }}
                    >
                      {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Package className="w-4 h-4" />}
                      Create Module
                    </button>
                  </div>
                )}

                <div className="space-y-2">
                  {modules.map((mod) => (
                    <div key={mod.id} className="rental-card p-3 rounded-xl" style={{
                      background: 'rgba(0, 0, 0, 0.3)',
                      border: '1px solid rgba(168, 85, 247, 0.3)'
                    }}>
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-sm font-bold text-white">{mod.name}</div>
                          <div className="text-xs text-gray-400">{mod.description}</div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="text-xs px-2 py-1 rounded-full" style={{
                            background: `${getTierColor(mod.tier)}20`,
                            color: getTierColor(mod.tier)
                          }}>
                            {mod.tier}
                          </div>
                          <div className="text-sm font-bold text-green-400">€{mod.basePriceEur}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Clients Management */}
            {clients.length > 0 && (
              <div className="rounded-2xl border p-5" style={{
                borderColor: 'rgba(36, 228, 255, 0.4)',
                background: 'rgba(7, 7, 18, 0.95)'
              }}>
                <div className="flex items-center justify-between mb-4">
                  <div className="text-xs font-bold text-cyan-400">CLIENTS ({clients.length})</div>
                  <button
                    onClick={() => setShowCreateClient(!showCreateClient)}
                    className="px-3 py-1 rounded-lg text-xs font-semibold"
                    style={{
                      background: 'rgba(36, 228, 255, 0.2)',
                      border: '1px solid rgba(36, 228, 255, 0.4)',
                      color: '#24e4ff'
                    }}
                  >
                    + Create Client
                  </button>
                </div>

                {showCreateClient && (
                  <div className="mb-4 p-4 rounded-xl" style={{
                    background: 'rgba(0, 0, 0, 0.4)',
                    border: '1px solid rgba(36, 228, 255, 0.3)'
                  }}>
                    <div className="grid grid-cols-2 gap-3 mb-3">
                      <input
                        type="text"
                        value={newClient.name}
                        onChange={(e) => setNewClient({...newClient, name: e.target.value})}
                        placeholder="Client name"
                        className="w-full rounded-lg border px-3 py-2 text-sm"
                        style={{
                          borderColor: 'rgba(36, 228, 255, 0.3)',
                          background: 'rgba(2, 0, 12, 0.9)',
                          color: '#f6fff6'
                        }}
                      />
                      <input
                        type="email"
                        value={newClient.email}
                        onChange={(e) => setNewClient({...newClient, email: e.target.value})}
                        placeholder="Email"
                        className="w-full rounded-lg border px-3 py-2 text-sm"
                        style={{
                          borderColor: 'rgba(36, 228, 255, 0.3)',
                          background: 'rgba(2, 0, 12, 0.9)',
                          color: '#f6fff6'
                        }}
                      />
                    </div>
                    <button
                      onClick={createClient}
                      disabled={isLoading}
                      className="w-full px-4 py-2 rounded-lg text-sm font-bold flex items-center justify-center gap-2 disabled:opacity-40"
                      style={{
                        background: 'linear-gradient(135deg, #24e4ff, #4eff8b)',
                        color: '#000'
                      }}
                    >
                      {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Users className="w-4 h-4" />}
                      Create Client
                    </button>
                  </div>
                )}

                <div className="space-y-2">
                  {clients.map((cli) => (
                    <div key={cli.id} className="rental-card p-3 rounded-xl" style={{
                      background: 'rgba(0, 0, 0, 0.3)',
                      border: '1px solid rgba(36, 228, 255, 0.3)'
                    }}>
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-sm font-bold text-white">{cli.name}</div>
                          <div className="text-xs text-gray-400">{cli.email}</div>
                        </div>
                        <div className="text-xs px-2 py-1 rounded-full" style={{
                          background: 'rgba(78, 255, 139, 0.2)',
                          color: '#4eff8b'
                        }}>
                          {cli.plan}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Database Rentals */}
            {dbRentals.length > 0 && (
              <div className="rounded-2xl border p-5" style={{
                borderColor: 'rgba(255, 219, 124, 0.4)',
                background: 'rgba(7, 7, 18, 0.95)'
              }}>
                <div className="text-xs font-bold text-yellow-400 mb-4">DATABASE RENTALS ({dbRentals.length})</div>
                <div className="space-y-2">
                  {dbRentals.slice(0, 10).map((rental) => (
                    <div key={rental.id} className="rental-card p-3 rounded-xl" style={{
                      background: 'rgba(0, 0, 0, 0.3)',
                      border: `1px solid ${getModeColor(rental.mode)}40`
                    }}>
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-sm font-bold text-white">{rental.moduleName}</div>
                          <div className="text-xs text-gray-400">{rental.clientName}</div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="text-xs px-2 py-1 rounded-full" style={{
                            background: `${getModeColor(rental.mode)}20`,
                            color: getModeColor(rental.mode)
                          }}>
                            {rental.mode}
                          </div>
                          <div className="text-xs text-green-400">€{rental.estimatedPriceEur}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* CLIENT MODE */}
        {mode === 'client' && (
          <div className="space-y-6">
            {/* API Key Input */}
            <div className="rounded-2xl border p-5" style={{
              borderColor: 'rgba(36, 228, 255, 0.4)',
              background: 'rgba(7, 7, 18, 0.95)'
            }}>
              <div className="flex items-center justify-between mb-4">
                <div className="text-xs font-bold text-cyan-400">CLIENT API KEY</div>
                <Key className="w-5 h-5 text-cyan-400" />
              </div>
              <input
                type="password"
                value={clientApiKey}
                onChange={(e) => setClientApiKey(e.target.value)}
                className="w-full rounded-xl border px-4 py-2 text-sm mb-4"
                style={{
                  borderColor: 'rgba(36, 228, 255, 0.3)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#f6fff6'
                }}
                placeholder="Enter your API key..."
              />
              <div className="flex gap-3">
                <button
                  onClick={fetchClientModules}
                  disabled={isLoading || !clientApiKey}
                  className="px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 transition-all disabled:opacity-40"
                  style={{
                    background: 'rgba(36, 228, 255, 0.2)',
                    border: '1px solid rgba(36, 228, 255, 0.4)',
                    color: '#fff'
                  }}
                >
                  <Package className="w-4 h-4" />
                  Browse Modules
                </button>
                <button
                  onClick={fetchMyRentals}
                  disabled={isLoading || !clientApiKey}
                  className="px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 transition-all disabled:opacity-40"
                  style={{
                    background: 'rgba(168, 85, 247, 0.2)',
                    border: '1px solid rgba(168, 85, 247, 0.4)',
                    color: '#fff'
                  }}
                >
                  <Activity className="w-4 h-4" />
                  My Rentals
                </button>
              </div>
            </div>

            {/* Available Modules */}
            {availableModules.length > 0 && (
              <div className="rounded-2xl border p-5" style={{
                borderColor: 'rgba(168, 85, 247, 0.4)',
                background: 'rgba(7, 7, 18, 0.95)'
              }}>
                <div className="text-xs font-bold text-purple-400 mb-4">AVAILABLE MODULES ({availableModules.length})</div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {availableModules.map((mod) => (
                    <div 
                      key={mod.id}
                      onClick={() => setSelectedModule(mod)}
                      className="rental-card p-4 rounded-xl cursor-pointer"
                      style={{
                        background: selectedModule?.id === mod.id ? 'rgba(168, 85, 247, 0.2)' : 'rgba(0, 0, 0, 0.3)',
                        border: `1px solid ${selectedModule?.id === mod.id ? 'rgba(168, 85, 247, 0.6)' : 'rgba(255, 255, 255, 0.1)'}`
                      }}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="text-sm font-bold text-white">{mod.name}</div>
                        <div className="text-xs px-2 py-1 rounded-full" style={{
                          background: `${getTierColor(mod.tier)}20`,
                          color: getTierColor(mod.tier)
                        }}>
                          {mod.tier}
                        </div>
                      </div>
                      <div className="text-xs text-gray-400 mb-3">{mod.description}</div>
                      <div className="flex items-center justify-between">
                        <div className="flex gap-2">
                          {mod.modes.includes('time_rental') && (
                            <div className="text-[10px] px-2 py-0.5 rounded-full" style={{
                              background: 'rgba(36, 228, 255, 0.2)',
                              color: '#24e4ff'
                            }}>
                              TIME
                            </div>
                          )}
                          {mod.modes.includes('pay_per_use') && (
                            <div className="text-[10px] px-2 py-0.5 rounded-full" style={{
                              background: 'rgba(168, 85, 247, 0.2)',
                              color: '#a855f7'
                            }}>
                              CREDITS
                            </div>
                          )}
                        </div>
                        <div className="text-sm font-bold text-green-400">€{mod.basePriceEur}</div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Rental Form */}
                {selectedModule && (
                  <div className="mt-4 p-4 rounded-xl" style={{
                    background: 'rgba(168, 85, 247, 0.1)',
                    border: '1px solid rgba(168, 85, 247, 0.3)'
                  }}>
                    <div className="text-sm font-bold text-purple-400 mb-3">RENT: {selectedModule.name}</div>
                    
                    <div className="mb-3">
                      <label className="text-xs text-gray-400 mb-2 block">Rental Mode:</label>
                      <div className="flex gap-2">
                        {selectedModule.modes.includes('time_rental') && (
                          <button
                            onClick={() => setRentalForm({...rentalForm, mode: 'time_rental'})}
                            className="flex-1 px-4 py-2 rounded-lg text-sm font-semibold"
                            style={{
                              background: rentalForm.mode === 'time_rental' ? 'rgba(36, 228, 255, 0.3)' : 'rgba(0, 0, 0, 0.3)',
                              border: `1px solid ${rentalForm.mode === 'time_rental' ? 'rgba(36, 228, 255, 0.6)' : 'rgba(255, 255, 255, 0.1)'}`,
                              color: rentalForm.mode === 'time_rental' ? '#24e4ff' : '#8c8faf'
                            }}
                          >
                            Time Rental
                          </button>
                        )}
                        {selectedModule.modes.includes('pay_per_use') && (
                          <button
                            onClick={() => setRentalForm({...rentalForm, mode: 'pay_per_use'})}
                            className="flex-1 px-4 py-2 rounded-lg text-sm font-semibold"
                            style={{
                              background: rentalForm.mode === 'pay_per_use' ? 'rgba(168, 85, 247, 0.3)' : 'rgba(0, 0, 0, 0.3)',
                              border: `1px solid ${rentalForm.mode === 'pay_per_use' ? 'rgba(168, 85, 247, 0.6)' : 'rgba(255, 255, 255, 0.1)'}`,
                              color: rentalForm.mode === 'pay_per_use' ? '#a855f7' : '#8c8faf'
                            }}
                          >
                            Pay Per Use
                          </button>
                        )}
                      </div>
                    </div>

                    {rentalForm.mode === 'time_rental' && (
                      <div className="mb-3">
                        <label className="text-xs text-gray-400 mb-2 block">Duration (minutes):</label>
                        <input
                          type="number"
                          value={rentalForm.durationMinutes}
                          onChange={(e) => setRentalForm({...rentalForm, durationMinutes: parseInt(e.target.value)})}
                          className="w-full rounded-lg border px-3 py-2 text-sm"
                          style={{
                            borderColor: 'rgba(36, 228, 255, 0.3)',
                            background: 'rgba(2, 0, 12, 0.9)',
                            color: '#f6fff6'
                          }}
                        />
                      </div>
                    )}

                    {rentalForm.mode === 'pay_per_use' && (
                      <div className="mb-3">
                        <label className="text-xs text-gray-400 mb-2 block">Prepaid Credits:</label>
                        <input
                          type="number"
                          value={rentalForm.prepaidCredits}
                          onChange={(e) => setRentalForm({...rentalForm, prepaidCredits: parseInt(e.target.value)})}
                          className="w-full rounded-lg border px-3 py-2 text-sm"
                          style={{
                            borderColor: 'rgba(168, 85, 247, 0.3)',
                            background: 'rgba(2, 0, 12, 0.9)',
                            color: '#f6fff6'
                          }}
                        />
                      </div>
                    )}

                    <button
                      onClick={createRental}
                      disabled={isLoading}
                      className="w-full px-4 py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-2 disabled:opacity-40"
                      style={{
                        background: 'linear-gradient(135deg, #24e4ff, #a855f7)',
                        color: '#000'
                      }}
                    >
                      {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Zap className="w-5 h-5" />}
                      CREATE RENTAL
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* My Rentals */}
            {myRentals.length > 0 && (
              <div className="rounded-2xl border p-5" style={{
                borderColor: 'rgba(255, 219, 124, 0.4)',
                background: 'rgba(7, 7, 18, 0.95)'
              }}>
                <div className="text-xs font-bold text-yellow-400 mb-4">MY ACTIVE RENTALS ({myRentals.length})</div>
                <div className="space-y-3">
                  {myRentals.map((rental) => (
                    <div 
                      key={rental.id}
                      onClick={() => setSelectedRental(rental)}
                      className="rental-card p-4 rounded-xl cursor-pointer"
                      style={{
                        background: selectedRental?.id === rental.id ? 'rgba(255, 219, 124, 0.2)' : 'rgba(0, 0, 0, 0.3)',
                        border: `1px solid ${selectedRental?.id === rental.id ? 'rgba(255, 219, 124, 0.6)' : getModeColor(rental.mode)}40`
                      }}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-sm font-bold text-white">{rental.moduleName}</div>
                        <div className="flex items-center gap-2">
                          <div className="text-xs px-2 py-1 rounded-full" style={{
                            background: `${getModeColor(rental.mode)}20`,
                            color: getModeColor(rental.mode)
                          }}>
                            {rental.mode}
                          </div>
                          {rental.active && (
                            <div className="w-2 h-2 rounded-full bg-green-400" style={{
                              boxShadow: '0 0 8px rgba(78, 255, 139, 0.9)'
                            }} />
                          )}
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-2 text-xs">
                        {rental.mode === 'time_rental' && rental.expiresAt && (
                          <div>
                            <div className="text-gray-500">Expires:</div>
                            <div className="text-cyan-400">{new Date(rental.expiresAt).toLocaleTimeString()}</div>
                          </div>
                        )}
                        {rental.mode === 'pay_per_use' && (
                          <div>
                            <div className="text-gray-500">Credits:</div>
                            <div className="text-purple-400">{rental.credits}</div>
                          </div>
                        )}
                        <div>
                          <div className="text-gray-500">Price:</div>
                          <div className="text-green-400">€{rental.estimatedPriceEur}</div>
                        </div>
                        <div>
                          <div className="text-gray-500">Status:</div>
                          <div className={rental.active ? 'text-green-400' : 'text-red-400'}>
                            {rental.active ? 'Active' : 'Inactive'}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Execution Panel */}
                {selectedRental && (
                  <div className="mt-4 p-4 rounded-xl" style={{
                    background: 'rgba(255, 219, 124, 0.1)',
                    border: '1px solid rgba(255, 219, 124, 0.3)'
                  }}>
                    <div className="text-sm font-bold text-yellow-400 mb-3 flex items-center gap-2">
                      <Play className="w-4 h-4" />
                      EXECUTE: {selectedRental.moduleName}
                    </div>
                    
                    <textarea
                      value={executionPayload}
                      onChange={(e) => setExecutionPayload(e.target.value)}
                      rows={4}
                      placeholder='{"key": "value"}'
                      className="w-full rounded-lg border px-3 py-2 text-xs font-mono resize-none mb-3"
                      style={{
                        borderColor: 'rgba(255, 219, 124, 0.3)',
                        background: 'rgba(2, 0, 12, 0.9)',
                        color: '#f6fff6'
                      }}
                    />

                    <button
                      onClick={executeModule}
                      disabled={isLoading || !selectedRental.active}
                      className="w-full px-4 py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-2 disabled:opacity-40"
                      style={{
                        background: 'linear-gradient(135deg, #ffdb7c, #ff6ec7)',
                        color: '#000'
                      }}
                    >
                      {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Play className="w-5 h-5" />}
                      EXECUTE MODULE
                    </button>

                    {executionResult && (
                      <div className="mt-3 p-3 rounded-lg" style={{
                        background: 'rgba(0, 0, 0, 0.4)'
                      }}>
                        <div className="text-xs font-bold text-green-400 mb-2">RESULT:</div>
                        <pre className="text-[10px] text-gray-300 font-mono whitespace-pre-wrap">
                          {JSON.stringify(executionResult.result, null, 2)}
                        </pre>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}