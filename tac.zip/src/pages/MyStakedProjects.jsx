import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Lock, Code2, DollarSign } from "lucide-react";
import StakePanel from "../components/StakePanel";
import EngagementInbox from "../components/EngagementInbox";

const STAKE_API = import.meta.env.VITE_STAKE_BACKEND_URL || "http://localhost:3005";

const STAKE_TIER_CONFIG = {
  S0: { label: "Rejected", color: "text-red-400", bg: "bg-red-600/20" },
  S1: { label: "Acceptable", color: "text-gray-400", bg: "bg-gray-600/20" },
  S2: { label: "Good", color: "text-blue-400", bg: "bg-blue-600/20" },
  S3: { label: "High-Value", color: "text-cyan-400", bg: "bg-cyan-600/20" },
  S4: { label: "Enterprise-Ready", color: "text-purple-400", bg: "bg-purple-600/20" },
  S5: { label: "Godlike-Enterprise", color: "text-yellow-400", bg: "bg-yellow-600/20" }
};

export default function MyStakedProjects() {
  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: projects = [], isLoading } = useQuery({
    queryKey: ['stakedProjects', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      const res = await fetch(`${STAKE_API}/api/stake/user/${user.email}`);
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!user?.email,
    refetchInterval: 30000,
  });

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-black text-white mb-2">My Staked Projects</h1>
          <p className="text-gray-400">Manage your enterprise pool listings and engagement requests</p>
        </div>

        <div className="grid lg:grid-cols-[1.2fr_1fr] gap-8">
          {/* Left: Staked Projects */}
          <div className="space-y-6">
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <div className="flex items-center gap-3 mb-4">
                <Lock className="w-6 h-6 text-indigo-400" />
                <h2 className="text-xl font-black text-white">Staked Projects</h2>
              </div>

              {isLoading ? (
                <div className="text-center py-8">
                  <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto" />
                </div>
              ) : projects.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Lock className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p className="text-sm">No staked projects yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {projects.map((project) => {
                    const tierCfg = STAKE_TIER_CONFIG[project.stakeTier] || STAKE_TIER_CONFIG.S1;
                    
                    return (
                      <div key={project.id} className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <h3 className="font-bold text-white mb-1">{project.title}</h3>
                            <div className="flex items-center gap-2">
                              <Code2 className="w-3 h-3 text-gray-400" />
                              <span className="text-xs text-gray-400">
                                {project.language} • {project.linesOfCode} LOC
                              </span>
                            </div>
                          </div>
                          <Badge className={`${tierCfg.bg} ${tierCfg.color} border-[#1a1f2e]`}>
                            {project.stakeTier}
                          </Badge>
                        </div>

                        <div className="grid grid-cols-2 gap-2 mb-2 text-xs">
                          <div className="p-2 rounded bg-[#0a0a0f] border border-[#1a1f2e] text-center">
                            <div className="font-bold text-white">{project.stakeScore}/100</div>
                            <div className="text-gray-500">Stake Score</div>
                          </div>
                          <div className="p-2 rounded bg-[#0a0a0f] border border-[#1a1f2e] text-center">
                            <div className="font-bold text-indigo-400">{project.enterpriseFitScore}/100</div>
                            <div className="text-gray-500">Enterprise Fit</div>
                          </div>
                        </div>

                        <div className="p-2 rounded bg-gradient-to-br from-green-600/10 to-emerald-600/10 border border-green-600/30">
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-gray-400">Suggested Budget</span>
                            <span className="text-sm font-bold text-green-400">
                              €{project.suggestedBudgetEUR?.toLocaleString()}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </Card>
          </div>

          {/* Right: Engagement Inbox */}
          <div>
            <EngagementInbox devId={user?.email} />
          </div>
        </div>
      </div>
    </div>
  );
}