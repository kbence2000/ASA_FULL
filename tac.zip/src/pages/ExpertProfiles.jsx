import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Search, Mail, ExternalLink, Award, Briefcase } from "lucide-react";
import RankBadge from "../components/RankBadge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const experienceLevels = {
  junior: "Junior",
  mid: "Mid-Level",
  senior: "Senior",
  lead: "Lead"
};

const experienceColors = {
  junior: "bg-blue-600/20 text-blue-300 border-blue-600/30",
  mid: "bg-purple-600/20 text-purple-300 border-purple-600/30",
  senior: "bg-amber-600/20 text-amber-300 border-amber-600/30",
  lead: "bg-red-600/20 text-red-300 border-red-600/30"
};

const BACKEND_URL = import.meta.env.VITE_MDC_BACKEND_URL || "http://localhost:3000";

export default function ExpertProfiles() {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: profiles, isLoading } = useQuery({
    queryKey: ['expertProfiles'],
    queryFn: () => base44.entities.ExpertProfile.list('-created_date'),
    initialData: [],
  });

  // Fetch demigod data for experts
  const { data: demigodProfiles } = useQuery({
    queryKey: ['allDemigodProfiles'],
    queryFn: async () => {
      try {
        const res = await fetch(`${BACKEND_URL}/api/search`);
        if (!res.ok) return [];
        const data = await res.json();
        return data.result || [];
      } catch {
        return [];
      }
    },
    initialData: [],
  });

  // Create a map of email -> demigod profile
  const demigodMap = {};
  demigodProfiles.forEach(profile => {
    if (profile.github?.username) {
      // Assuming expert email might contain github username
      demigodMap[profile.github.username.toLowerCase()] = profile;
    }
  });

  const filteredProfiles = profiles.filter(profile => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      profile.headline?.toLowerCase().includes(query) ||
      profile.bio?.toLowerCase().includes(query) ||
      profile.user_email?.toLowerCase().includes(query) ||
      profile.skills?.some(skill => skill.toLowerCase().includes(query))
    );
  });

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-black text-white mb-4">Expert Profiles</h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Browse verified experts, check their AI rankings, and hire the best talent.
          </p>
        </div>

        {/* Search */}
        <div className="mb-8">
          <div className="relative max-w-2xl mx-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder="Search by skills, headline, or name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-[#0f1419] border-[#1a1f2e] text-white"
            />
          </div>
        </div>

        {/* Loading */}
        {isLoading && (
          <div className="text-center py-20">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-[#00E599] border-t-transparent"></div>
            <p className="text-gray-400 mt-4">Loading experts...</p>
          </div>
        )}

        {/* No Results */}
        {!isLoading && filteredProfiles.length === 0 && (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-2xl font-bold text-white mb-2">No experts found</h3>
            <p className="text-gray-400">Try a different search term</p>
          </div>
        )}

        {/* Expert Grid */}
        {!isLoading && filteredProfiles.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProfiles.map(profile => {
              // Try to find matching demigod profile
              const emailUsername = profile.user_email?.split('@')[0].toLowerCase();
              const demigodProfile = demigodMap[emailUsername] || null;

              return (
                <Card 
                  key={profile.id} 
                  className="border-[#1a1f2e] bg-[#0f1419] p-6 hover:border-[#262637] transition-all"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#00E599] to-[#00B8D4] flex items-center justify-center text-black font-bold text-lg">
                        {profile.headline?.charAt(0).toUpperCase() || 'E'}
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-white truncate">
                          {profile.user_email?.split('@')[0]}
                        </h3>
                        {demigodProfile && (
                          <RankBadge 
                            rank={demigodProfile.mdcTier.id} 
                            size="xs" 
                            showName 
                          />
                        )}
                      </div>
                    </div>
                  </div>

                  <h4 className="text-sm font-semibold text-white mb-2">
                    {profile.headline}
                  </h4>

                  {profile.pitch && (
                    <p className="text-xs text-gray-400 mb-3 line-clamp-2 italic">
                      "{profile.pitch}"
                    </p>
                  )}

                  <div className="flex items-center gap-4 text-xs text-gray-400 mb-4">
                    {profile.experience_level && (
                      <Badge className={`border ${experienceColors[profile.experience_level]}`}>
                        {experienceLevels[profile.experience_level]}
                      </Badge>
                    )}
                    {profile.hourly_rate && (
                      <span className="font-semibold text-[#00E599]">
                        ${profile.hourly_rate}/hr
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-3 text-xs text-gray-500 mb-4">
                    {demigodProfile && (
                      <>
                        <div className="flex items-center gap-1">
                          <Award className="w-3 h-3" />
                          Score: {demigodProfile.scores.totalScore}
                        </div>
                        {demigodProfile.feedbackStats?.count > 0 && (
                          <div className="flex items-center gap-1">
                            <Briefcase className="w-3 h-3" />
                            {demigodProfile.feedbackStats.count} reviews
                          </div>
                        )}
                      </>
                    )}
                    {profile.completed_tasks > 0 && (
                      <div className="flex items-center gap-1">
                        <Briefcase className="w-3 h-3" />
                        {profile.completed_tasks} tasks
                      </div>
                    )}
                  </div>

                  {profile.skills && profile.skills.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mb-4">
                      {profile.skills.slice(0, 5).map((skill, idx) => (
                        <Badge 
                          key={idx} 
                          variant="outline" 
                          className="text-xs border-[#1a1f2e] bg-[#141923] text-gray-400"
                        >
                          {skill}
                        </Badge>
                      ))}
                      {profile.skills.length > 5 && (
                        <Badge variant="outline" className="text-xs border-[#1a1f2e] bg-[#141923] text-gray-500">
                          +{profile.skills.length - 5}
                        </Badge>
                      )}
                    </div>
                  )}

                  <div className="flex gap-2">
                    {demigodProfile && (
                      <Link 
                        to={createPageUrl("DemigodProfile") + `?userId=${demigodProfile.userId}`}
                        className="flex-1"
                      >
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full border-[#1a1f2e] text-white hover:bg-[#1a1f2e]"
                        >
                          <Award className="w-3 h-3 mr-2" />
                          View Rank
                        </Button>
                      </Link>
                    )}
                    <Button 
                      size="sm" 
                      className="flex-1 bg-gradient-to-r from-[#00E599] to-[#00B8D4] text-black hover:opacity-90"
                    >
                      <Mail className="w-3 h-3 mr-2" />
                      Contact
                    </Button>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}