import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { 
  MessageCircle, Zap, Users, Shield, Code2, 
  CheckCircle2, ArrowRight, Copy, ExternalLink,
  Sparkles, Trophy, Crown, Globe, Activity
} from "lucide-react";
import { toast } from "sonner";
import DiscordProfileDemo from "../components/DiscordProfileDemo";

export default function DiscordIntegration() {
  const [copied, setCopied] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const BASE_URL = window.location.origin;
  const connectUrl = user ? `${BASE_URL}/discord/connect?userId=${user.id}` : `${BASE_URL}/discord/connect?userId=YOUR_USER_ID`;

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    toast.success("Copied to clipboard!");
    setTimeout(() => setCopied(false), 2000);
  };

  const handleConnect = () => {
    if (user?.id) {
      window.open(`${BASE_URL}/discord/connect?userId=${user.id}`, '_blank');
    } else {
      base44.auth.redirectToLogin();
    }
  };

  const features = [
    {
      icon: Trophy,
      title: "Guild Activity Tracking",
      description: "Boost your demigod rank with Discord community contributions",
      gradient: "from-purple-500 to-pink-500"
    },
    {
      icon: Activity,
      title: "Real-Time Signals",
      description: "Your Discord activity enhances AI ranking and matching",
      gradient: "from-cyan-500 to-blue-500"
    },
    {
      icon: Users,
      title: "Community Verification",
      description: "Guild membership adds credibility to your profile",
      gradient: "from-green-500 to-emerald-500"
    },
    {
      icon: Crown,
      title: "Elite Status Display",
      description: "Show off your Discord roles and server leadership",
      gradient: "from-yellow-500 to-orange-500"
    },
    {
      icon: Sparkles,
      title: "Enhanced Recommendations",
      description: "Better For You feed based on Discord communities",
      gradient: "from-indigo-500 to-purple-500"
    },
    {
      icon: Globe,
      title: "Cross-Platform Identity",
      description: "Link Discord to MDC for unified developer presence",
      gradient: "from-pink-500 to-red-500"
    }
  ];

  const benefits = [
    {
      icon: Shield,
      title: "Secure OAuth 2.0",
      description: "Industry-standard security, we never store your Discord password"
    },
    {
      icon: Zap,
      title: "Instant Sync",
      description: "Profile and guild data synced in real-time"
    },
    {
      icon: CheckCircle2,
      title: "Privacy First",
      description: "You control what data is shared and can disconnect anytime"
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 grid-pattern opacity-30" />
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl" />
        
        <div className="relative max-w-7xl mx-auto px-4 py-20">
          <div className="text-center mb-16">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6" style={{
              background: 'rgba(88, 101, 242, 0.1)',
              border: '1px solid rgba(88, 101, 242, 0.3)'
            }}>
              <MessageCircle className="w-4 h-4 text-[#5865F2]" />
              <span className="text-sm font-mono uppercase tracking-wider text-[#5865F2]">
                Discord Integration
              </span>
            </div>

            {/* Title */}
            <h1 className="text-5xl lg:text-6xl font-black mb-6">
              <span className="gradient-text">Level Up</span> Your Profile
              <br />
              With Discord
            </h1>

            {/* Subtitle */}
            <p className="text-xl text-gray-400 mb-12 max-w-3xl mx-auto leading-relaxed">
              Connect your Discord account to MDC and unlock enhanced ranking, better AI matching,
              and community-verified status. Your guild activity becomes part of your demigod score.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4 justify-center mb-12">
              <Button 
                className="btn-primary group"
                onClick={handleConnect}
              >
                <MessageCircle className="w-5 h-5 mr-2" />
                {user ? 'Connect Discord Account' : 'Sign In to Connect'}
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              
              {user && (
                <Button 
                  variant="outline"
                  className="btn-secondary"
                  onClick={() => copyToClipboard(connectUrl)}
                >
                  {copied ? (
                    <>
                      <CheckCircle2 className="w-5 h-5 mr-2 text-green-400" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-5 h-5 mr-2" />
                      Copy Connect Link
                    </>
                  )}
                </Button>
              )}
            </div>

            {/* Trust Badges */}
            <div className="flex flex-wrap gap-4 justify-center">
              {benefits.map((benefit, idx) => {
                const Icon = benefit.icon;
                return (
                  <div key={idx} className="badge-premium">
                    <Icon className="w-4 h-4 text-purple-400" />
                    <span className="text-purple-300">{benefit.title}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Demo Profile Display */}
          <div className="max-w-5xl mx-auto">
            <DiscordProfileDemo />
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-black mb-4">
              Why <span className="gradient-text">Connect Discord</span>?
            </h2>
            <p className="text-gray-400 text-lg">
              Unlock powerful features and boost your demigod ranking
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, idx) => {
              const Icon = feature.icon;
              return (
                <div key={idx} className="premium-card hover-lift">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-4`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  
                  <h3 className="text-xl font-bold mb-2 text-white">{feature.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-black mb-4">
              Connect in <span className="gradient-text">3 Simple Steps</span>
            </h2>
            <p className="text-gray-400 text-lg">
              Secure OAuth flow, takes less than 30 seconds
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                number: "01",
                title: "Click Connect",
                description: "Start the secure OAuth flow from your MDC profile",
                icon: MessageCircle
              },
              {
                number: "02",
                title: "Authorize Discord",
                description: "Grant MDC access to view your profile and guilds",
                icon: Shield
              },
              {
                number: "03",
                title: "Boost Your Rank",
                description: "Your Discord activity now enhances your demigod score",
                icon: Trophy
              }
            ].map((step, idx) => {
              const Icon = step.icon;
              return (
                <div key={idx} className="glass-card p-8 text-center hover-lift">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 mb-6">
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  
                  <div className="text-4xl font-black gradient-text mb-4">{step.number}</div>
                  <h3 className="text-xl font-bold mb-3 text-white">{step.title}</h3>
                  <p className="text-gray-400">{step.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* What We Collect Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4">
          <Card className="border-purple-500/30 bg-[#0b0816] p-8">
            <div className="flex items-start gap-4 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-white mb-2">Privacy & Data</h3>
                <p className="text-gray-400">
                  We respect your privacy. Here's exactly what we collect and why:
                </p>
              </div>
            </div>

            <div className="space-y-4 ml-16">
              <div>
                <div className="font-semibold text-white mb-1">👤 Profile Information</div>
                <p className="text-sm text-gray-400">
                  Username, discriminator, avatar — Used to display your Discord identity on MDC
                </p>
              </div>
              
              <div>
                <div className="font-semibold text-white mb-1">🏰 Guild Memberships</div>
                <p className="text-sm text-gray-400">
                  List of servers you're in — Helps us verify your community involvement and expertise areas
                </p>
              </div>

              <div className="pt-4 border-t border-purple-500/20">
                <p className="text-sm text-gray-500">
                  💡 We <strong className="text-white">never</strong> post on your behalf, read your messages, 
                  or access private data. You can disconnect anytime from your profile settings.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-black mb-4">
              <span className="gradient-text">Frequently Asked</span> Questions
            </h2>
          </div>

          <div className="space-y-4">
            {[
              {
                q: "Will MDC post messages on my behalf?",
                a: "No. We only read your profile and guild list. We never post, send messages, or modify anything on Discord."
              },
              {
                q: "How does Discord connection affect my rank?",
                a: "Guild memberships in developer communities add credibility. Active participation in verified servers can boost your demigod score by up to 15%."
              },
              {
                q: "Can I disconnect my Discord account?",
                a: "Yes, anytime. Go to your profile settings and click 'Disconnect Discord'. Your MDC account remains intact."
              },
              {
                q: "What if I'm not in any Discord servers?",
                a: "That's fine! Connecting still verifies your identity and enables future ranking features. You don't need to be in specific servers."
              }
            ].map((faq, idx) => (
              <div key={idx} className="glass-card p-6 hover-lift">
                <h4 className="font-bold text-white mb-2">{faq.q}</h4>
                <p className="text-gray-400 text-sm leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="premium-card p-12 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-[#5865F2]/10 to-purple-500/10" />
            
            <div className="relative">
              <MessageCircle className="w-16 h-16 mx-auto mb-6 text-[#5865F2]" />
              
              <h2 className="text-4xl font-black mb-4">
                Ready to <span className="gradient-text">Amplify</span> Your Profile?
              </h2>
              
              <p className="text-gray-400 text-lg mb-8 max-w-2xl mx-auto">
                Join hundreds of demigod developers who've connected Discord to unlock enhanced ranking and AI matching
              </p>
              
              <div className="flex flex-wrap gap-4 justify-center">
                <Button 
                  className="btn-primary"
                  onClick={handleConnect}
                >
                  <MessageCircle className="w-5 h-5 mr-2" />
                  {user ? 'Connect Your Discord' : 'Sign In to Connect'}
                </Button>
                
                <Button 
                  className="btn-secondary"
                  onClick={() => window.open('https://docs.maddevcity.com/discord', '_blank')}
                >
                  <ExternalLink className="w-5 h-5 mr-2" />
                  View Documentation
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}