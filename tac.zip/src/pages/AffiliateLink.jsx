import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";

// Set affiliate cookie
function setAffiliateCookie(code, days = 30) {
  const expires = new Date();
  expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);
  document.cookie = `affiliate=${code};expires=${expires.toUTCString()};path=/;SameSite=Lax`;
}

export default function AffiliateLink() {
  const navigate = useNavigate();

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const ref = urlParams.get('ref');
    const to = urlParams.get('to') || '/';

    if (ref) {
      // Set affiliate cookie
      setAffiliateCookie(ref, 30);

      // Track click
      base44.entities.Affiliate.filter({ code: ref })
        .then(affiliates => {
          if (affiliates.length > 0) {
            const affiliate = affiliates[0];
            
            // Track the click
            base44.entities.AffiliateClick.create({
              affiliate_id: affiliate.id,
              ip_address: 'browser',
              user_agent: navigator.userAgent.slice(0, 255),
              landing_page: to,
              converted: false
            }).catch(err => console.error('Click tracking error:', err));

            // Update click count
            base44.entities.Affiliate.update(affiliate.id, {
              total_clicks: (affiliate.total_clicks || 0) + 1
            }).catch(err => console.error('Update error:', err));
          }
        })
        .catch(err => console.error('Affiliate lookup error:', err));
    }

    // Redirect to target page
    if (to.startsWith('/')) {
      navigate(to);
    } else {
      navigate('/');
    }
  }, [navigate]);

  return (
    <div className="min-h-screen bg-[#0A0E14] flex items-center justify-center">
      <div className="text-white text-lg">Átirányítás...</div>
    </div>
  );
}