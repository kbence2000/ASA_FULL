import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import DualDebugPanel from "../components/DualDebugPanel";
import DemigodRoyaltyPanel from "../components/DemigodRoyaltyPanel";
import { 
  Brain, Layers, Sparkles, Code2, 
  Users, Award, TrendingUp 
} from "lucide-react";

const BACKEND_URL = import.meta.env.VITE_MDC_BACKEND_URL || "http://localhost:3000";

export default function DualDebug() {
  const [analysisCount, setAnalysisCount] = useState(0);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const handleAnalysisComplete = (data) => {
    setAnalysisCount(prev => prev + 1);
  };

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#1a1f2e] bg-[#0f1419] mb-4">
            <Layers className="w-4 h-4 text-purple-500" />
            <span className="text-sm text-gray-400 uppercase tracking-wider">Dual-Layer AI</span>
          </div>
          <h1 className="text-5xl font-black mb-4" style={{
            background: "linear-gradient(135deg, #A855F7, #6366F1)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}>
            Dual-Layer Debug Engine
          </h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            OpenAI Core Analysis + Demigod Enhanced Insights. Get the best of AI and elite developer patterns.
          </p>
        </div>

        <div className="grid lg:grid-cols-[1fr_320px] gap-8">
          {/* Left: Debug Panel */}
          <div>
            <DualDebugPanel 
              userId={user?.email || 'anonymous'}
              onAnalysisComplete={handleAnalysisComplete}
            />

            {/* Bottom Info */}
            <div className="grid md:grid-cols-3 gap-6 mt-8">
              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6 text-center">
                <Brain className="w-8 h-8 text-purple-400 mx-auto mb-3" />
                <h4 className="text-lg font-bold text-white mb-2">OpenAI Core</h4>
                <p className="text-sm text-gray-400">
                  Advanced GPT-4 analysis for bugs, anti-patterns, security issues
                </p>
              </Card>

              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6 text-center">
                <Sparkles className="w-8 h-8 text-indigo-400 mx-auto mb-3" />
                <h4 className="text-lg font-bold text-white mb-2">Demigod Layer</h4>
                <p className="text-sm text-gray-400">
                  Real-world patterns from R6/R7 elite developers
                </p>
              </Card>

              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6 text-center">
                <Award className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
                <h4 className="text-lg font-bold text-white mb-2">Royalty System</h4>
                <p className="text-sm text-gray-400">
                  Demigods earn credits when their insights help others
                </p>
              </Card>
            </div>
          </div>

          {/* Right: Royalty & Info */}
          <div className="space-y-6">
            {/* Royalty Panel (only for demigods) */}
            <DemigodRoyaltyPanel userId={user?.email} />

            {/* Session Stats */}
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-lg font-bold text-white mb-4">Session Stats</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Analyses Run</span>
                  <span className="text-2xl font-bold text-purple-400">{analysisCount}</span>
                </div>
              </div>
            </Card>

            {/* How It Works */}
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-lg font-bold text-white mb-4">How It Works</h3>
              <div className="space-y-3 text-sm text-gray-400">
                <div className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-purple-600/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-bold text-purple-400">1</span>
                  </div>
                  <div>
                    <div className="font-semibold text-white">Submit Code</div>
                    <div className="text-xs">Paste problematic code + error description</div>
                  </div>
                </div>
                
                <div className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-purple-600/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-bold text-purple-400">2</span>
                  </div>
                  <div>
                    <div className="font-semibold text-white">Core Analysis</div>
                    <div className="text-xs">OpenAI GPT-4 identifies issues</div>
                  </div>
                </div>
                
                <div className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-purple-600/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-bold text-purple-400">3</span>
                  </div>
                  <div>
                    <div className="font-semibold text-white">Demigod Search</div>
                    <div className="text-xs">Finds relevant patterns from R6/R7 devs</div>
                  </div>
                </div>
                
                <div className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-purple-600/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-bold text-purple-400">4</span>
                  </div>
                  <div>
                    <div className="font-semibold text-white">Enhanced Output</div>
                    <div className="text-xs">Get fixes + refactored code + tests</div>
                  </div>
                </div>
              </div>
            </Card>

            {/* Layer Comparison */}
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-lg font-bold text-white mb-4">Layer Comparison</h3>
              <div className="space-y-3">
                <div className="p-3 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                  <div className="flex items-center gap-2 mb-2">
                    <Brain className="w-4 h-4 text-purple-400" />
                    <span className="text-sm font-bold text-white">OpenAI Core</span>
                  </div>
                  <ul className="text-xs text-gray-400 space-y-1 ml-6 list-disc">
                    <li>Bug detection</li>
                    <li>Security analysis</li>
                    <li>Performance issues</li>
                    <li>Best practices</li>
                  </ul>
                </div>

                <div className="p-3 rounded-lg bg-gradient-to-br from-purple-600/10 to-indigo-600/10 border border-purple-600/30">
                  <div className="flex items-center gap-2 mb-2">
                    <Sparkles className="w-4 h-4 text-indigo-400" />
                    <span className="text-sm font-bold text-white">Demigod Enhanced</span>
                  </div>
                  <ul className="text-xs text-purple-300 space-y-1 ml-6 list-disc">
                    <li>Real-world patterns</li>
                    <li>Production-tested fixes</li>
                    <li>Elite-level insights</li>
                    <li>Royalty to contributors</li>
                  </ul>
                </div>
              </div>
            </Card>

            {/* Supported Languages */}
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-lg font-bold text-white mb-3">Supported Languages</h3>
              <div className="flex flex-wrap gap-2">
                {['JavaScript', 'TypeScript', 'Python', 'Java', 'Go', 'Rust', 'C++', 'C#', 'PHP', 'Ruby'].map(lang => (
                  <div key={lang} className="px-2 py-1 rounded-lg bg-[#141923] border border-[#1a1f2e] text-xs text-gray-300">
                    {lang}
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}