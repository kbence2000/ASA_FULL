import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Building, Briefcase, Users, Target, Lightbulb, LayoutDashboard } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import CompanyProfileCard from "../components/CompanyProfileCard";
import CompanyDashboardView from "../components/CompanyDashboardView";
import CompanyMissionBoard from "../components/CompanyMissionBoard";
import CompanyAIShortlist from "../components/CompanyAIShortlist";
import CompanyAIInsights from "../components/CompanyAIInsights";

export default function CompanyPortal() {
  const [companyId, setCompanyId] = useState("demo-company-001");
  const [selectedMission, setSelectedMission] = useState(null);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br from-blue-500 to-purple-500">
              <Building className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-black text-white">Company Portal</h1>
              <p className="text-gray-400">Hire elite developers & manage missions</p>
            </div>
          </div>
        </div>

        {/* Company Profile */}
        <div className="mb-8">
          <CompanyProfileCard companyId={companyId} />
        </div>

        {/* Mission Detail View */}
        {selectedMission ? (
          <div className="space-y-6">
            <Button
              onClick={() => setSelectedMission(null)}
              variant="outline"
              className="border-[#1a1f2e] text-gray-400 hover:text-white"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Missions
            </Button>

            <Card className="border p-6" style={{
              background: 'rgba(15, 23, 42, 0.95)',
              borderColor: 'rgba(148, 163, 184, 0.35)'
            }}>
              <h2 className="text-2xl font-bold text-white mb-4">
                {selectedMission.title}
              </h2>
              <p className="text-gray-300 leading-relaxed mb-4">
                {selectedMission.description}
              </p>
              <div className="flex items-center gap-2 mb-6">
                <Badge className={
                  selectedMission.status === "open" ? "bg-green-600/20 text-green-300 border-green-600/30" :
                  "bg-gray-600/20 text-gray-300 border-gray-600/30"
                }>
                  {selectedMission.status}
                </Badge>
                <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30">
                  {selectedMission.complexity}
                </Badge>
                <Badge className={
                  selectedMission.aiMode === "ai-only" 
                    ? "bg-purple-600/20 text-purple-300 border-purple-600/30"
                    : "bg-cyan-600/20 text-cyan-300 border-cyan-600/30"
                }>
                  {selectedMission.aiMode}
                </Badge>
                <span className="text-cyan-400 font-bold ml-auto">
                  €{selectedMission.bounty}
                </span>
              </div>
            </Card>

            {/* AI Shortlist for this mission */}
            <CompanyAIShortlist
              companyId={companyId}
              missionId={selectedMission.id}
              missionData={selectedMission}
            />
          </div>
        ) : (
          /* Main Tabs */
          <Tabs defaultValue="dashboard" className="space-y-6">
            <TabsList className="bg-[#0f1419] border border-[#1a1f2e]">
              <TabsTrigger value="dashboard" className="data-[state=active]:bg-purple-600/20">
                <LayoutDashboard className="w-4 h-4 mr-2" />
                Dashboard
              </TabsTrigger>
              <TabsTrigger value="missions" className="data-[state=active]:bg-cyan-600/20">
                <Briefcase className="w-4 h-4 mr-2" />
                Missions
              </TabsTrigger>
              <TabsTrigger value="insights" className="data-[state=active]:bg-pink-600/20">
                <Lightbulb className="w-4 h-4 mr-2" />
                AI Insights
              </TabsTrigger>
            </TabsList>

            <TabsContent value="dashboard">
              <CompanyDashboardView companyId={companyId} />
            </TabsContent>

            <TabsContent value="missions">
              <CompanyMissionBoard 
                companyId={companyId}
                onSelectMission={setSelectedMission}
              />
            </TabsContent>

            <TabsContent value="insights">
              <CompanyAIInsights companyId={companyId} />
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  );
}