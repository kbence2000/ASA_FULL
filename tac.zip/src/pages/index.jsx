import Layout from "./Layout.jsx";

import Marketplace from "./Marketplace";

import AppDetail from "./AppDetail";

import AddApp from "./AddApp";

import MyApps from "./MyApps";

import AdminDashboard from "./AdminDashboard";

import AffiliateDashboard from "./AffiliateDashboard";

import AffiliateLink from "./AffiliateLink";

import ExpertMarketplace from "./ExpertMarketplace";

import PostTask from "./PostTask";

import TaskDetail from "./TaskDetail";

import MyExpertProfile from "./MyExpertProfile";

import ExpertProfiles from "./ExpertProfiles";

import LinkedInSearch from "./LinkedInSearch";

import Lobby from "./Lobby";

import Home from "./Home";

import DemigodProfile from "./DemigodProfile";

import Leaderboard from "./Leaderboard";

import MostWanted from "./MostWanted";

import CloudRuntime from "./CloudRuntime";

import DualDebug from "./DualDebug";

import DebugConsole from "./DebugConsole";

import ForYou from "./ForYou";

import DemigodTips from "./DemigodTips";

import UnifiedConsole from "./UnifiedConsole";

import EnterprisePool from "./EnterprisePool";

import MyStakedProjects from "./MyStakedProjects";

import CodingPvP from "./CodingPvP";

import InnovationPvP from "./InnovationPvP";

import TalentDashboard from "./TalentDashboard";

import MentorDashboard from "./MentorDashboard";

import DealValuator from "./DealValuator";

import StraightFromTop from "./StraightFromTop";

import Landing from "./Landing";

import InvestorView from "./InvestorView";

import SlackIntegration from "./SlackIntegration";

import DiscordIntegration from "./DiscordIntegration";

import AlmightyCore from "./AlmightyCore";

import Dashboard from "./Dashboard";

import DashboardMobile from "./DashboardMobile";

import DashboardDesktop from "./DashboardDesktop";

import PatternLibrary from "./PatternLibrary";

import CodeMaker from "./CodeMaker";

import MastermindDashboard from "./MastermindDashboard";

import SecurityDashboard from "./SecurityDashboard";

import TrendingAdmin from "./TrendingAdmin";

import APCDashboard from "./APCDashboard";

import DevGuardianDashboard from "./DevGuardianDashboard";

import MissionsDashboard from "./MissionsDashboard";

import CoreDashboard from "./CoreDashboard";

import DemigodHub from "./DemigodHub";

import CompanyPortal from "./CompanyPortal";

import SystemStatus from "./SystemStatus";

import MatrixHub from "./MatrixHub";

import TriMindOS from "./TriMindOS";

import EvolutionLab from "./EvolutionLab";

import DualLoop from "./DualLoop";

import ParadoxEngine from "./ParadoxEngine";

import HallucinatorMind from "./HallucinatorMind";

import PipelineEngine from "./PipelineEngine";

import TACEvolution from "./TACEvolution";

import ModuleVault from "./ModuleVault";

import SecurityOversight from "./SecurityOversight";

import ControlHub from "./ControlHub";

import NQFiceEngine from "./NQFiceEngine";

import Field1998Engine from "./Field1998Engine";

import AntiField1998Engine from "./AntiField1998Engine";

import InfinityExpansionEngine from "./InfinityExpansionEngine";

import UniversalUpgradeEngine from "./UniversalUpgradeEngine";

import ChaosUpgradePipeline from "./ChaosUpgradePipeline";

import MasterOrchestratorEngine from "./MasterOrchestratorEngine";

import FounderPanel from "./FounderPanel";

import HexMindEngine from "./HexMindEngine";

import ParadoxFusionHexEngine from "./ParadoxFusionHexEngine";

import TACFeedbackHub from "./TACFeedbackHub";

import MissionLoop from "./MissionLoop";

import AntiN8NEngine from "./AntiN8NEngine";

import DualAutomation from "./DualAutomation";

import ArchIntegration from "./ArchIntegration";

import AIRentalEngine from "./AIRentalEngine";

import TACDashboard from "./TACDashboard";

import NeuralCore from "./NeuralCore";

import CodeRepository from "./CodeRepository";

import HyperOrchestrator from "./HyperOrchestrator";

import DebugFixBot from "./DebugFixBot";

import WhiteNoiseEngine from "./WhiteNoiseEngine";

import SemanticIntegrityCore from "./SemanticIntegrityCore";

import IdeaCollectorAI from "./IdeaCollectorAI";

import DualShieldEngine from "./DualShieldEngine";

import CNAnalyzer from "./CNAnalyzer";

import FormatIntelligenceEngine from "./FormatIntelligenceEngine";

import MathMindClone from "./MathMindClone";

import ModuleIdeaVault from "./ModuleIdeaVault";

import AntiRiftEngine from "./AntiRiftEngine";

import StabilityDashboard from "./StabilityDashboard";

import GlobalHealthDashboard from "./GlobalHealthDashboard";

import HealthMonitor from "./HealthMonitor";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Marketplace: Marketplace,
    
    AppDetail: AppDetail,
    
    AddApp: AddApp,
    
    MyApps: MyApps,
    
    AdminDashboard: AdminDashboard,
    
    AffiliateDashboard: AffiliateDashboard,
    
    AffiliateLink: AffiliateLink,
    
    ExpertMarketplace: ExpertMarketplace,
    
    PostTask: PostTask,
    
    TaskDetail: TaskDetail,
    
    MyExpertProfile: MyExpertProfile,
    
    ExpertProfiles: ExpertProfiles,
    
    LinkedInSearch: LinkedInSearch,
    
    Lobby: Lobby,
    
    Home: Home,
    
    DemigodProfile: DemigodProfile,
    
    Leaderboard: Leaderboard,
    
    MostWanted: MostWanted,
    
    CloudRuntime: CloudRuntime,
    
    DualDebug: DualDebug,
    
    DebugConsole: DebugConsole,
    
    ForYou: ForYou,
    
    DemigodTips: DemigodTips,
    
    UnifiedConsole: UnifiedConsole,
    
    EnterprisePool: EnterprisePool,
    
    MyStakedProjects: MyStakedProjects,
    
    CodingPvP: CodingPvP,
    
    InnovationPvP: InnovationPvP,
    
    TalentDashboard: TalentDashboard,
    
    MentorDashboard: MentorDashboard,
    
    DealValuator: DealValuator,
    
    StraightFromTop: StraightFromTop,
    
    Landing: Landing,
    
    InvestorView: InvestorView,
    
    SlackIntegration: SlackIntegration,
    
    DiscordIntegration: DiscordIntegration,
    
    AlmightyCore: AlmightyCore,
    
    Dashboard: Dashboard,
    
    DashboardMobile: DashboardMobile,
    
    DashboardDesktop: DashboardDesktop,
    
    PatternLibrary: PatternLibrary,
    
    CodeMaker: CodeMaker,
    
    MastermindDashboard: MastermindDashboard,
    
    SecurityDashboard: SecurityDashboard,
    
    TrendingAdmin: TrendingAdmin,
    
    APCDashboard: APCDashboard,
    
    DevGuardianDashboard: DevGuardianDashboard,
    
    MissionsDashboard: MissionsDashboard,
    
    CoreDashboard: CoreDashboard,
    
    DemigodHub: DemigodHub,
    
    CompanyPortal: CompanyPortal,
    
    SystemStatus: SystemStatus,
    
    MatrixHub: MatrixHub,
    
    TriMindOS: TriMindOS,
    
    EvolutionLab: EvolutionLab,
    
    DualLoop: DualLoop,
    
    ParadoxEngine: ParadoxEngine,
    
    HallucinatorMind: HallucinatorMind,
    
    PipelineEngine: PipelineEngine,
    
    TACEvolution: TACEvolution,
    
    ModuleVault: ModuleVault,
    
    SecurityOversight: SecurityOversight,
    
    ControlHub: ControlHub,
    
    NQFiceEngine: NQFiceEngine,
    
    Field1998Engine: Field1998Engine,
    
    AntiField1998Engine: AntiField1998Engine,
    
    InfinityExpansionEngine: InfinityExpansionEngine,
    
    UniversalUpgradeEngine: UniversalUpgradeEngine,
    
    ChaosUpgradePipeline: ChaosUpgradePipeline,
    
    MasterOrchestratorEngine: MasterOrchestratorEngine,
    
    FounderPanel: FounderPanel,
    
    HexMindEngine: HexMindEngine,
    
    ParadoxFusionHexEngine: ParadoxFusionHexEngine,
    
    TACFeedbackHub: TACFeedbackHub,
    
    MissionLoop: MissionLoop,
    
    AntiN8NEngine: AntiN8NEngine,
    
    DualAutomation: DualAutomation,
    
    ArchIntegration: ArchIntegration,
    
    AIRentalEngine: AIRentalEngine,
    
    TACDashboard: TACDashboard,
    
    NeuralCore: NeuralCore,
    
    CodeRepository: CodeRepository,
    
    HyperOrchestrator: HyperOrchestrator,
    
    DebugFixBot: DebugFixBot,
    
    WhiteNoiseEngine: WhiteNoiseEngine,
    
    SemanticIntegrityCore: SemanticIntegrityCore,
    
    IdeaCollectorAI: IdeaCollectorAI,
    
    DualShieldEngine: DualShieldEngine,
    
    CNAnalyzer: CNAnalyzer,
    
    FormatIntelligenceEngine: FormatIntelligenceEngine,
    
    MathMindClone: MathMindClone,
    
    ModuleIdeaVault: ModuleIdeaVault,
    
    AntiRiftEngine: AntiRiftEngine,
    
    StabilityDashboard: StabilityDashboard,
    
    GlobalHealthDashboard: GlobalHealthDashboard,
    
    HealthMonitor: HealthMonitor,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Marketplace />} />
                
                
                <Route path="/Marketplace" element={<Marketplace />} />
                
                <Route path="/AppDetail" element={<AppDetail />} />
                
                <Route path="/AddApp" element={<AddApp />} />
                
                <Route path="/MyApps" element={<MyApps />} />
                
                <Route path="/AdminDashboard" element={<AdminDashboard />} />
                
                <Route path="/AffiliateDashboard" element={<AffiliateDashboard />} />
                
                <Route path="/AffiliateLink" element={<AffiliateLink />} />
                
                <Route path="/ExpertMarketplace" element={<ExpertMarketplace />} />
                
                <Route path="/PostTask" element={<PostTask />} />
                
                <Route path="/TaskDetail" element={<TaskDetail />} />
                
                <Route path="/MyExpertProfile" element={<MyExpertProfile />} />
                
                <Route path="/ExpertProfiles" element={<ExpertProfiles />} />
                
                <Route path="/LinkedInSearch" element={<LinkedInSearch />} />
                
                <Route path="/Lobby" element={<Lobby />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/DemigodProfile" element={<DemigodProfile />} />
                
                <Route path="/Leaderboard" element={<Leaderboard />} />
                
                <Route path="/MostWanted" element={<MostWanted />} />
                
                <Route path="/CloudRuntime" element={<CloudRuntime />} />
                
                <Route path="/DualDebug" element={<DualDebug />} />
                
                <Route path="/DebugConsole" element={<DebugConsole />} />
                
                <Route path="/ForYou" element={<ForYou />} />
                
                <Route path="/DemigodTips" element={<DemigodTips />} />
                
                <Route path="/UnifiedConsole" element={<UnifiedConsole />} />
                
                <Route path="/EnterprisePool" element={<EnterprisePool />} />
                
                <Route path="/MyStakedProjects" element={<MyStakedProjects />} />
                
                <Route path="/CodingPvP" element={<CodingPvP />} />
                
                <Route path="/InnovationPvP" element={<InnovationPvP />} />
                
                <Route path="/TalentDashboard" element={<TalentDashboard />} />
                
                <Route path="/MentorDashboard" element={<MentorDashboard />} />
                
                <Route path="/DealValuator" element={<DealValuator />} />
                
                <Route path="/StraightFromTop" element={<StraightFromTop />} />
                
                <Route path="/Landing" element={<Landing />} />
                
                <Route path="/InvestorView" element={<InvestorView />} />
                
                <Route path="/SlackIntegration" element={<SlackIntegration />} />
                
                <Route path="/DiscordIntegration" element={<DiscordIntegration />} />
                
                <Route path="/AlmightyCore" element={<AlmightyCore />} />
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/DashboardMobile" element={<DashboardMobile />} />
                
                <Route path="/DashboardDesktop" element={<DashboardDesktop />} />
                
                <Route path="/PatternLibrary" element={<PatternLibrary />} />
                
                <Route path="/CodeMaker" element={<CodeMaker />} />
                
                <Route path="/MastermindDashboard" element={<MastermindDashboard />} />
                
                <Route path="/SecurityDashboard" element={<SecurityDashboard />} />
                
                <Route path="/TrendingAdmin" element={<TrendingAdmin />} />
                
                <Route path="/APCDashboard" element={<APCDashboard />} />
                
                <Route path="/DevGuardianDashboard" element={<DevGuardianDashboard />} />
                
                <Route path="/MissionsDashboard" element={<MissionsDashboard />} />
                
                <Route path="/CoreDashboard" element={<CoreDashboard />} />
                
                <Route path="/DemigodHub" element={<DemigodHub />} />
                
                <Route path="/CompanyPortal" element={<CompanyPortal />} />
                
                <Route path="/SystemStatus" element={<SystemStatus />} />
                
                <Route path="/MatrixHub" element={<MatrixHub />} />
                
                <Route path="/TriMindOS" element={<TriMindOS />} />
                
                <Route path="/EvolutionLab" element={<EvolutionLab />} />
                
                <Route path="/DualLoop" element={<DualLoop />} />
                
                <Route path="/ParadoxEngine" element={<ParadoxEngine />} />
                
                <Route path="/HallucinatorMind" element={<HallucinatorMind />} />
                
                <Route path="/PipelineEngine" element={<PipelineEngine />} />
                
                <Route path="/TACEvolution" element={<TACEvolution />} />
                
                <Route path="/ModuleVault" element={<ModuleVault />} />
                
                <Route path="/SecurityOversight" element={<SecurityOversight />} />
                
                <Route path="/ControlHub" element={<ControlHub />} />
                
                <Route path="/NQFiceEngine" element={<NQFiceEngine />} />
                
                <Route path="/Field1998Engine" element={<Field1998Engine />} />
                
                <Route path="/AntiField1998Engine" element={<AntiField1998Engine />} />
                
                <Route path="/InfinityExpansionEngine" element={<InfinityExpansionEngine />} />
                
                <Route path="/UniversalUpgradeEngine" element={<UniversalUpgradeEngine />} />
                
                <Route path="/ChaosUpgradePipeline" element={<ChaosUpgradePipeline />} />
                
                <Route path="/MasterOrchestratorEngine" element={<MasterOrchestratorEngine />} />
                
                <Route path="/FounderPanel" element={<FounderPanel />} />
                
                <Route path="/HexMindEngine" element={<HexMindEngine />} />
                
                <Route path="/ParadoxFusionHexEngine" element={<ParadoxFusionHexEngine />} />
                
                <Route path="/TACFeedbackHub" element={<TACFeedbackHub />} />
                
                <Route path="/MissionLoop" element={<MissionLoop />} />
                
                <Route path="/AntiN8NEngine" element={<AntiN8NEngine />} />
                
                <Route path="/DualAutomation" element={<DualAutomation />} />
                
                <Route path="/ArchIntegration" element={<ArchIntegration />} />
                
                <Route path="/AIRentalEngine" element={<AIRentalEngine />} />
                
                <Route path="/TACDashboard" element={<TACDashboard />} />
                
                <Route path="/NeuralCore" element={<NeuralCore />} />
                
                <Route path="/CodeRepository" element={<CodeRepository />} />
                
                <Route path="/HyperOrchestrator" element={<HyperOrchestrator />} />
                
                <Route path="/DebugFixBot" element={<DebugFixBot />} />
                
                <Route path="/WhiteNoiseEngine" element={<WhiteNoiseEngine />} />
                
                <Route path="/SemanticIntegrityCore" element={<SemanticIntegrityCore />} />
                
                <Route path="/IdeaCollectorAI" element={<IdeaCollectorAI />} />
                
                <Route path="/DualShieldEngine" element={<DualShieldEngine />} />
                
                <Route path="/CNAnalyzer" element={<CNAnalyzer />} />
                
                <Route path="/FormatIntelligenceEngine" element={<FormatIntelligenceEngine />} />
                
                <Route path="/MathMindClone" element={<MathMindClone />} />
                
                <Route path="/ModuleIdeaVault" element={<ModuleIdeaVault />} />
                
                <Route path="/AntiRiftEngine" element={<AntiRiftEngine />} />
                
                <Route path="/StabilityDashboard" element={<StabilityDashboard />} />
                
                <Route path="/GlobalHealthDashboard" element={<GlobalHealthDashboard />} />
                
                <Route path="/HealthMonitor" element={<HealthMonitor />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}