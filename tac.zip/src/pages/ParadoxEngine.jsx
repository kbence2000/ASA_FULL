import React, { useState, useRef, useEffect } from 'react';
import { Zap, Shield, Flame, Sparkles, Loader2, TrendingUp, AlertTriangle, X } from 'lucide-react';

const ORDER_AGENTS = [
  "Origin Architect",
  "Flow Strategist",
  "System Mapper",
  "Logic Weaver",
  "UX Synthesizer",
  "Risk Controller",
  "Performance Optimizer",
  "Scalability Engineer",
  "Stability Arbiter"
];

const CHAOS_AGENTS = [
  "Pattern Breaker",
  "Assumption Hacker",
  "Edge-Case Summoner",
  "Anomaly Amplifier",
  "Glitch Prophet",
  "Inverse Strategist",
  "Exploit Hunter",
  "Weirdness Engineer",
  "Entropy Bringer"
];

export default function ParadoxEngine() {
  const [brief, setBrief] = useState("Design an AI-powered code marketplace module that evaluates, ranks, and prices uploaded code assets for enterprises.");
  const [cycles, setCycles] = useState(3);
  const [isRunning, setIsRunning] = useState(false);
  const [isPanelOpen, setIsPanelOpen] = useState(false);
  const [convergenceResult, setConvergenceResult] = useState(null);
  const [error, setError] = useState(null);

  const runParadox = async () => {
    if (isRunning || !brief.trim()) return;

    setIsRunning(true);
    setError(null);
    setConvergenceResult(null);

    try {
      const response = await fetch('http://localhost:7070/api/paradox/run', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          brief,
          cycles
        })
      });

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();

      if (data.status !== 'ok') {
        throw new Error(data.error || 'Unknown backend error');
      }

      setConvergenceResult(data.paradoxOutput || null);

    } catch (err) {
      console.error('Paradox Engine error:', err);
      setError(err.message);
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="relative w-full min-h-screen" style={{
      background: 'radial-gradient(circle at 20% 0%, #0b1120 0%, #020617 55%, #000 100%)'
    }}>
      <style>{`
        @keyframes badgePulse {
          0% { transform: scale(1); opacity: 1; }
          60% { transform: scale(1.5); opacity: 0.3; }
          100% { transform: scale(1); opacity: 1; }
        }

        @keyframes ripple {
          0% { transform: scale(0.6); opacity: 0.9; }
          70% { transform: scale(1.3); opacity: 0.15; }
          100% { transform: scale(1.4); opacity: 0; }
        }

        @keyframes dotPulse {
          0% { transform: scale(1); opacity: 1; }
          50% { transform: scale(1.6); opacity: 0.3; }
          100% { transform: scale(1); opacity: 1; }
        }

        .matrix-bg {
          position: absolute;
          inset: 0;
          background-image: 
            linear-gradient(to right, rgba(255, 255, 255, 0.04) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(255, 255, 255, 0.04) 1px, transparent 1px);
          background-size: 40px 40px;
          opacity: 0.35;
          pointer-events: none;
        }

        .paradox-panel-slide {
          transform: translateY(120%);
          opacity: 0;
          transition: transform 260ms ease-out, opacity 260ms ease-out;
        }

        .paradox-panel-slide.open {
          transform: translateY(0);
          opacity: 1;
        }

        .ring {
          position: absolute;
          border-radius: 999px;
          border: 1px dashed rgba(148, 163, 184, 0.25);
          pointer-events: none;
        }

        .ring.r1 {
          width: 220px;
          height: 220px;
        }

        .ring.r2 {
          width: 320px;
          height: 320px;
          opacity: 0.7;
          border-style: solid;
          border-color: rgba(34, 197, 94, 0.3);
        }

        .ring.r3 {
          width: 440px;
          height: 440px;
          opacity: 0.45;
          border-style: solid;
          border-color: rgba(168, 85, 247, 0.3);
        }

        .rope-center {
          position: absolute;
          width: 2px;
          height: 260px;
          top: calc(50% - 130px);
          left: 50%;
          transform: translateX(-50%);
          background: linear-gradient(
            to bottom,
            rgba(94, 234, 212, 0),
            rgba(94, 234, 212, 0.9),
            rgba(94, 234, 212, 0)
          );
          opacity: 0.7;
          filter: blur(0.5px);
          pointer-events: none;
        }
      `}</style>

      {/* Matrix BG */}
      <div className="matrix-bg" />

      {/* Main Container */}
      <div className="relative max-w-[1200px] mx-auto px-3 py-3 pb-20">
        {/* Matrix Core */}
        <div className="relative h-[60vh] min-h-[420px] max-h-[640px] mt-4 rounded-[32px] overflow-hidden border"
          style={{
            background: 'radial-gradient(circle at 50% 0%, #020617 0%, #020617 40%, #000 100%)',
            boxShadow: '0 0 40px rgba(0, 0, 0, 0.7)',
            borderColor: 'rgba(148, 163, 184, 0.25)'
          }}
        >
          {/* Header */}
          <div className="flex justify-between items-center px-[18px] py-[14px] border-b"
            style={{
              borderColor: 'rgba(148, 163, 184, 0.3)',
              backdropFilter: 'blur(12px)',
              background: 'linear-gradient(to bottom, rgba(15, 23, 42, 0.96), rgba(15, 23, 42, 0.8), transparent)'
            }}
          >
            <div>
              <div className="text-sm uppercase tracking-[0.18em] text-gray-400">
                Matrix Core · Paradox Engine
              </div>
              <div className="text-[11px] uppercase tracking-[0.12em] text-gray-500">
                Order × Chaos · Dual-Layer AI Loop
              </div>
            </div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] uppercase tracking-[0.16em]"
              style={{
                background: 'radial-gradient(circle at 30% 0%, #22c55e, #16a34a, #15803d)',
                boxShadow: '0 0 20px rgba(34, 197, 94, 0.6)'
              }}
            >
              <div className="w-1.5 h-1.5 rounded-full bg-green-200"
                style={{
                  boxShadow: '0 0 10px rgba(187, 247, 208, 0.9)',
                  animation: 'badgePulse 1.8s ease-in-out infinite'
                }}
              />
              LIVE ORCHESTRATION
            </div>
          </div>

          {/* Matrix Space */}
          <div className="relative w-full h-[calc(100%-52px)] flex items-center justify-center overflow-hidden">
            {/* Rings */}
            <div className="ring r1" />
            <div className="ring r2" />
            <div className="ring r3" />

            {/* Center rope */}
            <div className="rope-center" />

            {/* Paradox Core */}
            <button
              onClick={() => setIsPanelOpen(true)}
              className="relative w-[120px] h-[120px] rounded-full flex items-center justify-center cursor-pointer transition-all duration-200 hover:scale-105"
              style={{
                background: 'radial-gradient(circle at 30% 20%, #bbf7d0, #22c55e, #064e3b)',
                boxShadow: '0 0 35px rgba(34, 197, 94, 0.9), 0 0 90px rgba(22, 163, 74, 0.9)',
                transform: 'translateY(-6px)'
              }}
            >
              <div className="relative w-[82px] h-[82px] rounded-full flex flex-col items-center justify-center text-center p-1.5 overflow-hidden"
                style={{
                  background: 'radial-gradient(circle at 50% 30%, #ecfeff, #a7f3d0, #22c55e)',
                  border: '1px solid rgba(240, 253, 250, 0.7)'
                }}
              >
                <div className="absolute inset-0 rounded-full border border-teal-50/50"
                  style={{ animation: 'ripple 3.4s ease-out infinite', animationDelay: '0s' }}
                />
                <div className="absolute inset-0 rounded-full border border-teal-50/50"
                  style={{ animation: 'ripple 3.4s ease-out infinite', animationDelay: '0.8s' }}
                />
                <div className="absolute inset-0 rounded-full border border-teal-50/50"
                  style={{ animation: 'ripple 3.4s ease-out infinite', animationDelay: '1.6s' }}
                />
                <div className="text-[10px] uppercase tracking-[0.18em] text-teal-950 opacity-85">
                  Paradox
                </div>
                <div className="text-[11px] font-semibold mt-1 text-teal-950 uppercase tracking-[0.15em]">
                  Engine
                </div>
                <div className="text-[9px] mt-1 text-teal-700 opacity-85">
                  Tap to orchestrate
                </div>
              </div>
            </button>

            {/* Order Nodes */}
            <div className="absolute w-16 h-16 rounded-full flex items-center justify-center text-[10px] text-center p-1 leading-tight border backdrop-blur-sm cursor-default"
              style={{
                top: '18%',
                left: '16%',
                background: 'radial-gradient(circle at 20% 0%, rgba(56, 189, 248, 0.9), rgba(8, 47, 73, 0.9))',
                boxShadow: '0 0 18px rgba(56, 189, 248, 0.7)',
                borderColor: 'rgba(148, 163, 184, 0.4)'
              }}
            >
              <div className="uppercase tracking-[0.08em]">Order Council</div>
            </div>

            <div className="absolute w-16 h-16 rounded-full flex items-center justify-center text-[10px] text-center p-1 leading-tight border backdrop-blur-sm cursor-default"
              style={{
                top: '38%',
                left: '8%',
                background: 'radial-gradient(circle at 20% 0%, rgba(56, 189, 248, 0.9), rgba(8, 47, 73, 0.9))',
                boxShadow: '0 0 18px rgba(56, 189, 248, 0.7)',
                borderColor: 'rgba(148, 163, 184, 0.4)'
              }}
            >
              <div className="uppercase tracking-[0.08em]">Stability</div>
            </div>

            <div className="absolute w-16 h-16 rounded-full flex items-center justify-center text-[10px] text-center p-1 leading-tight border backdrop-blur-sm cursor-default"
              style={{
                top: '60%',
                left: '18%',
                background: 'radial-gradient(circle at 20% 0%, rgba(56, 189, 248, 0.9), rgba(8, 47, 73, 0.9))',
                boxShadow: '0 0 18px rgba(56, 189, 248, 0.7)',
                borderColor: 'rgba(148, 163, 184, 0.4)'
              }}
            >
              <div className="uppercase tracking-[0.08em]">Structure</div>
            </div>

            {/* Chaos Nodes */}
            <div className="absolute w-16 h-16 rounded-full flex items-center justify-center text-[10px] text-center p-1 leading-tight border backdrop-blur-sm cursor-default"
              style={{
                top: '18%',
                right: '16%',
                background: 'radial-gradient(circle at 20% 0%, rgba(248, 113, 113, 0.96), rgba(127, 29, 29, 0.9))',
                boxShadow: '0 0 18px rgba(248, 113, 113, 0.7)',
                borderColor: 'rgba(148, 163, 184, 0.4)'
              }}
            >
              <div className="uppercase tracking-[0.08em]">Chaos Council</div>
            </div>

            <div className="absolute w-16 h-16 rounded-full flex items-center justify-center text-[10px] text-center p-1 leading-tight border backdrop-blur-sm cursor-default"
              style={{
                top: '38%',
                right: '8%',
                background: 'radial-gradient(circle at 20% 0%, rgba(248, 113, 113, 0.96), rgba(127, 29, 29, 0.9))',
                boxShadow: '0 0 18px rgba(248, 113, 113, 0.7)',
                borderColor: 'rgba(148, 163, 184, 0.4)'
              }}
            >
              <div className="uppercase tracking-[0.08em]">Distortion</div>
            </div>

            <div className="absolute w-16 h-16 rounded-full flex items-center justify-center text-[10px] text-center p-1 leading-tight border backdrop-blur-sm cursor-default"
              style={{
                top: '60%',
                right: '18%',
                background: 'radial-gradient(circle at 20% 0%, rgba(248, 113, 113, 0.96), rgba(127, 29, 29, 0.9))',
                boxShadow: '0 0 18px rgba(248, 113, 113, 0.7)',
                borderColor: 'rgba(148, 163, 184, 0.4)'
              }}
            >
              <div className="uppercase tracking-[0.08em]">Anomaly</div>
            </div>
          </div>
        </div>

        {/* Slide-up Panel */}
        <div className="fixed left-0 right-0 bottom-0 max-w-[1200px] mx-auto px-2.5 pb-2.5 z-20 pointer-events-none">
          <div className={`paradox-panel-slide ${isPanelOpen ? 'open' : ''} rounded-[22px] border p-2.5 pb-3 pointer-events-auto`}
            style={{
              background: 'radial-gradient(circle at 0% 0%, #020617, #020617 40%, #000 100%)',
              borderColor: 'rgba(148, 163, 184, 0.7)',
              boxShadow: '0 -18px 40px rgba(0, 0, 0, 0.9)'
            }}
          >
            {/* Card Header */}
            <div className="flex justify-between items-center gap-3 mb-1.5">
              <div>
                <div className="text-[13px] uppercase tracking-[0.18em] text-gray-400">
                  Paradox Engine Control
                </div>
                <div className="text-[11px] uppercase tracking-[0.12em] text-gray-500">
                  Define · Distort · Refine · Converge
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] px-2 py-0.5 rounded-full uppercase tracking-[0.12em] text-green-200 border"
                  style={{
                    background: 'rgba(34, 197, 94, 0.15)',
                    borderColor: 'rgba(34, 197, 94, 0.5)'
                  }}
                >
                  Dual Council
                </span>
                <button
                  onClick={() => setIsPanelOpen(false)}
                  className="p-1 rounded-full text-gray-400 hover:bg-slate-700/20 hover:text-gray-200 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Panel Grid */}
            <div className="grid grid-cols-1 md:grid-cols-[1.4fr_1fr] gap-2">
              {/* Left: Input */}
              <div>
                <div className="text-[11px] text-gray-400 uppercase tracking-[0.12em] mb-1">
                  Brief / Problem Statement
                </div>
                <textarea
                  value={brief}
                  onChange={(e) => setBrief(e.target.value)}
                  disabled={isRunning}
                  rows={3}
                  className="w-full resize-y rounded-xl border px-2.5 py-2 text-xs outline-none"
                  style={{
                    minHeight: '80px',
                    maxHeight: '120px',
                    background: 'rgba(15, 23, 42, 0.95)',
                    borderColor: 'rgba(148, 163, 184, 0.6)',
                    color: '#f9fafb'
                  }}
                  placeholder="Pl.: Tervezd meg az AI-powered code marketplace Paradox Engine modulját..."
                />

                <div className="flex items-center gap-2.5 mt-1.5">
                  <span className="text-[11px] text-gray-400">Cycles</span>
                  <input
                    type="range"
                    min="1"
                    max="6"
                    value={cycles}
                    onChange={(e) => setCycles(parseInt(e.target.value))}
                    disabled={isRunning}
                    className="flex-1"
                    style={{ accentColor: '#22c55e' }}
                  />
                  <span className="text-[11px] text-gray-400">{cycles}</span>
                </div>

                <button
                  onClick={runParadox}
                  disabled={isRunning}
                  className="w-full mt-2 rounded-full px-2.5 py-2 text-xs font-semibold uppercase tracking-[0.16em] flex items-center justify-center gap-1.5 transition-all disabled:opacity-55 hover:scale-[1.01]"
                  style={{
                    background: 'linear-gradient(90deg, #22c55e, #a3e635)',
                    color: '#022c22',
                    boxShadow: isRunning ? 'none' : '0 0 22px rgba(34, 197, 94, 0.7)'
                  }}
                >
                  {isRunning && (
                    <div className="w-2 h-2 rounded-full bg-green-900"
                      style={{
                        boxShadow: '0 0 10px rgba(22, 163, 74, 0.9)',
                        animation: 'dotPulse 1s ease-in-out infinite'
                      }}
                    />
                  )}
                  {isRunning ? 'Orchestrating...' : 'Run Paradox'}
                </button>

                {error && (
                  <div className="text-[10px] text-rose-400 mt-1">
                    ⚠ {error}
                    <br />
                    <span className="text-gray-500">Make sure backend is running: <code className="bg-black/40 px-1 rounded">node paradox-server.js</code></span>
                  </div>
                )}
              </div>

              {/* Right: Output */}
              <div>
                <div className="text-xs px-2 py-1.5 rounded-xl border"
                  style={{
                    background: 'radial-gradient(circle at 0% 0%, rgba(15, 23, 42, 0.96), #020617)',
                    borderColor: 'rgba(148, 163, 184, 0.55)',
                    maxHeight: '130px',
                    overflowY: 'auto'
                  }}
                >
                  <div className="text-[10px] uppercase tracking-[0.14em] text-gray-400 mb-1">
                    Final Blueprint (Convergence Core)
                  </div>
                  <div className="text-[11px] text-gray-300">
                    {convergenceResult ? (
                      <>
                        <div className="font-semibold text-green-300 mb-1">{convergenceResult.finalSummary}</div>
                        <div className="whitespace-pre-wrap">{convergenceResult.finalBlueprint}</div>
                      </>
                    ) : (
                      <span className="text-gray-500 text-[10px]">
                        The Paradox Engine will blend the Order and Chaos Councils into a single evolved concept. Launch a run to see the synthesized blueprint here.
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}