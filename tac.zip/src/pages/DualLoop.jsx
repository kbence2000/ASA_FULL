
import React, { useState, useRef, useEffect } from 'react';
import { Zap, TrendingUp, AlertTriangle, Activity, Waves, Eye } from 'lucide-react';
import { 
  NineMindsMetadata, 
  DistortedSynergyMetadata, 
  dualLoop, 
  distortedSynergyBridge,
  simulateBrainProcessing 
} from '../components/DistortedSynergyUtils';

export default function DualLoop() {
  const [input, setInput] = useState("Create a neural interface for quantum code synthesis");
  const [isProcessing, setIsProcessing] = useState(false);
  const [nineMindsOutput, setNineMindsOutput] = useState([]);
  const [distortedOutput, setDistortedOutput] = useState([]);
  const [deltaAnalysis, setDeltaAnalysis] = useState(null);
  const [currentBrain, setCurrentBrain] = useState(null);
  const [bridgeData, setBridgeData] = useState(null);
  const timelineEndRef = useRef(null);

  useEffect(() => {
    if (timelineEndRef.current) {
      timelineEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [nineMindsOutput, distortedOutput]);

  const runDualLoop = async () => {
    if (isProcessing || !input.trim()) return;

    setIsProcessing(true);
    setNineMindsOutput([]);
    setDistortedOutput([]);
    setDeltaAnalysis(null);
    setBridgeData(null);

    // Bridge initialization
    const bridge = distortedSynergyBridge(input);
    setBridgeData(bridge);

    let processedSignal = input;
    const nineResults = [];
    const distortedResults = [];

    // Process through Nine Minds
    for (let i = 0; i < NineMindsMetadata.length; i++) {
      const brain = NineMindsMetadata[i];
      setCurrentBrain({ system: 'nine', brain });
      
      const output = await simulateBrainProcessing(brain.name, processedSignal, 180);
      nineResults.push({ brain, output });
      setNineMindsOutput([...nineResults]);
      processedSignal = output;
    }

    // Reset signal for distorted processing
    processedSignal = bridge.distorted;

    // Process through Distorted Synergy
    for (let i = 0; i < DistortedSynergyMetadata.length; i++) {
      const brain = DistortedSynergyMetadata[i];
      setCurrentBrain({ system: 'distorted', brain });
      
      const output = await simulateBrainProcessing(brain.name, processedSignal, 180);
      distortedResults.push({ brain, output });
      setDistortedOutput([...distortedResults]);
      processedSignal = output;
    }

    // Final comparison
    const finalNine = nineResults[nineResults.length - 1]?.output || input;
    const finalDistorted = distortedResults[distortedResults.length - 1]?.output || bridge.distorted;
    
    const delta = dualLoop(input);
    setDeltaAnalysis({
      ...delta.delta,
      originalFinal: finalNine,
      distortedFinal: finalDistorted,
      inputOriginal: input,
      inputDistorted: bridge.distorted
    });

    setCurrentBrain(null);
    setIsProcessing(false);
  };

  return (
    <div className="min-h-screen p-4 md:p-6" style={{
      background: 'radial-gradient(circle at 0% 0%, #1a0f2e 0%, #0a0514 30%, #02000c 70%)'
    }}>
      <style>{`
        @keyframes brainPulse {
          0%, 100% { opacity: 0.6; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.05); }
        }

        .active-brain {
          animation: brainPulse 0.8s ease-in-out;
          box-shadow: 0 0 20px currentColor;
        }

        @keyframes deltaAppear {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .delta-card {
          animation: deltaAppear 0.4s ease-out;
        }
      `}</style>

      {/* Container */}
      <div className="max-w-[1200px] mx-auto">
        {/* Header */}
        <div className="mb-6 text-center">
          <div className="flex items-center justify-center gap-3 mb-2">
            <div className="w-6 h-6 rounded-full" style={{
              background: 'conic-gradient(from 0deg, #00ff8a, #ff0066, #00ff8a)',
              boxShadow: '0 0 20px rgba(0, 255, 138, 0.9)'
            }} />
            <h1 className="text-2xl md:text-3xl font-black tracking-wider uppercase text-white">
              DUAL LOOP SYSTEM
            </h1>
            <div className="w-6 h-6 rounded-full" style={{
              background: 'conic-gradient(from 180deg, #ff0066, #00ff8a, #ff0066)',
              boxShadow: '0 0 20px rgba(255, 0, 102, 0.9)'
            }} />
          </div>
          <p className="text-sm text-gray-400 tracking-wide">
            ASYMMETRIC DUALITY · NINE MINDS ⇄ DISTORTED SYNERGY
          </p>
        </div>

        {/* Input Section */}
        <div className="mb-6 rounded-2xl border p-6" style={{
          borderColor: 'rgba(183, 136, 255, 0.3)',
          background: 'rgba(7, 7, 18, 0.95)',
          boxShadow: '0 0 40px rgba(0, 0, 0, 0.7)'
        }}>
          <label className="block text-xs tracking-widest uppercase text-gray-400 mb-3">
            INPUT SIGNAL
          </label>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isProcessing}
            rows={3}
            className="w-full rounded-xl border px-4 py-3 text-sm resize-none"
            style={{
              borderColor: 'rgba(183, 136, 255, 0.3)',
              background: 'rgba(2, 0, 12, 0.9)',
              color: '#f6fff6'
            }}
            placeholder="Enter a concept to process through both systems..."
          />
          
          <div className="flex items-center justify-between mt-4 flex-wrap gap-3">
            <button
              onClick={runDualLoop}
              disabled={isProcessing}
              className="px-6 py-3 rounded-full text-sm font-bold tracking-wider uppercase flex items-center gap-2 transition-all disabled:opacity-40"
              style={{
                background: 'linear-gradient(135deg, #00ff8a, #ff0066)',
                color: '#000',
                boxShadow: isProcessing ? 'none' : '0 0 20px rgba(0, 255, 138, 0.7)'
              }}
            >
              {isProcessing ? (
                <>
                  <div className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                  PROCESSING...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  RUN DUAL LOOP
                </>
              )}
            </button>

            {bridgeData && (
              <div className="flex items-center gap-4 text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-400" style={{ boxShadow: '0 0 8px rgba(0, 255, 138, 0.9)' }} />
                  <span className="text-gray-400">BRIDGE: ACTIVE</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Dual Processing Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
          {/* Nine Minds Panel */}
          <div className="rounded-2xl border p-4" style={{
            borderColor: 'rgba(0, 255, 138, 0.4)',
            background: 'rgba(7, 7, 18, 0.95)',
            boxShadow: '0 0 40px rgba(0, 255, 138, 0.2)'
          }}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs tracking-widest uppercase text-green-400 flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                NINE MINDS
              </h3>
              <span className="text-[0.6rem] text-gray-500">ORIGINAL SYSTEM</span>
            </div>

            {/* Brain Grid */}
            <div className="grid grid-cols-3 gap-2 mb-4">
              {NineMindsMetadata.map((brain, idx) => {
                const isActive = currentBrain?.system === 'nine' && currentBrain?.brain.id === brain.id;
                const isProcessed = nineMindsOutput.some(o => o.brain.id === brain.id);
                
                return (
                  <div
                    key={brain.id}
                    className={`p-2 rounded-lg border text-center transition-all ${isActive ? 'active-brain' : ''}`}
                    style={{
                      borderColor: isProcessed ? `${brain.color}80` : 'rgba(255, 255, 255, 0.1)',
                      background: isProcessed ? `${brain.color}15` : 'rgba(0, 0, 0, 0.3)',
                      color: isActive ? brain.color : (isProcessed ? '#fff' : '#666')
                    }}
                  >
                    <div className="text-[0.6rem] font-bold">{brain.name}</div>
                    <div className="text-[0.5rem] mt-0.5 opacity-70">{brain.role}</div>
                  </div>
                );
              })}
            </div>

            {/* Output Timeline */}
            <div className="max-h-[200px] overflow-y-auto space-y-2">
              {nineMindsOutput.length === 0 && (
                <div className="text-center text-xs text-gray-500 py-8">
                  Awaiting signal processing...
                </div>
              )}
              {nineMindsOutput.map((item, idx) => (
                <div
                  key={idx}
                  className="p-2 rounded-lg border text-xs"
                  style={{
                    borderColor: `${item.brain.color}40`,
                    background: 'rgba(0, 0, 0, 0.4)',
                    borderLeft: `3px solid ${item.brain.color}`
                  }}
                >
                  <div className="font-semibold mb-1" style={{ color: item.brain.color }}>
                    {item.brain.name}
                  </div>
                  <div className="text-gray-300 font-mono text-[0.65rem] break-all">
                    {item.output}
                  </div>
                </div>
              ))}
              <div ref={timelineEndRef} />
            </div>
          </div>

          {/* Distorted Synergy Panel */}
          <div className="rounded-2xl border p-4" style={{
            borderColor: 'rgba(255, 0, 102, 0.4)',
            background: 'rgba(18, 7, 12, 0.95)',
            boxShadow: '0 0 40px rgba(255, 0, 102, 0.2)'
          }}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs tracking-widest uppercase text-red-400 flex items-center gap-2">
                <Waves className="w-4 h-4" />
                DISTORTED SYNERGY
              </h3>
              <span className="text-[0.6rem] text-gray-500">CORRUPTED CLONE</span>
            </div>

            {/* Brain Grid */}
            <div className="grid grid-cols-3 gap-2 mb-4">
              {DistortedSynergyMetadata.map((brain, idx) => {
                const isActive = currentBrain?.system === 'distorted' && currentBrain?.brain.id === brain.id;
                const isProcessed = distortedOutput.some(o => o.brain.id === brain.id);
                
                return (
                  <div
                    key={brain.id}
                    className={`p-2 rounded-lg border text-center transition-all ${isActive ? 'active-brain' : ''}`}
                    style={{
                      borderColor: isProcessed ? `${brain.color}80` : 'rgba(255, 255, 255, 0.1)',
                      background: isProcessed ? `${brain.color}15` : 'rgba(0, 0, 0, 0.3)',
                      color: isActive ? brain.color : (isProcessed ? '#fff' : '#666')
                    }}
                  >
                    <div className="text-[0.6rem] font-bold">{brain.name}</div>
                    <div className="text-[0.5rem] mt-0.5 opacity-70">{brain.role}</div>
                  </div>
                );
              })}
            </div>

            {/* Output Timeline */}
            <div className="max-h-[200px] overflow-y-auto space-y-2">
              {distortedOutput.length === 0 && (
                <div className="text-center text-xs text-gray-500 py-8">
                  Awaiting distorted signal...
                </div>
              )}
              {distortedOutput.map((item, idx) => (
                <div
                  key={idx}
                  className="p-2 rounded-lg border text-xs"
                  style={{
                    borderColor: `${item.brain.color}40`,
                    background: 'rgba(0, 0, 0, 0.4)',
                    borderLeft: `3px solid ${item.brain.color}`
                  }}
                >
                  <div className="font-semibold mb-1" style={{ color: item.brain.color }}>
                    {item.brain.name}
                  </div>
                  <div className="text-gray-300 font-mono text-[0.65rem] break-all">
                    {item.output}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Delta Analysis */}
        {deltaAnalysis && (
          <div className="delta-card rounded-2xl border p-6" style={{
            borderColor: 'rgba(183, 136, 255, 0.4)',
            background: 'rgba(7, 7, 18, 0.95)',
            boxShadow: '0 0 60px rgba(183, 136, 255, 0.3)'
          }}>
            <div className="flex items-center gap-3 mb-4">
              <Activity className="w-5 h-5 text-purple-400" />
              <h3 className="text-sm tracking-widest uppercase text-purple-400">
                DELTA ANALYSIS · ASYMMETRIC DUALITY
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div className="p-3 rounded-xl border" style={{
                borderColor: 'rgba(183, 136, 255, 0.3)',
                background: 'rgba(0, 0, 0, 0.4)'
              }}>
                <div className="text-[0.65rem] text-gray-400 mb-1">LENGTH DIFFERENCE</div>
                <div className="text-lg font-bold text-white">{deltaAnalysis.lengthDifference}</div>
              </div>
              <div className="p-3 rounded-xl border" style={{
                borderColor: 'rgba(183, 136, 255, 0.3)',
                background: 'rgba(0, 0, 0, 0.4)'
              }}>
                <div className="text-[0.65rem] text-gray-400 mb-1">DISTORTION LEVEL</div>
                <div className="text-lg font-bold text-red-400">{(deltaAnalysis.distortionLevel * 100).toFixed(1)}%</div>
              </div>
              <div className="p-3 rounded-xl border" style={{
                borderColor: 'rgba(183, 136, 255, 0.3)',
                background: 'rgba(0, 0, 0, 0.4)'
              }}>
                <div className="text-[0.65rem] text-gray-400 mb-1">COHERENCE</div>
                <div className="text-lg font-bold text-cyan-400">{(deltaAnalysis.coherence * 100).toFixed(1)}%</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl border" style={{
                borderColor: 'rgba(0, 255, 138, 0.3)',
                background: 'rgba(0, 255, 138, 0.05)'
              }}>
                <div className="text-xs font-bold text-green-400 mb-2 flex items-center gap-2">
                  <Eye className="w-3 h-3" />
                  NINE MINDS OUTPUT
                </div>
                <pre className="text-[0.65rem] text-gray-300 font-mono whitespace-pre-wrap break-all">
                  {deltaAnalysis.originalFinal}
                </pre>
              </div>
              <div className="p-4 rounded-xl border" style={{
                borderColor: 'rgba(255, 0, 102, 0.3)',
                background: 'rgba(255, 0, 102, 0.05)'
              }}>
                <div className="text-xs font-bold text-red-400 mb-2 flex items-center gap-2">
                  <AlertTriangle className="w-3 h-3" />
                  DISTORTED SYNERGY OUTPUT
                </div>
                <pre className="text-[0.65rem] text-gray-300 font-mono whitespace-pre-wrap break-all">
                  {deltaAnalysis.distortedFinal}
                </pre>
              </div>
            </div>

            <div className="mt-4 p-3 rounded-xl" style={{
              background: 'rgba(183, 136, 255, 0.1)',
              border: '1px solid rgba(183, 136, 255, 0.3)'
            }}>
              <div className="text-xs text-gray-300">
                <span className="font-bold text-purple-400">Relation:</span> {deltaAnalysis.relation} · 
                <span className="font-bold text-purple-400 ml-2">Entropy:</span> {(deltaAnalysis.entropy * 100).toFixed(1)}%
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
