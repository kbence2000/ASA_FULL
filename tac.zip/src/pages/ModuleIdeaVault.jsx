import React, { useState, useEffect } from 'react';
import { Database, Search, Zap, Activity, Package, Tag, Clock, Sparkles } from 'lucide-react';

export default function ModuleIdeaVault() {
  const [modules, setModules] = useState([]);
  const [filteredModules, setFilteredModules] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedModule, setSelectedModule] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchModules();
  }, []);

  useEffect(() => {
    filterModules();
  }, [searchTerm, selectedCategory, modules]);

  const fetchModules = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('http://localhost:3000/vault/list');
      if (!response.ok) throw new Error('Failed to fetch modules');
      
      const data = await response.json();
      setModules(data.modules || []);
      setFilteredModules(data.modules || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const filterModules = () => {
    let filtered = [...modules];

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(m =>
        m.name.toLowerCase().includes(term) ||
        m.description.toLowerCase().includes(term) ||
        m.tags.some(tag => tag.toLowerCase().includes(term))
      );
    }

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(m => m.category === selectedCategory);
    }

    setFilteredModules(filtered);
  };

  const categories = [...new Set(modules.map(m => m.category))];
  const categoryCounts = categories.reduce((acc, cat) => {
    acc[cat] = modules.filter(m => m.category === cat).length;
    return acc;
  }, {});

  const getCategoryColor = (category) => {
    const colors = {
      'ai-mind': '#ff6ec7',
      'logic-core': '#b788ff',
      'semantic': '#24e4ff',
      'semantic-security': '#4eff8b',
      'noise': '#ffcc4b',
      'noise-defense': '#ff4b81',
      'security': '#ff4b81',
      'math-metric': '#24e4ff',
      'math-format': '#4eff8b',
      'math-security': '#ff4b81',
      'math-converter': '#b788ff',
      'math-mind': '#b788ff',
      'interop': '#24e4ff',
      'meta': '#ff6ec7',
      'meta-evolution': '#b788ff'
    };
    return colors[category] || '#9094b2';
  };

  return (
    <div className="min-h-screen p-4" style={{
      background: 'radial-gradient(circle at top, #0a0a14 0, #030306 55%)'
    }}>
      <style>{`
        .vault-panel {
          background: #0a0a12;
          border: 1px solid #1a1a26;
        }

        .module-card {
          background: #060612;
          border: 1px solid #1a1a26;
          transition: all 0.2s ease-out;
          cursor: pointer;
        }

        .module-card:hover {
          transform: translateY(-2px);
          border-color: rgba(183, 136, 255, 0.4);
        }

        .module-card.selected {
          border-color: #b788ff;
          box-shadow: 0 0 20px rgba(183, 136, 255, 0.3);
        }

        .category-badge {
          transition: all 0.2s ease-out;
        }
      `}</style>

      <div className="max-w-[1600px] mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: 'radial-gradient(circle at 20% 0, #ffffff, #ff6ec7 40%, #b8004f)',
                boxShadow: '0 0 30px rgba(255, 110, 199, 0.6)'
              }}
            >
              <Database className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="text-xl font-bold text-white tracking-wide">
                MODULE IDEA VAULT
              </div>
              <div className="text-xs text-gray-400 tracking-wider">
                AI Module Registry • Atlas • Hybrid Fusion
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-4 py-2 rounded-full" style={{
              background: 'rgba(255, 110, 199, 0.12)',
              border: '1px solid rgba(255, 110, 199, 0.6)'
            }}>
              <Package className="w-3 h-3" style={{ color: '#ff6ec7' }} />
              <span className="text-xs font-semibold" style={{ color: '#ff6ec7' }}>
                {modules.length} MODULES
              </span>
            </div>
            <button
              onClick={fetchModules}
              disabled={isLoading}
              className="px-4 py-2 rounded-full text-xs font-semibold uppercase tracking-wider transition-all"
              style={{
                background: 'rgba(183, 136, 255, 0.2)',
                color: '#b788ff',
                border: '1px solid rgba(183, 136, 255, 0.4)'
              }}
            >
              {isLoading ? <Activity className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3" />}
            </button>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl border border-red-500/50 bg-red-900/10 flex items-center gap-3">
            <div className="text-sm font-bold text-red-400">Error: {error}</div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left: Filters & Categories */}
          <div className="lg:col-span-3 space-y-4">
            {/* Search */}
            <div className="vault-panel rounded-2xl p-4">
              <div className="mb-3">
                <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                  Search Modules
                </div>
              </div>

              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 rounded-xl text-xs"
                  style={{
                    background: '#05050d',
                    border: '1px solid #1a1a26',
                    color: '#a3a7cf'
                  }}
                  placeholder="Search by name, description, tags..."
                />
              </div>
            </div>

            {/* Categories */}
            <div className="vault-panel rounded-2xl p-4">
              <div className="mb-3">
                <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                  Categories
                </div>
              </div>

              <div className="space-y-1">
                <button
                  onClick={() => setSelectedCategory('all')}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs transition-all"
                  style={{
                    background: selectedCategory === 'all' ? 'rgba(183, 136, 255, 0.2)' : 'transparent',
                    color: selectedCategory === 'all' ? '#b788ff' : '#9094b2'
                  }}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">All Modules</span>
                    <span className="text-[10px]">{modules.length}</span>
                  </div>
                </button>

                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs transition-all"
                    style={{
                      background: selectedCategory === cat ? 'rgba(255, 255, 255, 0.05)' : 'transparent',
                      color: selectedCategory === cat ? getCategoryColor(cat) : '#9094b2',
                      borderLeft: selectedCategory === cat ? `3px solid ${getCategoryColor(cat)}` : 'none'
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium truncate">{cat}</span>
                      <span className="text-[10px]">{categoryCounts[cat]}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Center: Module List */}
          <div className="lg:col-span-5 space-y-3 max-h-[800px] overflow-y-auto pr-2">
            {isLoading ? (
              <div className="vault-panel rounded-2xl p-6 flex items-center justify-center">
                <Activity className="w-6 h-6 animate-spin text-gray-500" />
              </div>
            ) : filteredModules.length === 0 ? (
              <div className="vault-panel rounded-2xl p-6 text-center text-gray-500">
                <Database className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <div className="text-sm">No modules found</div>
              </div>
            ) : (
              filteredModules.map(module => (
                <div
                  key={module.id}
                  onClick={() => setSelectedModule(module)}
                  className={`module-card rounded-2xl p-4 ${selectedModule?.id === module.id ? 'selected' : ''}`}
                >
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-bold text-white mb-1 truncate">{module.name}</div>
                      <div className="text-xs text-gray-400 line-clamp-2">{module.description}</div>
                    </div>
                    <div 
                      className="px-2 py-1 rounded-lg text-[9px] font-semibold uppercase tracking-wider flex-shrink-0"
                      style={{
                        background: `${getCategoryColor(module.category)}22`,
                        color: getCategoryColor(module.category),
                        border: `1px solid ${getCategoryColor(module.category)}44`
                      }}
                    >
                      {module.category.split('-')[0]}
                    </div>
                  </div>

                  {module.tags && module.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {module.tags.slice(0, 4).map((tag, idx) => (
                        <div 
                          key={idx}
                          className="px-2 py-0.5 rounded text-[9px] font-mono"
                          style={{
                            background: '#05050d',
                            color: '#9094b2',
                            border: '1px solid #1a1a26'
                          }}
                        >
                          {tag}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>

          {/* Right: Module Details */}
          <div className="lg:col-span-4 space-y-4">
            {!selectedModule ? (
              <div className="vault-panel rounded-2xl p-6 h-full flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <Sparkles className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <div className="text-sm font-semibold">No Module Selected</div>
                  <div className="text-xs mt-1">Click a module to view details</div>
                </div>
              </div>
            ) : (
              <>
                <div className="vault-panel rounded-2xl p-4">
                  <div className="flex items-start gap-3 mb-4">
                    <div 
                      className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{
                        background: `${getCategoryColor(selectedModule.category)}22`,
                        border: `2px solid ${getCategoryColor(selectedModule.category)}44`
                      }}
                    >
                      <Package className="w-6 h-6" style={{ color: getCategoryColor(selectedModule.category) }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-lg font-bold text-white mb-1">{selectedModule.name}</div>
                      <div 
                        className="inline-block px-2 py-1 rounded text-[9px] font-semibold uppercase tracking-wider"
                        style={{
                          background: `${getCategoryColor(selectedModule.category)}22`,
                          color: getCategoryColor(selectedModule.category)
                        }}
                      >
                        {selectedModule.category}
                      </div>
                    </div>
                  </div>

                  <div className="text-xs text-gray-300 leading-relaxed">
                    {selectedModule.description}
                  </div>
                </div>

                {selectedModule.tags && selectedModule.tags.length > 0 && (
                  <div className="vault-panel rounded-2xl p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Tag className="w-4 h-4 text-gray-400" />
                      <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                        Tags
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {selectedModule.tags.map((tag, idx) => (
                        <div 
                          key={idx}
                          className="px-3 py-1 rounded-lg text-xs font-mono"
                          style={{
                            background: 'rgba(183, 136, 255, 0.1)',
                            color: '#b788ff',
                            border: '1px solid rgba(183, 136, 255, 0.3)'
                          }}
                        >
                          {tag}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="vault-panel rounded-2xl p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <Clock className="w-4 h-4 text-gray-400" />
                    <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                      Metadata
                    </div>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Module ID</span>
                      <span className="text-gray-300 font-mono">#{selectedModule.id}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Created</span>
                      <span className="text-gray-300">{new Date(selectedModule.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}