import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import RankBadge from "../components/RankBadge";
import { 
  Flame, TrendingUp, Lock, Crown, Target, 
  Zap, Award, Github, Users, Eye 
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { formatDistanceToNow } from "date-fns";

const BACKEND_URL = import.meta.env.VITE_MDC_BACKEND_URL || "http://localhost:3000";

export default function MostWanted() {
  const [activeType, setActiveType] = useState("global");

  const { data: mostWantedData, isLoading } = useQuery({
    queryKey: ["mostWanted", activeType],
    queryFn: async () => {
      const res = await fetch(`${BACKEND_URL}/api/mostwanted?type=${activeType}&limit=50`);
      if (!res.ok) throw new Error("Failed to fetch Most Wanted list");
      return res.json();
    },
  });

  const demigods = mostWantedData?.result || [];

  const typeConfig = {
    global: {
      title: "Global Most Wanted",
      subtitle: "Top-signal, peer-validated demigods (R3+)",
      icon: Target,
      color: "#8B5CF6",
      gradient: "from-purple-600 to-indigo-700",
    },
    rising: {
      title: "Rising Stars",
      subtitle: "Active in last 7 days, climbing fast",
      icon: TrendingUp,
      color: "#F59E0B",
      gradient: "from-amber-600 to-orange-700",
    },
    vault: {
      title: "Vault Tier",
      subtitle: "Ultra-elite R7 demigods only",
      icon: Lock,
      color: "#FFE38A",
      gradient: "from-yellow-500 to-amber-600",
    },
  };

  const config = typeConfig[activeType];
  const Icon = config.icon;

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#1a1f2e] bg-[#0f1419] mb-4">
            <Flame className="w-4 h-4 text-red-500" />
            <span className="text-sm text-gray-400 uppercase tracking-wider">Most Wanted</span>
          </div>
          <h1 className="text-5xl font-black mb-4" style={{
            background: `linear-gradient(135deg, ${config.color}, #24E4FF)`,
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}>
            {config.title}
          </h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            {config.subtitle}
          </p>
        </div>

        {/* Type Switcher */}
        <Tabs value={activeType} onValueChange={setActiveType} className="mb-8">
          <TabsList className="bg-[#0f1419] border border-[#1a1f2e] grid grid-cols-3 w-full max-w-2xl mx-auto">
            <TabsTrigger value="global" className="data-[state=active]:bg-[#1a1f2e]">
              <Target className="w-4 h-4 mr-2" />
              Global
            </TabsTrigger>
            <TabsTrigger value="rising" className="data-[state=active]:bg-[#1a1f2e]">
              <TrendingUp className="w-4 h-4 mr-2" />
              Rising
            </TabsTrigger>
            <TabsTrigger value="vault" className="data-[state=active]:bg-[#1a1f2e]">
              <Lock className="w-4 h-4 mr-2" />
              Vault
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Info Panel */}
        <Card className="border-[#1a1f2e] bg-[#0f1419] p-6 mb-8">
          <div className="flex items-start gap-4">
            <div 
              className="p-3 rounded-lg"
              style={{
                background: `linear-gradient(135deg, ${config.color}33, transparent)`,
                border: `1px solid ${config.color}66`,
              }}
            >
              <Icon className="w-6 h-6" style={{ color: config.color }} />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-bold text-white mb-2">
                What is "{config.title}"?
              </h3>
              <p className="text-sm text-gray-400 leading-relaxed mb-3">
                {activeType === "global" && (
                  "Ranked by MostWanted Score: 20% Hard Skills + 20% AI Quality + 20% Runtime + 20% Peer Feedback + 10% Community + 10% Total Score + Activity Boost. Only R3+ demigods qualify."
                )}
                {activeType === "rising" && (
                  "Demigods who showed activity in the last 7 days (code runs or recent signup). These are the fast-moving talents climbing the ranks."
                )}
                {activeType === "vault" && (
                  "The absolute elite. Only R7 (Vault Tier) demigods appear here. Perfect 100 score, invite-only tier."
                )}
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge className="bg-purple-600/20 text-purple-300 border border-purple-600/30">
                  R3+ Required
                </Badge>
                <Badge className="bg-blue-600/20 text-blue-300 border border-blue-600/30">
                  Peer Validated
                </Badge>
                <Badge className="bg-green-600/20 text-green-300 border border-green-600/30">
                  Activity Weighted
                </Badge>
              </div>
            </div>
          </div>
        </Card>

        {/* Loading */}
        {isLoading && (
          <div className="text-center py-20">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-purple-600 border-t-transparent"></div>
            <p className="text-gray-400 mt-4">Loading Most Wanted...</p>
          </div>
        )}

        {/* Empty State */}
        {!isLoading && demigods.length === 0 && (
          <Card className="border-[#1a1f2e] bg-[#0f1419] p-12 text-center">
            <Icon className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-white mb-2">No demigods found</h3>
            <p className="text-gray-400">
              {activeType === "vault" 
                ? "No R7 Vault Tier demigods yet. Be the first to reach perfection!"
                : "No qualifying demigods in this category."}
            </p>
          </Card>
        )}

        {/* Most Wanted List */}
        {!isLoading && demigods.length > 0 && (
          <div className="space-y-4">
            {demigods.map((demigod, idx) => (
              <MostWantedCard 
                key={demigod.userId} 
                demigod={demigod} 
                position={idx + 1}
                type={activeType}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function MostWantedCard({ demigod, position, type }) {
  const isTop3 = position <= 3;
  const isVault = type === "vault";

  const positionStyles = {
    1: { icon: Crown, color: "#F4C76A", label: "🥇" },
    2: { icon: Award, color: "#C0C0C0", label: "🥈" },
    3: { icon: Award, color: "#CD7F32", label: "🥉" },
  };

  const posStyle = positionStyles[position];

  return (
    <Link to={createPageUrl("DemigodProfile") + `?userId=${demigod.userId}`}>
      <Card 
        className={`border-[#1a1f2e] bg-[#0f1419] p-6 hover:border-[#262637] transition-all cursor-pointer ${
          isTop3 ? 'hover:shadow-2xl' : ''
        }`}
        style={isTop3 ? {
          border: `1px solid ${posStyle.color}44`,
          background: `radial-gradient(circle at top left, ${posStyle.color}11, transparent 50%), #0f1419`,
        } : {}}
      >
        <div className="flex items-center gap-4">
          {/* Position */}
          <div 
            className="flex-shrink-0 w-16 h-16 rounded-full flex items-center justify-center font-bold text-xl"
            style={isTop3 ? {
              background: `radial-gradient(circle, ${posStyle.color}33, transparent 70%)`,
              border: `2px solid ${posStyle.color}`,
              color: posStyle.color,
            } : {
              background: "#141923",
              color: "#6B7280",
            }}
          >
            {isTop3 ? posStyle.label : `#${position}`}
          </div>

          {/* Rank Badge */}
          <div className="flex-shrink-0">
            <RankBadge rank={demigod.mdcTier.id} size="md" showName={false} />
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="text-xl font-bold text-white truncate">
                {demigod.username || demigod.userId}
              </h3>
              {isVault && (
                <Badge className="bg-yellow-600/20 text-yellow-300 border border-yellow-600/30 flex items-center gap-1">
                  <Lock className="w-3 h-3" />
                  Vault
                </Badge>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-3 text-xs text-gray-400">
              <span className="flex items-center gap-1">
                <Award className="w-3 h-3" />
                {demigod.mdcTier.name}
              </span>
              {demigod.feedbackStats?.count > 0 && (
                <span className="flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  {demigod.feedbackStats.count} reviews
                </span>
              )}
              {demigod.runtime?.lastRunAt && (
                <span className="flex items-center gap-1">
                  <Zap className="w-3 h-3" />
                  Active {formatDistanceToNow(new Date(demigod.runtime.lastRunAt), { addSuffix: true })}
                </span>
              )}
            </div>
          </div>

          {/* Scores */}
          <div className="hidden md:flex items-center gap-6">
            <div className="text-center">
              <div className="text-sm text-gray-500 mb-1">MostWanted</div>
              <div 
                className="text-2xl font-black"
                style={{
                  background: "linear-gradient(135deg, #8B5CF6, #24E4FF)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                }}
              >
                {demigod.mostWantedScore}
              </div>
            </div>

            <div className="text-center">
              <div className="text-sm text-gray-500 mb-1">Total</div>
              <div className="text-2xl font-bold text-white">
                {demigod.scores.totalScore}
              </div>
            </div>
          </div>

          {/* View Profile */}
          <Button 
            size="sm" 
            className="bg-gradient-to-r from-purple-600 to-indigo-700 text-white hover:opacity-90"
          >
            <Eye className="w-4 h-4 mr-2" />
            View
          </Button>
        </div>

        {/* Mobile Scores */}
        <div className="md:hidden mt-4 pt-4 border-t border-[#1a1f2e] flex justify-around">
          <div className="text-center">
            <div className="text-xs text-gray-500 mb-1">MostWanted</div>
            <div 
              className="text-xl font-black"
              style={{
                background: "linear-gradient(135deg, #8B5CF6, #24E4FF)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              {demigod.mostWantedScore}
            </div>
          </div>
          <div className="text-center">
            <div className="text-xs text-gray-500 mb-1">Total Score</div>
            <div className="text-xl font-bold text-white">
              {demigod.scores.totalScore}
            </div>
          </div>
        </div>
      </Card>
    </Link>
  );
}