
import React, { useState, useMemo, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Brain, Sparkles, Code2, Zap, TrendingUp, Award,
  Layers, Target, Copy, Check, RefreshCw, Lock, Download, Upload, AlertCircle, BookOpen
} from "lucide-react";
import { toast } from "sonner";
import { observeCode, SOURCE_TYPES } from "@/components/AlmightyObserver";
import AlmightyIntegrationGuide from "@/components/AlmightyIntegrationGuide";

// Pattern extraction & analysis engine (client-side)
const RANK_WEIGHT = {
  demigod: 3.0,
  elite: 2.2,
  rising: 1.4,
  regular: 1.0,
  unknown: 0.9
};

function rankWeight(rank = "regular") {
  const r = (rank || "").toLowerCase();
  return RANK_WEIGHT[r] || 1.0;
}

function calcLineComplexity(line) {
  const length = line.length;
  const depthChars = (line.match(/[{}()\[\]]/g) || []).length;
  const operators = (line.match(/[+\-/*%=&|<>!?:]/g) || []).length;
  const commas = (line.match(/,/g) || []).length;
  const dots = (line.match(/\./g) || []).length;

  return (
    length * 0.4 +
    depthChars * 2.0 +
    operators * 1.5 +
    commas * 0.8 +
    dots * 0.7
  );
}

function normalizeLine(line) {
  return line
    .replace(/\/\/.*$/, "")
    .replace(/#.*$/, "")
    .trim()
    .replace(/\s+/g, " ");
}

function analyzeSnippet(code, rank, language) {
  const lines = (code || "")
    .split(/\r?\n/)
    .map((l) => l.replace(/\t/g, "    "));

  const scoredLines = lines
    .map((line, idx) => {
      const normalized = normalizeLine(line);
      if (!normalized || normalized.length < 5) return null;
      const complexity = calcLineComplexity(normalized);
      return {
        line,
        normalized,
        lineIndex: idx,
        complexity
      };
    })
    .filter(Boolean);

  scoredLines.sort((a, b) => b.complexity - a.complexity);
  const topLines = scoredLines.slice(0, Math.min(5, scoredLines.length));

  const wRank = rankWeight(rank);

  return topLines.map((entry) => ({
    normalized: entry.normalized,
    rawLine: entry.line,
    weight: entry.complexity * wRank,
    language: language || "unknown",
    complexity: entry.complexity
  }));
}

function aggregatePatterns(allPatterns) {
  const statsMap = new Map();

  allPatterns.forEach((pattern) => {
    const key = pattern.normalized;
    let stats = statsMap.get(key);
    if (!stats) {
      stats = {
        normalized: key,
        totalWeight: 0,
        count: 0,
        examples: []
      };
      statsMap.set(key, stats);
    }
    stats.totalWeight += pattern.weight;
    stats.count += 1;
    if (stats.examples.length < 3) {
      stats.examples.push({
        rawLine: pattern.rawLine,
        language: pattern.language
      });
    }
  });

  return Array.from(statsMap.values())
    .sort((a, b) => b.totalWeight - a.totalWeight);
}

function generateInnovationSuggestions(topPatterns, goal, language) {
  if (!topPatterns || topPatterns.length === 0) {
    return [
      "Az AlmightyCollective Core meg keveset latott - etesd meg PvP/elite kodokkal, utana sokkal erosebb otleteket fog dobni."
    ];
  }

  const suggestions = [];
  const lang = (language || "").toLowerCase();

  topPatterns.slice(0, 10).forEach((p, idx) => {
    const line = p.normalized;

    if (p.totalWeight > 50 && suggestions.length < 4) {
      suggestions.push(
        `Vedd alapmintanak ezt a gondolkodast:\n  ${line}\nes epits kore egy uj "${goal}" modulmagot - utana csomagold be egy ujrafelhasznalhato ${lang || "code"} helper/service formajaba.`
      );
    }

    if (idx < 3 && suggestions.length < 6) {
      suggestions.push(
        `Absztrahald a logikat ebbol a mintabol:\n  ${line}\negy magasabb szintu epitokovave (pl. higher-order function / class / agent step), amit a projekt tobb helyen is hasznalni tudsz.`
      );
    }
  });

  if (suggestions.length === 0) {
    suggestions.push(
      `Epits egy minimal verziót a "${goal}" megoldasbol, majd a legkritikusabb utvonalakat refaktorald az AlmightyCollective legerosebb mintai alapjan.`
    );
  }

  return suggestions;
}

export default function AlmightyCore() {
  const [goal, setGoal] = useState("");
  const [language, setLanguage] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [copied, setCopied] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [masterKey, setMasterKey] = useState("");
  const [showPrivileged, setShowPrivileged] = useState(false);
  const [activeTab, setActiveTab] = useState("core");

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Auto-detect admin user
  useEffect(() => {
    if (user?.role === 'admin') {
      setShowPrivileged(true);
    }
  }, [user]);

  // Mock snippet data - in production, fetch from MDC entities
  const mockSnippets = useMemo(() => [
    {
      id: "sn_001",
      userId: "nova",
      rank: "demigod",
      language: "typescript",
      code: `const processStream = async (stream: ReadableStream) => {\n  const reader = stream.getReader();\n  const decoder = new TextDecoder();\n  let buffer = "";\n  \n  while (true) {\n    const { done, value } = await reader.read();\n    if (done) break;\n    buffer += decoder.decode(value, { stream: true });\n    const lines = buffer.split("\\n");\n    buffer = lines.pop() || "";\n    for (const line of lines) yield JSON.parse(line);\n  }\n};`,
      meta: { source: "coding_pvp", score: 99 }
    },
    {
      id: "sn_002",
      userId: "lyra",
      rank: "demigod",
      language: "rust",
      code: `pub async fn batch_process<T, F, R>(items: Vec<T>, f: F, concurrency: usize) -> Vec<R>\nwhere\n    F: Fn(T) -> Pin<Box<dyn Future<Output = R> + Send>>,\n{\n    use futures::stream::{self, StreamExt};\n    stream::iter(items)\n        .map(f)\n        .buffer_unordered(concurrency)\n        .collect()\n        .await\n}`,
      meta: { source: "innovation_pvp", score: 95 }
    },
    {
      id: "sn_003",
      userId: "user123",
      rank: "rising",
      language: "python",
      code: `@lru_cache(maxsize=1024)\ndef fibonacci_optimized(n: int) -> int:\n    if n <= 1:\n        return n\n    return fibonacci_optimized(n-1) + fibonacci_optimized(n-2)\n\n# Vectorized batch processing\nresults = np.vectorize(fibonacci_optimized)(np.arange(100))`,
      meta: { source: "project", score: 88 }
    }
  ], []);

  // Analyze all snippets and extract patterns
  const allPatterns = useMemo(() => {
    const patterns = [];
    mockSnippets.forEach((snippet) => {
      const extracted = analyzeSnippet(snippet.code, snippet.rank, snippet.language);
      patterns.push(...extracted);
    });
    return patterns;
  }, [mockSnippets]);

  const masterPatterns = useMemo(() => {
    return aggregatePatterns(allPatterns);
  }, [allPatterns]);

  const handleGenerateSuggestions = () => {
    if (!goal.trim()) {
      toast.error("Kérlek, ird le elobb a celod!");
      return;
    }

    setAnalyzing(true);
    setTimeout(() => {
      const result = generateInnovationSuggestions(masterPatterns, goal, language);
      setSuggestions(result);
      setAnalyzing(false);
      toast.success("Innovacios javaslatok generalva!");
    }, 800);
  };

  const handleCopyPattern = (pattern, index) => {
    navigator.clipboard.writeText(pattern.normalized);
    setCopied(index);
    toast.success("Minta a vagolapa masolt!");
    setTimeout(() => setCopied(null), 2000);
  };

  const handleTestObservation = () => {
    // Test observation call
    observeCode({
      userId: user?.id || "test_user",
      rank: user?.role === "admin" ? "demigod" : "regular",
      language: "javascript",
      code: `function testAlmighty() {\n  console.log("Testing AlmightyCollective observation!");\n  return { success: true };\n}`,
      sourceType: SOURCE_TYPES.GENERIC,
      meta: { test: true }
    });
    toast.success("Test observation sent to AlmightyCore!");
  };

  const handleExportState = () => {
    const state = {
      snippets: mockSnippets,
      patterns: allPatterns,
      patternStats: Array.from(masterPatterns.entries())
    };

    const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `almighty-core-state-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("AlmightyCore state exported!");
  };

  const stats = {
    totalSnippets: mockSnippets.length,
    totalPatterns: allPatterns.length,
    masterPatterns: masterPatterns.length,
    avgWeight: masterPatterns.length > 0
      ? (masterPatterns.reduce((sum, p) => sum + p.totalWeight, 0) / masterPatterns.length).toFixed(1)
      : 0
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 grid-pattern opacity-30" />
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl" />
        
        <div className="relative max-w-7xl mx-auto px-4 py-20">
          <div className="max-w-4xl">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6" style={{
              background: 'rgba(183, 136, 255, 0.1)',
              border: '1px solid rgba(183, 136, 255, 0.3)'
            }}>
              <Brain className="w-4 h-4 text-purple-400" />
              <span className="text-sm font-mono uppercase tracking-wider text-purple-300">
                DarkBox Evolutionary Engine
              </span>
            </div>

            <h1 className="text-5xl lg:text-6xl font-black mb-6">
              <span className="gradient-text">AlmightyCollective</span>
              <br />
              Core
            </h1>

            <p className="text-xl text-gray-400 mb-8 leading-relaxed">
              A mintatanitó motor, amely az elit demigod kodbol kiemeli a mestermintakat.
              Etesd snipetekkel, es megtanitja neked az excelencia epitokockait.
            </p>

            <div className="flex flex-wrap gap-6 text-sm">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-purple-400" />
                <span className="text-gray-400">{stats.totalSnippets} snippet elemezve</span>
              </div>
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span className="text-gray-400">{stats.masterPatterns} mesterminta</span>
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-pink-400" />
                <span className="text-gray-400">Atlag suly: {stats.avgWeight}</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tabs */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="bg-[#0f1419] border border-[#1a1f2e] mb-8">
              <TabsTrigger value="core" className="data-[state=active]:bg-purple-600/20 data-[state=active]:text-white">
                <Brain className="w-4 h-4 mr-2" />
                Core Engine
              </TabsTrigger>
              <TabsTrigger value="integration" className="data-[state=active]:bg-cyan-600/20 data-[state=active]:text-white">
                <BookOpen className="w-4 h-4 mr-2" />
                Backend Integration
              </TabsTrigger>
            </TabsList>

            <TabsContent value="core">
              <div className="grid lg:grid-cols-[1.5fr_1.2fr] gap-6">
                {/* Master Patterns Panel */}
                <Card className="border-purple-500/30 bg-[#0b0816]">
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                          <Code2 className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h2 className="text-xl font-bold text-white">Mestermintaok</h2>
                          <p className="text-sm text-gray-400">Legerosebb ismetlodo sorok az elit kodbol</p>
                        </div>
                      </div>
                      <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30">
                        {masterPatterns.length} minta
                      </Badge>
                    </div>

                    <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
                      {masterPatterns.slice(0, 30).map((pattern, idx) => (
                        <div
                          key={idx}
                          className="rounded-lg border border-purple-500/20 bg-[#050013] p-4 hover:border-purple-500/40 transition-all group"
                        >
                          <div className="flex items-start justify-between mb-2">
                            <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30 text-xs">
                              #{idx + 1}
                            </Badge>
                            <button
                              onClick={() => handleCopyPattern(pattern, idx)}
                              className="opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              {copied === idx ? (
                                <Check className="w-4 h-4 text-green-400" />
                              ) : (
                                <Copy className="w-4 h-4 text-gray-400 hover:text-purple-400" />
                              )}
                            </button>
                          </div>

                          <div className="bg-[#0a0318] rounded-md p-3 mb-3 font-mono text-xs text-purple-200 overflow-x-auto">
                            {pattern.normalized}
                          </div>

                          <div className="flex items-center justify-between text-xs">
                            <div className="flex items-center gap-3 text-gray-500">
                              <span>Suly: <strong className="text-cyan-400">{pattern.totalWeight.toFixed(1)}</strong></span>
                              <span>Latta: <strong className="text-pink-400">{pattern.count}x</strong></span>
                            </div>
                            <div className="flex gap-1">
                              {pattern.examples.slice(0, 2).map((ex, i) => (
                                <Badge key={i} className="bg-gray-800 text-gray-400 text-xs">
                                  {ex.language}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {masterPatterns.length === 0 && (
                      <div className="text-center py-20">
                        <Brain className="w-16 h-16 text-gray-600 mx-auto mb-4 opacity-50" />
                        <p className="text-gray-500">Meg nincs minta. Etesd a magot elit snipetekkel!</p>
                      </div>
                    )}
                  </div>
                </Card>

                {/* Innovation Suggestion Panel + Stats + Controls */}
                <div className="space-y-6">
                  <Card className="border-cyan-500/30 bg-[#0b0816]">
                    <div className="p-6">
                      <div className="flex items-center gap-3 mb-6">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center">
                          <Sparkles className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h2 className="text-xl font-bold text-white">Innovacios Kohaszat</h2>
                          <p className="text-sm text-gray-400">AI javaslatok a tanult mintakbol</p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <label className="text-sm text-gray-400 mb-2 block">Ird le a celod</label>
                          <Textarea
                            value={goal}
                            onChange={(e) => setGoal(e.target.value)}
                            placeholder="pl. Epitsd fel egy skalazható event-driven API-t a tehetségkutato marketplace-hez..."
                            className="bg-[#050013] border-purple-500/30 text-white min-h-[100px]"
                          />
                        </div>

                        <div>
                          <label className="text-sm text-gray-400 mb-2 block">Nyelv (opcionalos)</label>
                          <Input
                            value={language}
                            onChange={(e) => setLanguage(e.target.value)}
                            placeholder="pl. typescript, rust, python"
                            className="bg-[#050013] border-purple-500/30 text-white"
                          />
                        </div>

                        <Button
                          onClick={handleGenerateSuggestions}
                          disabled={analyzing}
                          className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:opacity-90"
                        >
                          {analyzing ? (
                            <>
                              <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                              Mintok elemzese...
                            </>
                          ) : (
                            <>
                              <Zap className="w-4 h-4 mr-2" />
                              Javaslatok Generalasa
                            </>
                          )}
                        </Button>
                      </div>

                      {suggestions.length > 0 && (
                        <div className="mt-6 space-y-3">
                          <div className="flex items-center gap-2 text-sm text-gray-400">
                            <Target className="w-4 h-4" />
                            <span>Javaslatok {masterPatterns.length} mesterminta alapjan</span>
                          </div>
                          {suggestions.map((suggestion, idx) => (
                            <div
                              key={idx}
                              className="rounded-lg border border-cyan-500/20 bg-[#050013] p-4"
                            >
                              <div className="flex items-start gap-3">
                                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-cyan-500 to-purple-500 flex items-center justify-center flex-shrink-0 text-xs font-bold text-white">
                                  {idx + 1}
                                </div>
                                <p className="text-sm text-gray-300 leading-relaxed whitespace-pre-wrap">
                                  {suggestion}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </Card>

                  <Card className="border-pink-500/30 bg-[#0b0816]">
                    <div className="p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <Award className="w-5 h-5 text-pink-400" />
                        <h3 className="font-bold text-white">Core Statisztikak</h3>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <div className="text-xs text-gray-400 mb-1">Osszes Snippet</div>
                          <div className="text-2xl font-bold text-white">{stats.totalSnippets}</div>
                        </div>
                        <div>
                          <div className="text-xs text-gray-400 mb-1">Kivont Mintak</div>
                          <div className="text-2xl font-bold text-purple-400">{stats.totalPatterns}</div>
                        </div>
                        <div>
                          <div className="text-xs text-gray-400 mb-1">Mestermintak</div>
                          <div className="text-2xl font-bold text-cyan-400">{stats.masterPatterns}</div>
                        </div>
                        <div>
                          <div className="text-xs text-gray-400 mb-1">Atlag Suly</div>
                          <div className="text-2xl font-bold text-pink-400">{stats.avgWeight}</div>
                        </div>
                      </div>
                    </div>
                  </Card>

                  {/* Privileged Controls (Admin Only) */}
                  {showPrivileged && (
                    <Card className="border-yellow-500/30 bg-gradient-to-br from-yellow-900/20 to-orange-900/20">
                      <div className="p-6">
                        <div className="flex items-center gap-3 mb-4">
                          <Lock className="w-5 h-5 text-yellow-400" />
                          <h3 className="font-bold text-white">Privileged Controls</h3>
                        </div>
                        <div className="space-y-3">
                          <Button
                            onClick={handleTestObservation}
                            variant="outline"
                            className="w-full border-purple-500/30 hover:border-purple-500/50"
                          >
                            <Brain className="w-4 h-4 mr-2" />
                            Test Observation
                          </Button>
                          <Button
                            onClick={handleExportState}
                            variant="outline"
                            className="w-full border-cyan-500/30 hover:border-cyan-500/50"
                          >
                            <Download className="w-4 h-4 mr-2" />
                            Export State
                          </Button>
                          {/* Removed ROOT_MASTER_KEY input as per instructions */}
                        </div>
                      </div>
                    </Card>
                  )}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="integration">
              <AlmightyIntegrationGuide />
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Integration Points (This section remains outside the tabs, as it's general info) */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-black mb-4">
              <span className="gradient-text">Auto-Observation Points</span>
            </h2>
            <p className="text-gray-400">
              AlmightyCore automatikusan tanul az MDC platform minden kodfolyamatabol
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { name: "Coding PvP", desc: "Battle snippets auto-observed", color: "from-orange-500 to-red-500" },
              { name: "Innovation PvP", desc: "Challenge submissions tracked", color: "from-purple-500 to-pink-500" },
              { name: "App Uploads", desc: "Full codebase analyzed", color: "from-cyan-500 to-blue-500" },
              { name: "Project Stakes", desc: "Staked code monitored", color: "from-green-500 to-emerald-500" },
              { name: "Demigod Tips", desc: "Expert code shared", color: "from-yellow-500 to-amber-500" },
              { name: "Cloud Runtime", desc: "Execution patterns learned", color: "from-indigo-500 to-violet-500" }
            ].map((point, idx) => (
              <div key={idx} className="glass-card p-6 text-center hover-lift">
                <div className={`w-12 h-12 mx-auto mb-4 rounded-xl bg-gradient-to-br ${point.color} flex items-center justify-center`}>
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-white mb-2">{point.name}</h3>
                <p className="text-sm text-gray-400">{point.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
