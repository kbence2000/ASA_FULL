import React, { useState } from 'react';
import { Activity, Zap, AlertTriangle, CheckCircle2, TrendingUp, AlertCircle } from 'lucide-react';

export default function CNAnalyzer() {
  const [inputText, setInputText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('http://localhost:3000/cn/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: inputText })
      });

      if (!response.ok) throw new Error('Analysis failed');
      
      const data = await response.json();
      setResult(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const loadExample = (type) => {
    if (type === 'clean') {
      setInputText('This is a well-structured, professional message with clear semantic meaning and appropriate technical depth.');
    } else if (type === 'complex') {
      setInputText('The implementation leverages asynchronous paradigms, incorporates distributed consensus mechanisms, and utilizes sophisticated heuristic algorithms for optimal resource allocation across heterogeneous computing environments.');
    } else if (type === 'noisy') {
      setInputText('OMG!!! This is SOOOO COOL!!! 🔥🔥🔥 Like seriously the BEST thing EVER!!! 💯💯💯');
    } else if (type === 'garbage') {
      setInputText('asdkjfh!!!@@## RANDOM text wiiiiith TOO many!!!!! symbols@@@@ and WEIRD casing');
    }
  };

  const getClassificationColor = (classification) => {
    switch (classification) {
      case 'high-value': return { bg: '#4eff8b', text: '#4eff8b', glow: 'rgba(78, 255, 139, 0.4)' };
      case 'clean': return { bg: '#24e4ff', text: '#24e4ff', glow: 'rgba(36, 228, 255, 0.4)' };
      case 'noisy': return { bg: '#ffcc4b', text: '#ffcc4b', glow: 'rgba(255, 204, 75, 0.4)' };
      case 'critical-noise': return { bg: '#ff4b81', text: '#ff4b81', glow: 'rgba(255, 75, 129, 0.4)' };
      default: return { bg: '#9094b2', text: '#9094b2', glow: 'rgba(144, 148, 178, 0.4)' };
    }
  };

  const getScoreGradient = (score, max = 5) => {
    const percentage = (score / max) * 100;
    if (percentage < 33) return 'from-green-500 to-green-600';
    if (percentage < 66) return 'from-yellow-500 to-yellow-600';
    return 'from-red-500 to-red-600';
  };

  return (
    <div className="min-h-screen p-4" style={{
      background: 'radial-gradient(circle at top, #0a0a14 0, #030306 55%)'
    }}>
      <style>{`
        .cn-panel {
          background: #0a0a12;
          border: 1px solid #1a1a26;
        }

        .result-panel {
          background: #05050d;
          border: 1px solid #1a1a26;
        }

        .score-bar {
          height: 8px;
          border-radius: 4px;
          overflow: hidden;
          background: #1a1a26;
        }

        .score-fill {
          height: 100%;
          transition: width 0.5s ease-out;
        }
      `}</style>

      <div className="max-w-[1400px] mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: 'radial-gradient(circle at 20% 0, #ffffff, #24e4ff 40%, #0b6b6f)',
                boxShadow: '0 0 30px rgba(36, 228, 255, 0.6)'
              }}
            >
              <Activity className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="text-xl font-bold text-white tracking-wide">
                C/N ANALYZER
              </div>
              <div className="text-xs text-gray-400 tracking-wider">
                Complexity / Noise Ratio Engine
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full" style={{
            background: 'rgba(36, 228, 255, 0.12)',
            border: '1px solid rgba(36, 228, 255, 0.6)'
          }}>
            <div className="w-2 h-2 rounded-full pulse-dot" style={{ background: '#24e4ff' }} />
            <span className="text-xs font-semibold" style={{ color: '#24e4ff' }}>
              ACTIVE
            </span>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-4 p-3 rounded-xl border border-red-500/50 bg-red-900/10 flex items-center gap-3">
            <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Error</div>
              <div className="text-xs text-gray-300 mt-0.5">{error}</div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left: Input */}
          <div className="lg:col-span-5 space-y-4">
            <div className="cn-panel rounded-2xl p-4">
              <div className="mb-3">
                <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                  Input Text
                </div>
                <div className="text-[10px] text-gray-500">
                  Enter text for complexity/noise analysis
                </div>
              </div>

              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                className="w-full h-[300px] rounded-xl p-4 text-xs resize-none"
                style={{
                  background: '#05050d',
                  border: '1px solid #1a1a26',
                  color: '#a3a7cf'
                }}
                placeholder="Enter text to analyze complexity and noise levels..."
              />

              <div className="mt-3 grid grid-cols-4 gap-2">
                <button
                  onClick={() => loadExample('clean')}
                  className="px-2 py-2 rounded-xl text-[9px] font-semibold uppercase tracking-wider transition-all hover:bg-white/5"
                  style={{
                    background: 'rgba(255, 255, 255, 0.02)',
                    color: '#9094b2',
                    border: '1px solid rgba(255, 255, 255, 0.08)'
                  }}
                >
                  Clean
                </button>
                <button
                  onClick={() => loadExample('complex')}
                  className="px-2 py-2 rounded-xl text-[9px] font-semibold uppercase tracking-wider transition-all hover:bg-white/5"
                  style={{
                    background: 'rgba(255, 255, 255, 0.02)',
                    color: '#9094b2',
                    border: '1px solid rgba(255, 255, 255, 0.08)'
                  }}
                >
                  Complex
                </button>
                <button
                  onClick={() => loadExample('noisy')}
                  className="px-2 py-2 rounded-xl text-[9px] font-semibold uppercase tracking-wider transition-all hover:bg-white/5"
                  style={{
                    background: 'rgba(255, 255, 255, 0.02)',
                    color: '#9094b2',
                    border: '1px solid rgba(255, 255, 255, 0.08)'
                  }}
                >
                  Noisy
                </button>
                <button
                  onClick={() => loadExample('garbage')}
                  className="px-2 py-2 rounded-xl text-[9px] font-semibold uppercase tracking-wider transition-all hover:bg-white/5"
                  style={{
                    background: 'rgba(255, 255, 255, 0.02)',
                    color: '#9094b2',
                    border: '1px solid rgba(255, 255, 255, 0.08)'
                  }}
                >
                  Garbage
                </button>
              </div>
            </div>

            <button
              onClick={handleAnalyze}
              disabled={isAnalyzing || !inputText}
              className="w-full px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all disabled:opacity-40"
              style={{
                background: 'radial-gradient(circle at 20% 0, #ffffff, #24e4ff 40%, #08b8b8 70%)',
                color: '#020206',
                boxShadow: isAnalyzing ? 'none' : '0 8px 24px rgba(36, 228, 255, 0.6)'
              }}
            >
              {isAnalyzing ? (
                <>
                  <Activity className="w-4 h-4 animate-spin" />
                  ANALYZING...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  ANALYZE C/N RATIO
                </>
              )}
            </button>
          </div>

          {/* Right: Results */}
          <div className="lg:col-span-7 space-y-4">
            {!result ? (
              <div className="cn-panel rounded-2xl p-6 h-full flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <Activity className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <div className="text-sm font-semibold">No Analysis Yet</div>
                  <div className="text-xs mt-1">Enter text and run analysis</div>
                </div>
              </div>
            ) : (
              <>
                {/* Classification */}
                <div className="cn-panel rounded-2xl p-4">
                  <div className="flex items-center justify-between">
                    <div className="text-xs text-gray-400 uppercase tracking-wider">Classification</div>
                    <div 
                      className="px-6 py-2 rounded-full text-sm font-bold uppercase tracking-wider"
                      style={{
                        background: `${getClassificationColor(result.classification).glow}`,
                        color: getClassificationColor(result.classification).text,
                        border: `2px solid ${getClassificationColor(result.classification).text}`
                      }}
                    >
                      {result.classification}
                    </div>
                  </div>
                </div>

                {/* Scores */}
                <div className="cn-panel rounded-2xl p-4">
                  <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-4">
                    Metrics
                  </div>

                  <div className="space-y-4">
                    {/* Complexity */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <TrendingUp className="w-4 h-4 text-purple-400" />
                          <span className="text-xs text-gray-400">Complexity</span>
                        </div>
                        <span className="text-sm font-bold text-white">{result.complexity.toFixed(3)}</span>
                      </div>
                      <div className="score-bar">
                        <div 
                          className={`score-fill bg-gradient-to-r ${getScoreGradient(result.complexity)}`}
                          style={{ width: `${(result.complexity / 5) * 100}%` }}
                        />
                      </div>
                    </div>

                    {/* Noise */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <AlertCircle className="w-4 h-4 text-yellow-400" />
                          <span className="text-xs text-gray-400">Noise</span>
                        </div>
                        <span className="text-sm font-bold text-white">{result.noise.toFixed(3)}</span>
                      </div>
                      <div className="score-bar">
                        <div 
                          className={`score-fill bg-gradient-to-r ${getScoreGradient(result.noise)}`}
                          style={{ width: `${(result.noise / 5) * 100}%` }}
                        />
                      </div>
                    </div>

                    {/* Ratio */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Activity className="w-4 h-4 text-cyan-400" />
                          <span className="text-xs text-gray-400">C/N Ratio</span>
                        </div>
                        <span className="text-sm font-bold text-white">{result.ratio.toFixed(3)}</span>
                      </div>
                      <div className="score-bar">
                        <div 
                          className="score-fill bg-gradient-to-r from-cyan-500 to-cyan-600"
                          style={{ width: `${Math.min((result.ratio / 5) * 100, 100)}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Interpretation */}
                <div className="cn-panel rounded-2xl p-4">
                  <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
                    Interpretation
                  </div>

                  <div className="result-panel rounded-xl p-4 space-y-2 text-xs text-gray-300">
                    {result.classification === 'high-value' && (
                      <>
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0" />
                          <span>High-value content: Complex with minimal noise</span>
                        </div>
                        <div className="text-[11px] text-gray-400 ml-6">
                          This text demonstrates sophisticated structure and semantic depth while maintaining clarity.
                        </div>
                      </>
                    )}
                    {result.classification === 'clean' && (
                      <>
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                          <span>Clean content: Good complexity/noise balance</span>
                        </div>
                        <div className="text-[11px] text-gray-400 ml-6">
                          Well-structured text with appropriate complexity and low noise levels.
                        </div>
                      </>
                    )}
                    {result.classification === 'noisy' && (
                      <>
                        <div className="flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4 text-yellow-400 flex-shrink-0" />
                          <span>Noisy content: Elevated noise levels detected</span>
                        </div>
                        <div className="text-[11px] text-gray-400 ml-6">
                          The text contains significant noise that may obscure its intended meaning.
                        </div>
                      </>
                    )}
                    {result.classification === 'critical-noise' && (
                      <>
                        <div className="flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
                          <span>Critical noise: Very high noise/complexity ratio</span>
                        </div>
                        <div className="text-[11px] text-gray-400 ml-6">
                          Excessive noise dominates the content, severely impacting interpretability.
                        </div>
                      </>
                    )}

                    <div className="border-t border-gray-700 pt-2 mt-3">
                      <div className="text-[10px] text-gray-500">
                        C/N Ratio Guide: &gt;4 = High Value • &gt;2 = Clean • &gt;1 = Noisy • ≤1 = Critical
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}