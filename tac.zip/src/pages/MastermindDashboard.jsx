import React from "react";
import MastermindPanel from "../components/MastermindPanel";

export default function MastermindDashboard() {
  return <MastermindPanel />;
}