import React, { useState, useRef, useEffect } from 'react';
import { Infinity, Loader2, AlertTriangle, Zap, TrendingUp, Gauge, Activity, Layers, Target } from 'lucide-react';

export default function InfinityExpansionEngine() {
  const [label, setLabel] = useState("TAC Core v1");
  const [energyDensity, setEnergyDensity] = useState(1.8);
  const [curvature, setCurvature] = useState(0.4);
  const [entropy, setEntropy] = useState(2.1);
  const [radius, setRadius] = useState(3.5);
  const [complexity, setComplexity] = useState(2.7);
  const [connectivity, setConnectivity] = useState(3.2);
  const [darkEnergyProjection, setDarkEnergyProjection] = useState(0.62);
  const [field1998Symmetry, setField1998Symmetry] = useState(1.0);
  const [antiField1998Symmetry, setAntiField1998Symmetry] = useState(-1.0);
  const [isRunning, setIsRunning] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const canvasRef = useRef(null);

  // Animated infinity spiral background
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    let rotation = 0;
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    let animationId;
    const animate = () => {
      ctx.fillStyle = 'rgba(10, 5, 0, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      rotation += 0.005;

      // Draw expanding spirals (infinity expansion)
      for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        for (let angle = 0; angle < Math.PI * 4; angle += 0.1) {
          const r = (angle * 8) + (i * 20) + (rotation * 30);
          const x = centerX + r * Math.cos(angle + rotation + i);
          const y = centerY + r * Math.sin(angle + rotation + i);
          if (angle === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.strokeStyle = `rgba(255, 165, 0, ${0.3 / (i + 1)})`;
        ctx.lineWidth = 2;
        ctx.stroke();
      }

      // Draw pulsing infinity symbol at center
      const scale = 1 + Math.sin(rotation * 2) * 0.2;
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.scale(scale, scale);
      
      // Draw infinity symbol (∞)
      ctx.beginPath();
      for (let t = 0; t < Math.PI * 2; t += 0.01) {
        const x = 40 * Math.cos(t) / (1 + Math.sin(t) * Math.sin(t));
        const y = 40 * Math.sin(t) * Math.cos(t) / (1 + Math.sin(t) * Math.sin(t));
        if (t === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      ctx.strokeStyle = 'rgba(255, 165, 0, 0.8)';
      ctx.lineWidth = 3;
      ctx.stroke();
      ctx.restore();

      animationId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const runExpansion = async () => {
    if (isRunning) return;

    setIsRunning(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('http://localhost:9112/api/infinity/expand', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          label,
          energyDensity,
          curvature,
          entropy,
          radius,
          complexity,
          connectivity,
          darkEnergyProjection,
          field1998Symmetry,
          antiField1998Symmetry
        })
      });

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();

      if (data.status !== 'ok') {
        throw new Error(data.message || 'Unknown backend error');
      }

      setResult(data);

    } catch (err) {
      console.error('Infinity Expansion error:', err);
      setError(err.message);
    } finally {
      setIsRunning(false);
    }
  };

  const getTrendColor = (trend) => {
    switch (trend) {
      case 'latent': return '#3b82f6';
      case 'emerging': return '#22c55e';
      case 'expanding': return '#f59e0b';
      case 'runaway': return '#ef4444';
      default: return '#9ca3af';
    }
  };

  return (
    <div className="relative min-h-screen overflow-hidden" style={{
      background: 'radial-gradient(circle at 50% 0%, #1a0f05 0%, #0a0502 30%, #02000c 70%)'
    }}>
      <style>{`
        @keyframes infinityPulse {
          0%, 100% { opacity: 0.7; transform: scale(1) rotate(0deg); }
          50% { opacity: 1; transform: scale(1.1) rotate(180deg); }
        }

        @keyframes shimmerOrange {
          0% { background-position: -1000px 0; }
          100% { background-position: 1000px 0; }
        }

        @keyframes expandFloat {
          0%, 100% { transform: translateY(0px) scale(1); }
          50% { transform: translateY(-10px) scale(1.02); }
        }

        .infinity-badge {
          animation: infinityPulse 4s ease-in-out infinite;
        }

        .expand-card {
          animation: expandFloat 6s ease-in-out infinite;
        }

        .shimmer-infinity {
          background: linear-gradient(90deg, #ff8c00, #ffa500, #ffd700, #ffa500, #ff8c00);
          background-size: 200% 100%;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: shimmerOrange 4s linear infinite;
        }

        .infinity-border {
          position: relative;
        }

        .infinity-border::before {
          content: '';
          position: absolute;
          inset: -2px;
          border-radius: inherit;
          padding: 2px;
          background: linear-gradient(135deg, rgba(255, 165, 0, 0.6), transparent, rgba(255, 165, 0, 0.6));
          -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          -webkit-mask-composite: xor;
          mask-composite: exclude;
        }
      `}</style>

      {/* Animated Background Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ opacity: 0.5 }}
      />

      {/* Main Content */}
      <div className="relative z-10 max-w-[1800px] mx-auto px-4 py-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-3">
            <Infinity className="w-16 h-16 text-orange-500 infinity-badge" />
            <h1 className="text-5xl md:text-6xl font-black tracking-wider uppercase shimmer-infinity">
              INFINITY EXPANSION ENGINE
            </h1>
          </div>
          <p className="text-sm text-gray-400 tracking-wide mb-2">
            Ultra Mathematical Framework :: Infinite Growth Potential Analysis
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs uppercase tracking-wider"
            style={{
              background: 'rgba(255, 165, 0, 0.15)',
              border: '1px solid rgba(255, 165, 0, 0.5)',
              boxShadow: '0 0 20px rgba(255, 165, 0, 0.3)'
            }}
          >
            <Zap className="w-3 h-3" />
            Hooks: Dark Energy · 1998-Field · Anti-1998 · Paradox
          </div>
        </div>

        {/* Info Banner */}
        <div className="mb-6 p-4 rounded-2xl border infinity-border"
          style={{
            background: 'rgba(255, 165, 0, 0.08)',
            borderColor: 'rgba(255, 165, 0, 0.3)'
          }}
        >
          <div className="flex items-start gap-3">
            <Infinity className="w-5 h-5 text-orange-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <span className="font-bold text-orange-300">Infinity Expansion Theory:</span>
              <br />
              Mathematical model for infinite growth potential. Combines energy density, curvature, entropy, radius, complexity, and connectivity.
              Optionally integrates with Dark Energy Projection, 1998-Field Symmetry, and Anti-1998-Field Symmetry for multi-dimensional analysis.
              <br />
              <span className="text-orange-400 font-semibold">Output:</span> Infinity Index, Branching Factor, Entropy Acceleration, Collapse Probability + AI narrative.
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 rounded-xl border border-red-500/50 bg-red-900/20 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Backend Connection Error</div>
              <div className="text-xs text-gray-300 mt-1">{error}</div>
              <div className="text-xs text-gray-400 mt-2">
                Make sure the backend server is running: <code className="bg-black/40 px-2 py-0.5 rounded">node infinity-expansion-engine.js</code> on port 9112
              </div>
            </div>
          </div>
        )}

        {/* Main Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          {/* Left: Input Controls */}
          <div className="xl:col-span-5 space-y-4">
            <div className="infinity-border rounded-2xl border p-6"
              style={{
                borderColor: 'rgba(255, 165, 0, 0.3)',
                background: 'rgba(10, 5, 0, 0.95)',
                boxShadow: '0 0 40px rgba(0, 0, 0, 0.7)'
              }}
            >
              <label className="block text-xs tracking-widest uppercase text-orange-400 mb-3">
                LABEL / IDENTIFIER
              </label>
              <input
                type="text"
                value={label}
                onChange={(e) => setLabel(e.target.value)}
                disabled={isRunning}
                className="w-full rounded-xl border px-4 py-2 text-sm mb-4"
                style={{
                  borderColor: 'rgba(255, 165, 0, 0.4)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#fff5e6'
                }}
                placeholder="e.g., TAC Core v1, Module X, System Y..."
              />

              <div className="text-xs tracking-wider uppercase text-orange-400 mb-3">
                CORE PARAMETERS (Required)
              </div>

              <div className="grid grid-cols-2 gap-3 mb-4">
                <div>
                  <label className="block text-xs text-gray-400 mb-1">Energy Density</label>
                  <input
                    type="number"
                    step="0.1"
                    value={energyDensity}
                    onChange={(e) => setEnergyDensity(parseFloat(e.target.value))}
                    disabled={isRunning}
                    className="w-full rounded-lg border px-3 py-2 text-sm"
                    style={{
                      borderColor: 'rgba(255, 165, 0, 0.3)',
                      background: 'rgba(2, 0, 12, 0.9)',
                      color: '#fff5e6'
                    }}
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-400 mb-1">Curvature</label>
                  <input
                    type="number"
                    step="0.1"
                    value={curvature}
                    onChange={(e) => setCurvature(parseFloat(e.target.value))}
                    disabled={isRunning}
                    className="w-full rounded-lg border px-3 py-2 text-sm"
                    style={{
                      borderColor: 'rgba(255, 165, 0, 0.3)',
                      background: 'rgba(2, 0, 12, 0.9)',
                      color: '#fff5e6'
                    }}
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-400 mb-1">Entropy</label>
                  <input
                    type="number"
                    step="0.1"
                    value={entropy}
                    onChange={(e) => setEntropy(parseFloat(e.target.value))}
                    disabled={isRunning}
                    className="w-full rounded-lg border px-3 py-2 text-sm"
                    style={{
                      borderColor: 'rgba(255, 165, 0, 0.3)',
                      background: 'rgba(2, 0, 12, 0.9)',
                      color: '#fff5e6'
                    }}
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-400 mb-1">Radius</label>
                  <input
                    type="number"
                    step="0.1"
                    value={radius}
                    onChange={(e) => setRadius(parseFloat(e.target.value))}
                    disabled={isRunning}
                    className="w-full rounded-lg border px-3 py-2 text-sm"
                    style={{
                      borderColor: 'rgba(255, 165, 0, 0.3)',
                      background: 'rgba(2, 0, 12, 0.9)',
                      color: '#fff5e6'
                    }}
                  />
                </div>
              </div>

              <div className="text-xs tracking-wider uppercase text-orange-400 mb-3">
                OPTIONAL PARAMETERS
              </div>

              <div className="grid grid-cols-2 gap-3 mb-4">
                <div>
                  <label className="block text-xs text-gray-400 mb-1">Complexity</label>
                  <input
                    type="number"
                    step="0.1"
                    value={complexity}
                    onChange={(e) => setComplexity(parseFloat(e.target.value))}
                    disabled={isRunning}
                    className="w-full rounded-lg border px-3 py-2 text-sm"
                    style={{
                      borderColor: 'rgba(255, 165, 0, 0.3)',
                      background: 'rgba(2, 0, 12, 0.9)',
                      color: '#fff5e6'
                    }}
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-400 mb-1">Connectivity</label>
                  <input
                    type="number"
                    step="0.1"
                    value={connectivity}
                    onChange={(e) => setConnectivity(parseFloat(e.target.value))}
                    disabled={isRunning}
                    className="w-full rounded-lg border px-3 py-2 text-sm"
                    style={{
                      borderColor: 'rgba(255, 165, 0, 0.3)',
                      background: 'rgba(2, 0, 12, 0.9)',
                      color: '#fff5e6'
                    }}
                  />
                </div>
              </div>

              <div className="text-xs tracking-wider uppercase text-orange-400 mb-3">
                INTEGRATION HOOKS
              </div>

              <div className="grid grid-cols-1 gap-3 mb-4">
                <div>
                  <label className="block text-xs text-gray-400 mb-1">Dark Energy Projection (0-1)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="1"
                    value={darkEnergyProjection}
                    onChange={(e) => setDarkEnergyProjection(parseFloat(e.target.value))}
                    disabled={isRunning}
                    className="w-full rounded-lg border px-3 py-2 text-sm"
                    style={{
                      borderColor: 'rgba(255, 165, 0, 0.3)',
                      background: 'rgba(2, 0, 12, 0.9)',
                      color: '#fff5e6'
                    }}
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-gray-400 mb-1">1998-Field Symmetry</label>
                    <input
                      type="number"
                      step="0.1"
                      value={field1998Symmetry}
                      onChange={(e) => setField1998Symmetry(parseFloat(e.target.value))}
                      disabled={isRunning}
                      className="w-full rounded-lg border px-3 py-2 text-sm"
                      style={{
                        borderColor: 'rgba(255, 165, 0, 0.3)',
                        background: 'rgba(2, 0, 12, 0.9)',
                        color: '#fff5e6'
                      }}
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-400 mb-1">Anti-1998 Symmetry</label>
                    <input
                      type="number"
                      step="0.1"
                      value={antiField1998Symmetry}
                      onChange={(e) => setAntiField1998Symmetry(parseFloat(e.target.value))}
                      disabled={isRunning}
                      className="w-full rounded-lg border px-3 py-2 text-sm"
                      style={{
                        borderColor: 'rgba(255, 165, 0, 0.3)',
                        background: 'rgba(2, 0, 12, 0.9)',
                        color: '#fff5e6'
                      }}
                    />
                  </div>
                </div>
              </div>

              <button
                onClick={runExpansion}
                disabled={isRunning}
                className="w-full py-3 rounded-full text-sm font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                style={{
                  background: 'linear-gradient(135deg, #ff8c00, #ffa500)',
                  color: '#1a0f05',
                  boxShadow: isRunning ? 'none' : '0 0 30px rgba(255, 165, 0, 0.6)'
                }}
              >
                {isRunning ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    EXPANDING...
                  </>
                ) : (
                  <>
                    <Infinity className="w-5 h-5" />
                    COMPUTE INFINITY EXPANSION
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Right: Output */}
          <div className="xl:col-span-7">
            <div className="rounded-2xl border p-6 h-full"
              style={{
                borderColor: 'rgba(255, 165, 0, 0.4)',
                background: 'rgba(10, 5, 0, 0.95)',
                boxShadow: '0 0 60px rgba(255, 165, 0, 0.2)'
              }}
            >
              <h3 className="text-xs tracking-widest uppercase text-orange-400 mb-4 flex items-center gap-2">
                <Target className="w-4 h-4" />
                INFINITY EXPANSION ANALYSIS
              </h3>

              {!result && !isRunning && (
                <div className="text-center py-12">
                  <Infinity className="w-16 h-16 mx-auto mb-4 text-orange-500/30" />
                  <p className="text-sm text-gray-500">
                    No expansion analysis generated yet.
                    <br />
                    Configure parameters and click "Compute Infinity Expansion".
                  </p>
                </div>
              )}

              {isRunning && (
                <div className="text-center py-12">
                  <Loader2 className="w-16 h-16 mx-auto mb-4 text-orange-500 animate-spin" />
                  <p className="text-sm text-gray-400">
                    Computing infinite expansion potential...
                  </p>
                </div>
              )}

              {result && result.math && (
                <div className="space-y-4 max-h-[800px] overflow-y-auto">
                  {/* Key Metrics */}
                  <div className="expand-card grid grid-cols-2 md:grid-cols-4 gap-3"
                    style={{ animationDelay: '0s' }}
                  >
                    <div className="p-3 rounded-xl text-center"
                      style={{
                        background: 'rgba(255, 165, 0, 0.1)',
                        border: '1px solid rgba(255, 165, 0, 0.3)'
                      }}
                    >
                      <div className="text-xs text-gray-400 mb-1">Infinity Index</div>
                      <div className="text-2xl font-bold text-orange-300">
                        {result.math.infinityIndex.toFixed(2)}
                      </div>
                      <div 
                        className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full mt-1"
                        style={{
                          background: `${getTrendColor(result.math.growthTrend)}30`,
                          color: getTrendColor(result.math.growthTrend)
                        }}
                      >
                        {result.math.growthTrend}
                      </div>
                    </div>

                    <div className="p-3 rounded-xl text-center"
                      style={{
                        background: 'rgba(255, 165, 0, 0.1)',
                        border: '1px solid rgba(255, 165, 0, 0.3)'
                      }}
                    >
                      <div className="text-xs text-gray-400 mb-1">Branching Factor</div>
                      <div className="text-2xl font-bold text-orange-300">
                        {result.math.branchingFactor.toFixed(1)}
                      </div>
                    </div>

                    <div className="p-3 rounded-xl text-center"
                      style={{
                        background: 'rgba(255, 165, 0, 0.1)',
                        border: '1px solid rgba(255, 165, 0, 0.3)'
                      }}
                    >
                      <div className="text-xs text-gray-400 mb-1">Entropy Accel</div>
                      <div className="text-2xl font-bold text-orange-300">
                        {result.math.entropyAcceleration.toFixed(2)}
                      </div>
                    </div>

                    <div className="p-3 rounded-xl text-center"
                      style={{
                        background: 'rgba(239, 68, 68, 0.15)',
                        border: '1px solid rgba(239, 68, 68, 0.3)'
                      }}
                    >
                      <div className="text-xs text-gray-400 mb-1">Collapse Risk</div>
                      <div className="text-2xl font-bold text-red-400">
                        {(result.math.collapseProbability * 100).toFixed(1)}%
                      </div>
                    </div>
                  </div>

                  {/* Detailed Metrics */}
                  <div className="expand-card"
                    style={{ animationDelay: '0.1s' }}
                  >
                    <div className="text-xs font-bold text-orange-300 mb-2 flex items-center gap-2">
                      <Gauge className="w-4 h-4" />
                      DETAILED METRICS
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-xs">
                      <div className="p-2 rounded" style={{ background: 'rgba(255, 165, 0, 0.05)', border: '1px solid rgba(255, 165, 0, 0.15)' }}>
                        <span className="text-gray-400">Expansion Potential:</span>
                        <div className="text-white font-semibold">{result.math.expansionPotential.toFixed(3)}</div>
                      </div>
                      <div className="p-2 rounded" style={{ background: 'rgba(255, 165, 0, 0.05)', border: '1px solid rgba(255, 165, 0, 0.15)' }}>
                        <span className="text-gray-400">Symmetry Influence:</span>
                        <div className="text-white font-semibold">{result.math.symmetryInfluence.toFixed(3)}</div>
                      </div>
                      <div className="p-2 rounded" style={{ background: 'rgba(255, 165, 0, 0.05)', border: '1px solid rgba(255, 165, 0, 0.15)' }}>
                        <span className="text-gray-400">Dark Weight:</span>
                        <div className="text-white font-semibold">{result.math.darkWeight.toFixed(3)}</div>
                      </div>
                      <div className="p-2 rounded" style={{ background: 'rgba(255, 165, 0, 0.05)', border: '1px solid rgba(255, 165, 0, 0.15)' }}>
                        <span className="text-gray-400">Normalized Infinity:</span>
                        <div className="text-white font-semibold">{(result.math.normalizedInfinity * 100).toFixed(1)}%</div>
                      </div>
                      <div className="p-2 rounded" style={{ background: 'rgba(255, 165, 0, 0.05)', border: '1px solid rgba(255, 165, 0, 0.15)' }}>
                        <span className="text-gray-400">Complexity:</span>
                        <div className="text-white font-semibold">{result.math.complexity.toFixed(2)}</div>
                      </div>
                      <div className="p-2 rounded" style={{ background: 'rgba(255, 165, 0, 0.05)', border: '1px solid rgba(255, 165, 0, 0.15)' }}>
                        <span className="text-gray-400">Connectivity:</span>
                        <div className="text-white font-semibold">{result.math.connectivity.toFixed(2)}</div>
                      </div>
                    </div>
                  </div>

                  {/* AI Narrative */}
                  {result.narrative && !result.narrative.parseError && (
                    <>
                      {/* Explanation */}
                      {result.narrative.explanation && (
                        <div className="expand-card p-4 rounded-xl"
                          style={{
                            background: 'rgba(255, 165, 0, 0.12)',
                            border: '2px solid rgba(255, 165, 0, 0.4)',
                            animationDelay: '0.2s',
                            boxShadow: '0 0 30px rgba(255, 165, 0, 0.3)'
                          }}
                        >
                          <div className="text-xs font-bold text-orange-300 mb-2">EXPLANATION</div>
                          <div className="text-sm text-white leading-relaxed">{result.narrative.explanation}</div>
                        </div>
                      )}

                      {/* Creative vs Risk */}
                      {result.narrative.creativeVsRisk && (
                        <div className="expand-card p-4 rounded-xl"
                          style={{
                            background: 'rgba(255, 165, 0, 0.1)',
                            border: '1px solid rgba(255, 165, 0, 0.3)',
                            animationDelay: '0.3s'
                          }}
                        >
                          <div className="text-xs font-bold text-orange-300 mb-2">CREATIVE POTENTIAL vs INSTABILITY RISK</div>
                          <div className="text-xs text-gray-300 leading-relaxed">{result.narrative.creativeVsRisk}</div>
                        </div>
                      )}

                      {/* Integration Hints */}
                      {result.narrative.integrationHints && (
                        <div className="expand-card"
                          style={{ animationDelay: '0.4s' }}
                        >
                          <div className="text-xs font-bold text-orange-300 mb-2 flex items-center gap-2">
                            <Layers className="w-4 h-4" />
                            INTEGRATION HINTS
                          </div>
                          <div className="space-y-2">
                            {result.narrative.integrationHints.field1998 && (
                              <div className="p-3 rounded-lg" style={{ background: 'rgba(255, 215, 0, 0.1)', border: '1px solid rgba(255, 215, 0, 0.3)' }}>
                                <div className="text-xs text-yellow-300 font-semibold mb-1">→ 1998-Field:</div>
                                <div className="text-xs text-gray-300">{result.narrative.integrationHints.field1998}</div>
                              </div>
                            )}
                            {result.narrative.integrationHints.antiField1998 && (
                              <div className="p-3 rounded-lg" style={{ background: 'rgba(139, 0, 139, 0.1)', border: '1px solid rgba(139, 0, 139, 0.3)' }}>
                                <div className="text-xs text-purple-300 font-semibold mb-1">→ Anti-1998-Field:</div>
                                <div className="text-xs text-gray-300">{result.narrative.integrationHints.antiField1998}</div>
                              </div>
                            )}
                            {result.narrative.integrationHints.darkEnergy && (
                              <div className="p-3 rounded-lg" style={{ background: 'rgba(75, 0, 130, 0.1)', border: '1px solid rgba(75, 0, 130, 0.3)' }}>
                                <div className="text-xs text-indigo-300 font-semibold mb-1">→ Dark Energy:</div>
                                <div className="text-xs text-gray-300">{result.narrative.integrationHints.darkEnergy}</div>
                              </div>
                            )}
                            {result.narrative.integrationHints.paradoxEngine && (
                              <div className="p-3 rounded-lg" style={{ background: 'rgba(34, 197, 94, 0.1)', border: '1px solid rgba(34, 197, 94, 0.3)' }}>
                                <div className="text-xs text-green-300 font-semibold mb-1">→ Paradox Engine:</div>
                                <div className="text-xs text-gray-300">{result.narrative.integrationHints.paradoxEngine}</div>
                              </div>
                            )}
                            {result.narrative.integrationHints.matrixUI && (
                              <div className="p-3 rounded-lg" style={{ background: 'rgba(36, 228, 255, 0.1)', border: '1px solid rgba(36, 228, 255, 0.3)' }}>
                                <div className="text-xs text-cyan-300 font-semibold mb-1">→ Matrix UI:</div>
                                <div className="text-xs text-gray-300">{result.narrative.integrationHints.matrixUI}</div>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Architect Notes */}
                      {result.narrative.architectNotes && (
                        <div className="expand-card p-4 rounded-xl"
                          style={{
                            background: 'rgba(255, 165, 0, 0.08)',
                            border: '1px solid rgba(255, 165, 0, 0.3)',
                            animationDelay: '0.5s'
                          }}
                        >
                          <div className="text-xs font-bold text-orange-300 mb-2">ARCHITECT RECOMMENDATIONS</div>
                          <ul className="space-y-1">
                            {result.narrative.architectNotes.map((note, i) => (
                              <li key={i} className="flex items-start gap-2 text-xs text-gray-300">
                                <span className="text-orange-400">•</span>
                                <span>{note}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer Info */}
        <div className="mt-6 text-center text-xs text-gray-500">
          <p>Infinity Expansion Ultra Engine :: Mathematical Growth Potential Framework</p>
          <p className="mt-1">Backend: http://localhost:9112/api/infinity/expand</p>
          <p className="mt-1 text-orange-500/60">Fictional mathematical model for TAC/Paradox/Field ecosystem.</p>
        </div>
      </div>
    </div>
  );
}