import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Cpu, Shield, Activity, Grid3x3, Terminal } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import CoreHeartbeatMonitor from "../components/CoreHeartbeatMonitor";
import CoreModuleManager from "../components/CoreModuleManager";
import CoreSecurityMonitor from "../components/CoreSecurityMonitor";
import CoreSwarmEvents from "../components/CoreSwarmEvents";

export default function CoreDashboard() {
  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Admin check
  if (user && user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md w-full p-8 text-center border" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <Terminal className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Admin Only</h2>
          <p className="text-gray-400">
            Core Dashboard requires administrator privileges
          </p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br from-purple-500 to-cyan-500">
              <Cpu className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-black text-white">Core Dashboard</h1>
              <p className="text-gray-400">MDC Backend API Control Center</p>
            </div>
          </div>
        </div>

        {/* Heartbeat Monitor */}
        <div className="mb-6">
          <CoreHeartbeatMonitor />
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="modules" className="space-y-6">
          <TabsList className="bg-[#0f1419] border border-[#1a1f2e]">
            <TabsTrigger value="modules" className="data-[state=active]:bg-purple-600/20">
              <Grid3x3 className="w-4 h-4 mr-2" />
              Modules
            </TabsTrigger>
            <TabsTrigger value="security" className="data-[state=active]:bg-cyan-600/20">
              <Shield className="w-4 h-4 mr-2" />
              Security
            </TabsTrigger>
            <TabsTrigger value="swarm" className="data-[state=active]:bg-orange-600/20">
              <Activity className="w-4 h-4 mr-2" />
              Swarm Events
            </TabsTrigger>
          </TabsList>

          <TabsContent value="modules">
            <CoreModuleManager />
          </TabsContent>

          <TabsContent value="security">
            <CoreSecurityMonitor />
          </TabsContent>

          <TabsContent value="swarm">
            <CoreSwarmEvents />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}