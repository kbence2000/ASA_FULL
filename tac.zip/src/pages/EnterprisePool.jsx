import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  Briefcase, DollarSign, Code2, Award,
  Send, TrendingUp, Users, Lock
} from "lucide-react";
import { toast } from "sonner";
import RankBadge from "../components/RankBadge";

const STAKE_API = import.meta.env.VITE_STAKE_BACKEND_URL || "http://localhost:3005";

const STAKE_TIER_CONFIG = {
  S0: { label: "Rejected", color: "text-red-400" },
  S1: { label: "Acceptable", color: "text-gray-400" },
  S2: { label: "Good", color: "text-blue-400" },
  S3: { label: "High-Value", color: "text-cyan-400" },
  S4: { label: "Enterprise-Ready", color: "text-purple-400" },
  S5: { label: "Godlike-Enterprise", color: "text-yellow-400" }
};

export default function EnterprisePool() {
  const [minTier, setMinTier] = useState("S1");
  const [category, setCategory] = useState("all");
  const [minBudget, setMinBudget] = useState("");
  const [maxBudget, setMaxBudget] = useState("");
  const [selectedProject, setSelectedProject] = useState(null);
  const [engagementBudget, setEngagementBudget] = useState("");
  const [engagementNotes, setEngagementNotes] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: pool = [], isLoading } = useQuery({
    queryKey: ['enterprisePool', minTier, category, minBudget, maxBudget],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (minTier !== "all") params.set('minTier', minTier);
      if (category !== "all") params.set('category', category);
      if (minBudget) params.set('minBudget', minBudget);
      if (maxBudget) params.set('maxBudget', maxBudget);

      const res = await fetch(`${STAKE_API}/api/stake/pool?${params.toString()}`);
      if (!res.ok) return [];
      return res.json();
    },
    refetchInterval: 30000,
  });

  const requestMutation = useMutation({
    mutationFn: async ({ projectId, companyId, budgetEUR, notes }) => {
      const res = await fetch(`${STAKE_API}/api/stake/request-engagement`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ projectId, companyId, budgetEUR, notes })
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Engagement request failed');
      }
      return res.json();
    },
    onSuccess: (data) => {
      toast.success(`Engagement requested! Developer will review your offer.`);
      setDialogOpen(false);
      setSelectedProject(null);
      setEngagementBudget("");
      setEngagementNotes("");
    },
    onError: (error) => {
      toast.error(error.message);
    }
  });

  const openRequestDialog = (project) => {
    setSelectedProject(project);
    setEngagementBudget(project.suggestedBudgetEUR?.toString() || "");
    setEngagementNotes("");
    setDialogOpen(true);
  };

  const handleSendRequest = () => {
    if (!user) {
      toast.error("Please login first");
      return;
    }
    if (!selectedProject) return;
    if (!engagementBudget || Number(engagementBudget) < 100) {
      toast.error("Budget must be at least €100");
      return;
    }

    requestMutation.mutate({
      projectId: selectedProject.id,
      companyId: user.email,
      budgetEUR: Number(engagementBudget),
      notes: engagementNotes
    });
  };

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#1a1f2e] bg-[#0f1419] mb-4">
            <Briefcase className="w-4 h-4 text-indigo-500" />
            <span className="text-sm text-gray-400 uppercase tracking-wider">Enterprise Talent Pool</span>
          </div>
          <h1 className="text-5xl font-black mb-4" style={{
            background: "linear-gradient(135deg, #6366F1, #8B5CF6)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}>
            Enterprise Code Pool
          </h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Pre-vetted, staked projects from R1-R7 developers. AI-evaluated for enterprise readiness (S1-S5 tiers).
          </p>
        </div>

        {/* Stats Banner */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="border-[#1a1f2e] bg-[#0f1419] p-4 text-center">
            <Lock className="w-6 h-6 text-indigo-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{pool.length}</div>
            <div className="text-xs text-gray-400">Staked Projects</div>
          </Card>

          <Card className="border-[#1a1f2e] bg-[#0f1419] p-4 text-center">
            <Award className="w-6 h-6 text-purple-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">
              {pool.filter(p => p.stakeTier === "S4" || p.stakeTier === "S5").length}
            </div>
            <div className="text-xs text-gray-400">Enterprise-Ready (S4+)</div>
          </Card>

          <Card className="border-[#1a1f2e] bg-[#0f1419] p-4 text-center">
            <TrendingUp className="w-6 h-6 text-cyan-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">
              {pool.filter(p => p.enterpriseFitScore >= 80).length}
            </div>
            <div className="text-xs text-gray-400">High Enterprise Fit</div>
          </Card>

          <Card className="border-[#1a1f2e] bg-[#0f1419] p-4 text-center">
            <DollarSign className="w-6 h-6 text-green-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">18%</div>
            <div className="text-xs text-gray-400">Platform Fee</div>
          </Card>
        </div>

        {/* Filters */}
        <Card className="border-[#1a1f2e] bg-[#0f1419] p-6 mb-8">
          <h3 className="text-lg font-bold text-white mb-4">Filter Pool</h3>
          <div className="grid md:grid-cols-4 gap-4">
            <div>
              <label className="text-xs text-gray-400 block mb-1">Min Stake Tier</label>
              <Select value={minTier} onValueChange={setMinTier}>
                <SelectTrigger className="bg-[#141923] border-[#1a1f2e] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Tiers</SelectItem>
                  <SelectItem value="S1">S1+ (Acceptable)</SelectItem>
                  <SelectItem value="S2">S2+ (Good)</SelectItem>
                  <SelectItem value="S3">S3+ (High-Value)</SelectItem>
                  <SelectItem value="S4">S4+ (Enterprise-Ready)</SelectItem>
                  <SelectItem value="S5">S5 (Godlike)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-xs text-gray-400 block mb-1">Category</label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="bg-[#141923] border-[#1a1f2e] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="dev-tool">Dev Tool</SelectItem>
                  <SelectItem value="ai-tool">AI Tool</SelectItem>
                  <SelectItem value="niche-saas">Niche SaaS</SelectItem>
                  <SelectItem value="general-saas">General SaaS</SelectItem>
                  <SelectItem value="backend-service">Backend Service</SelectItem>
                  <SelectItem value="fullstack-app">Fullstack App</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-xs text-gray-400 block mb-1">Min Budget (€)</label>
              <Input
                type="number"
                value={minBudget}
                onChange={(e) => setMinBudget(e.target.value)}
                className="bg-[#141923] border-[#1a1f2e] text-white"
                placeholder="500"
              />
            </div>

            <div>
              <label className="text-xs text-gray-400 block mb-1">Max Budget (€)</label>
              <Input
                type="number"
                value={maxBudget}
                onChange={(e) => setMaxBudget(e.target.value)}
                className="bg-[#141923] border-[#1a1f2e] text-white"
                placeholder="50000"
              />
            </div>
          </div>
        </Card>

        {/* Pool Grid */}
        {isLoading ? (
          <div className="text-center py-20">
            <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-gray-400 mt-4">Loading pool...</p>
          </div>
        ) : pool.length === 0 ? (
          <div className="text-center py-20">
            <Lock className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-white mb-2">No Projects Found</h3>
            <p className="text-gray-400">Try adjusting your filters</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pool.map((project) => {
              const tierCfg = STAKE_TIER_CONFIG[project.stakeTier] || STAKE_TIER_CONFIG.S1;
              
              return (
                <Card key={project.id} className="border-[#1a1f2e] bg-[#0f1419] p-6 hover:border-indigo-500/50 transition-all">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-white mb-1">{project.title}</h3>
                      <p className="text-xs text-gray-400">by {project.ownerName}</p>
                    </div>
                    <Badge className={`${tierCfg.color} bg-[#141923] border-[#1a1f2e]`}>
                      {project.stakeTier}
                    </Badge>
                  </div>

                  {project.description && (
                    <p className="text-sm text-gray-300 mb-3 line-clamp-2">
                      {project.description}
                    </p>
                  )}

                  <div className="flex items-center gap-2 mb-3 flex-wrap">
                    <Badge className="bg-blue-600/20 text-blue-400 border-blue-600/30 text-xs">
                      {project.language}
                    </Badge>
                    <Badge className="bg-purple-600/20 text-purple-400 border-purple-600/30 text-xs">
                      {project.category}
                    </Badge>
                    <Badge className="bg-gray-600/20 text-gray-400 border-gray-600/30 text-xs">
                      {project.linesOfCode} LOC
                    </Badge>
                  </div>

                  {project.tags && project.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-3">
                      {project.tags.slice(0, 3).map((tag) => (
                        <span key={tag} className="text-xs px-2 py-0.5 rounded-full bg-[#141923] text-gray-400 border border-[#1a1f2e]">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-2 mb-4 text-xs">
                    <div className="p-2 rounded bg-[#141923] border border-[#1a1f2e] text-center">
                      <div className="font-bold text-white">{project.stakeScore}/100</div>
                      <div className="text-gray-500">Stake Score</div>
                    </div>
                    <div className="p-2 rounded bg-[#141923] border border-[#1a1f2e] text-center">
                      <div className="font-bold text-indigo-400">{project.enterpriseFitScore}/100</div>
                      <div className="text-gray-500">Enterprise Fit</div>
                    </div>
                  </div>

                  <div className="p-3 rounded-lg bg-gradient-to-br from-green-600/10 to-emerald-600/10 border border-green-600/30 mb-4">
                    <div className="text-xs text-gray-400 mb-1">AI Budget Estimate</div>
                    <div className="text-lg font-bold text-green-400">
                      €{project.suggestedBudgetEUR?.toLocaleString()}
                    </div>
                    <div className="text-xs text-gray-500">
                      Range: €{project.basePriceMinEUR?.toLocaleString()} - €{project.basePriceMaxEUR?.toLocaleString()}
                    </div>
                  </div>

                  <Button
                    onClick={() => openRequestDialog(project)}
                    className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Request Engagement
                  </Button>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Engagement Request Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md bg-[#0A0E14] border-[#1a1f2e]">
          <DialogHeader>
            <DialogTitle className="text-white">Request Engagement</DialogTitle>
            <DialogDescription className="text-gray-400">
              Send offer to {selectedProject?.ownerName} for {selectedProject?.title}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <label className="text-xs text-gray-400 block mb-1">Your Budget (€)</label>
              <Input
                type="number"
                value={engagementBudget}
                onChange={(e) => setEngagementBudget(e.target.value)}
                className="bg-[#141923] border-[#1a1f2e] text-white"
                placeholder={selectedProject?.suggestedBudgetEUR?.toString()}
              />
              <p className="text-xs text-gray-500 mt-1">
                AI Suggested: €{selectedProject?.suggestedBudgetEUR?.toLocaleString()}
              </p>
            </div>

            {engagementBudget && Number(engagementBudget) > 0 && (
              <div className="p-3 rounded-lg bg-[#141923] border border-[#1a1f2e] text-xs">
                <div className="flex justify-between mb-1">
                  <span className="text-gray-400">Total Budget</span>
                  <span className="text-white font-bold">€{Number(engagementBudget).toLocaleString()}</span>
                </div>
                <div className="flex justify-between mb-1">
                  <span className="text-gray-400">Platform Fee (18%)</span>
                  <span className="text-red-400">-€{Math.round(Number(engagementBudget) * 0.18).toLocaleString()}</span>
                </div>
                <div className="flex justify-between pt-1 border-t border-[#1a1f2e]">
                  <span className="text-gray-400">Developer Receives</span>
                  <span className="text-green-400 font-bold">€{Math.round(Number(engagementBudget) * 0.82).toLocaleString()}</span>
                </div>
              </div>
            )}

            <div>
              <label className="text-xs text-gray-400 block mb-1">Project Notes (optional)</label>
              <Textarea
                value={engagementNotes}
                onChange={(e) => setEngagementNotes(e.target.value)}
                className="bg-[#141923] border-[#1a1f2e] text-white h-24"
                placeholder="Describe what you need, timeline, requirements..."
              />
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setDialogOpen(false)}
                className="flex-1 border-[#1a1f2e] text-white"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSendRequest}
                disabled={requestMutation.isPending}
                className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold"
              >
                {requestMutation.isPending ? "Sending..." : "Send Request"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}