import React, { useState } from 'react';
import { Box, FileText, Shield, Activity, TrendingUp, Layers, Eye, Zap, CheckCircle2, AlertTriangle, Loader2, Package, BookOpen, Code2, ArrowRight, Maximize2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export default function ArchIntegration() {
  const [activeTab, setActiveTab] = useState('pkgbuild');
  const [pkgbuildText, setPkgbuildText] = useState(`# Maintainer: TAC Developer <tac@maddevcity.com>
pkgname=tac-core
pkgver=1.0.0
pkgrel=1
pkgdesc="TAC Core Intelligence Engine"
url="https://maddevcity.com/tac"
depends=('nodejs' 'python' 'redis')
makedepends=('gcc' 'make')
optdepends=('postgresql: for advanced data storage')
`);
  
  const [descriptor, setDescriptor] = useState(JSON.stringify({
    name: 'tac-paradox-engine',
    deps: ['base44-sdk', 'openai', 'n8n-client'],
    linesOfCode: 450,
    features: ['paradox-analysis', 'dual-loop', 'ninefold-processing'],
    flags: {
      minimal: true,
      experimental: false,
      monolithic: false,
      hasReadme: true,
      hasDoc: true,
      archStyle: true
    }
  }, null, 2));
  
  const [wikiText, setWikiText] = useState(`= TAC Core Engine =

TAC is a self-evolving AI orchestration platform.

== Installation ==

Install via npm:
  npm install @tac/core

== Configuration ==

Edit the config file at ~/.tac/config.json

== Usage ==

Basic usage:
  tac init
  tac run --mode paradox

== Advanced Features ==

=== Dual Loop System ===

The dual loop combines Nine Minds and Distorted Synergy.

See also: [[Nine Minds]], [[Distorted Synergy]]

=== Mission Loop ===

Automated mission generation and execution.

External docs: [Official Docs](https://docs.tac.ai)
`);

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [error, setError] = useState(null);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [backendUrl] = useState('http://localhost:9988');
  const queryClient = useQueryClient();

  // Fetch package list
  const { data: packages = [] } = useQuery({
    queryKey: ['arch-packages'],
    queryFn: async () => {
      const list = await base44.entities.ArchIntegration.list('-created_date', 50);
      return list;
    },
    refetchInterval: 10000
  });

  // Save package mutation
  const savePackageMutation = useMutation({
    mutationFn: async (packageData) => {
      return await base44.entities.ArchIntegration.create(packageData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['arch-packages'] });
    }
  });

  const analyzePkgbuild = async () => {
    setIsAnalyzing(true);
    setError(null);
    setAnalysisResult(null);

    try {
      const response = await fetch(`${backendUrl}/api/arch/pkg/analyze-pkgbuild`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pkgbuildText })
      });

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status}`);
      }

      const data = await response.json();
      setAnalysisResult({ type: 'pkgbuild', data: data.analysis });

    } catch (err) {
      console.error('PKGBUILD analysis error:', err);
      setError(err.message);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const registerPackage = async () => {
    if (!analysisResult || analysisResult.type !== 'pkgbuild') {
      setError('Analyze PKGBUILD first before registering');
      return;
    }

    setIsAnalyzing(true);
    setError(null);

    try {
      const parsedDescriptor = JSON.parse(descriptor);
      
      const response = await fetch(`${backendUrl}/api/arch/pkg/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: analysisResult.data.meta.pkgname || 'unknown-package',
          pkgbuildText,
          descriptor: parsedDescriptor
        })
      });

      if (!response.ok) {
        throw new Error(`Registration error: ${response.status}`);
      }

      const data = await response.json();
      
      // Calculate arch affinity level
      const affinity = data.record.logicScore.overallArchAffinity;
      let affinityLevel = 'low';
      if (affinity >= 0.8) affinityLevel = 'elite';
      else if (affinity >= 0.6) affinityLevel = 'high';
      else if (affinity >= 0.4) affinityLevel = 'medium';

      // Save to database
      await savePackageMutation.mutateAsync({
        packageName: data.record.name,
        pkgMeta: data.record.pkgMeta,
        pkgStats: data.record.pkgStats,
        logicScore: data.record.logicScore,
        descriptor: parsedDescriptor,
        pkgbuildText,
        registeredAt: data.record.registeredAt,
        status: 'active',
        archAffinity: affinityLevel
      });

      setAnalysisResult({
        type: 'registered',
        data: data.record
      });

    } catch (err) {
      console.error('Registration error:', err);
      setError(err.message);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const parseWiki = async () => {
    setIsAnalyzing(true);
    setError(null);
    setAnalysisResult(null);

    try {
      const response = await fetch(`${backendUrl}/api/arch/wiki/parse`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ docText: wikiText })
      });

      if (!response.ok) {
        throw new Error(`Wiki parse error: ${response.status}`);
      }

      const data = await response.json();
      setAnalysisResult({ type: 'wiki', data: data.parsed });

    } catch (err) {
      console.error('Wiki parse error:', err);
      setError(err.message);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const emulateLogic = async () => {
    setIsAnalyzing(true);
    setError(null);
    setAnalysisResult(null);

    try {
      const parsedDescriptor = JSON.parse(descriptor);
      
      const response = await fetch(`${backendUrl}/api/arch/logic/emulate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ descriptor: parsedDescriptor })
      });

      if (!response.ok) {
        throw new Error(`Logic emulation error: ${response.status}`);
      }

      const data = await response.json();
      setAnalysisResult({ type: 'logic', data: data.score });

    } catch (err) {
      console.error('Logic emulation error:', err);
      setError(err.message);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getAffinityColor = (score) => {
    if (score >= 0.8) return '#4eff8b';
    if (score >= 0.6) return '#24e4ff';
    if (score >= 0.4) return '#ffdb7c';
    return '#ff4b81';
  };

  const getComplexityColor = (complexity) => {
    switch (complexity) {
      case 'minimal': return '#4eff8b';
      case 'medium': return '#24e4ff';
      case 'high': return '#ff4b81';
      default: return '#8c8faf';
    }
  };

  return (
    <div className="min-h-screen p-4" style={{
      background: 'radial-gradient(circle at top, #0a0a14 0, #030306 55%)'
    }}>
      <style>{`
        .arch-card {
          transition: all 0.3s ease-out;
        }
        
        .arch-card:hover {
          transform: translateY(-2px);
        }
        
        .score-bar {
          height: 8px;
          border-radius: 4px;
          background: rgba(255, 255, 255, 0.1);
          overflow: hidden;
        }
        
        .score-fill {
          height: 100%;
          transition: width 0.6s ease-out;
        }
      `}</style>

      <div className="max-w-[1600px] mx-auto">
        {/* Header */}
        <div className="mb-6 text-center">
          <div className="flex items-center justify-center gap-3 mb-2">
            <Box className="w-10 h-10 text-cyan-400" />
            <h1 className="text-3xl md:text-4xl font-black tracking-wider uppercase text-white">
              ARCH INTEGRATION STACK
            </h1>
            <Package className="w-10 h-10 text-purple-400" />
          </div>
          <p className="text-sm text-gray-400 tracking-wide">
            PKGBUILD Parser • Wiki Analyzer • Arch Philosophy Emulator
          </p>
        </div>

        {/* Info Banner */}
        <div className="mb-6 p-4 rounded-2xl border" style={{
          background: 'rgba(36, 228, 255, 0.1)',
          borderColor: 'rgba(36, 228, 255, 0.4)'
        }}>
          <div className="flex items-start gap-3">
            <Eye className="w-5 h-5 text-cyan-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <strong className="text-cyan-400">Arch Integration Stack:</strong> Analyze PKGBUILD metadata, parse Arch Wiki docs, and evaluate module designs against Arch philosophy (minimalism, modularity, transparency).
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 rounded-xl border border-red-500/50 bg-red-900/20 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Analysis Error</div>
              <div className="text-xs text-gray-300 mt-1">{error}</div>
              <div className="text-xs text-gray-400 mt-2">
                Backend: <code className="bg-black/40 px-2 py-0.5 rounded">node arch-integration-stack.js</code> on port 9988
              </div>
            </div>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="mb-6 flex flex-wrap gap-2">
          {[
            { id: 'pkgbuild', label: 'PKGBUILD Analyzer', icon: FileText },
            { id: 'logic', label: 'Logic Emulator', icon: Activity },
            { id: 'wiki', label: 'Wiki Parser', icon: BookOpen },
            { id: 'registry', label: 'Package Registry', icon: Package }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className="px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 transition-all"
                style={{
                  background: activeTab === tab.id ? 'rgba(36, 228, 255, 0.2)' : 'rgba(0, 0, 0, 0.3)',
                  border: `1px solid ${activeTab === tab.id ? 'rgba(36, 228, 255, 0.6)' : 'rgba(255, 255, 255, 0.1)'}`,
                  color: activeTab === tab.id ? '#24e4ff' : '#8c8faf'
                }}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Input Panel */}
          <div className="lg:col-span-5">
            {activeTab === 'pkgbuild' && (
              <div className="rounded-2xl border p-5" style={{
                borderColor: 'rgba(36, 228, 255, 0.3)',
                background: 'rgba(7, 7, 18, 0.95)'
              }}>
                <div className="flex items-center justify-between mb-4">
                  <div className="text-xs font-bold text-cyan-400">PKGBUILD TEXT</div>
                  <FileText className="w-5 h-5 text-cyan-400" />
                </div>

                <textarea
                  value={pkgbuildText}
                  onChange={(e) => setPkgbuildText(e.target.value)}
                  disabled={isAnalyzing}
                  rows={16}
                  className="w-full rounded-xl border px-3 py-3 text-xs font-mono resize-none mb-4"
                  style={{
                    borderColor: 'rgba(36, 228, 255, 0.3)',
                    background: 'rgba(2, 0, 12, 0.9)',
                    color: '#f6fff6'
                  }}
                  placeholder="Paste PKGBUILD content here..."
                />

                <div className="space-y-2">
                  <button
                    onClick={analyzePkgbuild}
                    disabled={isAnalyzing}
                    className="w-full px-4 py-3 rounded-xl text-sm font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                    style={{
                      background: 'linear-gradient(135deg, #24e4ff, #4eff8b)',
                      color: '#000',
                      boxShadow: isAnalyzing ? 'none' : '0 0 20px rgba(36, 228, 255, 0.6)'
                    }}
                  >
                    {isAnalyzing ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        ANALYZING...
                      </>
                    ) : (
                      <>
                        <Zap className="w-5 h-5" />
                        ANALYZE PKGBUILD
                      </>
                    )}
                  </button>

                  {analysisResult && analysisResult.type === 'pkgbuild' && (
                    <button
                      onClick={registerPackage}
                      disabled={isAnalyzing}
                      className="w-full px-4 py-3 rounded-xl text-sm font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                      style={{
                        background: 'rgba(139, 92, 255, 0.2)',
                        border: '1px solid rgba(139, 92, 255, 0.6)',
                        color: '#fff'
                      }}
                    >
                      <Package className="w-5 h-5" />
                      REGISTER PACKAGE
                    </button>
                  )}
                </div>

                <div className="mt-4 p-3 rounded-xl" style={{
                  background: 'rgba(36, 228, 255, 0.05)',
                  border: '1px solid rgba(36, 228, 255, 0.2)'
                }}>
                  <div className="text-xs text-gray-300">
                    <strong className="text-cyan-400">Expected format:</strong> Standard Arch PKGBUILD with pkgname, pkgver, depends, etc.
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'logic' && (
              <div className="rounded-2xl border p-5" style={{
                borderColor: 'rgba(168, 85, 247, 0.3)',
                background: 'rgba(7, 7, 18, 0.95)'
              }}>
                <div className="flex items-center justify-between mb-4">
                  <div className="text-xs font-bold text-purple-400">MODULE DESCRIPTOR (JSON)</div>
                  <Activity className="w-5 h-5 text-purple-400" />
                </div>

                <textarea
                  value={descriptor}
                  onChange={(e) => setDescriptor(e.target.value)}
                  disabled={isAnalyzing}
                  rows={18}
                  className="w-full rounded-xl border px-3 py-3 text-xs font-mono resize-none mb-4"
                  style={{
                    borderColor: 'rgba(168, 85, 247, 0.3)',
                    background: 'rgba(2, 0, 12, 0.9)',
                    color: '#f6fff6'
                  }}
                />

                <button
                  onClick={emulateLogic}
                  disabled={isAnalyzing}
                  className="w-full px-4 py-3 rounded-xl text-sm font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                  style={{
                    background: 'linear-gradient(135deg, #a855f7, #ff6ec7)',
                    color: '#fff',
                    boxShadow: isAnalyzing ? 'none' : '0 0 20px rgba(168, 85, 247, 0.6)'
                  }}
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      EMULATING...
                    </>
                  ) : (
                    <>
                      <Activity className="w-5 h-5" />
                      EMULATE ARCH LOGIC
                    </>
                  )}
                </button>
              </div>
            )}

            {activeTab === 'wiki' && (
              <div className="rounded-2xl border p-5" style={{
                borderColor: 'rgba(255, 219, 124, 0.3)',
                background: 'rgba(7, 7, 18, 0.95)'
              }}>
                <div className="flex items-center justify-between mb-4">
                  <div className="text-xs font-bold text-yellow-400">WIKI DOCUMENT TEXT</div>
                  <BookOpen className="w-5 h-5 text-yellow-400" />
                </div>

                <textarea
                  value={wikiText}
                  onChange={(e) => setWikiText(e.target.value)}
                  disabled={isAnalyzing}
                  rows={16}
                  className="w-full rounded-xl border px-3 py-3 text-xs font-mono resize-none mb-4"
                  style={{
                    borderColor: 'rgba(255, 219, 124, 0.3)',
                    background: 'rgba(2, 0, 12, 0.9)',
                    color: '#f6fff6'
                  }}
                  placeholder="Paste Arch wiki style documentation..."
                />

                <button
                  onClick={parseWiki}
                  disabled={isAnalyzing}
                  className="w-full px-4 py-3 rounded-xl text-sm font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                  style={{
                    background: 'linear-gradient(135deg, #ffdb7c, #ff6ec7)',
                    color: '#000',
                    boxShadow: isAnalyzing ? 'none' : '0 0 20px rgba(255, 219, 124, 0.6)'
                  }}
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      PARSING...
                    </>
                  ) : (
                    <>
                      <BookOpen className="w-5 h-5" />
                      PARSE WIKI DOC
                    </>
                  )}
                </button>
              </div>
            )}

            {activeTab === 'registry' && (
              <div className="rounded-2xl border p-5" style={{
                borderColor: 'rgba(78, 255, 139, 0.3)',
                background: 'rgba(7, 7, 18, 0.95)',
                minHeight: '600px'
              }}>
                <div className="flex items-center justify-between mb-4">
                  <div className="text-xs font-bold text-green-400">PACKAGE REGISTRY ({packages.length})</div>
                  <Package className="w-5 h-5 text-green-400" />
                </div>

                {packages.length === 0 && (
                  <div className="text-center py-12 text-sm text-gray-600">
                    No packages registered yet.
                    <br />
                    Analyze and register a PKGBUILD first.
                  </div>
                )}

                <div className="space-y-2">
                  {packages.map((pkg) => (
                    <div
                      key={pkg.id}
                      onClick={() => setSelectedPackage(pkg)}
                      className="arch-card p-3 rounded-xl border cursor-pointer"
                      style={{
                        background: selectedPackage?.id === pkg.id ? 'rgba(78, 255, 139, 0.1)' : 'rgba(0, 0, 0, 0.3)',
                        borderColor: selectedPackage?.id === pkg.id ? 'rgba(78, 255, 139, 0.5)' : 'rgba(255, 255, 255, 0.1)'
                      }}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-bold text-white">{pkg.packageName}</span>
                        <div 
                          className="text-[10px] px-2 py-0.5 rounded-full font-bold uppercase"
                          style={{
                            background: `${getAffinityColor(pkg.logicScore?.overallArchAffinity || 0)}20`,
                            color: getAffinityColor(pkg.logicScore?.overallArchAffinity || 0)
                          }}
                        >
                          {pkg.archAffinity}
                        </div>
                      </div>
                      <div className="text-[10px] text-gray-500">
                        {pkg.pkgMeta?.pkgdesc || 'No description'}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right: Results Panel */}
          <div className="lg:col-span-7">
            {!analysisResult && !selectedPackage && (
              <div className="rounded-2xl border p-12 text-center" style={{
                background: 'rgba(7, 7, 18, 0.95)',
                borderColor: 'rgba(255, 255, 255, 0.1)',
                minHeight: '600px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <div>
                  <Box className="w-20 h-20 mx-auto mb-4 text-purple-400/30" />
                  <p className="text-sm text-gray-400">
                    No analysis result yet.
                    <br />
                    {activeTab === 'pkgbuild' && 'Analyze a PKGBUILD to see results.'}
                    {activeTab === 'logic' && 'Run logic emulation to see scores.'}
                    {activeTab === 'wiki' && 'Parse a wiki document to see structure.'}
                    {activeTab === 'registry' && 'Select a package to view details.'}
                  </p>
                </div>
              </div>
            )}

            {analysisResult && analysisResult.type === 'pkgbuild' && (
              <div className="space-y-4">
                {/* Package Meta */}
                <div className="rounded-2xl border p-5" style={{
                  borderColor: 'rgba(36, 228, 255, 0.4)',
                  background: 'rgba(7, 7, 18, 0.95)'
                }}>
                  <div className="text-xs font-bold text-cyan-400 mb-4">PACKAGE METADATA</div>
                  
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="p-3 rounded-xl" style={{ background: 'rgba(0, 0, 0, 0.4)' }}>
                      <div className="text-[10px] text-gray-400 mb-1">Package Name</div>
                      <div className="text-sm text-white font-semibold">{analysisResult.data.meta.pkgname || 'N/A'}</div>
                    </div>
                    <div className="p-3 rounded-xl" style={{ background: 'rgba(0, 0, 0, 0.4)' }}>
                      <div className="text-[10px] text-gray-400 mb-1">Version</div>
                      <div className="text-sm text-white font-semibold">{analysisResult.data.meta.pkgver || 'N/A'}</div>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl mb-3" style={{ background: 'rgba(0, 0, 0, 0.4)' }}>
                    <div className="text-[10px] text-gray-400 mb-1">Description</div>
                    <div className="text-xs text-gray-300">{analysisResult.data.meta.pkgdesc || 'No description'}</div>
                  </div>

                  {analysisResult.data.meta.depends?.length > 0 && (
                    <div className="p-3 rounded-xl" style={{ background: 'rgba(0, 0, 0, 0.4)' }}>
                      <div className="text-[10px] text-gray-400 mb-2">Dependencies ({analysisResult.data.meta.depends.length})</div>
                      <div className="flex flex-wrap gap-2">
                        {analysisResult.data.meta.depends.map((dep, i) => (
                          <div key={i} className="text-[10px] px-2 py-1 rounded-full" style={{
                            background: 'rgba(36, 228, 255, 0.1)',
                            color: '#24e4ff'
                          }}>
                            {dep}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Stats */}
                <div className="rounded-2xl border p-5" style={{
                  borderColor: 'rgba(168, 85, 247, 0.4)',
                  background: 'rgba(7, 7, 18, 0.95)'
                }}>
                  <div className="text-xs font-bold text-purple-400 mb-4">PKGBUILD STATISTICS</div>
                  
                  <div className="grid grid-cols-3 gap-3">
                    <div className="p-3 rounded-xl text-center" style={{
                      background: 'rgba(36, 228, 255, 0.1)',
                      border: '1px solid rgba(36, 228, 255, 0.3)'
                    }}>
                      <div className="text-xs text-gray-400 mb-1">Lines</div>
                      <div className="text-2xl font-bold text-cyan-400">{analysisResult.data.stats.lineCount}</div>
                    </div>
                    <div className="p-3 rounded-xl text-center" style={{
                      background: 'rgba(168, 85, 247, 0.1)',
                      border: '1px solid rgba(168, 85, 247, 0.3)'
                    }}>
                      <div className="text-xs text-gray-400 mb-1">Dependencies</div>
                      <div className="text-2xl font-bold text-purple-400">{analysisResult.data.stats.depCount}</div>
                    </div>
                    <div className="p-3 rounded-xl text-center" style={{
                      background: `${getComplexityColor(analysisResult.data.stats.complexity)}20`,
                      border: `1px solid ${getComplexityColor(analysisResult.data.stats.complexity)}60`
                    }}>
                      <div className="text-xs text-gray-400 mb-1">Complexity</div>
                      <div className="text-sm font-bold uppercase" style={{
                        color: getComplexityColor(analysisResult.data.stats.complexity)
                      }}>
                        {analysisResult.data.stats.complexity}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {analysisResult && analysisResult.type === 'logic' && (
              <div className="space-y-4">
                {/* Arch Philosophy Scores */}
                <div className="rounded-2xl border p-5" style={{
                  borderColor: 'rgba(168, 85, 247, 0.4)',
                  background: 'rgba(7, 7, 18, 0.95)',
                  boxShadow: '0 0 40px rgba(168, 85, 247, 0.2)'
                }}>
                  <div className="flex items-center justify-between mb-4">
                    <div className="text-xs font-bold text-purple-400">ARCH PHILOSOPHY SCORING</div>
                    <div className="text-lg font-black" style={{
                      color: getAffinityColor(analysisResult.data.overallArchAffinity)
                    }}>
                      {(analysisResult.data.overallArchAffinity * 100).toFixed(0)}%
                    </div>
                  </div>

                  <div className="space-y-4">
                    {/* Minimalism */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-gray-400">Minimalism Score</span>
                        <span className="text-sm font-bold text-white">
                          {(analysisResult.data.minimalismScore * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div className="score-bar">
                        <div 
                          className="score-fill"
                          style={{
                            width: `${analysisResult.data.minimalismScore * 100}%`,
                            background: getAffinityColor(analysisResult.data.minimalismScore)
                          }}
                        />
                      </div>
                    </div>

                    {/* Modularity */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-gray-400">Modularity Score</span>
                        <span className="text-sm font-bold text-white">
                          {(analysisResult.data.modularityScore * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div className="score-bar">
                        <div 
                          className="score-fill"
                          style={{
                            width: `${analysisResult.data.modularityScore * 100}%`,
                            background: getAffinityColor(analysisResult.data.modularityScore)
                          }}
                        />
                      </div>
                    </div>

                    {/* Transparency */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-gray-400">Transparency Score</span>
                        <span className="text-sm font-bold text-white">
                          {(analysisResult.data.transparencyScore * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div className="score-bar">
                        <div 
                          className="score-fill"
                          style={{
                            width: `${analysisResult.data.transparencyScore * 100}%`,
                            background: getAffinityColor(analysisResult.data.transparencyScore)
                          }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 p-3 rounded-xl" style={{
                    background: `${getAffinityColor(analysisResult.data.overallArchAffinity)}10`,
                    border: `1px solid ${getAffinityColor(analysisResult.data.overallArchAffinity)}40`
                  }}>
                    <div className="text-xs text-gray-300">
                      <strong style={{ color: getAffinityColor(analysisResult.data.overallArchAffinity) }}>
                        Overall Arch Affinity:
                      </strong> {analysisResult.data.name} scores{' '}
                      {analysisResult.data.overallArchAffinity >= 0.8 ? 'elite' : 
                       analysisResult.data.overallArchAffinity >= 0.6 ? 'high' :
                       analysisResult.data.overallArchAffinity >= 0.4 ? 'medium' : 'low'} in Arch philosophy alignment.
                    </div>
                  </div>
                </div>
              </div>
            )}

            {analysisResult && analysisResult.type === 'wiki' && (
              <div className="space-y-4">
                {/* Wiki Structure */}
                <div className="rounded-2xl border p-5" style={{
                  borderColor: 'rgba(255, 219, 124, 0.4)',
                  background: 'rgba(7, 7, 18, 0.95)'
                }}>
                  <div className="text-xs font-bold text-yellow-400 mb-4">DOCUMENT STRUCTURE</div>
                  
                  <div className="grid grid-cols-3 gap-3 mb-4">
                    <div className="p-3 rounded-xl text-center" style={{
                      background: 'rgba(255, 219, 124, 0.1)',
                      border: '1px solid rgba(255, 219, 124, 0.3)'
                    }}>
                      <div className="text-xs text-gray-400 mb-1">Sections</div>
                      <div className="text-2xl font-bold text-yellow-400">{analysisResult.data.stats.sectionCount}</div>
                    </div>
                    <div className="p-3 rounded-xl text-center" style={{
                      background: 'rgba(255, 110, 199, 0.1)',
                      border: '1px solid rgba(255, 110, 199, 0.3)'
                    }}>
                      <div className="text-xs text-gray-400 mb-1">Links</div>
                      <div className="text-2xl font-bold text-pink-400">{analysisResult.data.links.length}</div>
                    </div>
                    <div className="p-3 rounded-xl text-center" style={{
                      background: 'rgba(36, 228, 255, 0.1)',
                      border: '1px solid rgba(36, 228, 255, 0.3)'
                    }}>
                      <div className="text-xs text-gray-400 mb-1">Depth</div>
                      <div className="text-xs font-bold uppercase text-cyan-400">
                        {analysisResult.data.stats.depthClass}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    {analysisResult.data.sections.map((section, i) => (
                      <div 
                        key={i}
                        className="p-3 rounded-xl"
                        style={{
                          background: 'rgba(0, 0, 0, 0.4)',
                          borderLeft: `3px solid ${section.level === 1 ? '#ffdb7c' : '#a855f7'}`
                        }}
                      >
                        <div className="text-sm font-bold text-white mb-1">{section.title}</div>
                        <div className="text-xs text-gray-400">{section.preview}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Links */}
                {analysisResult.data.links.length > 0 && (
                  <div className="rounded-2xl border p-5" style={{
                    borderColor: 'rgba(255, 110, 199, 0.4)',
                    background: 'rgba(7, 7, 18, 0.95)'
                  }}>
                    <div className="text-xs font-bold text-pink-400 mb-4">EXTRACTED LINKS</div>
                    
                    <div className="space-y-2">
                      {analysisResult.data.links.map((link, i) => (
                        <div 
                          key={i}
                          className="flex items-center gap-2 p-2 rounded-lg text-xs"
                          style={{
                            background: 'rgba(255, 110, 199, 0.1)',
                            border: '1px solid rgba(255, 110, 199, 0.3)'
                          }}
                        >
                          <ArrowRight className="w-3 h-3 text-pink-400 flex-shrink-0" />
                          <span className="text-gray-300">
                            {link.type === 'wiki' ? `[[${link.target}]]` : `${link.label} → ${link.url}`}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {selectedPackage && activeTab === 'registry' && (
              <div className="space-y-4">
                {/* Package Header */}
                <div className="rounded-2xl border p-5" style={{
                  borderColor: 'rgba(78, 255, 139, 0.4)',
                  background: 'rgba(7, 7, 18, 0.95)',
                  boxShadow: '0 0 40px rgba(78, 255, 139, 0.2)'
                }}>
                  <div className="flex items-center justify-between mb-3">
                    <h2 className="text-2xl font-black text-white">{selectedPackage.packageName}</h2>
                    <div 
                      className="text-xs px-3 py-1 rounded-full font-bold uppercase"
                      style={{
                        background: `${getAffinityColor(selectedPackage.logicScore?.overallArchAffinity || 0)}20`,
                        color: getAffinityColor(selectedPackage.logicScore?.overallArchAffinity || 0)
                      }}
                    >
                      {selectedPackage.archAffinity} AFFINITY
                    </div>
                  </div>
                  <div className="text-sm text-gray-400">
                    {selectedPackage.pkgMeta?.pkgdesc || 'No description available'}
                  </div>
                </div>

                {/* Arch Scores */}
                {selectedPackage.logicScore && (
                  <div className="rounded-2xl border p-5" style={{
                    borderColor: 'rgba(168, 85, 247, 0.4)',
                    background: 'rgba(7, 7, 18, 0.95)'
                  }}>
                    <div className="text-xs font-bold text-purple-400 mb-4">ARCH PHILOSOPHY SCORES</div>
                    
                    <div className="space-y-3">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs text-gray-400">Minimalism</span>
                          <span className="text-sm font-bold text-white">
                            {(selectedPackage.logicScore.minimalismScore * 100).toFixed(0)}%
                          </span>
                        </div>
                        <div className="score-bar">
                          <div 
                            className="score-fill"
                            style={{
                              width: `${selectedPackage.logicScore.minimalismScore * 100}%`,
                              background: getAffinityColor(selectedPackage.logicScore.minimalismScore)
                            }}
                          />
                        </div>
                      </div>
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs text-gray-400">Modularity</span>
                          <span className="text-sm font-bold text-white">
                            {(selectedPackage.logicScore.modularityScore * 100).toFixed(0)}%
                          </span>
                        </div>
                        <div className="score-bar">
                          <div 
                            className="score-fill"
                            style={{
                              width: `${selectedPackage.logicScore.modularityScore * 100}%`,
                              background: getAffinityColor(selectedPackage.logicScore.modularityScore)
                            }}
                          />
                        </div>
                      </div>
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs text-gray-400">Transparency</span>
                          <span className="text-sm font-bold text-white">
                            {(selectedPackage.logicScore.transparencyScore * 100).toFixed(0)}%
                          </span>
                        </div>
                        <div className="score-bar">
                          <div 
                            className="score-fill"
                            style={{
                              width: `${selectedPackage.logicScore.transparencyScore * 100}%`,
                              background: getAffinityColor(selectedPackage.logicScore.transparencyScore)
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Package Stats */}
                {selectedPackage.pkgStats && (
                  <div className="rounded-2xl border p-5" style={{
                    borderColor: 'rgba(36, 228, 255, 0.4)',
                    background: 'rgba(7, 7, 18, 0.95)'
                  }}>
                    <div className="text-xs font-bold text-cyan-400 mb-4">PACKAGE STATISTICS</div>
                    
                    <div className="grid grid-cols-3 gap-3">
                      <div className="p-3 rounded-xl text-center" style={{
                        background: 'rgba(36, 228, 255, 0.1)',
                        border: '1px solid rgba(36, 228, 255, 0.3)'
                      }}>
                        <div className="text-xs text-gray-400 mb-1">Lines</div>
                        <div className="text-xl font-bold text-cyan-400">{selectedPackage.pkgStats.lineCount}</div>
                      </div>
                      <div className="p-3 rounded-xl text-center" style={{
                        background: 'rgba(168, 85, 247, 0.1)',
                        border: '1px solid rgba(168, 85, 247, 0.3)'
                      }}>
                        <div className="text-xs text-gray-400 mb-1">Dependencies</div>
                        <div className="text-xl font-bold text-purple-400">{selectedPackage.pkgStats.depCount}</div>
                      </div>
                      <div className="p-3 rounded-xl text-center" style={{
                        background: `${getComplexityColor(selectedPackage.pkgStats.complexity)}20`,
                        border: `1px solid ${getComplexityColor(selectedPackage.pkgStats.complexity)}60`
                      }}>
                        <div className="text-xs text-gray-400 mb-1">Complexity</div>
                        <div className="text-xs font-bold uppercase" style={{
                          color: getComplexityColor(selectedPackage.pkgStats.complexity)
                        }}>
                          {selectedPackage.pkgStats.complexity}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}