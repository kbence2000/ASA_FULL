import React, { useState, useEffect } from 'react';
import { Shield, Activity, Radio, Zap } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function StabilityDashboard() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [dashboardData, setDashboardData] = useState(null);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [sampleSnapshot] = useState({
    source: "system_monitor",
    layers: [
      { name: "logic", baseValue: 0.8, drift: 0.2 },
      { name: "creative", baseValue: 1.2, drift: 0.4 },
      { name: "resonance", baseValue: 0.5, drift: 0.1 },
      { name: "silence", baseValue: 0.1, drift: -0.05 }
    ],
    paradoxCheck: {
      exprA: "2 + 2",
      exprB: "4"
    }
  });

  const refreshDashboard = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await base44.functions.invoke('dualRiftEngine', {
        snapshot: sampleSnapshot
      });

      setDashboardData(response.data);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshDashboard();
  }, []);

  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      refreshDashboard();
    }, 5000);

    return () => clearInterval(interval);
  }, [autoRefresh]);

  const getRiskClass = (level) => {
    if (level === 'low') return 'risk-low';
    if (level === 'medium') return 'risk-medium';
    if (level === 'high') return 'risk-high';
    return '';
  };

  return (
    <div style={{ 
      background: 'radial-gradient(circle at top, #101527, #05060a 65%)',
      minHeight: '100vh',
      color: '#f5f5ff'
    }}>
      <style>{`
        :root {
          --bg: #05060a;
          --panel: #0c0f18;
          --accent: #7cf7c9;
          --accent-soft: rgba(124, 247, 201, 0.18);
          --danger: #ff4b81;
          --warn: #ffc857;
          --ok: #5ee7ff;
          --text-main: #f5f5ff;
          --text-muted: #9da2c6;
          --border-subtle: rgba(255, 255, 255, 0.05);
        }

        .shell {
          max-width: 1180px;
          margin: 24px auto 40px;
          padding: 0 16px;
        }
        
        .brand {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        
        .brand-title {
          font-size: 20px;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          font-weight: 600;
        }
        
        .brand-sub {
          font-size: 12px;
          color: var(--text-muted);
        }
        
        .pill {
          padding: 4px 12px;
          border-radius: 999px;
          border: 1px solid var(--accent-soft);
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.09em;
          cursor: pointer;
          transition: all 0.2s;
        }
        
        .pill:hover {
          border-color: var(--accent);
          background: var(--accent-soft);
        }

        .pill.active {
          border-color: var(--accent);
          color: var(--accent);
        }

        .grid {
          display: grid;
          grid-template-columns: minmax(0, 2fr) minmax(0, 1.4fr);
          gap: 16px;
        }
        
        @media (max-width: 800px) {
          .grid {
            grid-template-columns: minmax(0, 1fr);
          }
        }
        
        .card {
          background: var(--panel);
          border-radius: 16px;
          padding: 14px 16px;
          border: 1px solid var(--border-subtle);
          box-shadow: 0 0 24px rgba(0,0,0,0.35);
        }
        
        .card-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 8px;
        }
        
        .card-title {
          font-size: 13px;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: var(--text-muted);
        }
        
        .risk-badge {
          padding: 3px 10px;
          border-radius: 999px;
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.07em;
          border: 1px solid;
        }
        
        .risk-low {
          border-color: var(--ok);
          color: var(--ok);
        }
        
        .risk-medium {
          border-color: var(--warn);
          color: var(--warn);
        }
        
        .risk-high {
          border-color: var(--danger);
          color: var(--danger);
        }

        .metrics-row {
          display: flex;
          flex-wrap: wrap;
          gap: 10px;
          margin-bottom: 8px;
        }
        
        .metric {
          flex: 1 1 90px;
          min-width: 80px;
          padding: 6px 8px;
          border-radius: 10px;
          background: rgba(255,255,255,0.02);
          border: 1px solid var(--border-subtle);
        }
        
        .metric-label {
          font-size: 11px;
          color: var(--text-muted);
          margin-bottom: 4px;
        }
        
        .metric-value {
          font-size: 14px;
          font-weight: 500;
        }

        .layers-table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 4px;
          font-size: 12px;
        }
        
        .layers-table th,
        .layers-table td {
          padding: 4px 6px;
          text-align: left;
          border-bottom: 1px solid rgba(255,255,255,0.03);
        }
        
        .layers-table th {
          color: var(--text-muted);
          font-weight: 500;
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.06em;
        }
        
        .mini-label {
          font-size: 11px;
          color: var(--text-muted);
          margin-bottom: 2px;
        }
        
        .prediction {
          font-size: 12px;
          color: var(--text-muted);
        }
        
        .prediction strong {
          color: var(--accent);
        }
        
        .paradox-line {
          font-size: 12px;
          margin-top: 6px;
        }
        
        .paradox-line span {
          font-weight: 500;
        }

        .btn-refresh {
          padding: 6px 12px;
          border-radius: 8px;
          border: 1px solid var(--border-subtle);
          background: rgba(255,255,255,0.02);
          color: var(--text-main);
          font-size: 12px;
          cursor: pointer;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .btn-refresh:hover {
          background: var(--accent-soft);
          border-color: var(--accent);
        }

        .btn-refresh:disabled {
          opacity: 0.4;
          cursor: not-allowed;
        }
      `}</style>

      <div className="shell">
        <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '16px', marginBottom: '18px', flexWrap: 'wrap' }}>
          <div className="brand">
            <div className="brand-title">TAC – Stability Dashboard</div>
            <div className="brand-sub">Dual Rift Engine • Anti-Rift • Paradox Crossing</div>
          </div>
          <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
            <div 
              className={`pill ${autoRefresh ? 'active' : ''}`}
              onClick={() => setAutoRefresh(!autoRefresh)}
            >
              {autoRefresh ? 'AUTO: ON' : 'AUTO: OFF'}
            </div>
            <button
              onClick={refreshDashboard}
              disabled={isLoading}
              className="btn-refresh"
            >
              {isLoading ? <Activity className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3" />}
              Refresh
            </button>
          </div>
        </header>

        {error && (
          <div style={{ 
            padding: '12px', 
            borderRadius: '12px', 
            background: 'rgba(255, 75, 129, 0.1)', 
            border: '1px solid rgba(255, 75, 129, 0.3)',
            marginBottom: '16px',
            fontSize: '13px',
            color: '#ff4b81'
          }}>
            Error: {error}
          </div>
        )}

        {!dashboardData ? (
          <div className="card" style={{ textAlign: 'center', padding: '40px' }}>
            <Activity className="w-8 h-8 mx-auto mb-2 opacity-50 animate-spin" style={{ display: 'inline-block' }} />
            <div style={{ fontSize: '13px', color: 'var(--text-muted)' }}>Loading dashboard...</div>
          </div>
        ) : (
          <div className="grid">
            {/* LEFT: Core Stability & Layers */}
            <div className="card">
              <div className="card-header">
                <div className="card-title">Current Stability Snapshot</div>
                <div className={`risk-badge ${getRiskClass(dashboardData.antiAnalysis?.riskLevel)}`}>
                  {dashboardData.antiAnalysis?.riskLevel?.toUpperCase() || 'LOADING'}
                </div>
              </div>

              <div className="metrics-row">
                <div className="metric">
                  <div className="metric-label">Avg Rift Intensity</div>
                  <div className="metric-value">{dashboardData.antiAnalysis?.avgIntensity?.toFixed(3) || '–'}</div>
                </div>
                <div className="metric">
                  <div className="metric-label">Max Rift</div>
                  <div className="metric-value">{dashboardData.antiAnalysis?.maxIntensity?.toFixed(3) || '–'}</div>
                </div>
                <div className="metric">
                  <div className="metric-label">Risk Level</div>
                  <div className="metric-value">{dashboardData.antiAnalysis?.riskLevel?.toUpperCase() || '–'}</div>
                </div>
              </div>

              <div className="mini-label">Layers – original vs smoothed (Anti-Rift harmonization)</div>
              <table className="layers-table">
                <thead>
                  <tr>
                    <th>Layer</th>
                    <th>Base</th>
                    <th>Rift</th>
                    <th>Smoothed Base</th>
                    <th>Smoothed Rift</th>
                  </tr>
                </thead>
                <tbody>
                  {dashboardData.harmonized?.smoothedLayers?.map((layer, idx) => (
                    <tr key={idx}>
                      <td>{layer.name}</td>
                      <td>{layer.originalBase?.toFixed(3)}</td>
                      <td>{layer.originalRift?.toFixed(3)}</td>
                      <td>{layer.smoothedBase?.toFixed(3)}</td>
                      <td>{layer.smoothedRift?.toFixed(3)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* RIGHT: Prediction + Paradox */}
            <div className="card">
              <div className="card-header">
                <div className="card-title">Prediction & Paradox Crossing</div>
              </div>

              <div className="metric" style={{ marginBottom: '8px' }}>
                <div className="metric-label">Prediction Mode</div>
                <div className="metric-value">{dashboardData.prediction?.mode || '–'}</div>
              </div>

              <p className="prediction">
                {dashboardData.prediction?.ok ? (
                  dashboardData.prediction.projectedMsToHighRisk != null ? (
                    <>
                      Estimated time to reach <strong>high-risk</strong> intensity (~{dashboardData.prediction.targetIntensity}): {' '}
                      <strong>{Math.max(0, Math.round(dashboardData.prediction.projectedMsToHighRisk / 60000))} min</strong> (trend-based).
                    </>
                  ) : (
                    "Trend indicates stable or cooling rift intensity. No aggressive spike predicted."
                  )
                ) : (
                  "Not enough data for prediction yet."
                )}
              </p>

              <div className="metric" style={{ marginTop: '8px' }}>
                <div className="metric-label">Paradox Crossing</div>
                <div className="metric-value">
                  {dashboardData.paradoxCross?.ok 
                    ? (dashboardData.paradoxCross.paradox ? 'PARADOX' : 'CONSISTENT')
                    : 'N/A'}
                </div>
              </div>
              {dashboardData.paradoxCross?.note && (
                <p className="paradox-line">{dashboardData.paradoxCross.note}</p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}