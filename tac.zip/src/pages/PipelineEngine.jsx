import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, Brain, Zap, Loader2, TrendingUp, Eye, AlertTriangle, Layers, ArrowRight, CheckCircle2, RefreshCw, Box, Orbit, Radio, Infinity as InfinityIcon } from 'lucide-react';

export default function PipelineEngine() {
  const [brief, setBrief] = useState("Design an AI-powered developer marketplace where code assets compete in neural arenas and developers earn reputation tokens.");
  const [wildness, setWildness] = useState(6);
  const [isRunning, setIsRunning] = useState(false);
  const [currentStage, setCurrentStage] = useState(null);
  const [pipelineResult, setPipelineResult] = useState(null);
  const [error, setError] = useState(null);

  const runPipeline = async () => {
    if (isRunning || !brief.trim()) return;

    setIsRunning(true);
    setError(null);
    setPipelineResult(null);
    setCurrentStage('mirror');

    try {
      // Stage progression
      const stageIds = ['mirror', 'hallucinator', 'paradox', 'nqfice', 'field1998', 'antifield1998', 'infinity'];
      let stageIndex = 0;

      const progressInterval = setInterval(() => {
        stageIndex++;
        if (stageIndex < stageIds.length) {
          setCurrentStage(stageIds[stageIndex]);
        }
      }, 3000);

      const response = await fetch('http://localhost:8080/api/pipeline/run', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          brief,
          wildness
        })
      });

      clearInterval(progressInterval);

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      setPipelineResult(data);
      setCurrentStage('complete');

    } catch (err) {
      console.error('Pipeline error:', err);
      setError(err.message);
      setCurrentStage(null);
    } finally {
      setIsRunning(false);
    }
  };

  const getWildnessLabel = (level) => {
    if (level <= 2) return "Subtle";
    if (level <= 4) return "Moderate";
    if (level <= 6) return "Creative";
    if (level <= 8) return "Surreal";
    return "Extreme";
  };

  const getWildnessColor = (level) => {
    if (level <= 2) return "#3b82f6";
    if (level <= 4) return "#22c55e";
    if (level <= 6) return "#a855f7";
    if (level <= 8) return "#f97316";
    return "#ef4444";
  };

  const stages = [
    { 
      id: 'mirror', 
      name: 'Mirror Chamber', 
      icon: Layers, 
      color: '#3b82f6',
      description: '9×9 minds interference pattern'
    },
    { 
      id: 'hallucinator', 
      name: 'Hallucinator', 
      icon: Brain, 
      color: '#a855f7',
      description: 'Wild creative variants'
    },
    { 
      id: 'paradox', 
      name: 'Paradox Engine', 
      icon: Zap, 
      color: '#22c55e',
      description: 'Order × Chaos convergence'
    },
    { 
      id: 'nqfice', 
      name: 'NQ-FICE', 
      icon: Box, 
      color: '#24e4ff',
      description: 'Negative quantum inversion'
    },
    { 
      id: 'field1998', 
      name: '1998-Field', 
      icon: Orbit, 
      color: '#ffd700',
      description: 'Positive metaphysical resonance'
    },
    { 
      id: 'antifield1998', 
      name: 'Anti-1998-Field', 
      icon: Radio, 
      color: '#8b008b',
      description: 'Negative metaphysical inversion'
    },
    { 
      id: 'infinity', 
      name: 'Infinity Expansion', 
      icon: InfinityIcon, 
      color: '#ff8c00',
      description: 'Growth potential synthesis'
    },
  ];

  return (
    <div className="relative min-h-screen p-4 md:p-6" style={{
      background: 'radial-gradient(circle at 20% 0%, #1a0f2e 0%, #0a0514 30%, #02000c 70%)'
    }}>
      <style>{`
        @keyframes pulseGlow {
          0%, 100% { opacity: 0.6; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.05); }
        }

        @keyframes slideInFromLeft {
          from { opacity: 0; transform: translateX(-20px); }
          to { opacity: 1; transform: translateX(0); }
        }

        .stage-active {
          animation: pulseGlow 1.5s ease-in-out infinite;
        }

        .stage-item {
          animation: slideInFromLeft 0.4s ease-out;
        }
      `}</style>

      {/* Container */}
      <div className="max-w-[1600px] mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-3">
            <Layers className="w-10 h-10 text-blue-400" />
            <h1 className="text-4xl md:text-5xl font-black tracking-wider uppercase text-white">
              ULTRA PIPELINE ENGINE
            </h1>
            <RefreshCw className="w-10 h-10 text-purple-400" />
          </div>
          <p className="text-sm text-gray-400 tracking-wide mb-2">
            7-Stage Ultimate AI Synthesis · Full TAC Reasoning Framework
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs uppercase tracking-wider"
            style={{
              background: 'rgba(168, 85, 247, 0.2)',
              border: '1px solid rgba(168, 85, 247, 0.5)',
              boxShadow: '0 0 20px rgba(168, 85, 247, 0.4)'
            }}
          >
            <Sparkles className="w-3 h-3" />
            Mirror · Hallucinator · Paradox · NQ-FICE · 1998 · Anti-1998 · Infinity
          </div>
        </div>

        {/* Info Banner */}
        <div className="mb-6 p-4 rounded-2xl border"
          style={{
            background: 'rgba(59, 130, 246, 0.1)',
            borderColor: 'rgba(59, 130, 246, 0.3)'
          }}
        >
          <div className="flex items-start gap-3">
            <Eye className="w-5 h-5 text-blue-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <span className="font-bold text-blue-300">What is Ultra Pipeline Engine?</span> 
              <br />
              The complete 7-stage TAC reasoning framework: (1) <strong>Mirror Chamber</strong> (9×9 minds), 
              (2) <strong>Hallucinator</strong> (creative variants), 
              (3) <strong>Paradox</strong> (Order × Chaos convergence),
              (4) <strong>NQ-FICE</strong> (negative quantum inversion),
              (5) <strong>1998-Field</strong> (positive metaphysical),
              (6) <strong>Anti-1998-Field</strong> (negative metaphysical),
              (7) <strong>Infinity Expansion</strong> (growth synthesis).
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 rounded-xl border border-red-500/50 bg-red-900/20 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Backend Connection Error</div>
              <div className="text-xs text-gray-300 mt-1">{error}</div>
              <div className="text-xs text-gray-400 mt-2">
                Make sure the backend server is running: <code className="bg-black/40 px-2 py-0.5 rounded">node pipeline-server.js</code> on port 8080
              </div>
            </div>
          </div>
        )}

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-6">
          {/* Left: Input Controls */}
          <div className="lg:col-span-1">
            <div className="rounded-2xl border p-6 sticky top-6"
              style={{
                borderColor: 'rgba(168, 85, 247, 0.3)',
                background: 'rgba(7, 7, 18, 0.95)',
                boxShadow: '0 0 40px rgba(0, 0, 0, 0.7)'
              }}
            >
              <label className="block text-xs tracking-widest uppercase text-purple-400 mb-3">
                CREATIVE BRIEF
              </label>
              <textarea
                value={brief}
                onChange={(e) => setBrief(e.target.value)}
                disabled={isRunning}
                rows={5}
                className="w-full rounded-xl border px-4 py-3 text-sm resize-none mb-4"
                style={{
                  borderColor: 'rgba(168, 85, 247, 0.4)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#f6fff6'
                }}
                placeholder="Enter your concept for the ultra pipeline..."
              />

              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs tracking-widest uppercase text-purple-400">
                    WILDNESS LEVEL
                  </label>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-400">{wildness}</span>
                    <span 
                      className="text-xs font-bold px-2 py-0.5 rounded-full"
                      style={{
                        color: getWildnessColor(wildness),
                        background: `${getWildnessColor(wildness)}20`,
                        border: `1px solid ${getWildnessColor(wildness)}40`
                      }}
                    >
                      {getWildnessLabel(wildness)}
                    </span>
                  </div>
                </div>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={wildness}
                  onChange={(e) => setWildness(parseInt(e.target.value))}
                  disabled={isRunning}
                  className="w-full"
                  style={{
                    accentColor: getWildnessColor(wildness)
                  }}
                />
              </div>

              <button
                onClick={runPipeline}
                disabled={isRunning}
                className="w-full py-3 rounded-full text-sm font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                style={{
                  background: 'linear-gradient(135deg, #3b82f6, #a855f7, #22c55e, #ffd700)',
                  color: '#fff',
                  boxShadow: isRunning ? 'none' : '0 0 30px rgba(168, 85, 247, 0.7)'
                }}
              >
                {isRunning ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    RUNNING...
                  </>
                ) : (
                  <>
                    <Layers className="w-5 h-5" />
                    RUN ULTRA PIPELINE
                  </>
                )}
              </button>

              {/* Pipeline Progress */}
              {isRunning && (
                <div className="mt-6 space-y-2">
                  <div className="text-xs tracking-widest uppercase text-purple-400 mb-2">
                    PIPELINE PROGRESS
                  </div>
                  {stages.map((stage, idx) => {
                    const isActive = currentStage === stage.id;
                    const isComplete = stages.findIndex(s => s.id === currentStage) > idx || currentStage === 'complete';
                    const Icon = stage.icon;

                    return (
                      <div 
                        key={stage.id}
                        className={`flex items-center gap-2 p-2 rounded-lg border transition-all ${isActive ? 'stage-active' : ''}`}
                        style={{
                          borderColor: isActive ? `${stage.color}80` : 'rgba(148, 163, 184, 0.2)',
                          background: isActive ? `${stage.color}20` : isComplete ? 'rgba(34, 197, 94, 0.1)' : 'rgba(0, 0, 0, 0.3)'
                        }}
                      >
                        {isComplete ? (
                          <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0" />
                        ) : isActive ? (
                          <Loader2 className="w-4 h-4 animate-spin flex-shrink-0" style={{ color: stage.color }} />
                        ) : (
                          <Icon className="w-4 h-4 text-gray-600 flex-shrink-0" />
                        )}
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-semibold text-white truncate">{stage.name}</div>
                          <div className="text-[9px] text-gray-400 truncate">{stage.description}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Right: Results */}
          <div className="lg:col-span-3">
            {!pipelineResult && !isRunning && (
              <div className="rounded-2xl border p-12 text-center h-full flex items-center justify-center"
                style={{
                  borderColor: 'rgba(148, 163, 184, 0.3)',
                  background: 'rgba(7, 7, 18, 0.95)'
                }}
              >
                <div>
                  <Layers className="w-20 h-20 mx-auto mb-4 text-purple-400/30" />
                  <p className="text-sm text-gray-500">
                    No pipeline result yet.
                    <br />
                    Enter a brief and run the 7-stage ultra pipeline.
                  </p>
                </div>
              </div>
            )}

            {isRunning && !pipelineResult && (
              <div className="rounded-2xl border p-12 text-center h-full flex items-center justify-center"
                style={{
                  borderColor: 'rgba(168, 85, 247, 0.4)',
                  background: 'rgba(7, 7, 18, 0.95)'
                }}
              >
                <div>
                  <Loader2 className="w-20 h-20 mx-auto mb-4 text-purple-400 animate-spin" />
                  <p className="text-sm text-gray-400">
                    Running 7-stage synthesis...
                    <br />
                    <span className="text-xs text-gray-600">
                      {currentStage === 'mirror' && 'Mirror Chamber analyzing 9×9 minds...'}
                      {currentStage === 'hallucinator' && 'Hallucinator Mind generating variants...'}
                      {currentStage === 'paradox' && 'Paradox Engine converging blueprint...'}
                      {currentStage === 'nqfice' && 'NQ-FICE inverting quantum space...'}
                      {currentStage === 'field1998' && '1998-Field computing resonance...'}
                      {currentStage === 'antifield1998' && 'Anti-1998-Field inverting symmetry...'}
                      {currentStage === 'infinity' && 'Infinity Expansion calculating growth...'}
                    </span>
                  </p>
                </div>
              </div>
            )}

            {pipelineResult && (
              <div className="space-y-4">
                {/* Stage 1: Mirror */}
                {pipelineResult.stages?.mirror && (
                  <div className="stage-item rounded-2xl border p-6"
                    style={{
                      borderColor: 'rgba(59, 130, 246, 0.4)',
                      background: 'rgba(7, 7, 18, 0.95)',
                      animationDelay: '0s'
                    }}
                  >
                    <div className="flex items-center gap-3 mb-4">
                      <Layers className="w-6 h-6 text-blue-400" />
                      <h3 className="text-lg font-bold text-white">Stage 1: Mirror Chamber</h3>
                    </div>
                    <div className="space-y-3">
                      <div className="p-3 rounded-lg" style={{ background: 'rgba(59, 130, 246, 0.1)' }}>
                        <div className="text-xs font-bold text-blue-300 mb-1">SUMMARY</div>
                        <div className="text-sm text-gray-300">{pipelineResult.stages.mirror.mirrorSummary || pipelineResult.stages.mirror.summary}</div>
                      </div>
                      <div className="p-3 rounded-lg" style={{ background: 'rgba(0, 0, 0, 0.3)' }}>
                        <div className="text-xs font-bold text-blue-300 mb-1">CORE CONCEPT</div>
                        <div className="text-sm text-gray-300">{pipelineResult.stages.mirror.coreConcept || pipelineResult.stages.mirror.concept}</div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Stage 2: Hallucinator */}
                {pipelineResult.stages?.hallucinator && (
                  <div className="stage-item rounded-2xl border p-6"
                    style={{
                      borderColor: 'rgba(168, 85, 247, 0.4)',
                      background: 'rgba(7, 7, 18, 0.95)',
                      animationDelay: '0.1s'
                    }}
                  >
                    <div className="flex items-center gap-3 mb-4">
                      <Brain className="w-6 h-6 text-purple-400" />
                      <h3 className="text-lg font-bold text-white">Stage 2: Hallucinator Mind</h3>
                    </div>
                    <div className="space-y-3">
                      <div className="p-3 rounded-lg" style={{ background: 'rgba(168, 85, 247, 0.1)' }}>
                        <div className="text-xs font-bold text-purple-300 mb-1">SUMMARY</div>
                        <div className="text-sm text-gray-300">{pipelineResult.stages.hallucinator.summary || pipelineResult.stages.hallucinator.hallucinationSummary}</div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Stage 3: Paradox */}
                {pipelineResult.stages?.paradox && (
                  <div className="stage-item rounded-2xl border p-6"
                    style={{
                      borderColor: 'rgba(34, 197, 94, 0.4)',
                      background: 'rgba(7, 7, 18, 0.95)',
                      boxShadow: '0 0 40px rgba(34, 197, 94, 0.2)',
                      animationDelay: '0.2s'
                    }}
                  >
                    <div className="flex items-center gap-3 mb-4">
                      <Zap className="w-6 h-6 text-green-400" />
                      <h3 className="text-lg font-bold text-white">Stage 3: Paradox Engine</h3>
                    </div>
                    <div className="space-y-3">
                      <div className="p-4 rounded-xl" style={{ background: 'rgba(34, 197, 94, 0.1)' }}>
                        <div className="text-xs font-bold text-green-300 mb-2">FINAL SUMMARY</div>
                        <div className="text-sm text-white font-semibold">{pipelineResult.stages.paradox.finalSummary || pipelineResult.stages.paradox.summary}</div>
                      </div>
                      {pipelineResult.stages.paradox.finalBlueprint && (
                        <div className="p-4 rounded-xl" style={{ background: 'rgba(0, 0, 0, 0.4)' }}>
                          <div className="text-xs font-bold text-green-300 mb-2">BLUEPRINT</div>
                          <div className="text-xs text-gray-300 whitespace-pre-wrap">{pipelineResult.stages.paradox.finalBlueprint}</div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Stage 4: NQ-FICE */}
                {pipelineResult.stages?.nqfice && (
                  <div className="stage-item rounded-2xl border p-6"
                    style={{
                      borderColor: 'rgba(36, 228, 255, 0.4)',
                      background: 'rgba(7, 7, 18, 0.95)',
                      animationDelay: '0.3s'
                    }}
                  >
                    <div className="flex items-center gap-3 mb-4">
                      <Box className="w-6 h-6 text-cyan-400" />
                      <h3 className="text-lg font-bold text-white">Stage 4: NQ-FICE</h3>
                    </div>
                    <div className="space-y-3">
                      {pipelineResult.stages.nqfice.fusedProposal && (
                        <div className="p-4 rounded-xl" style={{ background: 'rgba(36, 228, 255, 0.1)' }}>
                          <div className="text-xs font-bold text-cyan-300 mb-2">FUSED PROPOSAL</div>
                          <div className="text-sm text-gray-300">{pipelineResult.stages.nqfice.fusedProposal.summary}</div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Stage 5: 1998-Field */}
                {pipelineResult.stages?.field1998 && (
                  <div className="stage-item rounded-2xl border p-6"
                    style={{
                      borderColor: 'rgba(255, 215, 0, 0.4)',
                      background: 'rgba(7, 7, 18, 0.95)',
                      animationDelay: '0.4s'
                    }}
                  >
                    <div className="flex items-center gap-3 mb-4">
                      <Orbit className="w-6 h-6 text-yellow-400" />
                      <h3 className="text-lg font-bold text-white">Stage 5: 1998-Field</h3>
                    </div>
                    <div className="space-y-3">
                      {pipelineResult.stages.field1998.tachyonHypersphere && (
                        <div className="p-4 rounded-xl" style={{ background: 'rgba(255, 215, 0, 0.1)' }}>
                          <div className="text-xs font-bold text-yellow-300 mb-2">TACHYON INSIGHT</div>
                          <div className="text-sm text-gray-300">{pipelineResult.stages.field1998.tachyonHypersphere.meaning}</div>
                        </div>
                      )}
                      {pipelineResult.stages.field1998.symmetry && (
                        <div className="text-xs text-gray-400">
                          Symmetry: {pipelineResult.stages.field1998.symmetry.target} (deviation: {pipelineResult.stages.field1998.symmetry.deviation})
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Stage 6: Anti-1998-Field */}
                {pipelineResult.stages?.antifield1998 && (
                  <div className="stage-item rounded-2xl border p-6"
                    style={{
                      borderColor: 'rgba(139, 0, 139, 0.4)',
                      background: 'rgba(7, 7, 18, 0.95)',
                      animationDelay: '0.5s'
                    }}
                  >
                    <div className="flex items-center gap-3 mb-4">
                      <Radio className="w-6 h-6 text-purple-600" />
                      <h3 className="text-lg font-bold text-white">Stage 6: Anti-1998-Field</h3>
                    </div>
                    <div className="space-y-3">
                      {pipelineResult.stages.antifield1998.antiTachyonHypersphere && (
                        <div className="p-4 rounded-xl" style={{ background: 'rgba(139, 0, 139, 0.1)' }}>
                          <div className="text-xs font-bold text-purple-300 mb-2">ANTI-TACHYON INSIGHT</div>
                          <div className="text-sm text-gray-300">{pipelineResult.stages.antifield1998.antiTachyonHypersphere.meaning}</div>
                        </div>
                      )}
                      {pipelineResult.stages.antifield1998.symmetry && (
                        <div className="text-xs text-gray-400">
                          Inverted Symmetry: {pipelineResult.stages.antifield1998.symmetry.target} (deviation: {pipelineResult.stages.antifield1998.symmetry.deviation})
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Stage 7: Infinity Expansion */}
                {pipelineResult.stages?.infinity && (
                  <div className="stage-item rounded-2xl border p-6"
                    style={{
                      borderColor: 'rgba(255, 140, 0, 0.4)',
                      background: 'rgba(7, 7, 18, 0.95)',
                      boxShadow: '0 0 60px rgba(255, 140, 0, 0.3)',
                      animationDelay: '0.6s'
                    }}
                  >
                    <div className="flex items-center gap-3 mb-4">
                      <InfinityIcon className="w-6 h-6 text-orange-400" />
                      <h3 className="text-lg font-bold text-white">Stage 7: Infinity Expansion (Final)</h3>
                    </div>
                    <div className="space-y-4">
                      {pipelineResult.stages.infinity.math && (
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                          <div className="p-3 rounded-xl text-center" style={{ background: 'rgba(255, 140, 0, 0.1)', border: '1px solid rgba(255, 140, 0, 0.3)' }}>
                            <div className="text-xs text-gray-400 mb-1">Infinity Index</div>
                            <div className="text-xl font-bold text-orange-300">{pipelineResult.stages.infinity.math.infinityIndex?.toFixed(2)}</div>
                          </div>
                          <div className="p-3 rounded-xl text-center" style={{ background: 'rgba(255, 140, 0, 0.1)', border: '1px solid rgba(255, 140, 0, 0.3)' }}>
                            <div className="text-xs text-gray-400 mb-1">Growth Trend</div>
                            <div className="text-xs font-bold text-orange-300 uppercase">{pipelineResult.stages.infinity.math.growthTrend}</div>
                          </div>
                          <div className="p-3 rounded-xl text-center" style={{ background: 'rgba(255, 140, 0, 0.1)', border: '1px solid rgba(255, 140, 0, 0.3)' }}>
                            <div className="text-xs text-gray-400 mb-1">Branching</div>
                            <div className="text-xl font-bold text-orange-300">{pipelineResult.stages.infinity.math.branchingFactor?.toFixed(1)}</div>
                          </div>
                          <div className="p-3 rounded-xl text-center" style={{ background: 'rgba(239, 68, 68, 0.15)', border: '1px solid rgba(239, 68, 68, 0.3)' }}>
                            <div className="text-xs text-gray-400 mb-1">Collapse Risk</div>
                            <div className="text-xl font-bold text-red-400">{(pipelineResult.stages.infinity.math.collapseProbability * 100)?.toFixed(0)}%</div>
                          </div>
                        </div>
                      )}

                      {pipelineResult.stages.infinity.narrative?.explanation && (
                        <div className="p-4 rounded-xl" style={{ background: 'rgba(255, 140, 0, 0.12)' }}>
                          <div className="text-xs font-bold text-orange-300 mb-2">FINAL SYNTHESIS</div>
                          <div className="text-sm text-white leading-relaxed">{pipelineResult.stages.infinity.narrative.explanation}</div>
                        </div>
                      )}

                      {pipelineResult.stages.infinity.narrative?.architectNotes && (
                        <div className="p-4 rounded-xl" style={{ background: 'rgba(0, 0, 0, 0.4)' }}>
                          <div className="text-xs font-bold text-orange-300 mb-2">ARCHITECT RECOMMENDATIONS</div>
                          <ul className="space-y-1">
                            {pipelineResult.stages.infinity.narrative.architectNotes.map((note, i) => (
                              <li key={i} className="text-xs text-gray-300 flex items-start gap-2">
                                <ArrowRight className="w-3 h-3 text-orange-400 mt-0.5 flex-shrink-0" />
                                <span>{note}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer Info */}
        <div className="text-center text-xs text-gray-500">
          <p>Ultra Pipeline Engine · 7-Stage Full TAC Reasoning Framework</p>
          <p className="mt-1">Backend: http://localhost:8080/api/pipeline/run</p>
          <p className="mt-1 text-purple-400/60">Note: Backend must support all 7 stages for complete output</p>
        </div>
      </div>
    </div>
  );
}