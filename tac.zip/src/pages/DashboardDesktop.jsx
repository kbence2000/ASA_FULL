import React, { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, Sparkles, Shield, Zap, Clock, Brain, Users, RefreshCw, Network, X } from "lucide-react";

const LOG_MESSAGES = [
  "FutureMind: generated new abstraction.",
  "AlmightyCollective: module health anomaly detected.",
  "Meta overseer: evolving cluster routing.",
  "DebugAI: proposing code refinement.",
  "PvP Engine: new challenge pattern logged.",
  "FutureMind: Extracted pattern from PvP challenge.",
  "AlmightyCollective: Suggested 2 improvements to DebugAI.",
  "Meta overseer: Performance spike detected in agent cluster.",
  "FutureMind: Hybrid superpattern merged successfully.",
  "AlmightyCollective: Module reflection cycle completed."
];

const AGENT_STATES = ["good", "mid", "bad"];

const AGENT_ROLES = ["planner", "critic", "executor", "overseer"];
const ROLE_COLORS = {
  planner: "rgba(77, 255, 184,",
  critic: "rgba(255, 184, 77,",
  executor: "rgba(77, 183, 255,",
  overseer: "rgba(255, 75, 154,"
};

const AGENT_STATUSES = ["Idle", "Analyzing", "Routing", "Evolving", "Error"];
const AGENT_ACTIONS = [
  "Evaluating pattern",
  "Routing instruction",
  "Generating abstraction",
  "Verifying cluster link",
  "Passing token",
  "Checking module conflicts"
];
const ALMIGHTY_IMPACTS = ["Low", "Mid", "High"];

const TIMELINE_EVENTS = [
  { label: "Reflection cycle completed", tag: "AlmightyCollective" },
  { label: "Pattern extracted from PvP", tag: "FutureMind" },
  { label: "Agent cluster rebalanced", tag: "Meta Overseer" },
  { label: "Module conflict resolved", tag: "DebugAI" },
  { label: "New abstraction generated", tag: "FutureMind" },
  { label: "Performance spike detected", tag: "Meta Overseer" },
  { label: "Code refinement proposed", tag: "DebugAI" }
];

export default function DashboardDesktop() {
  const canvasRef = useRef(null);
  const globalCanvasRef = useRef(null);
  const pulseCanvasRef = useRef(null);
  const nodesRef = useRef([]);
  const globalNodesRef = useRef([]);
  const pulseDataRef = useRef([]);
  const [logs, setLogs] = useState([
    { text: "AlmightyCollective: Started new reflection cycle on FutureMind.", time: "just now" }
  ]);
  const [agentStates, setAgentStates] = useState(
    Array(8).fill(0).map((_, i) => ({
      id: i + 1,
      state: AGENT_STATES[Math.floor(Math.random() * AGENT_STATES.length)]
    }))
  );
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [agentInfoOpen, setAgentInfoOpen] = useState(false);
  const [timelineEvents, setTimelineEvents] = useState(
    TIMELINE_EVENTS.slice(0, 5).map(e => ({ ...e }))
  );

  // FutureMind Canvas Animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    let animationFrameId;

    function resizeCanvas() {
      const rect = canvas.parentElement.getBoundingClientRect();
      canvas.width = rect.width * window.devicePixelRatio;
      canvas.height = rect.height * window.devicePixelRatio;
      canvas.style.width = rect.width + "px";
      canvas.style.height = rect.height + "px";
    }

    function initNodes(count = 22) {
      nodesRef.current = [];
      for (let i = 0; i < count; i++) {
        nodesRef.current.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.4,
          vy: (Math.random() - 0.5) * 0.4
        });
      }
    }

    function draw() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const nodes = nodesRef.current;

      // Draw links
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const a = nodes[i], b = nodes[j];
          const dx = a.x - b.x, dy = a.y - b.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 160) {
            const alpha = 1 - dist / 160;
            ctx.strokeStyle = `rgba(136, 110, 157, ${alpha})`;
            ctx.lineWidth = 0.5;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.stroke();
          }
        }
      }

      // Draw nodes
      for (const n of nodes) {
        n.x += n.vx;
        n.y += n.vy;
        if (n.x < 0 || n.x > canvas.width) n.vx *= -1;
        if (n.y < 0 || n.y > canvas.height) n.vy *= -1;

        const r = 3 * window.devicePixelRatio;
        
        ctx.fillStyle = "#fff";
        ctx.beginPath();
        ctx.arc(n.x, n.y, r, 0, Math.PI * 2);
        ctx.fill();
      }

      animationFrameId = requestAnimationFrame(draw);
    }

    const handleResize = () => {
      resizeCanvas();
      initNodes(nodesRef.current.length || 22);
    };

    window.addEventListener("resize", handleResize);
    resizeCanvas();
    initNodes();
    draw();

    return () => {
      window.removeEventListener("resize", handleResize);
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, []);

  // Global Multi-Agent Map Canvas Animation with Click Interaction
  useEffect(() => {
    const canvas = globalCanvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    let animationFrameId;

    function resizeCanvas() {
      const rect = canvas.parentElement.getBoundingClientRect();
      canvas.width = rect.width * window.devicePixelRatio;
      canvas.height = rect.height * window.devicePixelRatio;
      canvas.style.width = rect.width + "px";
      canvas.style.height = rect.height + "px";
    }

    function initNodes(count = 30) {
      globalNodesRef.current = [];
      for (let i = 0; i < count; i++) {
        const role = AGENT_ROLES[Math.floor(Math.random() * AGENT_ROLES.length)];
        globalNodesRef.current.push({
          id: i,
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.3,
          vy: (Math.random() - 0.5) * 0.3,
          role,
          status: AGENT_STATUSES[Math.floor(Math.random() * AGENT_STATUSES.length)],
          action: AGENT_ACTIONS[Math.floor(Math.random() * AGENT_ACTIONS.length)],
          conf: Math.round(Math.random() * 40 + 60) + "%",
          depth: Math.floor(Math.random() * 5 + 1),
          impact: ALMIGHTY_IMPACTS[Math.floor(Math.random() * ALMIGHTY_IMPACTS.length)]
        });
      }
    }

    function draw() {
      // Background fade
      ctx.fillStyle = "rgba(2, 0, 20, 0.9)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const nodes = globalNodesRef.current;

      // Draw links
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const a = nodes[i], b = nodes[j];
          const dx = a.x - b.x, dy = a.y - b.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 180) {
            let alpha = 0.25 * (1 - dist / 180);
            const col = ROLE_COLORS[a.role] || "rgba(136, 110, 157,";
            
            // Enhanced highlight if selected
            const isHighlighted = selectedAgent && (a.id === selectedAgent.id || b.id === selectedAgent.id);
            if (isHighlighted) {
              alpha *= 2.2;
            }
            
            ctx.strokeStyle = col + alpha + ")";
            ctx.lineWidth = isHighlighted ? 1.4 : 0.4;
            
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.stroke();
          }
        }
      }

      // Draw nodes
      for (const n of nodes) {
        n.x += n.vx;
        n.y += n.vy;
        if (n.x < 0 || n.x > canvas.width) n.vx *= -1;
        if (n.y < 0 || n.y > canvas.height) n.vy *= -1;

        const r = 3 * window.devicePixelRatio;
        
        // Glow
        const glow = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, r * 4);
        const base = ROLE_COLORS[n.role] || "rgba(255, 255, 255,";
        glow.addColorStop(0, base + "1)");
        glow.addColorStop(1, base + "0)");
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(n.x, n.y, r * 4, 0, Math.PI * 2);
        ctx.fill();

        // Core
        ctx.fillStyle = "#fff";
        ctx.beginPath();
        ctx.arc(n.x, n.y, r, 0, Math.PI * 2);
        ctx.fill();

        // Selection ring
        if (selectedAgent && n.id === selectedAgent.id) {
          ctx.strokeStyle = "#ffffff";
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(n.x, n.y, r * 2.5, 0, Math.PI * 2);
          ctx.stroke();
        }
      }

      animationFrameId = requestAnimationFrame(draw);
    }

    function handleCanvasClick(event) {
      const rect = canvas.getBoundingClientRect();
      const scaleX = canvas.width / rect.width;
      const scaleY = canvas.height / rect.height;
      const mx = (event.clientX - rect.left) * scaleX;
      const my = (event.clientY - rect.top) * scaleY;

      const clickRadius = 12 * window.devicePixelRatio;
      const nodes = globalNodesRef.current;

      for (const node of nodes) {
        const dx = mx - node.x;
        const dy = my - node.y;
        const distance = Math.sqrt(dx * dx + dy * dy);

        if (distance < clickRadius) {
          setSelectedAgent(node);
          setAgentInfoOpen(true);
          return;
        }
      }

      // Click outside - close panel
      setSelectedAgent(null);
      setAgentInfoOpen(false);
    }

    const handleResize = () => {
      resizeCanvas();
      initNodes(globalNodesRef.current.length || 30);
    };

    canvas.addEventListener("click", handleCanvasClick);
    window.addEventListener("resize", handleResize);
    resizeCanvas();
    initNodes();
    draw();

    return () => {
      canvas.removeEventListener("click", handleCanvasClick);
      window.removeEventListener("resize", handleResize);
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, [selectedAgent]);

  // System Pulse Canvas Animation
  useEffect(() => {
    const canvas = pulseCanvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    let animationFrameId;

    function resizeCanvas() {
      const rect = canvas.parentElement.getBoundingClientRect();
      canvas.width = rect.width * window.devicePixelRatio;
      canvas.height = 60 * window.devicePixelRatio;
      canvas.style.width = rect.width + "px";
      canvas.style.height = "60px";
    }

    // Initialize pulse data
    const maxPoints = 100;
    pulseDataRef.current = Array(maxPoints).fill(0.5);

    function draw() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Add new data point
      const newValue = 0.3 + Math.random() * 0.7; // 0.3 to 1.0
      pulseDataRef.current.push(newValue);
      if (pulseDataRef.current.length > maxPoints) {
        pulseDataRef.current.shift();
      }

      const data = pulseDataRef.current;
      const stepX = canvas.width / (maxPoints - 1);
      const midY = canvas.height / 2;
      const amplitude = canvas.height * 0.35;

      // Draw pulse line
      ctx.beginPath();
      ctx.strokeStyle = "#4dffb8";
      ctx.lineWidth = 2 * window.devicePixelRatio;
      ctx.shadowBlur = 8 * window.devicePixelRatio;
      ctx.shadowColor = "#4dffb8";

      for (let i = 0; i < data.length; i++) {
        const x = i * stepX;
        const y = midY - (data[i] - 0.5) * amplitude;
        
        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }

      ctx.stroke();
      ctx.shadowBlur = 0;

      animationFrameId = requestAnimationFrame(draw);
    }

    const handleResize = () => {
      resizeCanvas();
    };

    window.addEventListener("resize", handleResize);
    resizeCanvas();
    draw();

    return () => {
      window.removeEventListener("resize", handleResize);
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, []);

  // Auto-update log feed
  useEffect(() => {
    const interval = setInterval(() => {
      const randomLog = LOG_MESSAGES[Math.floor(Math.random() * LOG_MESSAGES.length)];
      setLogs(prev => {
        const newLogs = [{ text: randomLog, time: "just now" }, ...prev];
        return newLogs.slice(0, 7);
      });
    }, 3500);

    return () => clearInterval(interval);
  }, []);

  // Auto-update agent states
  useEffect(() => {
    const interval = setInterval(() => {
      setAgentStates(
        Array(8).fill(0).map((_, i) => ({
          id: i + 1,
          state: AGENT_STATES[Math.floor(Math.random() * AGENT_STATES.length)]
        }))
      );
    }, 4500);

    return () => clearInterval(interval);
  }, []);

  // Auto-update timeline
  useEffect(() => {
    const interval = setInterval(() => {
      const randomEvent = TIMELINE_EVENTS[Math.floor(Math.random() * TIMELINE_EVENTS.length)];
      
      setTimelineEvents(prev => {
        return [{ ...randomEvent }, ...prev].slice(0, 5);
      });
    }, 6000);

    return () => clearInterval(interval);
  }, []);

  const closeAgentInfo = () => {
    setSelectedAgent(null);
    setAgentInfoOpen(false);
  };

  return (
    <div className="min-h-screen relative" style={{
      background: `
        radial-gradient(circle at top, rgba(77, 13, 111, 0.13), transparent),
        radial-gradient(circle at bottom, rgba(136, 110, 157, 0.13), transparent),
        #020007
      `
    }}>
      {/* ... keep existing code (full Desktop Dashboard content) ... */}
      {/* Header, Main Grid, Panels, Agent Info Sidebar, Footer */}
      {/* (teljes tartalom a korábbi Dashboard.jsx-ből) */}

      <header className="max-w-[1300px] mx-auto px-5 py-5">
        {/* ... keep existing code ... */}
      </header>

      <main className="max-w-[1300px] mx-auto px-5 pb-8">
        {/* ... keep existing code ... */}
      </main>

      <div className="fixed top-0 right-0 w-80 h-screen border-l p-5 overflow-y-auto transition-all duration-[350ms] z-50" style={{
        background: 'linear-gradient(180deg, #080010, #020006)',
        borderColor: 'rgba(255, 255, 255, 0.13)',
        boxShadow: '-4px 0 22px rgba(0, 0, 0, 0.7)',
        transform: agentInfoOpen ? 'translateX(0)' : 'translateX(100%)'
      }}>
        {/* ... keep existing code ... */}
      </div>

      {agentInfoOpen && (
        <div className="fixed inset-0 bg-black/40 z-40" onClick={closeAgentInfo} />
      )}

      <footer className="max-w-[1300px] mx-auto px-5 py-5 flex justify-between items-center gap-3 text-[10px] opacity-70 flex-wrap" style={{ color: '#b8a6cf' }}>
        {/* ... keep existing code ... */}
      </footer>
    </div>
  );
}