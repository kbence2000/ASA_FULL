import React, { useState, useEffect } from 'react';
import { MessageSquare, TrendingUp, AlertTriangle, CheckCircle2, Clock, Filter, RefreshCw, Zap, Brain, Eye, BarChart3, ArrowUpRight, Tag, Hexagon, Activity } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

const CATEGORY_COLORS = {
  bug: '#ff4b81',
  feature: '#24e4ff',
  improvement: '#4cffa8',
  question: '#ffdb7c',
  praise: '#a84cff',
  complaint: '#ff6ec7',
  general: '#8c8faf'
};

const PRIORITY_COLORS = {
  low: '#4cffa8',
  medium: '#ffdb7c',
  high: '#ff9966',
  critical: '#ff4b81'
};

const STATUS_COLORS = {
  pending: '#8c8faf',
  analyzed: '#4f7cff',
  in_progress: '#ffdb7c',
  resolved: '#4cffa8',
  rejected: '#ff4b81',
  archived: '#5a5a6e'
};

export default function TACFeedbackHub() {
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedFeedback, setSelectedFeedback] = useState(null);
  const queryClient = useQueryClient();

  // Fetch feedback
  const { data: feedbackList = [], isLoading } = useQuery({
    queryKey: ['feedback', selectedStatus, selectedCategory],
    queryFn: async () => {
      const list = await base44.entities.Feedback.list('-created_date', 100);
      
      // Apply filters
      let filtered = list;
      if (selectedStatus !== 'all') {
        filtered = filtered.filter(f => f.status === selectedStatus);
      }
      if (selectedCategory !== 'all') {
        filtered = filtered.filter(f => f.category === selectedCategory);
      }
      
      return filtered;
    },
    refetchInterval: 10000, // Refresh every 10s
  });

  // Update feedback mutation
  const updateFeedbackMutation = useMutation({
    mutationFn: async ({ id, updates }) => {
      return await base44.entities.Feedback.update(id, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['feedback'] });
    }
  });

  // Quick assign category
  const assignCategory = (feedbackId, category) => {
    updateFeedbackMutation.mutate({
      id: feedbackId,
      updates: { category, status: 'analyzed' }
    });
  };

  // Quick assign priority
  const assignPriority = (feedbackId, priority) => {
    updateFeedbackMutation.mutate({
      id: feedbackId,
      updates: { priority }
    });
  };

  // Update status
  const updateStatus = (feedbackId, status) => {
    const updates = { status };
    if (status === 'resolved') {
      updates.resolvedAt = new Date().toISOString();
    }
    updateFeedbackMutation.mutate({ id: feedbackId, updates });
  };

  // Stats
  const stats = {
    total: feedbackList.length,
    pending: feedbackList.filter(f => f.status === 'pending').length,
    analyzed: feedbackList.filter(f => f.status === 'analyzed').length,
    inProgress: feedbackList.filter(f => f.status === 'in_progress').length,
    resolved: feedbackList.filter(f => f.status === 'resolved').length,
    critical: feedbackList.filter(f => f.priority === 'critical').length
  };

  // Paradox metrics from analysis
  const getParadoxMetrics = (paradoxAnalysis) => {
    if (!paradoxAnalysis) return null;
    
    return {
      entropy: paradoxAnalysis.entropy || 0,
      coherence: paradoxAnalysis.coherence || 0,
      complexity: paradoxAnalysis.complexity || 0,
      innovation: paradoxAnalysis.innovation || 0,
      stability: paradoxAnalysis.stability || 0
    };
  };

  return (
    <div className="min-h-screen p-4" style={{
      background: 'radial-gradient(circle at top, #0a0a14 0, #030306 55%)'
    }}>
      <style>{`
        .feedback-card {
          transition: all 0.2s ease-out;
        }
        
        .feedback-card:hover {
          transform: translateY(-2px);
        }

        .feedback-card.selected {
          box-shadow: 0 0 0 2px rgba(36, 228, 255, 0.6);
        }

        .stat-card {
          background: rgba(10, 10, 20, 0.8);
          border: 1px solid rgba(255, 255, 255, 0.1);
          transition: all 0.3s;
        }

        .stat-card:hover {
          border-color: rgba(36, 228, 255, 0.4);
          box-shadow: 0 0 20px rgba(36, 228, 255, 0.2);
        }

        .metric-bar {
          height: 4px;
          border-radius: 2px;
          transition: all 0.3s;
        }
      `}</style>

      <div className="max-w-[1600px] mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: 'radial-gradient(circle at 20% 0, #ffffff, #24e4ff 40%, #0b6b8f)',
                boxShadow: '0 0 30px rgba(36, 228, 255, 0.6)'
              }}
            >
              <MessageSquare className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="text-xl font-bold text-white tracking-wide">
                TAC FEEDBACK HUB
              </div>
              <div className="text-xs text-gray-400 tracking-wider">
                Paradox-Powered Feedback Analysis • n8n Integration
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full" style={{
            background: 'rgba(36, 228, 255, 0.12)',
            border: '1px solid rgba(36, 228, 255, 0.6)'
          }}>
            <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: '#24e4ff' }} />
            <span className="text-xs font-semibold" style={{ color: '#24e4ff' }}>
              LIVE MONITORING
            </span>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mb-6">
          <div className="stat-card rounded-2xl p-4">
            <div className="text-xs text-gray-400 mb-2">Total</div>
            <div className="text-3xl font-black text-cyan-400">{stats.total}</div>
          </div>
          <div className="stat-card rounded-2xl p-4">
            <div className="text-xs text-gray-400 mb-2">Pending</div>
            <div className="text-3xl font-black text-gray-400">{stats.pending}</div>
          </div>
          <div className="stat-card rounded-2xl p-4">
            <div className="text-xs text-gray-400 mb-2">Analyzed</div>
            <div className="text-3xl font-black text-blue-400">{stats.analyzed}</div>
          </div>
          <div className="stat-card rounded-2xl p-4">
            <div className="text-xs text-gray-400 mb-2">In Progress</div>
            <div className="text-3xl font-black text-yellow-400">{stats.inProgress}</div>
          </div>
          <div className="stat-card rounded-2xl p-4">
            <div className="text-xs text-gray-400 mb-2">Resolved</div>
            <div className="text-3xl font-black text-green-400">{stats.resolved}</div>
          </div>
          <div className="stat-card rounded-2xl p-4">
            <div className="text-xs text-gray-400 mb-2">Critical</div>
            <div className="text-3xl font-black text-red-400">{stats.critical}</div>
          </div>
        </div>

        {/* Filters */}
        <div className="mb-6 flex flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-gray-400" />
            <span className="text-xs text-gray-400 uppercase">Status:</span>
            {['all', 'pending', 'analyzed', 'in_progress', 'resolved'].map(status => (
              <button
                key={status}
                onClick={() => setSelectedStatus(status)}
                className="px-3 py-1 rounded-full text-xs font-semibold uppercase transition-all"
                style={{
                  background: selectedStatus === status ? 'rgba(36, 228, 255, 0.2)' : 'transparent',
                  border: `1px solid ${selectedStatus === status ? 'rgba(36, 228, 255, 0.6)' : 'rgba(255, 255, 255, 0.1)'}`,
                  color: selectedStatus === status ? '#24e4ff' : '#8c8faf'
                }}
              >
                {status.replace('_', ' ')}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <Tag className="w-4 h-4 text-gray-400" />
            <span className="text-xs text-gray-400 uppercase">Category:</span>
            {['all', 'bug', 'feature', 'improvement', 'question', 'praise'].map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className="px-3 py-1 rounded-full text-xs font-semibold uppercase transition-all"
                style={{
                  background: selectedCategory === cat ? `${CATEGORY_COLORS[cat] || '#8c8faf'}20` : 'transparent',
                  border: `1px solid ${selectedCategory === cat ? `${CATEGORY_COLORS[cat] || '#8c8faf'}80` : 'rgba(255, 255, 255, 0.1)'}`,
                  color: selectedCategory === cat ? (CATEGORY_COLORS[cat] || '#8c8faf') : '#8c8faf'
                }}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Feedback List */}
          <div className="lg:col-span-7 space-y-3 max-h-[calc(100vh-350px)] overflow-y-auto pr-2">
            {isLoading && (
              <div className="text-center py-12">
                <RefreshCw className="w-8 h-8 mx-auto mb-3 animate-spin text-cyan-400" />
                <div className="text-sm text-gray-400">Loading feedback...</div>
              </div>
            )}

            {!isLoading && feedbackList.length === 0 && (
              <div className="text-center py-12 rounded-2xl border" style={{
                background: 'rgba(10, 10, 20, 0.8)',
                borderColor: 'rgba(255, 255, 255, 0.1)'
              }}>
                <MessageSquare className="w-12 h-12 mx-auto mb-3 text-gray-600" />
                <div className="text-sm text-gray-400">No feedback items found</div>
                <div className="text-xs text-gray-600 mt-2">
                  Send feedback via n8n webhook: POST /api/n8n-feedback
                </div>
              </div>
            )}

            {feedbackList.map((feedback, idx) => {
              const isSelected = selectedFeedback?.id === feedback.id;
              const metrics = getParadoxMetrics(feedback.paradoxAnalysis);
              
              return (
                <div
                  key={feedback.id}
                  onClick={() => setSelectedFeedback(feedback)}
                  className={`feedback-card rounded-2xl border p-4 cursor-pointer ${isSelected ? 'selected' : ''}`}
                  style={{
                    background: 'rgba(10, 10, 20, 0.9)',
                    borderColor: isSelected ? 'rgba(36, 228, 255, 0.6)' : 'rgba(255, 255, 255, 0.1)'
                  }}
                >
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3 flex-1">
                      <Hexagon className="w-5 h-5 flex-shrink-0 text-purple-400" />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-semibold text-white mb-1 truncate">
                          {feedback.content.substring(0, 80) + (feedback.content.length > 80 ? '...' : '')}
                        </div>
                        <div className="text-xs text-gray-500">
                          {new Date(feedback.created_date).toLocaleString()} • {feedback.userId || 'Anonymous'}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mb-2">
                    <span 
                      className="px-2 py-1 rounded-full text-[9px] font-bold uppercase"
                      style={{
                        background: `${STATUS_COLORS[feedback.status] || '#8c8faf'}20`,
                        color: STATUS_COLORS[feedback.status] || '#8c8faf',
                        border: `1px solid ${STATUS_COLORS[feedback.status] || '#8c8faf'}60`
                      }}
                    >
                      {feedback.status}
                    </span>
                    {feedback.category && (
                      <span 
                        className="px-2 py-1 rounded-full text-[9px] font-bold uppercase"
                        style={{
                          background: `${CATEGORY_COLORS[feedback.category]}20`,
                          color: CATEGORY_COLORS[feedback.category],
                          border: `1px solid ${CATEGORY_COLORS[feedback.category]}60`
                        }}
                      >
                        {feedback.category}
                      </span>
                    )}
                    {feedback.priority && (
                      <span 
                        className="px-2 py-1 rounded-full text-[9px] font-bold uppercase"
                        style={{
                          background: `${PRIORITY_COLORS[feedback.priority]}20`,
                          color: PRIORITY_COLORS[feedback.priority],
                          border: `1px solid ${PRIORITY_COLORS[feedback.priority]}60`
                        }}
                      >
                        {feedback.priority}
                      </span>
                    )}
                    {feedback.source && (
                      <span className="px-2 py-1 rounded-full text-[9px] font-bold uppercase bg-white/5 text-gray-400 border border-white/10">
                        {feedback.source}
                      </span>
                    )}
                  </div>

                  {/* Paradox Metrics (Mini) */}
                  {metrics && (
                    <div className="grid grid-cols-5 gap-2 text-[9px] text-gray-500">
                      <div>
                        <div className="mb-1">Entropy</div>
                        <div className="metric-bar" style={{ 
                          width: `${Math.min(metrics.entropy * 100, 100)}%`,
                          background: '#4f7cff'
                        }} />
                      </div>
                      <div>
                        <div className="mb-1">Coherence</div>
                        <div className="metric-bar" style={{ 
                          width: `${Math.min(metrics.coherence * 100, 100)}%`,
                          background: '#4cffa8'
                        }} />
                      </div>
                      <div>
                        <div className="mb-1">Complex</div>
                        <div className="metric-bar" style={{ 
                          width: `${Math.min(metrics.complexity * 100, 100)}%`,
                          background: '#ffdb7c'
                        }} />
                      </div>
                      <div>
                        <div className="mb-1">Innovate</div>
                        <div className="metric-bar" style={{ 
                          width: `${Math.min(metrics.innovation * 100, 100)}%`,
                          background: '#ff6ec7'
                        }} />
                      </div>
                      <div>
                        <div className="mb-1">Stability</div>
                        <div className="metric-bar" style={{ 
                          width: `${Math.min(metrics.stability * 100, 100)}%`,
                          background: '#a84cff'
                        }} />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Right: Feedback Details */}
          <div className="lg:col-span-5">
            {!selectedFeedback ? (
              <div className="rounded-2xl border p-12 text-center" style={{
                background: 'rgba(10, 10, 20, 0.9)',
                borderColor: 'rgba(255, 255, 255, 0.1)',
                minHeight: '500px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <div>
                  <Eye className="w-16 h-16 mx-auto mb-4 text-gray-600" />
                  <div className="text-sm text-gray-400">
                    Select a feedback item to view details
                  </div>
                </div>
              </div>
            ) : (
              <div className="rounded-2xl border p-6 space-y-4" style={{
                background: 'rgba(10, 10, 20, 0.9)',
                borderColor: 'rgba(36, 228, 255, 0.3)'
              }}>
                <div className="pb-4 border-b" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
                  <h3 className="text-lg font-bold text-white mb-2">Feedback Details</h3>
                  <div className="text-xs text-gray-500">ID: {selectedFeedback.id}</div>
                </div>

                {/* Content */}
                <div>
                  <div className="text-xs font-bold text-gray-400 mb-2">CONTENT</div>
                  <div className="text-sm text-gray-300 leading-relaxed p-3 rounded-lg" style={{
                    background: 'rgba(0, 0, 0, 0.3)'
                  }}>
                    {selectedFeedback.content}
                  </div>
                </div>

                {/* Paradox Analysis */}
                {selectedFeedback.paradoxAnalysis && (
                  <div>
                    <div className="text-xs font-bold text-gray-400 mb-2 flex items-center gap-2">
                      <Hexagon className="w-3 h-3" />
                      PARADOX ANALYSIS
                    </div>
                    <div className="space-y-3">
                      {(() => {
                        const metrics = getParadoxMetrics(selectedFeedback.paradoxAnalysis);
                        if (!metrics) return <div className="text-xs text-gray-500">No metrics available</div>;
                        
                        return (
                          <div className="grid grid-cols-2 gap-3">
                            {Object.entries(metrics).map(([key, value]) => (
                              <div key={key} className="p-2 rounded-lg" style={{ background: 'rgba(79, 124, 255, 0.1)' }}>
                                <div className="text-xs text-gray-400 uppercase mb-1">{key}</div>
                                <div className="text-xl font-bold text-cyan-400">{(value * 100).toFixed(1)}%</div>
                                <div className="metric-bar mt-1" style={{ 
                                  width: `${Math.min(value * 100, 100)}%`,
                                  background: '#4f7cff'
                                }} />
                              </div>
                            ))}
                          </div>
                        );
                      })()}
                      
                      {selectedFeedback.paradoxAnalysis.summary && (
                        <div className="text-xs text-gray-300 p-2 rounded" style={{ background: 'rgba(0, 0, 0, 0.3)' }}>
                          {selectedFeedback.paradoxAnalysis.summary}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Quick Actions */}
                <div>
                  <div className="text-xs font-bold text-gray-400 mb-2">QUICK ASSIGN</div>
                  
                  {/* Category */}
                  <div className="mb-3">
                    <div className="text-xs text-gray-500 mb-1">Category:</div>
                    <div className="flex flex-wrap gap-2">
                      {['bug', 'feature', 'improvement', 'question', 'praise'].map(cat => (
                        <button
                          key={cat}
                          onClick={() => assignCategory(selectedFeedback.id, cat)}
                          disabled={selectedFeedback.category === cat}
                          className="px-2 py-1 rounded text-[10px] font-bold uppercase transition-all disabled:opacity-50"
                          style={{
                            background: `${CATEGORY_COLORS[cat]}20`,
                            border: `1px solid ${CATEGORY_COLORS[cat]}60`,
                            color: CATEGORY_COLORS[cat]
                          }}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Priority */}
                  <div className="mb-3">
                    <div className="text-xs text-gray-500 mb-1">Priority:</div>
                    <div className="flex flex-wrap gap-2">
                      {['low', 'medium', 'high', 'critical'].map(pri => (
                        <button
                          key={pri}
                          onClick={() => assignPriority(selectedFeedback.id, pri)}
                          disabled={selectedFeedback.priority === pri}
                          className="px-2 py-1 rounded text-[10px] font-bold uppercase transition-all disabled:opacity-50"
                          style={{
                            background: `${PRIORITY_COLORS[pri]}20`,
                            border: `1px solid ${PRIORITY_COLORS[pri]}60`,
                            color: PRIORITY_COLORS[pri]
                          }}
                        >
                          {pri}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Status Actions */}
                <div>
                  <div className="text-xs font-bold text-gray-400 mb-2">STATUS ACTIONS</div>
                  <div className="flex flex-wrap gap-2">
                    {['in_progress', 'resolved', 'rejected', 'archived'].map(status => (
                      <button
                        key={status}
                        onClick={() => updateStatus(selectedFeedback.id, status)}
                        disabled={selectedFeedback.status === status}
                        className="px-3 py-2 rounded-lg text-xs font-semibold uppercase transition-all disabled:opacity-40"
                        style={{
                          background: 'rgba(36, 228, 255, 0.2)',
                          border: '1px solid rgba(36, 228, 255, 0.4)',
                          color: '#24e4ff'
                        }}
                      >
                        {status.replace('_', ' ')}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Metadata */}
                <div className="pt-4 border-t" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
                  <div className="text-xs text-gray-500 space-y-1">
                    <div>Source: {selectedFeedback.source}</div>
                    <div>User: {selectedFeedback.userId || 'Anonymous'}</div>
                    <div>Created: {new Date(selectedFeedback.created_date).toLocaleString()}</div>
                    {selectedFeedback.resolvedAt && (
                      <div>Resolved: {new Date(selectedFeedback.resolvedAt).toLocaleString()}</div>
                    )}
                    {selectedFeedback.assignedTo && (
                      <div>Assigned to: {selectedFeedback.assignedTo}</div>
                    )}
                  </div>
                </div>

                {/* Raw Data (Expandable) */}
                {selectedFeedback.raw && (
                  <details className="text-xs">
                    <summary className="text-gray-400 cursor-pointer hover:text-cyan-400 transition-colors">
                      View Raw Data
                    </summary>
                    <pre className="mt-2 p-2 rounded bg-black/40 text-gray-400 overflow-auto max-h-40 text-[10px]">
                      {selectedFeedback.raw}
                    </pre>
                  </details>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer Info */}
        <div className="mt-6 text-center text-xs text-gray-600">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Activity className="w-3 h-3" />
            <span>TAC Feedback Hub • Paradox-Powered Analysis</span>
          </div>
          <div>n8n Webhook: POST /api/n8n-feedback • Backend: processFeedback()</div>
        </div>
      </div>
    </div>
  );
}