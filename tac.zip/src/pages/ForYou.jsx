import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Sparkles, TrendingUp, Github, Linkedin, MessageSquare,
  Filter, Target, ExternalLink, Clock, ArrowUp, Flame, RefreshCw
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

const generateMockFeed = () => {
  const linkedInTrends = [
    {
      id: "li_001",
      source: "linkedin",
      title: "Engineering teams pivot to AI-first sprints",
      summary: "In 2025, 90% of developer roadmaps include AI productivity sprints. LinkedIn engineering leaders report 40% faster code reviews with generative AI tools.",
      link: "https://linkedin.com/pulse/ai-first-engineering",
      tags: ["ai", "engineering", "devproductivity"],
      score: 92,
      time: Date.now() - 1000 * 60 * 20
    },
    {
      id: "li_002",
      source: "linkedin",
      title: "Remote-first startups outpace traditional tech giants",
      summary: "Distributed engineering teams develop 3x faster with 50% higher retention compared to traditional companies.",
      link: "https://linkedin.com/pulse/remote-first-advantage",
      tags: ["remote", "startup", "engineering"],
      score: 88,
      time: Date.now() - 1000 * 60 * 45
    }
  ];

  const githubTrends = [
    {
      id: "gh_001",
      source: "github",
      title: "FastAPI 2025 new extensions released",
      summary: "FastAPI explodes with AI-ready architectures: automatic worker pool, agent plugin API, and native LangChain integration. The repo gained 12K+ stars in 48 hours.",
      tags: ["python", "api", "backend", "ai"],
      score: 89,
      time: Date.now() - 1000 * 60 * 30
    },
    {
      id: "gh_002",
      source: "github",
      title: "Rust-based web framework achieves 10x Node.js performance",
      summary: "Axum framework benchmarks show 10x faster request handling than vanilla Node.js with microsecond latency. Over 200 companies now use it in production.",
      tags: ["rust", "performance", "backend"],
      score: 91,
      time: Date.now() - 1000 * 60 * 50
    },
    {
      id: "gh_003",
      source: "github",
      title: "TypeScript 5.4 ships with major DX improvements",
      summary: "New version brings instant type-checking, 60% speed boost, and better inference. Community already updated 500+ open-source libraries.",
      tags: ["typescript", "javascript", "dx"],
      score: 86,
      time: Date.now() - 1000 * 60 * 90
    }
  ];

  const redditTrends = [
    {
      id: "rd_001",
      source: "reddit",
      title: "I built a SaaS in 48 hours with AI agents",
      summary: "r/Entrepreneur and r/Programming are buzzing with AI-SaaS rapid development. A solo developer built a $5K MRR SaaS over a weekend using Cursor AI and Claude. 2.3K upvotes, 400+ comments.",
      tags: ["startup", "indie", "ai", "saas"],
      score: 87,
      time: Date.now() - 1000 * 60 * 40
    },
    {
      id: "rd_002",
      source: "reddit",
      title: "Senior devs switching to consulting earn 2-3x more",
      summary: "r/ExperiencedDevs thread shows senior+ developers who switch to consulting average $200-400/hour vs $150K fixed salary. Over 50 success stories in the thread.",
      tags: ["career", "consulting", "salary"],
      score: 85,
      time: Date.now() - 1000 * 60 * 70
    }
  ];

  const mdcSignals = [
    {
      id: "mdc_001",
      source: "mdc",
      title: "Yesterday's Coding PvP final snippet",
      summary: "Demigod 'Nova' showed such optimized code that judges gave a 99 rating. The snippet handles 10K concurrent requests in 3 seconds with zero allocations.",
      tags: ["coding", "pvp", "demigod", "performance"],
      score: 95,
      time: Date.now() - 1000 * 60 * 10
    },
    {
      id: "mdc_002",
      source: "mdc",
      title: "New project uploaded: AI-driven marketplace manager",
      summary: "A Rising Star uploaded a microservice that automatically valuates projects. 12 companies are testing it in production with 94% average accuracy.",
      tags: ["project", "ai", "automation", "marketplace"],
      score: 88,
      time: Date.now() - 1000 * 60 * 60
    },
    {
      id: "mdc_003",
      source: "mdc",
      title: "Elite demigod unlocked: Lyra reaches R6 tier",
      summary: "Lyra reached Demigod R6 level in 3 months. Portfolio: 8 production SaaS, 150K+ GitHub stars, and 15 successful PvP challenges. Now available in Enterprise Pool.",
      tags: ["demigod", "milestone", "elite"],
      score: 93,
      time: Date.now() - 1000 * 60 * 15
    },
    {
      id: "mdc_004",
      source: "mdc",
      title: "Innovation PvP: Real-time AI translator wins $10K bounty",
      summary: "An Innovation Challenge winner built a context-aware real-time AI translator. 40ms latency, 23 language support, already used by 3 companies.",
      tags: ["innovation", "ai", "bounty", "translator"],
      score: 90,
      time: Date.now() - 1000 * 60 * 25
    }
  ];

  return [...linkedInTrends, ...githubTrends, ...redditTrends, ...mdcSignals];
};

const computeWeightedFeed = (feedItems, userProfile = {}) => {
  const tagsImportant = (userProfile.interests || []).map(t => t.toLowerCase());
  const userType = userProfile.type || "dev";

  return feedItems.map(item => {
    let score = item.score;

    const itemTags = (item.tags || []).map(t => t.toLowerCase());
    const matchCount = tagsImportant.filter(tag => itemTags.includes(tag)).length;
    if (matchCount > 0) {
      score += matchCount * 8;
    }

    if (item.source === "mdc") {
      score += 5;
    }

    if (userType === "business" && item.source === "linkedin") {
      score += 5;
    }

    if (userType === "dev" && item.source === "github") {
      score += 3;
    }

    const ageMinutes = (Date.now() - item.time) / (1000 * 60);
    const recencyBoost = Math.max(0, 10 - ageMinutes / 10);
    score += recencyBoost;

    return { ...item, weighted: Math.round(score) };
  });
};

export default function ForYou() {
  const [sourceFilter, setSourceFilter] = useState("all");
  const [refreshKey, setRefreshKey] = useState(0);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const rawFeed = useMemo(() => generateMockFeed(), [refreshKey]);

  const weightedFeed = useMemo(() => {
    const profile = {
      id: user?.id || "guest",
      interests: user?.tech_stack || ["ai", "startup", "engineering"],
      type: user?.role === "admin" ? "business" : "dev"
    };

    return computeWeightedFeed(rawFeed, profile)
      .sort((a, b) => b.weighted - a.weighted);
  }, [rawFeed, user]);

  const filteredFeed = useMemo(() => {
    if (sourceFilter === "all") return weightedFeed;
    return weightedFeed.filter(item => item.source === sourceFilter);
  }, [weightedFeed, sourceFilter]);

  const handleRefresh = () => {
    setRefreshKey(prev => prev + 1);
    toast.success("Feed refreshed!");
  };

  const sourceIcons = {
    linkedin: Linkedin,
    github: Github,
    reddit: MessageSquare,
    mdc: Sparkles
  };

  const sourceColors = {
    linkedin: "from-blue-500 to-blue-600",
    github: "from-purple-500 to-purple-600",
    reddit: "from-orange-500 to-orange-600",
    mdc: "from-pink-500 to-purple-600"
  };

  const sourceBadgeColors = {
    linkedin: "bg-blue-600/20 text-blue-300 border-blue-600/30",
    github: "bg-purple-600/20 text-purple-300 border-purple-600/30",
    reddit: "bg-orange-600/20 text-orange-300 border-orange-600/30",
    mdc: "bg-pink-600/20 text-pink-300 border-pink-600/30"
  };

  const formatTimeAgo = (timestamp) => {
    const minutes = Math.floor((Date.now() - timestamp) / (1000 * 60));
    if (minutes < 1) return "just now";
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  return (
    <div className="min-h-screen">
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 grid-pattern opacity-30" />
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl" />
        
        <div className="relative max-w-7xl mx-auto px-4 py-20">
          <div className="max-w-4xl">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6" style={{
              background: 'rgba(36, 228, 255, 0.1)',
              border: '1px solid rgba(36, 228, 255, 0.3)'
            }}>
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span className="text-sm font-mono uppercase tracking-wider text-cyan-300">
                AI-Powered Master Feed
              </span>
            </div>

            <h1 className="text-5xl lg:text-6xl font-black mb-6">
              Your <span className="gradient-text">Personalized</span>
              <br />
              Dev Intelligence
            </h1>

            <p className="text-xl text-gray-400 mb-8 leading-relaxed">
              AI-curated trends from LinkedIn, GitHub, Reddit, and MDC elite community.
              Stay ahead with insights tailored to your tech stack and interests.
            </p>

            <div className="flex flex-wrap gap-6 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <span className="text-gray-400">Live updates every 5 minutes</span>
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-cyan-400" />
                <span className="text-gray-400">{filteredFeed.length} trending topics</span>
              </div>
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-purple-400" />
                <span className="text-gray-400">Personalized for you</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-wrap gap-4 justify-between items-center mb-8">
            <div className="flex items-center gap-3">
              <Filter className="w-5 h-5 text-purple-400" />
              <Select value={sourceFilter} onValueChange={setSourceFilter}>
                <SelectTrigger className="w-48 border-purple-500/30 bg-[#0b0816]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Sources</SelectItem>
                  <SelectItem value="mdc">MDC Elite</SelectItem>
                  <SelectItem value="linkedin">LinkedIn</SelectItem>
                  <SelectItem value="github">GitHub</SelectItem>
                  <SelectItem value="reddit">Reddit</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button
              onClick={handleRefresh}
              variant="outline"
              className="border-purple-500/30 hover:border-purple-500/50"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh Feed
            </Button>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            {filteredFeed.map((item, idx) => {
              const SourceIcon = sourceIcons[item.source];
              const gradient = sourceColors[item.source];
              const badgeColor = sourceBadgeColors[item.source];

              return (
                <Card
                  key={item.id}
                  className="border-purple-500/30 bg-[#0b0816] hover:border-purple-500/50 transition-all hover:scale-[1.02] cursor-pointer group"
                  style={{ animationDelay: `${idx * 0.05}s` }}
                >
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center flex-shrink-0`}>
                        <SourceIcon className="w-6 h-6 text-white" />
                      </div>

                      <div className="flex items-center gap-2">
                        <Badge className={badgeColor}>
                          {item.source.toUpperCase()}
                        </Badge>
                        {item.weighted >= 95 && (
                          <Badge className="bg-yellow-600/20 text-yellow-300 border-yellow-600/30">
                            <Flame className="w-3 h-3 mr-1" />
                            HOT
                          </Badge>
                        )}
                      </div>
                    </div>

                    <h3 className="text-lg font-bold text-white mb-3 leading-tight group-hover:text-gradient transition-colors">
                      {item.title}
                    </h3>

                    <p className="text-sm text-gray-400 leading-relaxed mb-4">
                      {item.summary}
                    </p>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {item.tags.map((tag, i) => (
                        <span
                          key={i}
                          className="text-xs px-2 py-1 rounded-full border border-purple-500/30 text-purple-300"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-purple-500/20">
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {formatTimeAgo(item.time)}
                        </div>
                        <div className="flex items-center gap-1">
                          <ArrowUp className="w-3 h-3 text-cyan-400" />
                          <span className="text-cyan-400 font-semibold">
                            {item.weighted} score
                          </span>
                        </div>
                      </div>

                      {item.link && (
                        <a
                          href={item.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs text-purple-400 hover:text-purple-300 flex items-center gap-1"
                          onClick={(e) => e.stopPropagation()}
                        >
                          Read more
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>

          {filteredFeed.length === 0 && (
            <div className="text-center py-20">
              <Filter className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">No items match your filter</h3>
              <p className="text-gray-400">Try selecting All Sources to see all trends</p>
            </div>
          )}
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-black mb-4">
              <span className="gradient-text">Multi-Source</span> Intelligence
            </h2>
            <p className="text-gray-400">
              We aggregate signals from the best developer platforms
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-6">
            {[
              {
                name: "MDC Elite",
                icon: Sparkles,
                color: "from-pink-500 to-purple-600",
                desc: "Demigod activity, PvP battles, elite projects"
              },
              {
                name: "LinkedIn",
                icon: Linkedin,
                color: "from-blue-500 to-blue-600",
                desc: "Industry trends, engineering insights, B2B signals"
              },
              {
                name: "GitHub",
                icon: Github,
                color: "from-purple-500 to-purple-600",
                desc: "Trending repos, new releases, tech innovations"
              },
              {
                name: "Reddit",
                icon: MessageSquare,
                color: "from-orange-500 to-orange-600",
                desc: "Indie hackers, startup stories, dev discussions"
              }
            ].map((source, idx) => {
              const Icon = source.icon;
              return (
                <div key={idx} className="glass-card p-6 text-center hover-lift">
                  <div className={`w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-to-br ${source.color} flex items-center justify-center`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="font-bold text-white mb-2">{source.name}</h3>
                  <p className="text-sm text-gray-400">{source.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}