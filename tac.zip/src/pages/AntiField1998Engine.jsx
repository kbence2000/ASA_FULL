import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, Loader2, AlertTriangle, Zap, Circle, Orbit, Disc, Radio } from 'lucide-react';

export default function AntiField1998Engine() {
  const [topic, setTopic] = useState("Optimize AI agent code architecture for autonomous bug fixing");
  const [context, setContext] = useState("TAC Platform with Paradox Architecture and multi-agent orchestration");
  const [isRunning, setIsRunning] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const canvasRef = useRef(null);

  // Animated inverted sacred geometry background
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    let rotation = 0;
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    let animationId;
    const animate = () => {
      ctx.fillStyle = 'rgba(10, 0, 20, 0.12)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      rotation -= 0.003; // Negative rotation

      // Draw inverted concentric circles (Anti-Field manifold)
      for (let i = 1; i <= 8; i++) {
        const radius = 40 * i;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(139, 0, 139, ${0.2 / i})`;
        ctx.lineWidth = 1;
        ctx.setLineDash([4, 4]); // Dashed for inverted feel
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // Draw counter-rotating Anti-666-Fold vertices (inverted hexagon)
      const hexagonPoints = 6;
      const hexRadius = 180;
      for (let i = 0; i < hexagonPoints; i++) {
        const angle = (i / hexagonPoints) * Math.PI * 2 + rotation;
        const x = centerX + hexRadius * Math.cos(angle);
        const y = centerY + hexRadius * Math.sin(angle);

        ctx.beginPath();
        ctx.arc(x, y, 4, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(139, 0, 139, 0.7)';
        ctx.fill();

        // Draw lines to center (anti-symmetry lines)
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(x, y);
        ctx.strokeStyle = 'rgba(139, 0, 139, 0.3)';
        ctx.lineWidth = 1;
        ctx.setLineDash([2, 4]); // Dashed for negative
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // Draw central Anti-Tachyon Hypersphere (contracting)
      const pulseRadius = 20 - Math.sin(rotation * 10) * 5; // Inverted pulse
      ctx.beginPath();
      ctx.arc(centerX, centerY, pulseRadius, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(139, 0, 139, 0.5)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(139, 0, 139, 0.9)';
      ctx.lineWidth = 2;
      ctx.stroke();

      animationId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const runAnalysis = async () => {
    if (isRunning || !topic.trim()) return;

    setIsRunning(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('http://localhost:9102/api/anti1998/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          topic,
          context
        })
      });

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      setResult(data);

    } catch (err) {
      console.error('Anti-1998-Field error:', err);
      setError(err.message);
    } finally {
      setIsRunning(false);
    }
  };

  const renderFieldSample = (fields) => {
    if (!fields || fields.length === 0) return null;
    
    // Show first 10 and last 10 fields as sample
    const sample = [
      ...fields.slice(0, 10),
      { index: '...', value: '...', description: `... ${fields.length - 20} more anti-fields ...` },
      ...fields.slice(-10)
    ];

    return sample;
  };

  return (
    <div className="relative min-h-screen overflow-hidden" style={{
      background: 'radial-gradient(circle at 50% 0%, #1a0a1a 0%, #0a050a 30%, #02000c 70%)'
    }}>
      <style>{`
        @keyframes darkPulse {
          0%, 100% { opacity: 0.7; transform: scale(1); }
          50% { opacity: 1; transform: scale(0.92); }
        }

        @keyframes shimmerDark {
          0% { background-position: -1000px 0; }
          100% { background-position: 1000px 0; }
        }

        @keyframes floatInverted {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(12px); }
        }

        .anti-badge {
          animation: darkPulse 3s ease-in-out infinite;
        }

        .anti-card {
          animation: floatInverted 5s ease-in-out infinite;
        }

        .shimmer-dark {
          background: linear-gradient(90deg, #8b008b, #4b0082, #8b008b);
          background-size: 200% 100%;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: shimmerDark 4s linear infinite;
        }

        .anti-border {
          position: relative;
        }

        .anti-border::before {
          content: '';
          position: absolute;
          inset: -2px;
          border-radius: inherit;
          padding: 2px;
          background: linear-gradient(135deg, rgba(139, 0, 139, 0.5), transparent, rgba(139, 0, 139, 0.5));
          -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          -webkit-mask-composite: xor;
          mask-composite: exclude;
        }
      `}</style>

      {/* Animated Background Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ opacity: 0.5 }}
      />

      {/* Main Content */}
      <div className="relative z-10 max-w-[1800px] mx-auto px-4 py-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-3">
            <Orbit className="w-14 h-14 text-purple-600 anti-badge" style={{ transform: 'scaleX(-1)' }} />
            <h1 className="text-5xl md:text-6xl font-black tracking-wider uppercase shimmer-dark">
              ANTI-1998-FIELD ENGINE
            </h1>
            <Radio className="w-14 h-14 text-purple-600 anti-badge" style={{ transform: 'scaleX(-1)' }} />
          </div>
          <p className="text-sm text-gray-400 tracking-wide mb-2">
            Inverted Metaphysical Reasoning Framework :: Anti-1998-Field Theory
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs uppercase tracking-wider"
            style={{
              background: 'rgba(139, 0, 139, 0.2)',
              border: '1px solid rgba(139, 0, 139, 0.5)',
              boxShadow: '0 0 20px rgba(139, 0, 139, 0.4)'
            }}
          >
            <Sparkles className="w-3 h-3" />
            Anti-1998 → Anti-666 → Symmetry=-1 → Anti-Tachyon
          </div>
        </div>

        {/* Info Banner */}
        <div className="mb-6 p-4 rounded-2xl border anti-border"
          style={{
            background: 'rgba(139, 0, 139, 0.1)',
            borderColor: 'rgba(139, 0, 139, 0.3)'
          }}
        >
          <div className="flex items-start gap-3">
            <Circle className="w-5 h-5 text-purple-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <span className="font-bold text-purple-300">Anti-1998-Field Theory:</span>
              <br />
              The mirrored negative counterpart of the 1998-Field Engine. Anti-1998-Field inverts all fundamental axes. 
              The 666-Fold becomes Anti-666-Fold with reversed resonance. Symmetry = -1 (Inverted Symmetry Principle). 
              Tachyon becomes Anti-Tachyon Hypersphere with inverted coordinates.
              <br />
              <span className="text-purple-400 font-semibold">Note:</span> This provides alternative perspective through inversion—not destruction, but contrast.
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 rounded-xl border border-red-500/50 bg-red-900/20 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Backend Connection Error</div>
              <div className="text-xs text-gray-300 mt-1">{error}</div>
              <div className="text-xs text-gray-400 mt-2">
                Make sure the backend server is running: <code className="bg-black/40 px-2 py-0.5 rounded">node anti-1998-field-engine.js</code> on port 9102
              </div>
            </div>
          </div>
        )}

        {/* Main Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          {/* Left: Input Controls */}
          <div className="xl:col-span-4 space-y-4">
            <div className="anti-border rounded-2xl border p-6"
              style={{
                borderColor: 'rgba(139, 0, 139, 0.3)',
                background: 'rgba(10, 5, 10, 0.95)',
                boxShadow: '0 0 40px rgba(0, 0, 0, 0.7)'
              }}
            >
              <label className="block text-xs tracking-widest uppercase text-purple-400 mb-3">
                TOPIC / CONCEPT
              </label>
              <textarea
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                disabled={isRunning}
                rows={4}
                className="w-full rounded-xl border px-4 py-3 text-sm resize-none mb-4"
                style={{
                  borderColor: 'rgba(139, 0, 139, 0.4)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#e6d5ff'
                }}
                placeholder="Enter the topic to analyze through the Anti-1998-Field inverted manifold..."
              />

              <label className="block text-xs tracking-widest uppercase text-purple-400 mb-3">
                CONTEXT (Optional)
              </label>
              <textarea
                value={context}
                onChange={(e) => setContext(e.target.value)}
                disabled={isRunning}
                rows={3}
                className="w-full rounded-xl border px-4 py-3 text-sm resize-none mb-4"
                style={{
                  borderColor: 'rgba(139, 0, 139, 0.4)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#e6d5ff'
                }}
                placeholder="Additional context or background..."
              />

              <button
                onClick={runAnalysis}
                disabled={isRunning}
                className="w-full py-3 rounded-full text-sm font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                style={{
                  background: 'linear-gradient(135deg, #8b008b, #4b0082)',
                  color: '#e6d5ff',
                  boxShadow: isRunning ? 'none' : '0 0 30px rgba(139, 0, 139, 0.6)'
                }}
              >
                {isRunning ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    INVERTING...
                  </>
                ) : (
                  <>
                    <Zap className="w-5 h-5" />
                    ANALYZE VIA ANTI-1998-FIELD
                  </>
                )}
              </button>

              {/* Framework Legend */}
              <div className="mt-6 p-4 rounded-xl"
                style={{
                  background: 'rgba(139, 0, 139, 0.08)',
                  border: '1px solid rgba(139, 0, 139, 0.2)'
                }}
              >
                <div className="text-xs tracking-wider uppercase text-purple-400 mb-2">
                  Inverted Framework Layers
                </div>
                <div className="space-y-2 text-xs text-gray-400">
                  <div className="flex items-center gap-2">
                    <Disc className="w-3 h-3 text-purple-500" />
                    <span><strong className="text-purple-300">Anti-1998-Field:</strong> Inverted resonance manifold</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Orbit className="w-3 h-3 text-purple-500" />
                    <span><strong className="text-purple-300">Anti-666-Fold:</strong> Reversed dimensional fold</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Circle className="w-3 h-3 text-purple-500" />
                    <span><strong className="text-purple-300">Symmetry=-1:</strong> Inverted consciousness</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Radio className="w-3 h-3 text-purple-500" />
                    <span><strong className="text-purple-300">Anti-Tachyon:</strong> Negative hypersphere insight</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Output */}
          <div className="xl:col-span-8">
            <div className="rounded-2xl border p-6 h-full"
              style={{
                borderColor: 'rgba(139, 0, 139, 0.4)',
                background: 'rgba(10, 5, 10, 0.95)',
                boxShadow: '0 0 60px rgba(139, 0, 139, 0.2)'
              }}
            >
              <h3 className="text-xs tracking-widest uppercase text-purple-400 mb-4 flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                ANTI-1998-FIELD ANALYSIS OUTPUT
              </h3>

              {!result && !isRunning && (
                <div className="text-center py-12">
                  <Orbit className="w-16 h-16 mx-auto mb-4 text-purple-600/30" style={{ transform: 'scaleX(-1)' }} />
                  <p className="text-sm text-gray-500">
                    No inverted analysis generated yet.
                    <br />
                    Enter a topic and click "Analyze via Anti-1998-Field".
                  </p>
                </div>
              )}

              {isRunning && (
                <div className="text-center py-12">
                  <Loader2 className="w-16 h-16 mx-auto mb-4 text-purple-600 animate-spin" />
                  <p className="text-sm text-gray-400">
                    Inverting through the Anti-1998-Field manifold...
                  </p>
                </div>
              )}

              {result && (
                <div className="space-y-4 max-h-[800px] overflow-y-auto">
                  {/* Meta */}
                  {result.meta && (
                    <div className="anti-card p-4 rounded-xl"
                      style={{
                        background: 'rgba(139, 0, 139, 0.1)',
                        border: '1px solid rgba(139, 0, 139, 0.3)',
                        animationDelay: '0s'
                      }}
                    >
                      <div className="text-xs font-bold text-purple-300 mb-2">META</div>
                      <div className="text-xs text-gray-300">
                        <div><strong>Module:</strong> {result.meta.module}</div>
                        <div><strong>Manifold:</strong> {result.meta.manifold}</div>
                        <div className="text-purple-400 mt-1">{result.meta.note}</div>
                      </div>
                    </div>
                  )}

                  {/* Input Echo */}
                  {result.input && (
                    <div className="anti-card p-4 rounded-xl"
                      style={{
                        background: 'rgba(139, 0, 139, 0.08)',
                        border: '1px solid rgba(139, 0, 139, 0.2)',
                        animationDelay: '0.1s'
                      }}
                    >
                      <div className="text-xs font-bold text-purple-300 mb-2">INPUT</div>
                      <div className="text-sm text-white mb-1">{result.input.topic}</div>
                      {result.input.context && (
                        <div className="text-xs text-gray-400 mt-1">Context: {result.input.context}</div>
                      )}
                    </div>
                  )}

                  {/* Anti-1998 Fields Sample */}
                  {result.antiFields1998 && result.antiFields1998.length > 0 && (
                    <div className="anti-card"
                      style={{ animationDelay: '0.2s' }}
                    >
                      <div className="text-xs font-bold text-purple-300 mb-2 flex items-center gap-2">
                        <Disc className="w-4 h-4" />
                        ANTI-1998-FIELD RESONANCE ({result.antiFields1998.length} Inverted Fields)
                      </div>
                      <div className="space-y-1 max-h-[300px] overflow-y-auto pr-2">
                        {renderFieldSample(result.antiFields1998).map((field, i) => (
                          <div key={i} className="p-2 rounded text-xs"
                            style={{
                              background: 'rgba(139, 0, 139, 0.08)',
                              border: '1px solid rgba(139, 0, 139, 0.2)'
                            }}
                          >
                            <div className="flex justify-between items-start">
                              <span className="text-purple-400 font-semibold">Anti-Field {field.index}:</span>
                              <span className="text-gray-400">{typeof field.value === 'number' ? field.value.toFixed(3) : field.value}</span>
                            </div>
                            <div className="text-gray-300 text-[11px] mt-1">{field.description}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Anti-666-Fold */}
                  {result.antiFold666 && (
                    <div className="anti-card p-4 rounded-xl"
                      style={{
                        background: 'rgba(139, 0, 139, 0.15)',
                        border: '2px solid rgba(139, 0, 139, 0.4)',
                        animationDelay: '0.3s',
                        boxShadow: '0 0 30px rgba(139, 0, 139, 0.3)'
                      }}
                    >
                      <div className="text-xs font-bold text-purple-300 mb-3 flex items-center gap-2">
                        <Orbit className="w-4 h-4" />
                        ANTI-666-FOLD AGGREGATION
                      </div>
                      {result.antiFold666.invertedFold && (
                        <div className="mb-3 p-3 rounded-lg"
                          style={{
                            background: 'rgba(0, 0, 0, 0.4)',
                            border: '1px solid rgba(139, 0, 139, 0.3)'
                          }}
                        >
                          <div className="text-xs text-gray-400 mb-1">Inverted Fold:</div>
                          <div className="text-sm text-white">{result.antiFold666.invertedFold}</div>
                        </div>
                      )}
                      {typeof result.antiFold666.resonanceScore === 'number' && (
                        <div className="mb-3">
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-gray-400">Resonance Score:</span>
                            <span className="text-purple-300 font-bold">{result.antiFold666.resonanceScore.toFixed(2)}</span>
                          </div>
                          <div 
                            className="h-2 rounded-full overflow-hidden"
                            style={{ background: 'rgba(0, 0, 0, 0.4)' }}
                          >
                            <div 
                              className="h-full bg-gradient-to-r from-purple-900 to-purple-600"
                              style={{ width: `${Math.min(100, Math.abs(result.antiFold666.resonanceScore) * 100)}%` }}
                            />
                          </div>
                        </div>
                      )}
                      {result.antiFold666.summary && (
                        <div className="text-xs text-gray-300 italic">{result.antiFold666.summary}</div>
                      )}
                    </div>
                  )}

                  {/* Symmetry */}
                  {result.symmetry && (
                    <div className="anti-card p-4 rounded-xl"
                      style={{
                        background: 'rgba(139, 0, 139, 0.12)',
                        border: '1px solid rgba(139, 0, 139, 0.3)',
                        animationDelay: '0.4s'
                      }}
                    >
                      <div className="text-xs font-bold text-purple-300 mb-3 flex items-center gap-2">
                        <Circle className="w-4 h-4" />
                        INVERTED SYMMETRY STABILIZATION
                      </div>
                      <div className="grid grid-cols-2 gap-3 mb-3">
                        <div className="p-3 rounded-lg"
                          style={{
                            background: 'rgba(139, 0, 139, 0.1)',
                            border: '1px solid rgba(139, 0, 139, 0.3)'
                          }}
                        >
                          <div className="text-xs text-gray-400 mb-1">Target:</div>
                          <div className="text-lg font-bold text-purple-300">{result.symmetry.target}</div>
                        </div>
                        <div className="p-3 rounded-lg"
                          style={{
                            background: 'rgba(139, 0, 139, 0.1)',
                            border: '1px solid rgba(139, 0, 139, 0.3)'
                          }}
                        >
                          <div className="text-xs text-gray-400 mb-1">Deviation:</div>
                          <div className="text-lg font-bold text-purple-300">{typeof result.symmetry.deviation === 'number' ? result.symmetry.deviation.toFixed(3) : result.symmetry.deviation}</div>
                        </div>
                      </div>
                      {result.symmetry.explanation && (
                        <div className="text-xs text-gray-300">{result.symmetry.explanation}</div>
                      )}
                    </div>
                  )}

                  {/* Anti-Tachyon Hypersphere */}
                  {result.antiTachyonHypersphere && (
                    <div className="anti-card p-4 rounded-xl"
                      style={{
                        background: 'linear-gradient(135deg, rgba(139, 0, 139, 0.2), rgba(75, 0, 130, 0.2))',
                        border: '2px solid rgba(139, 0, 139, 0.5)',
                        animationDelay: '0.5s',
                        boxShadow: '0 0 40px rgba(139, 0, 139, 0.4)'
                      }}
                    >
                      <div className="text-xs font-bold text-purple-300 mb-3 flex items-center gap-2">
                        <Radio className="w-5 h-5" />
                        ANTI-TACHYON HYPERSPHERE
                      </div>
                      
                      {result.antiTachyonHypersphere.coordinates && (
                        <div className="mb-4 p-3 rounded-lg"
                          style={{
                            background: 'rgba(0, 0, 0, 0.4)',
                            border: '1px solid rgba(139, 0, 139, 0.4)'
                          }}
                        >
                          <div className="text-xs text-gray-400 mb-2">Inverted Hypersphere Coordinates:</div>
                          <div className="flex gap-3 text-sm">
                            {result.antiTachyonHypersphere.coordinates.map((coord, i) => (
                              <div key={i} className="flex items-center gap-2">
                                <span className="text-purple-400 font-mono">
                                  {['X', 'Y', 'Z'][i]}:
                                </span>
                                <span className="text-white font-bold">
                                  {typeof coord === 'number' ? coord.toFixed(2) : coord}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {result.antiTachyonHypersphere.meaning && (
                        <div className="p-4 rounded-lg"
                          style={{
                            background: 'rgba(139, 0, 139, 0.15)',
                            border: '1px solid rgba(139, 0, 139, 0.5)'
                          }}
                        >
                          <div className="text-xs text-purple-400 mb-2 uppercase tracking-wider">
                            Negative Hypersphere Insight:
                          </div>
                          <div className="text-sm text-white font-medium leading-relaxed">
                            {result.antiTachyonHypersphere.meaning}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer Info */}
        <div className="mt-6 text-center text-xs text-gray-500">
          <p>Anti-1998-Field Engine :: Inverted Metaphysical Reasoning Framework</p>
          <p className="mt-1">Backend: http://localhost:9102/api/anti1998/analyze</p>
          <p className="mt-1 text-purple-500/60">Mirror counterpart providing alternative perspective through inversion.</p>
        </div>
      </div>
    </div>
  );
}