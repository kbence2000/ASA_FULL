import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Plus, Settings } from "lucide-react";
import AppCard from "../components/AppCard";
import ShopifyProductManager from "../components/ShopifyProductManager";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export default function MyApps() {
  const [selectedApp, setSelectedApp] = useState(null);
  const [shopifyDialogOpen, setShopifyDialogOpen] = useState(false);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: myApps, isLoading } = useQuery({
    queryKey: ['myApps', user?.email],
    queryFn: () => base44.entities.App.filter({ created_by: user.email }, '-created_date'),
    enabled: !!user?.email,
    initialData: [],
  });

  const updateAppMutation = useMutation({
    mutationFn: async ({ appId, data }) => {
      return await base44.entities.App.update(appId, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myApps'] });
      setShopifyDialogOpen(false);
    },
  });

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-black text-white mb-2">Saját Programjaim</h1>
            <p className="text-gray-400">Kezeld a feltöltött programjaidat</p>
          </div>
          <Link to={createPageUrl("AddApp")}>
            <Button className="bg-gradient-to-r from-[#00E599] to-[#00B8D4] text-black font-bold hover:opacity-90">
              <Plus className="w-5 h-5 mr-2" />
              Új Program
            </Button>
          </Link>
        </div>

        {isLoading ? (
          <div className="text-center py-20">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-[#00E599] border-t-transparent"></div>
            <p className="text-gray-400 mt-4">Betöltés...</p>
          </div>
        ) : myApps.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">📦</div>
            <h3 className="text-2xl font-bold text-white mb-2">Még nincs feltöltött programod</h3>
            <p className="text-gray-400 mb-6">Töltsd fel az első programodat a piactérre!</p>
            <Link to={createPageUrl("AddApp")}>
              <Button className="bg-gradient-to-r from-[#00E599] to-[#00B8D4] text-black font-bold hover:opacity-90">
                <Plus className="w-5 h-5 mr-2" />
                Program Feltöltése
              </Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {myApps.map(app => (
                <div key={app.id} className="relative group">
                  <AppCard app={app} />
                  <Dialog open={shopifyDialogOpen && selectedApp?.id === app.id} onOpenChange={setShopifyDialogOpen}>
                    <DialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setSelectedApp(app)}
                        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-[#0f1419]/90 hover:bg-[#1a1f2e]"
                      >
                        <Settings className="w-4 h-4 text-gray-400" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto bg-[#0A0E14] border-[#1a1f2e]">
                      <DialogHeader>
                        <DialogTitle className="text-white">
                          Shopify Integráció - {app.name}
                        </DialogTitle>
                        <DialogDescription className="text-gray-400">
                          Szinkronizáld a termékedet Shopify áruházaddal
                        </DialogDescription>
                      </DialogHeader>
                      <ShopifyProductManager
                        app={app}
                        onSync={(data) => updateAppMutation.mutate({ appId: app.id, data })}
                      />
                    </DialogContent>
                  </Dialog>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}