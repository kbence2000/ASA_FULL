import React, { useState, useEffect, useRef } from 'react';
import { Shield, AlertTriangle, CheckCircle2, Activity, Zap, Lock, Unlock, Wrench } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

const MOCK_MODULES = [
  { name: "TrendHarvester", status: "ok", type: "AI-INTEL" },
  { name: "SecuritySentinel", status: "ok", type: "GUARD" },
  { name: "MissionDeploy", status: "warn", type: "AGENT-OPS" },
  { name: "DebugChamber", status: "bad", type: "AI-OPS" },
  { name: "ChaosArchitect", status: "ok", type: "GENESIS" },
  { name: "ParadoxEngine", status: "ok", type: "CORE" },
  { name: "HallucinatorMind", status: "ok", type: "CREATIVE" }
];

export default function SecurityOversight() {
  const [modules, setModules] = useState(MOCK_MODULES);
  const [logs, setLogs] = useState(['# Security AI initialized', '# Monitoring TAC ecosystem...']);
  const [isScanning, setIsScanning] = useState(false);
  const logRef = useRef(null);
  const queryClient = useQueryClient();

  // Fetch security quarantine records
  const { data: quarantineRecords = [] } = useQuery({
    queryKey: ['security-quarantine'],
    queryFn: async () => {
      try {
        const records = await base44.entities.SecurityQuarantine.list('-created_date', 20);
        return records;
      } catch (err) {
        console.error('Failed to fetch quarantine records:', err);
        return [];
      }
    },
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Fetch metrics for health monitoring
  const { data: metrics = [] } = useQuery({
    queryKey: ['mastermind-metrics'],
    queryFn: async () => {
      try {
        const allMetrics = await base44.entities.MastermindMetric.list('-timestamp', 50);
        return allMetrics;
      } catch (err) {
        console.error('Failed to fetch metrics:', err);
        return [];
      }
    },
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  // Quarantine mutation
  const quarantineMutation = useMutation({
    mutationFn: async (moduleName) => {
      return await base44.entities.SecurityQuarantine.create({
        moduleName,
        role: modules.find(m => m.name === moduleName)?.type || 'unknown',
        status: 'quarantined',
        reason: 'Manual quarantine triggered by Security Oversight',
        lastTs: new Date().toISOString(),
        successRate: 0,
        avgLatency: 0
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['security-quarantine'] });
      addLog('✓ Module quarantined successfully');
    }
  });

  // Release mutation
  const releaseMutation = useMutation({
    mutationFn: async (quarantineId) => {
      return await base44.entities.SecurityQuarantine.update(quarantineId, {
        status: 'released',
        releasedAt: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['security-quarantine'] });
      addLog('✓ Module released from quarantine');
    }
  });

  useEffect(() => {
    if (logRef.current) {
      logRef.current.scrollTop = logRef.current.scrollHeight;
    }
  }, [logs]);

  // Sync module status with quarantine records
  useEffect(() => {
    if (quarantineRecords.length > 0) {
      setModules(prev => prev.map(mod => {
        const inQuarantine = quarantineRecords.find(
          q => q.moduleName === mod.name && q.status === 'quarantined'
        );
        if (inQuarantine) {
          return { ...mod, status: 'bad' };
        }
        return mod;
      }));
    }
  }, [quarantineRecords]);

  // Analyze metrics for module health
  useEffect(() => {
    if (metrics.length > 0) {
      const recentMetrics = metrics.slice(0, 10);
      const failedModules = new Set();
      
      recentMetrics.forEach(metric => {
        if (!metric.success && metric.moduleName) {
          failedModules.add(metric.moduleName);
        }
      });

      if (failedModules.size > 0) {
        setModules(prev => prev.map(mod => {
          if (failedModules.has(mod.name) && mod.status === 'ok') {
            addLog(`⚠ ${mod.name} showing failures in metrics`);
            return { ...mod, status: 'warn' };
          }
          return mod;
        }));
      }
    }
  }, [metrics]);

  const addLog = (msg) => {
    const timestamp = new Date().toLocaleTimeString('en-US', { hour12: false });
    setLogs(prev => [...prev, `[${timestamp}] ${msg}`]);
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'ok':
        return <CheckCircle2 className="w-4 h-4 text-green-400" />;
      case 'warn':
        return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
      case 'bad':
        return <AlertTriangle className="w-4 h-4 text-red-400" />;
      default:
        return <Activity className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'ok':
        return { bg: '#00ffa3', text: '#00ffa3', glow: 'rgba(0, 255, 163, 0.4)' };
      case 'warn':
        return { bg: '#ffcc4b', text: '#ffcc4b', glow: 'rgba(255, 204, 75, 0.4)' };
      case 'bad':
        return { bg: '#ff4b81', text: '#ff4b81', glow: 'rgba(255, 75, 129, 0.4)' };
      default:
        return { bg: '#8c8faf', text: '#8c8faf', glow: 'rgba(140, 143, 175, 0.4)' };
    }
  };

  const healthStats = {
    healthy: modules.filter(m => m.status === 'ok').length,
    warnings: modules.filter(m => m.status === 'warn').length,
    critical: modules.filter(m => m.status === 'bad').length,
  };

  const runDeepScan = async () => {
    setIsScanning(true);
    addLog('→ Running Deep Scan...');
    addLog('→ Analyzing module integrity...');
    
    setTimeout(() => {
      addLog('→ Checking for anomalies...');
    }, 1000);

    setTimeout(() => {
      const threats = modules.filter(m => m.status !== 'ok').length;
      if (threats > 0) {
        addLog(`⚠ Deep Scan complete. ${threats} module(s) require attention.`);
      } else {
        addLog('✓ Scan Complete. No critical threats detected.');
      }
      setIsScanning(false);
    }, 2500);
  };

  const forceQuarantine = () => {
    const unstableModules = modules.filter(m => m.status === 'bad');
    if (unstableModules.length === 0) {
      addLog('⚠ No unstable modules to quarantine');
      return;
    }

    addLog('→ Forcing quarantine on unstable modules...');
    unstableModules.forEach(mod => {
      quarantineMutation.mutate(mod.name);
      addLog(`→ ${mod.name} moved to quarantine.`);
    });
  };

  const releaseFromQuarantine = () => {
    const quarantined = quarantineRecords.filter(q => q.status === 'quarantined');
    if (quarantined.length === 0) {
      addLog('⚠ No modules in quarantine');
      return;
    }

    addLog('→ Releasing modules from quarantine...');
    quarantined.forEach(record => {
      releaseMutation.mutate(record.id);
      addLog(`→ ${record.moduleName} released.`);
    });
    
    setTimeout(() => {
      addLog('✓ Quarantine released.');
      addLog('✓ Modules restored to active state.');
    }, 500);
  };

  const triggerAutoRepair = () => {
    const damaged = modules.filter(m => m.status === 'bad');
    if (damaged.length === 0) {
      addLog('⚠ No damaged modules to repair');
      return;
    }

    addLog('→ Auto-repair routine triggered...');
    addLog('→ Analyzing failure patterns...');
    
    setTimeout(() => {
      addLog('→ Applying fixes...');
      setModules(prev => prev.map(m => 
        m.status === 'bad' ? { ...m, status: 'warn' } : m
      ));
    }, 1500);

    setTimeout(() => {
      addLog('✓ Repair complete. Stability restored.');
      addLog('→ Recommend manual verification before full activation.');
    }, 2500);
  };

  return (
    <div className="min-h-screen p-4" style={{
      background: 'radial-gradient(circle at top, #0a0a14 0, #030306 55%)'
    }}>
      <style>{`
        .security-panel {
          background: #0a0a12;
          border: 1px solid #1a1a26;
        }

        .status-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
        }

        @keyframes pulse-glow {
          0%, 100% {
            opacity: 1;
          }
          50% {
            opacity: 0.6;
          }
        }

        .pulse-dot {
          animation: pulse-glow 2s ease-in-out infinite;
        }
      `}</style>

      <div className="max-w-[1400px] mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: 'radial-gradient(circle at 20% 0, #ffffff, #14f4a8 40%, #0b6b4f)',
                boxShadow: '0 0 30px rgba(20, 244, 168, 0.6)'
              }}
            >
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="text-xl font-bold text-white tracking-wide">
                SECURITY OVERSIGHT AI
              </div>
              <div className="text-xs text-gray-400 tracking-wider">
                TAC Ecosystem Guardian • Real-time Threat Detection
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full" style={{
            background: 'rgba(20, 244, 168, 0.12)',
            border: '1px solid rgba(20, 244, 168, 0.6)'
          }}>
            <div className="w-2 h-2 rounded-full pulse-dot" style={{ background: '#14f4a8' }} />
            <span className="text-xs font-semibold" style={{ color: '#14f4a8' }}>
              MONITORING ACTIVE
            </span>
          </div>
        </div>

        {/* Health Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="security-panel rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-gray-400 uppercase tracking-wider">Healthy Modules</span>
              <CheckCircle2 className="w-5 h-5 text-green-400" />
            </div>
            <div className="text-3xl font-bold text-green-400">{healthStats.healthy}</div>
            <div className="text-[10px] text-gray-500 mt-1">All systems operational</div>
          </div>

          <div className="security-panel rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-gray-400 uppercase tracking-wider">Warnings</span>
              <AlertTriangle className="w-5 h-5 text-yellow-400" />
            </div>
            <div className="text-3xl font-bold text-yellow-400">{healthStats.warnings}</div>
            <div className="text-[10px] text-gray-500 mt-1">Require attention</div>
          </div>

          <div className="security-panel rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-gray-400 uppercase tracking-wider">Critical Issues</span>
              <AlertTriangle className="w-5 h-5 text-red-400" />
            </div>
            <div className="text-3xl font-bold text-red-400">{healthStats.critical}</div>
            <div className="text-[10px] text-gray-500 mt-1">Quarantine recommended</div>
          </div>
        </div>

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left: Module Health */}
          <div className="lg:col-span-4 security-panel rounded-2xl p-4">
            <div className="mb-4">
              <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-1">
                Module Health Status
              </div>
              <div className="text-[10px] text-gray-500">
                Real-time monitoring of {modules.length} core modules
              </div>
            </div>

            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-2">
              {modules.map((module, idx) => {
                const statusColor = getStatusColor(module.status);
                return (
                  <div 
                    key={idx}
                    className="rounded-xl p-3 border transition-all hover:border-white/10"
                    style={{
                      background: '#05050d',
                      borderColor: 'rgba(255, 255, 255, 0.05)'
                    }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {getStatusIcon(module.status)}
                        <span className="text-sm font-semibold text-white">{module.name}</span>
                      </div>
                      <div 
                        className="status-dot"
                        style={{ 
                          background: statusColor.bg,
                          boxShadow: `0 0 10px ${statusColor.glow}`
                        }}
                      />
                    </div>
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-gray-500">{module.type}</span>
                      <span 
                        className="px-2 py-0.5 rounded-full font-semibold uppercase"
                        style={{
                          background: `${statusColor.glow}`,
                          color: statusColor.text
                        }}
                      >
                        {module.status}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Center: Security Log Stream */}
          <div className="lg:col-span-5 security-panel rounded-2xl p-4">
            <div className="mb-4">
              <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-1">
                Live Security Log Stream
              </div>
              <div className="text-[10px] text-gray-500">
                Real-time event monitoring and threat detection
              </div>
            </div>

            <div 
              ref={logRef}
              className="rounded-xl p-4 font-mono text-xs overflow-y-auto"
              style={{
                background: '#05050d',
                border: '1px solid #1a1a26',
                color: '#a3a7cf',
                height: '500px',
                lineHeight: '1.6'
              }}
            >
              {logs.map((log, idx) => (
                <div key={idx}>{log}</div>
              ))}
            </div>
          </div>

          {/* Right: Control Actions */}
          <div className="lg:col-span-3 security-panel rounded-2xl p-4">
            <div className="mb-4">
              <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-1">
                Security Controls
              </div>
              <div className="text-[10px] text-gray-500">
                Manual intervention tools
              </div>
            </div>

            <div className="space-y-3">
              <button
                onClick={runDeepScan}
                disabled={isScanning}
                className="w-full px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                style={{
                  background: 'linear-gradient(135deg, #14f4a8, #0b6b4f)',
                  color: '#020206',
                  boxShadow: isScanning ? 'none' : '0 0 20px rgba(20, 244, 168, 0.4)'
                }}
              >
                <Activity className={`w-4 h-4 ${isScanning ? 'animate-spin' : ''}`} />
                {isScanning ? 'SCANNING...' : 'Run Deep Scan'}
              </button>

              <button
                onClick={forceQuarantine}
                className="w-full px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all hover:opacity-80"
                style={{
                  background: 'rgba(255, 75, 129, 0.15)',
                  color: '#ff4b81',
                  border: '1px solid rgba(255, 75, 129, 0.4)'
                }}
              >
                <Lock className="w-4 h-4" />
                Force Quarantine
              </button>

              <button
                onClick={releaseFromQuarantine}
                className="w-full px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all hover:opacity-80"
                style={{
                  background: 'rgba(255, 204, 75, 0.15)',
                  color: '#ffcc4b',
                  border: '1px solid rgba(255, 204, 75, 0.4)'
                }}
              >
                <Unlock className="w-4 h-4" />
                Release Quarantine
              </button>

              <button
                onClick={triggerAutoRepair}
                className="w-full px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all hover:opacity-80"
                style={{
                  background: 'rgba(36, 228, 255, 0.15)',
                  color: '#24e4ff',
                  border: '1px solid rgba(36, 228, 255, 0.4)'
                }}
              >
                <Wrench className="w-4 h-4" />
                Trigger Auto-Repair
              </button>

              {/* Security Status Panel */}
              <div 
                className="rounded-xl p-3 mt-6"
                style={{
                  background: '#05050d',
                  border: '1px solid #1a1a26'
                }}
              >
                <div className="text-xs text-gray-400 mb-2 uppercase tracking-wider">
                  Security Status
                </div>
                <div className="space-y-2 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Threat Level:</span>
                    <span className="text-green-400 font-semibold">LOW</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Last Scan:</span>
                    <span className="text-white">2m ago</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Quarantined:</span>
                    <span className="text-white">{quarantineRecords.filter(q => q.status === 'quarantined').length} modules</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Active Metrics:</span>
                    <span className="text-white">{metrics.length}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}