
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Plus, X, Sparkles, Zap } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";
import AIValuator from "../components/AIValuator";
import AIAnalyzer from "../components/AIAnalyzer";

const categories = [
  { value: "productivity", label: "Produktivitás" },
  { value: "development", label: "Fejlesztés" },
  { value: "design", label: "Dizájn" },
  { value: "business", label: "Üzleti" },
  { value: "games", label: "Játékok" },
  { value: "education", label: "Oktatás" },
  { value: "utilities", label: "Segédprogramok" },
  { value: "other", label: "Egyéb" }
];

export default function AddApp() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    category: "productivity",
    price: 0,
    floor_price: 0,
    ceiling_price: 0,
    currency: "HUF",
    license_type: "BASIC",
    developer: user?.full_name || user?.email?.split('@')[0] || "",
    icon_url: "",
    version: "1.0.0",
    changelog: "",
    featured: false,
    verified: false,
    download_url: "",
    demo_url: "",
    support_email: user?.email || "",
    ai_analysis: null, // New field for AI Analyzer output
    ai_quality_score: null, // New field for AI Analyzer output
    ai_estimated_price: null, // New field for AI Analyzer output
    ai_complexity: null, // New field for AI Analyzer output
  });

  const [techStack, setTechStack] = useState([]);
  const [newTech, setNewTech] = useState("");
  const [tags, setTags] = useState([]);
  const [newTag, setNewTag] = useState("");
  const [screenshots, setScreenshots] = useState([]);
  const [newScreenshot, setNewScreenshot] = useState("");
  const [showAIValuator, setShowAIValuator] = useState(false);
  const [showAIAnalyzer, setShowAIAnalyzer] = useState(false); // New state for AI Analyzer visibility
  const [codeForAnalysis, setCodeForAnalysis] = useState(""); // New state for AI Analyzer code input

  const createAppMutation = useMutation({
    mutationFn: (appData) => base44.entities.App.create(appData),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['apps'] });
      toast.success("Program sikeresen feltöltve!");
      navigate(createPageUrl("AppDetail") + `?id=${data.id}`);
    },
    onError: () => {
      toast.error("Hiba történt a feltöltés során!");
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.description) {
      toast.error("Kérlek töltsd ki az összes kötelező mezőt!");
      return;
    }

    // Auto-calculate floor/ceiling if not set
    const floor = formData.floor_price || Math.round(formData.price * 0.7);
    const ceiling = formData.ceiling_price || Math.round(formData.price * 1.3);

    createAppMutation.mutate({
      ...formData,
      tech_stack: techStack,
      tags: tags,
      screenshots: screenshots,
      floor_price: floor,
      ceiling_price: ceiling
    });
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const addTech = () => {
    if (newTech.trim() && !techStack.includes(newTech.trim())) {
      setTechStack([...techStack, newTech.trim()]);
      setNewTech("");
    }
  };

  const removeTech = (tech) => {
    setTechStack(techStack.filter(t => t !== tech));
  };

  const addTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      setTags([...tags, newTag.trim()]);
      setNewTag("");
    }
  };

  const removeTag = (tag) => {
    setTags(tags.filter(t => t !== tag));
  };

  const addScreenshot = () => {
    if (newScreenshot.trim() && !screenshots.includes(newScreenshot.trim())) {
      setScreenshots([...screenshots, newScreenshot.trim()]);
      setNewScreenshot("");
    }
  };

  const removeScreenshot = (url) => {
    setScreenshots(screenshots.filter(s => s !== url));
  };

  const handleValuationComplete = (valuation) => {
    if (valuation?.estimated_value_usd) {
      const usdToHuf = 380; // rough conversion
      const midPriceHuf = Math.round(valuation.estimated_value_usd.mid * usdToHuf);
      const lowPriceHuf = Math.round(valuation.estimated_value_usd.low * usdToHuf);
      const highPriceHuf = Math.round(valuation.estimated_value_usd.high * usdToHuf);
      
      setFormData(prev => ({
        ...prev,
        price: midPriceHuf,
        floor_price: lowPriceHuf,
        ceiling_price: highPriceHuf
      }));
      
      toast.success(`AI ajánlás alkalmazva! Ajánlott ár: ${midPriceHuf} Ft`);
      setShowAIValuator(false);
    }
  };

  // New handler for AI Analyzer completion
  const handleAnalysisComplete = (analysis) => {
    if (analysis) {
      // Store AI analysis data in form
      setFormData(prev => ({
        ...prev,
        ai_analysis: analysis.fullAnalysis,
        ai_quality_score: analysis.qualityScore,
        ai_estimated_price: analysis.estimatedPrice,
        ai_complexity: analysis.complexity,
        // Auto-fill price if not already set or is 0
        price: prev.price === 0 ? analysis.estimatedPrice : prev.price,
        floor_price: prev.floor_price === 0 ? Math.round(analysis.estimatedPrice * 0.7) : prev.floor_price,
        ceiling_price: prev.ceiling_price === 0 ? Math.round(analysis.estimatedPrice * 1.3) : prev.ceiling_price
      }));
      
      toast.success("AI elemzés mentve!");
      setShowAIAnalyzer(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link to={createPageUrl("Marketplace")}>
          <Button variant="ghost" className="mb-6 text-gray-400 hover:text-white hover:bg-[#1a1f2e]">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Vissza
          </Button>
        </Link>

        <Card className="border border-[#1a1f2e] bg-[#0f1419] p-8">
          <h1 className="text-3xl font-black text-white mb-2">Program Feltöltése</h1>
          <p className="text-gray-400 mb-8">Töltsd fel programodat a piactérre részletes információkkal</p>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Basic Info */}
            <div className="space-y-6 pb-6 border-b border-[#1a1f2e]">
              <h3 className="text-lg font-bold text-white">Alapinformációk</h3>
              
              <div>
                <Label className="text-white mb-2 block">Program Neve *</Label>
                <Input
                  type="text"
                  value={formData.name}
                  onChange={(e) => handleChange('name', e.target.value)}
                  className="bg-[#141923] border-[#1a1f2e] text-white"
                  placeholder="pl. Super Todo App"
                  required
                />
              </div>

              <div>
                <Label className="text-white mb-2 block">Leírás *</Label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => handleChange('description', e.target.value)}
                  className="bg-[#141923] border-[#1a1f2e] text-white min-h-[150px]"
                  placeholder="Írd le részletesen, hogy mire jó a programod..."
                  required
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label className="text-white mb-2 block">Kategória *</Label>
                  <Select value={formData.category} onValueChange={(value) => handleChange('category', value)}>
                    <SelectTrigger className="bg-[#141923] border-[#1a1f2e] text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(cat => (
                        <SelectItem key={cat.value} value={cat.value}>
                          {cat.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-white mb-2 block">Licenc Típus *</Label>
                  <Select value={formData.license_type} onValueChange={(value) => handleChange('license_type', value)}>
                    <SelectTrigger className="bg-[#141923] border-[#1a1f2e] text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="BASIC">Alap</SelectItem>
                      <SelectItem value="EXTENDED">Kibővített</SelectItem>
                      <SelectItem value="EXCLUSIVE">Exkluzív</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* AI Code Analyzer - NEW SECTION */}
            <div className="space-y-6 pb-6 border-b border-[#1a1f2e]">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-white">AI Kód Elemzés</h3>
                <Button
                  type="button"
                  onClick={() => setShowAIAnalyzer(!showAIAnalyzer)}
                  variant="outline"
                  className="border-cyan-600/50 text-cyan-400 hover:bg-cyan-600/20"
                >
                  <Zap className="w-4 h-4 mr-2" />
                  {showAIAnalyzer ? 'Bezárás' : 'Kód Elemzés'}
                </Button>
              </div>

              {showAIAnalyzer && (
                <div className="space-y-4">
                  <div>
                    <Label className="text-white mb-2 block">Kód Minta (opcionális)</Label>
                    <Textarea
                      value={codeForAnalysis}
                      onChange={(e) => setCodeForAnalysis(e.target.value)}
                      className="bg-[#141923] border-[#1a1f2e] text-white min-h-[200px] font-mono text-sm"
                      placeholder="Másolj be egy kód részletet a programodból..."
                    />
                  </div>
                  
                  <AIAnalyzer 
                    code={codeForAnalysis} 
                    onAnalysisComplete={handleAnalysisComplete}
                  />
                </div>
              )}
            </div>

            {/* Pricing */}
            <div className="space-y-6 pb-6 border-b border-[#1a1f2e]">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-white">Árazás</h3>
                <Button
                  type="button"
                  onClick={() => setShowAIValuator(!showAIValuator)}
                  variant="outline"
                  className="border-purple-600/50 text-purple-400 hover:bg-purple-600/20"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  {showAIValuator ? 'Manuális árazás' : 'AI Árbecslés'}
                </Button>
              </div>
              
              {showAIValuator && (
                <AIValuator onValuationComplete={handleValuationComplete} />
              )}
              
              {!showAIValuator && (
                <>
              
              <div className="grid md:grid-cols-3 gap-6">
                <div>
                  <Label className="text-white mb-2 block">Ajánlott Ár *</Label>
                  <Input
                    type="number"
                    min="0"
                    value={formData.price}
                    onChange={(e) => handleChange('price', Number(e.target.value))}
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                    placeholder="0 = ingyenes"
                  />
                </div>

                <div>
                  <Label className="text-white mb-2 block">Min. Ár</Label>
                  <Input
                    type="number"
                    min="0"
                    value={formData.floor_price}
                    onChange={(e) => handleChange('floor_price', Number(e.target.value))}
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                    placeholder="Automatikus"
                  />
                </div>

                <div>
                  <Label className="text-white mb-2 block">Max. Ár</Label>
                  <Input
                    type="number"
                    min="0"
                    value={formData.ceiling_price}
                    onChange={(e) => handleChange('ceiling_price', Number(e.target.value))}
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                    placeholder="Automatikus"
                  />
                </div>
              </div>
              </>
              )}
            </div>

            {/* Tech Stack */}
            <div className="space-y-6 pb-6 border-b border-[#1a1f2e]">
              <h3 className="text-lg font-bold text-white">Technológiák</h3>
              
              <div>
                <Label className="text-white mb-2 block">Technológiai Stack</Label>
                <div className="flex gap-2 mb-3">
                  <Input
                    type="text"
                    value={newTech}
                    onChange={(e) => setNewTech(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTech())}
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                    placeholder="pl. React, Node.js, PostgreSQL"
                  />
                  <Button type="button" onClick={addTech} className="bg-[#00E599] text-black hover:bg-[#00E599]/90">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {techStack.map(tech => (
                    <div key={tech} className="flex items-center gap-2 px-3 py-1 bg-[#141923] rounded-lg border border-[#1a1f2e]">
                      <span className="text-white text-sm">{tech}</span>
                      <button type="button" onClick={() => removeTech(tech)} className="text-gray-400 hover:text-white">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-white mb-2 block">Címkék</Label>
                <div className="flex gap-2 mb-3">
                  <Input
                    type="text"
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                    placeholder="pl. responsive, dark-mode, realtime"
                  />
                  <Button type="button" onClick={addTag} className="bg-[#00E599] text-black hover:bg-[#00E599]/90">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {tags.map(tag => (
                    <div key={tag} className="flex items-center gap-2 px-3 py-1 bg-[#141923] rounded-lg border border-[#1a1f2e]">
                      <span className="text-white text-sm">#{tag}</span>
                      <button type="button" onClick={() => removeTag(tag)} className="text-gray-400 hover:text-white">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Media */}
            <div className="space-y-6 pb-6 border-b border-[#1a1f2e]">
              <h3 className="text-lg font-bold text-white">Média</h3>
              
              <div>
                <Label className="text-white mb-2 block">Ikon URL</Label>
                <Input
                  type="url"
                  value={formData.icon_url}
                  onChange={(e) => handleChange('icon_url', e.target.value)}
                  className="bg-[#141923] border-[#1a1f2e] text-white"
                  placeholder="https://example.com/icon.png"
                />
              </div>

              <div>
                <Label className="text-white mb-2 block">Képernyőképek</Label>
                <div className="flex gap-2 mb-3">
                  <Input
                    type="url"
                    value={newScreenshot}
                    onChange={(e) => setNewScreenshot(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addScreenshot())}
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                    placeholder="https://example.com/screenshot.png"
                  />
                  <Button type="button" onClick={addScreenshot} className="bg-[#00E599] text-black hover:bg-[#00E599]/90">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {screenshots.map(url => (
                    <div key={url} className="relative group">
                      <img src={url} alt="Screenshot" className="w-full aspect-video object-cover rounded-lg" />
                      <button
                        type="button"
                        onClick={() => removeScreenshot(url)}
                        className="absolute top-2 right-2 p-1 bg-red-600 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X className="w-4 h-4 text-white" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Version Info */}
            <div className="space-y-6 pb-6 border-b border-[#1a1f2e]">
              <h3 className="text-lg font-bold text-white">Verzió & Változások</h3>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label className="text-white mb-2 block">Fejlesztő Neve *</Label>
                  <Input
                    type="text"
                    value={formData.developer}
                    onChange={(e) => handleChange('developer', e.target.value)}
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                    required
                  />
                </div>

                <div>
                  <Label className="text-white mb-2 block">Verzió</Label>
                  <Input
                    type="text"
                    value={formData.version}
                    onChange={(e) => handleChange('version', e.target.value)}
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                    placeholder="1.0.0"
                  />
                </div>
              </div>

              <div>
                <Label className="text-white mb-2 block">Változásnapló</Label>
                <Textarea
                  value={formData.changelog}
                  onChange={(e) => handleChange('changelog', e.target.value)}
                  className="bg-[#141923] border-[#1a1f2e] text-white"
                  placeholder="Mi újság ebben a verzióban?"
                  rows={4}
                />
              </div>
            </div>

            {/* Links */}
            <div className="space-y-6 pb-6 border-b border-[#1a1f2e]">
              <h3 className="text-lg font-bold text-white">Linkek</h3>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label className="text-white mb-2 block">Letöltési Link</Label>
                  <Input
                    type="url"
                    value={formData.download_url}
                    onChange={(e) => handleChange('download_url', e.target.value)}
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                    placeholder="https://example.com/download"
                  />
                </div>

                <div>
                  <Label className="text-white mb-2 block">Demo URL</Label>
                  <Input
                    type="url"
                    value={formData.demo_url}
                    onChange={(e) => handleChange('demo_url', e.target.value)}
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                    placeholder="https://demo.example.com"
                  />
                </div>
              </div>

              <div>
                <Label className="text-white mb-2 block">Támogatás Email</Label>
                <Input
                  type="email"
                  value={formData.support_email}
                  onChange={(e) => handleChange('support_email', e.target.value)}
                  className="bg-[#141923] border-[#1a1f2e] text-white"
                  placeholder="support@example.com"
                />
              </div>
            </div>

            {/* Options */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Checkbox
                  id="featured"
                  checked={formData.featured}
                  onCheckedChange={(checked) => handleChange('featured', checked)}
                />
                <Label htmlFor="featured" className="text-white cursor-pointer">
                  Kiemelt program (nagyobb láthatóság)
                </Label>
              </div>

              <div className="flex items-center gap-3">
                <Checkbox
                  id="verified"
                  checked={formData.verified}
                  onCheckedChange={(checked) => handleChange('verified', checked)}
                />
                <Label htmlFor="verified" className="text-white cursor-pointer">
                  Ellenőrzött program (bizalmi jelvény)
                </Label>
              </div>
            </div>

            {/* Submit */}
            <div className="flex gap-4 pt-6 border-t border-[#1a1f2e]">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate(createPageUrl("Marketplace"))}
                className="flex-1 border-[#1a1f2e] text-white hover:bg-[#1a1f2e]"
              >
                Mégse
              </Button>
              <Button
                type="submit"
                disabled={createAppMutation.isPending}
                className="flex-1 bg-gradient-to-r from-[#00E599] to-[#00B8D4] text-black font-bold hover:opacity-90"
              >
                {createAppMutation.isPending ? 'Feltöltés...' : 'Program Feltöltése'}
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
}
