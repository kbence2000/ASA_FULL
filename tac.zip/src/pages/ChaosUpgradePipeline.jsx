import React, { useState, useRef, useEffect } from 'react';
import { Flame, Loader2, AlertTriangle, Sparkles, TrendingUp, Zap, Database, CheckCircle2, ArrowRight, Clock, Trophy } from 'lucide-react';

export default function ChaosUpgradePipeline() {
  const [isRunning, setIsRunning] = useState(false);
  const [currentStage, setCurrentStage] = useState(null);
  const [pipelineResult, setPipelineResult] = useState(null);
  const [vault, setVault] = useState([]);
  const [error, setError] = useState(null);
  const canvasRef = useRef(null);

  // Animated chaos background
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles = [];
    for (let i = 0; i < 150; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 3,
        vy: (Math.random() - 0.5) * 3,
        size: Math.random() * 3 + 1,
        color: Math.random() > 0.5 ? '#ff6ec7' : '#ff4b81',
        opacity: Math.random() * 0.5 + 0.3
      });
    }

    let animationId;
    const animate = () => {
      ctx.fillStyle = 'rgba(2, 0, 12, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `${p.color}${Math.floor(p.opacity * 255).toString(16).padStart(2, '0')}`;
        ctx.fill();
      });

      animationId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  // Load vault on mount
  useEffect(() => {
    loadVault();
  }, []);

  const loadVault = async () => {
    try {
      const response = await fetch('http://localhost:9911/api/chaos/vault');
      const data = await response.json();
      if (data.status === 'ok') {
        setVault(data.vault || []);
      }
    } catch (err) {
      console.error('Failed to load vault:', err);
    }
  };

  const runPipeline = async () => {
    if (isRunning) return;

    setIsRunning(true);
    setError(null);
    setPipelineResult(null);
    setCurrentStage('chaos');

    try {
      // Stage progression
      setTimeout(() => setCurrentStage('evolution'), 2000);
      setTimeout(() => setCurrentStage('vault'), 4000);

      const response = await fetch('http://localhost:9911/api/chaos/run');

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();

      if (data.status !== 'ok') {
        throw new Error('Pipeline execution failed');
      }

      setPipelineResult(data);
      setCurrentStage('complete');
      
      // Reload vault
      await loadVault();

    } catch (err) {
      console.error('Chaos Pipeline error:', err);
      setError(err.message);
      setCurrentStage(null);
    } finally {
      setIsRunning(false);
    }
  };

  const stages = [
    { id: 'chaos', label: 'Chaos Architect', desc: '10 insane ideas', icon: Flame },
    { id: 'evolution', label: 'Evolution Sim', desc: '1000→100→best', icon: TrendingUp },
    { id: 'vault', label: 'Vault Storage', desc: 'Top 10 saved', icon: Database },
  ];

  return (
    <div className="relative min-h-screen overflow-hidden" style={{
      background: 'radial-gradient(circle at 50% 0%, #2a0518 0%, #0a0208 30%, #02000c 70%)'
    }}>
      <style>{`
        @keyframes chaosPulse {
          0%, 100% { opacity: 0.8; transform: scale(1) rotate(0deg); }
          50% { opacity: 1; transform: scale(1.05) rotate(180deg); }
        }

        @keyframes shimmerChaos {
          0% { background-position: -1000px 0; }
          100% { background-position: 1000px 0; }
        }

        @keyframes chaosFloat {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-12px) rotate(5deg); }
        }

        .chaos-badge {
          animation: chaosPulse 3s ease-in-out infinite;
        }

        .chaos-card {
          animation: chaosFloat 6s ease-in-out infinite;
        }

        .shimmer-chaos {
          background: linear-gradient(90deg, #ff4b81, #ff6ec7, #ec4899, #ff4b81);
          background-size: 200% 100%;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: shimmerChaos 3s linear infinite;
        }

        .chaos-border {
          position: relative;
        }

        .chaos-border::before {
          content: '';
          position: absolute;
          inset: -2px;
          border-radius: inherit;
          padding: 2px;
          background: linear-gradient(135deg, rgba(255, 110, 199, 0.6), transparent, rgba(255, 75, 129, 0.6));
          -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          -webkit-mask-composite: xor;
          mask-composite: exclude;
        }

        .stage-active {
          animation: chaosPulse 1.5s ease-in-out infinite;
        }

        .idea-item {
          animation: chaosFloat 4s ease-in-out infinite;
        }
      `}</style>

      {/* Animated Background Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ opacity: 0.5 }}
      />

      {/* Main Content */}
      <div className="relative z-10 max-w-[1800px] mx-auto px-4 py-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-3">
            <Flame className="w-16 h-16 text-pink-500 chaos-badge" />
            <h1 className="text-5xl md:text-6xl font-black tracking-wider uppercase shimmer-chaos">
              CHAOS UPGRADE PIPELINE
            </h1>
          </div>
          <p className="text-sm text-gray-400 tracking-wide mb-2">
            Chaos Architect → Universal Upgrade → Evolution → Vault Storage
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs uppercase tracking-wider"
            style={{
              background: 'rgba(255, 110, 199, 0.15)',
              border: '1px solid rgba(255, 110, 199, 0.5)',
              boxShadow: '0 0 20px rgba(255, 110, 199, 0.3)'
            }}
          >
            <Sparkles className="w-3 h-3" />
            10 Ideas · 1000 Candidates · Top 10 to Vault
          </div>
        </div>

        {/* Info Banner */}
        <div className="mb-6 p-4 rounded-2xl border chaos-border"
          style={{
            background: 'rgba(255, 110, 199, 0.08)',
            borderColor: 'rgba(255, 110, 199, 0.3)'
          }}
        >
          <div className="flex items-start gap-3">
            <Flame className="w-5 h-5 text-pink-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <span className="font-bold text-pink-300">Chaos Upgrade Pipeline:</span>
              <br />
              Fully automated real-time development assembly line: (1) <strong>Chaos Architect</strong> generates 10 insane AI upgrade concepts,
              (2) Each runs through <strong>Universal Upgrade Engine</strong> with instant 1000→100→5gen evolution simulation,
              (3) Top 10 breakthrough candidates automatically stored in <strong>Chaos Vault</strong> for review.
              <br />
              <span className="text-pink-400 font-semibold">Process time:</span> ~5-10 seconds for complete cycle.
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 rounded-xl border border-red-500/50 bg-red-900/20 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Backend Connection Error</div>
              <div className="text-xs text-gray-300 mt-1">{error}</div>
              <div className="text-xs text-gray-400 mt-2">
                Make sure the backend server is running: <code className="bg-black/40 px-2 py-0.5 rounded">node chaos-upgrade-pipeline.js</code> on port 9911
              </div>
            </div>
          </div>
        )}

        {/* Main Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          {/* Left: Controls + Progress */}
          <div className="xl:col-span-4 space-y-4">
            {/* Run Control */}
            <div className="chaos-border rounded-2xl border p-6"
              style={{
                borderColor: 'rgba(255, 110, 199, 0.3)',
                background: 'rgba(42, 5, 24, 0.95)',
                boxShadow: '0 0 40px rgba(0, 0, 0, 0.7)'
              }}
            >
              <div className="text-xs tracking-widest uppercase text-pink-400 mb-4">
                PIPELINE CONTROL
              </div>

              <button
                onClick={runPipeline}
                disabled={isRunning}
                className="w-full py-4 rounded-full text-sm font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                style={{
                  background: 'linear-gradient(135deg, #ff4b81, #ff6ec7)',
                  color: '#fff',
                  boxShadow: isRunning ? 'none' : '0 0 30px rgba(255, 110, 199, 0.7)'
                }}
              >
                {isRunning ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    PIPELINE RUNNING...
                  </>
                ) : (
                  <>
                    <Flame className="w-5 h-5" />
                    RUN CHAOS PIPELINE
                  </>
                )}
              </button>

              {/* Pipeline Progress */}
              {isRunning && (
                <div className="mt-6 space-y-3">
                  <div className="text-xs tracking-widest uppercase text-pink-400 mb-2">
                    PIPELINE STAGES
                  </div>
                  {stages.map((stage, idx) => {
                    const isActive = currentStage === stage.id;
                    const isComplete = stages.findIndex(s => s.id === currentStage) > idx || currentStage === 'complete';
                    const Icon = stage.icon;

                    return (
                      <div 
                        key={stage.id}
                        className={`flex items-center gap-3 p-3 rounded-lg border transition-all ${isActive ? 'stage-active' : ''}`}
                        style={{
                          borderColor: isActive ? 'rgba(255, 110, 199, 0.8)' : 'rgba(148, 163, 184, 0.2)',
                          background: isActive ? 'rgba(255, 110, 199, 0.2)' : isComplete ? 'rgba(34, 197, 94, 0.1)' : 'rgba(0, 0, 0, 0.3)'
                        }}
                      >
                        {isComplete ? (
                          <CheckCircle2 className="w-5 h-5 text-green-400" />
                        ) : isActive ? (
                          <Loader2 className="w-5 h-5 animate-spin text-pink-400" />
                        ) : (
                          <Icon className="w-5 h-5 text-gray-600" />
                        )}
                        <div className="flex-1">
                          <div className="text-xs font-semibold text-white">{stage.label}</div>
                          <div className="text-[10px] text-gray-400">{stage.desc}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Stats */}
              {!isRunning && (
                <div className="mt-6 pt-4 border-t" style={{ borderColor: 'rgba(255, 110, 199, 0.2)' }}>
                  <div className="text-xs text-gray-400 mb-2">Pipeline Stats</div>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Vault Records:</span>
                      <span className="text-white font-semibold">{vault.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Ideas per Cycle:</span>
                      <span className="text-white font-semibold">10</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Evolution Depth:</span>
                      <span className="text-white font-semibold">1000→100→5gen</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Vault Summary */}
            <div className="chaos-border rounded-2xl border p-6"
              style={{
                borderColor: 'rgba(255, 110, 199, 0.3)',
                background: 'rgba(42, 5, 24, 0.95)'
              }}
            >
              <div className="flex items-center gap-2 mb-4">
                <Database className="w-4 h-4 text-pink-400" />
                <div className="text-xs tracking-widest uppercase text-pink-400">
                  CHAOS VAULT
                </div>
              </div>

              {vault.length === 0 ? (
                <div className="text-center py-6 text-xs text-gray-500">
                  No records yet.
                  <br />
                  Run the pipeline to generate ideas.
                </div>
              ) : (
                <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2">
                  {vault.map((record, idx) => (
                    <div 
                      key={idx}
                      className="p-3 rounded-lg border"
                      style={{
                        background: 'rgba(0, 0, 0, 0.3)',
                        borderColor: 'rgba(255, 110, 199, 0.2)'
                      }}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Clock className="w-3 h-3 text-pink-400" />
                          <span className="text-xs text-gray-400">
                            {new Date(record.timestamp).toLocaleString()}
                          </span>
                        </div>
                        <div className="text-xs px-2 py-0.5 rounded-full"
                          style={{
                            background: 'rgba(34, 197, 94, 0.2)',
                            border: '1px solid rgba(34, 197, 94, 0.4)',
                            color: '#4ade80'
                          }}
                        >
                          {record.batch?.length || 0} ideas
                        </div>
                      </div>
                      {record.batch && record.batch[0] && (
                        <div className="text-xs text-gray-300 truncate">
                          Top: {record.batch[0].idea?.slice(0, 50)}...
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Right: Results */}
          <div className="xl:col-span-8">
            {!pipelineResult && !isRunning && (
              <div className="rounded-2xl border p-12 text-center h-full flex items-center justify-center"
                style={{
                  borderColor: 'rgba(148, 163, 184, 0.3)',
                  background: 'rgba(42, 5, 24, 0.95)'
                }}
              >
                <div>
                  <Flame className="w-20 h-20 mx-auto mb-4 text-pink-500/30" />
                  <p className="text-sm text-gray-500">
                    No pipeline result yet.
                    <br />
                    Click "Run Chaos Pipeline" to start the assembly line.
                  </p>
                </div>
              </div>
            )}

            {isRunning && !pipelineResult && (
              <div className="rounded-2xl border p-12 text-center h-full flex items-center justify-center"
                style={{
                  borderColor: 'rgba(255, 110, 199, 0.4)',
                  background: 'rgba(42, 5, 24, 0.95)'
                }}
              >
                <div>
                  <Loader2 className="w-20 h-20 mx-auto mb-4 text-pink-500 animate-spin" />
                  <p className="text-sm text-gray-400">
                    Running chaos pipeline...
                    <br />
                    <span className="text-xs text-gray-600">
                      {currentStage === 'chaos' && 'Generating 10 insane ideas...'}
                      {currentStage === 'evolution' && 'Evolving 1000 candidates per idea...'}
                      {currentStage === 'vault' && 'Storing top 10 to vault...'}
                    </span>
                  </p>
                </div>
              </div>
            )}

            {pipelineResult && pipelineResult.cycles && (
              <div className="space-y-4">
                {/* Summary Card */}
                <div className="chaos-card rounded-2xl border p-6"
                  style={{
                    borderColor: 'rgba(255, 110, 199, 0.4)',
                    background: 'rgba(42, 5, 24, 0.95)',
                    boxShadow: '0 0 60px rgba(255, 110, 199, 0.3)',
                    animationDelay: '0s'
                  }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <Trophy className="w-6 h-6 text-pink-400" />
                      <h3 className="text-lg font-bold text-white">Pipeline Complete</h3>
                    </div>
                    <div className="text-xs px-3 py-1 rounded-full"
                      style={{
                        background: 'rgba(34, 197, 94, 0.2)',
                        border: '1px solid rgba(34, 197, 94, 0.4)',
                        color: '#4ade80'
                      }}
                    >
                      {pipelineResult.cycles.top10?.length || 0} Winners
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div className="p-3 rounded-xl"
                      style={{
                        background: 'rgba(255, 110, 199, 0.1)',
                        border: '1px solid rgba(255, 110, 199, 0.3)'
                      }}
                    >
                      <div className="text-xs text-gray-400 mb-1">Ideas Generated</div>
                      <div className="text-2xl font-bold text-pink-300">
                        {pipelineResult.cycles.ideas?.length || 0}
                      </div>
                    </div>
                    <div className="p-3 rounded-xl"
                      style={{
                        background: 'rgba(255, 110, 199, 0.1)',
                        border: '1px solid rgba(255, 110, 199, 0.3)'
                      }}
                    >
                      <div className="text-xs text-gray-400 mb-1">Top Picks</div>
                      <div className="text-2xl font-bold text-pink-300">
                        {pipelineResult.cycles.top10?.length || 0}
                      </div>
                    </div>
                    <div className="p-3 rounded-xl"
                      style={{
                        background: 'rgba(34, 197, 94, 0.15)',
                        border: '1px solid rgba(34, 197, 94, 0.3)'
                      }}
                    >
                      <div className="text-xs text-gray-400 mb-1">Vault Size</div>
                      <div className="text-2xl font-bold text-green-400">
                        {pipelineResult.vaultSize || 0}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Top 10 Results */}
                {pipelineResult.cycles.top10 && (
                  <div className="chaos-card"
                    style={{ animationDelay: '0.1s' }}
                  >
                    <div className="text-xs font-bold text-pink-300 mb-4 flex items-center gap-2">
                      <Sparkles className="w-4 h-4" />
                      TOP 10 BREAKTHROUGH IDEAS
                    </div>

                    <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
                      {pipelineResult.cycles.top10.map((item, idx) => (
                        <div 
                          key={idx}
                          className="idea-item rounded-xl border p-4"
                          style={{
                            background: idx === 0 
                              ? 'rgba(34, 197, 94, 0.1)' 
                              : 'rgba(255, 110, 199, 0.08)',
                            borderColor: idx === 0 
                              ? 'rgba(34, 197, 94, 0.4)' 
                              : 'rgba(255, 110, 199, 0.3)',
                            animationDelay: `${idx * 0.05}s`
                          }}
                        >
                          <div className="flex items-start gap-3 mb-3">
                            <div 
                              className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold"
                              style={{
                                background: idx === 0 
                                  ? 'linear-gradient(135deg, #4ade80, #22c55e)' 
                                  : 'rgba(255, 110, 199, 0.3)',
                                color: idx === 0 ? '#000' : '#fff'
                              }}
                            >
                              {idx === 0 ? '👑' : `#${idx + 1}`}
                            </div>
                            <div className="flex-1">
                              <div className="text-sm text-white font-semibold mb-2">
                                {item.idea}
                              </div>
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                                <div className="flex justify-between">
                                  <span className="text-gray-400">Fitness:</span>
                                  <span className="text-white font-semibold">
                                    {item.best?.fitness?.toFixed(3) || 'N/A'}
                                  </span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-400">Improve:</span>
                                  <span className="text-white font-semibold">
                                    {item.best?.impro?.toFixed(2) || 'N/A'}
                                  </span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-400">Novelty:</span>
                                  <span className="text-white font-semibold">
                                    {item.best?.novelty?.toFixed(2) || 'N/A'}
                                  </span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-400">Risk:</span>
                                  <span className="text-red-400 font-semibold">
                                    {item.best?.risk?.toFixed(2) || 'N/A'}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Breakthrough Meter */}
                          <div className="mt-3 pt-3 border-t" style={{ borderColor: 'rgba(255, 110, 199, 0.2)' }}>
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-xs text-gray-400">Breakthrough Potential</span>
                              <span className="text-xs font-bold text-pink-300">
                                {(item.breakthrough * 100).toFixed(1)}%
                              </span>
                            </div>
                            <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-gradient-to-r from-pink-500 to-red-500"
                                style={{ width: `${item.breakthrough * 100}%` }}
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer Info */}
        <div className="mt-6 text-center text-xs text-gray-500">
          <p>Chaos Upgrade Pipeline :: Automated AI Development Assembly Line</p>
          <p className="mt-1">Backend: http://localhost:9911/api/chaos/run</p>
          <p className="mt-1 text-pink-500/60">Real-time: Chaos → Evolution → Vault in ~5-10 seconds.</p>
        </div>
      </div>
    </div>
  );
}