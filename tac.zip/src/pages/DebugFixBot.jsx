import React, { useState } from 'react';
import { Bug, Zap, AlertTriangle, CheckCircle2, Code2, FileText, Activity, Wrench } from 'lucide-react';

export default function DebugFixBot() {
  const [code, setCode] = useState('');
  const [errorLog, setErrorLog] = useState('');
  const [language, setLanguage] = useState('js');
  const [context, setContext] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('http://localhost:3000/debug/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code,
          errorLog,
          language,
          context: context ? JSON.parse(context) : {}
        })
      });

      if (!response.ok) throw new Error('Analysis failed');
      
      const data = await response.json();
      setResult(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const loadExample = (type) => {
    if (type === 'missing-brace') {
      setCode(`function calculate(a, b) {
  const result = a + b;
  if (result > 10) {
    console.log('Large number');
  // Missing closing brace
  return result;
}`);
      setErrorLog('');
      setLanguage('js');
    } else if (type === 'reference-error') {
      setCode(`const user = { name: 'John' };
console.log(userr.name); // Typo: userr instead of user
const result = processData();`);
      setErrorLog(`ReferenceError: userr is not defined
    at Object.<anonymous> (/app/index.js:2:13)
    at Module._compile (node:internal/modules/cjs/loader:1254:14)`);
      setLanguage('js');
    } else if (type === 'type-error') {
      setCode(`const data = null;
console.log(data.length); // Cannot read property of null
const items = data.map(x => x * 2);`);
      setErrorLog(`TypeError: Cannot read properties of null (reading 'length')
    at Object.<anonymous> (/app/index.js:2:18)`);
      setLanguage('js');
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'low': return { bg: '#4eff8b', text: '#4eff8b', glow: 'rgba(78, 255, 139, 0.4)' };
      case 'medium': return { bg: '#ffcc4b', text: '#ffcc4b', glow: 'rgba(255, 204, 75, 0.4)' };
      case 'high': return { bg: '#ff6ec7', text: '#ff6ec7', glow: 'rgba(255, 110, 199, 0.4)' };
      case 'critical': return { bg: '#ff4b81', text: '#ff4b81', glow: 'rgba(255, 75, 129, 0.4)' };
      default: return { bg: '#9094b2', text: '#9094b2', glow: 'rgba(144, 148, 178, 0.4)' };
    }
  };

  const getIssueIcon = (type) => {
    if (type.includes('error')) return <AlertTriangle className="w-4 h-4 text-red-400" />;
    if (type.includes('warning')) return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
    return <CheckCircle2 className="w-4 h-4 text-gray-400" />;
  };

  return (
    <div className="min-h-screen p-4" style={{
      background: 'radial-gradient(circle at top, #0a0a14 0, #030306 55%)'
    }}>
      <style>{`
        .debug-panel {
          background: #0a0a12;
          border: 1px solid #1a1a26;
        }

        .result-panel {
          background: #05050d;
          border: 1px solid #1a1a26;
        }

        .issue-card {
          background: #060612;
          border: 1px solid #1a1a26;
          transition: all 0.2s ease-out;
        }

        .issue-card:hover {
          background: #0a0a18;
          border-color: #26263a;
        }
      `}</style>

      <div className="max-w-[1600px] mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: 'radial-gradient(circle at 20% 0, #ffffff, #ff6ec7 40%, #6b0f4f)',
                boxShadow: '0 0 30px rgba(255, 110, 199, 0.6)'
              }}
            >
              <Bug className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="text-xl font-bold text-white tracking-wide">
                DEBUG FIX BOT
              </div>
              <div className="text-xs text-gray-400 tracking-wider">
                AI-Powered Code Analyzer & Auto-Fixer
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full" style={{
            background: 'rgba(255, 110, 199, 0.12)',
            border: '1px solid rgba(255, 110, 199, 0.6)'
          }}>
            <div className="w-2 h-2 rounded-full pulse-dot" style={{ background: '#ff6ec7' }} />
            <span className="text-xs font-semibold" style={{ color: '#ff6ec7' }}>
              READY
            </span>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-4 p-3 rounded-xl border border-red-500/50 bg-red-900/10 flex items-center gap-3">
            <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Error</div>
              <div className="text-xs text-gray-300 mt-0.5">{error}</div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left: Input */}
          <div className="lg:col-span-7 space-y-4">
            {/* Code Input */}
            <div className="debug-panel rounded-2xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                    Code Input
                  </div>
                  <div className="text-[10px] text-gray-500">
                    Paste your code here for analysis
                  </div>
                </div>
                <div className="flex gap-2">
                  <select
                    value={language}
                    onChange={(e) => setLanguage(e.target.value)}
                    className="px-3 py-1 rounded-lg text-xs"
                    style={{
                      background: '#05050d',
                      border: '1px solid #1a1a26',
                      color: '#fff'
                    }}
                  >
                    <option value="js">JavaScript</option>
                    <option value="ts">TypeScript</option>
                    <option value="py">Python</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              <textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full h-[300px] rounded-xl p-4 text-xs font-mono resize-none"
                style={{
                  background: '#05050d',
                  border: '1px solid #1a1a26',
                  color: '#a3a7cf'
                }}
                placeholder="// Paste your code here..."
              />
            </div>

            {/* Error Log Input */}
            <div className="debug-panel rounded-2xl p-4">
              <div className="mb-3">
                <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                  Error Log (Optional)
                </div>
                <div className="text-[10px] text-gray-500">
                  Stack trace or runtime errors
                </div>
              </div>

              <textarea
                value={errorLog}
                onChange={(e) => setErrorLog(e.target.value)}
                className="w-full h-[120px] rounded-xl p-4 text-xs font-mono resize-none"
                style={{
                  background: '#05050d',
                  border: '1px solid #1a1a26',
                  color: '#a3a7cf'
                }}
                placeholder="ReferenceError: xyz is not defined..."
              />
            </div>

            {/* Context (Optional) */}
            <div className="debug-panel rounded-2xl p-4">
              <div className="mb-3">
                <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                  Context (Optional JSON)
                </div>
                <div className="text-[10px] text-gray-500">
                  Additional metadata like fileName, moduleName
                </div>
              </div>

              <input
                type="text"
                value={context}
                onChange={(e) => setContext(e.target.value)}
                className="w-full rounded-xl px-4 py-2 text-xs font-mono"
                style={{
                  background: '#05050d',
                  border: '1px solid #1a1a26',
                  color: '#a3a7cf'
                }}
                placeholder='{"fileName": "app.js", "moduleName": "TrendHarvester"}'
              />
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <button
                onClick={handleAnalyze}
                disabled={isAnalyzing || !code}
                className="flex-1 px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                style={{
                  background: 'radial-gradient(circle at 20% 0, #ffffff, #ff6ec7 40%, #b80f88 70%)',
                  color: '#020206',
                  boxShadow: isAnalyzing ? 'none' : '0 8px 24px rgba(255, 110, 199, 0.6)'
                }}
              >
                {isAnalyzing ? (
                  <>
                    <Activity className="w-4 h-4 animate-spin" />
                    ANALYZING...
                  </>
                ) : (
                  <>
                    <Wrench className="w-4 h-4" />
                    ANALYZE & FIX
                  </>
                )}
              </button>
            </div>

            {/* Examples */}
            <div className="flex gap-2">
              <button
                onClick={() => loadExample('missing-brace')}
                className="flex-1 px-3 py-2 rounded-xl text-[10px] font-semibold uppercase tracking-wider transition-all hover:bg-white/5"
                style={{
                  background: 'rgba(255, 255, 255, 0.02)',
                  color: '#9094b2',
                  border: '1px solid rgba(255, 255, 255, 0.08)'
                }}
              >
                Example: Missing Brace
              </button>
              <button
                onClick={() => loadExample('reference-error')}
                className="flex-1 px-3 py-2 rounded-xl text-[10px] font-semibold uppercase tracking-wider transition-all hover:bg-white/5"
                style={{
                  background: 'rgba(255, 255, 255, 0.02)',
                  color: '#9094b2',
                  border: '1px solid rgba(255, 255, 255, 0.08)'
                }}
              >
                Example: ReferenceError
              </button>
              <button
                onClick={() => loadExample('type-error')}
                className="flex-1 px-3 py-2 rounded-xl text-[10px] font-semibold uppercase tracking-wider transition-all hover:bg-white/5"
                style={{
                  background: 'rgba(255, 255, 255, 0.02)',
                  color: '#9094b2',
                  border: '1px solid rgba(255, 255, 255, 0.08)'
                }}
              >
                Example: TypeError
              </button>
            </div>
          </div>

          {/* Right: Results */}
          <div className="lg:col-span-5 space-y-4">
            {!result ? (
              <div className="debug-panel rounded-2xl p-6 h-full flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <Bug className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <div className="text-sm font-semibold">No Analysis Yet</div>
                  <div className="text-xs mt-1">Enter code and click "Analyze & Fix"</div>
                </div>
              </div>
            ) : (
              <>
                {/* Severity Badge */}
                <div className="debug-panel rounded-2xl p-4">
                  <div className="flex items-center justify-between">
                    <div className="text-xs text-gray-400 uppercase tracking-wider">Severity</div>
                    <div 
                      className="px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider"
                      style={{
                        background: `${getSeverityColor(result.severity).glow}`,
                        color: getSeverityColor(result.severity).text,
                        border: `1px solid ${getSeverityColor(result.severity).text}`
                      }}
                    >
                      {result.severity}
                    </div>
                  </div>
                  {result.meta && (
                    <div className="mt-3 text-[10px] text-gray-500 space-y-1">
                      <div>Issues Found: <strong className="text-white">{result.meta.issueCount}</strong></div>
                      <div>Language: <strong className="text-white">{result.meta.language}</strong></div>
                      {result.meta.autoPatched && (
                        <div className="text-green-400">✓ Auto-patch applied</div>
                      )}
                    </div>
                  )}
                </div>

                {/* Issues */}
                {result.issues && result.issues.length > 0 && (
                  <div className="debug-panel rounded-2xl p-4">
                    <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
                      Issues Detected ({result.issues.length})
                    </div>
                    <div className="space-y-2 max-h-[300px] overflow-y-auto">
                      {result.issues.map((issue, idx) => (
                        <div key={idx} className="issue-card rounded-xl p-3">
                          <div className="flex items-start gap-2 mb-2">
                            {getIssueIcon(issue.type)}
                            <div className="flex-1">
                              <div className="text-xs text-white font-semibold">{issue.message}</div>
                              {issue.line && (
                                <div className="text-[10px] text-gray-500 mt-1">Line: {issue.line}</div>
                              )}
                            </div>
                          </div>
                          {issue.hint && (
                            <div className="text-[10px] text-gray-400 mt-2 pl-6">
                              💡 {issue.hint}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Suggestions */}
                {result.suggestions && result.suggestions.length > 0 && (
                  <div className="debug-panel rounded-2xl p-4">
                    <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
                      Suggestions
                    </div>
                    <div className="space-y-2">
                      {result.suggestions.map((suggestion, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-[11px] text-gray-300">
                          <CheckCircle2 className="w-3 h-3 text-cyan-400 mt-0.5 flex-shrink-0" />
                          <span>{suggestion}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Patched Code */}
                {result.patchedCode && (
                  <div className="debug-panel rounded-2xl p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                        Auto-Patched Code
                      </div>
                      <div className="px-2 py-1 rounded-full text-[9px] uppercase tracking-wider" style={{
                        background: 'rgba(78, 255, 139, 0.16)',
                        color: '#4eff8b',
                        border: '1px solid rgba(78, 255, 139, 0.4)'
                      }}>
                        FIXED
                      </div>
                    </div>
                    <div className="result-panel rounded-xl p-3 max-h-[200px] overflow-auto">
                      <pre className="text-[10px] text-gray-300 font-mono">
                        {result.patchedCode}
                      </pre>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}