import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Activity, Terminal } from "lucide-react";
import { Card } from "@/components/ui/card";
import CoreStatusOverview from "../components/CoreStatusOverview";
import CoreModulesList from "../components/CoreModulesList";
import CoreHeartbeatMonitor from "../components/CoreHeartbeatMonitor";

export default function SystemStatus() {
  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Admin check
  if (user && user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md w-full p-8 text-center border" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <Terminal className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Admin Only</h2>
          <p className="text-gray-400">
            System Status requires administrator privileges
          </p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br from-green-500 to-cyan-500">
              <Activity className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-black text-white">System Status</h1>
              <p className="text-gray-400">MDC Platform Health Monitor</p>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {/* Heartbeat */}
          <CoreHeartbeatMonitor />

          {/* Status Overview */}
          <CoreStatusOverview />

          {/* Modules List */}
          <CoreModulesList />
        </div>
      </div>
    </div>
  );
}