import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Sparkles, 
  Code2, 
  Zap, 
  Loader2, 
  Save,
  TrendingUp,
  Lightbulb,
  DollarSign,
  CheckCircle2,
  Tag,
  Package,
  Wand2,
  Copy,
  Check
} from "lucide-react";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function CodeMaker() {
  const [code, setCode] = useState("");
  const [description, setDescription] = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [analysis, setAnalysis] = useState(null);
  const [assetTitle, setAssetTitle] = useState("");
  const [saving, setSaving] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState("analyze");

  const handleAnalyze = async () => {
    if (!code || code.trim().length === 0) {
      toast.error("Please enter some code to analyze!");
      return;
    }

    setAnalyzing(true);
    setAnalysis(null);

    try {
      const response = await fetch('/api/ai/fm-analyze-value', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ code })
      });

      if (!response.ok) {
        throw new Error('AI analysis failed');
      }

      const data = await response.json();
      
      const qualityScore = parseQualityScore(data.value.quality, data.value.score);
      const complexity = parseComplexity(data.value.complexity);
      const estimatedPrice = parsePrice(data.value.price_estimate);

      const result = {
        qualityScore,
        complexity,
        estimatedPrice,
        fullAnalysis: data.value,
        summary: data.summary || '',
        patterns: data.patterns || [],
        suggestions: data.suggestions || [],
        tags: data.tags || [],
        raw: data
      };

      setAnalysis(result);
      toast.success("AI analysis complete!");
    } catch (error) {
      console.error('AI Analysis error:', error);
      toast.error("Analysis failed. Please try again!");
    } finally {
      setAnalyzing(false);
    }
  };

  const handleGenerateFull = async () => {
    if (!description || description.trim().length === 0) {
      toast.error("Please describe what code you want to generate!");
      return;
    }

    setGenerating(true);
    setAnalysis(null);
    setCode("");

    try {
      const response = await fetch('/api/ai/generate-full', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ description })
      });

      if (!response.ok) {
        throw new Error('Code generation failed');
      }

      const data = await response.json();
      
      // Set generated code
      setCode(data.generated_code || "");

      // Parse analysis
      const qualityScore = parseQualityScore(data.value.quality, data.value.score);
      const complexity = parseComplexity(data.value.complexity);
      const estimatedPrice = parsePrice(data.value.price_estimate);

      const result = {
        qualityScore,
        complexity,
        estimatedPrice,
        fullAnalysis: data.value,
        summary: data.summary || '',
        patterns: data.patterns || [],
        suggestions: data.suggestions || [],
        tags: data.tags || [],
        generated: true,
        raw: data
      };

      setAnalysis(result);
      toast.success("Code generated & analyzed!");
      
      // Auto-switch to analyze tab to show generated code
      setActiveTab("analyze");
    } catch (error) {
      console.error('Generate error:', error);
      toast.error("Generation failed. Please try again!");
    } finally {
      setGenerating(false);
    }
  };

  const handleCopyCode = () => {
    if (code) {
      navigator.clipboard.writeText(code);
      setCopied(true);
      toast.success("Code copied to clipboard!");
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSave = async () => {
    if (!analysis) {
      toast.error("No analysis to save!");
      return;
    }

    if (!assetTitle || assetTitle.trim().length === 0) {
      toast.error("Please enter an asset title!");
      return;
    }

    if (!code || code.trim().length === 0) {
      toast.error("No code to save!");
      return;
    }

    setSaving(true);

    try {
      const response = await fetch('/api/market/save-asset', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title: assetTitle,
          summary: analysis.summary,
          patterns: analysis.patterns,
          suggestions: analysis.suggestions,
          tags: analysis.tags,
          code: code,
          value: {
            quality: analysis.qualityScore,
            complexity: analysis.complexity,
            price_estimate: analysis.estimatedPrice,
            score: analysis.qualityScore
          }
        })
      });

      if (!response.ok) {
        throw new Error('Failed to save asset');
      }

      const result = await response.json();
      
      if (result.success) {
        toast.success("Asset saved to Pattern Library!");
        setAssetTitle("");
      }
    } catch (error) {
      console.error('Save asset error:', error);
      toast.error("Failed to save asset!");
    } finally {
      setSaving(false);
    }
  };

  // Helper parsers
  const parseQualityScore = (quality, score) => {
    if (score && typeof score === 'number') return Math.round(score);
    if (score && typeof score === 'string') {
      const match = score.match(/(\d+)/);
      if (match) return Math.min(5, parseInt(match[1]));
    }
    if (typeof quality === 'string') {
      const lower = quality.toLowerCase();
      if (lower.includes('excellent') || lower.includes('5')) return 5;
      if (lower.includes('good') || lower.includes('4')) return 4;
      if (lower.includes('average') || lower.includes('3')) return 3;
      if (lower.includes('below') || lower.includes('2')) return 2;
      if (lower.includes('poor') || lower.includes('1')) return 1;
    }
    return 3;
  };

  const parseComplexity = (complexity) => {
    if (!complexity) return 'medium';
    const str = String(complexity).toLowerCase();
    if (str.includes('low') || str.includes('simple')) return 'low';
    if (str.includes('high') || str.includes('complex') || str.includes('advanced')) return 'high';
    return 'medium';
  };

  const parsePrice = (price) => {
    if (!price || price === 'N/A') return 0;
    if (typeof price === 'number') return Math.round(price);
    const match = String(price).match(/(\d+)/);
    return match ? parseInt(match[1]) : 0;
  };

  return (
    <div className="min-h-screen">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Hero Header */}
        <section className="mb-12">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center" style={{
              background: 'linear-gradient(135deg, #4d0d6f, #886E9D)'
            }}>
              <Code2 className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-black gradient-text">Code Maker</h1>
              <p className="text-gray-400">AI-powered code generation, pattern extraction & marketplace asset creation</p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <Card className="border p-4" style={{
              background: 'rgba(15, 23, 42, 0.95)',
              borderColor: 'rgba(139, 92, 255, 0.3)'
            }}>
              <div className="flex items-center gap-3">
                <Wand2 className="w-8 h-8 text-purple-400" />
                <div>
                  <div className="text-sm font-semibold text-white">Code Forge</div>
                  <div className="text-xs text-gray-400">Generate from Idea</div>
                </div>
              </div>
            </Card>

            <Card className="border p-4" style={{
              background: 'rgba(15, 23, 42, 0.95)',
              borderColor: 'rgba(36, 228, 255, 0.3)'
            }}>
              <div className="flex items-center gap-3">
                <Sparkles className="w-8 h-8 text-cyan-400" />
                <div>
                  <div className="text-sm font-semibold text-white">FutureMind</div>
                  <div className="text-xs text-gray-400">Pattern Analysis</div>
                </div>
              </div>
            </Card>

            <Card className="border p-4" style={{
              background: 'rgba(15, 23, 42, 0.95)',
              borderColor: 'rgba(255, 184, 77, 0.3)'
            }}>
              <div className="flex items-center gap-3">
                <Zap className="w-8 h-8 text-yellow-400" />
                <div>
                  <div className="text-sm font-semibold text-white">Value Analyst</div>
                  <div className="text-xs text-gray-400">Price Estimation</div>
                </div>
              </div>
            </Card>
          </div>
        </section>

        <div className="grid lg:grid-cols-[1.2fr_1fr] gap-8">
          {/* Left: Input Tabs */}
          <div>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="bg-[#0f1419] border border-[#1a1f2e] w-full grid grid-cols-2">
                <TabsTrigger value="analyze" className="data-[state=active]:bg-purple-600/20">
                  <Code2 className="w-4 h-4 mr-2" />
                  Analyze Code
                </TabsTrigger>
                <TabsTrigger value="generate" className="data-[state=active]:bg-cyan-600/20">
                  <Wand2 className="w-4 h-4 mr-2" />
                  Generate Code
                </TabsTrigger>
              </TabsList>

              {/* TAB 1: Analyze Existing Code */}
              <TabsContent value="analyze">
                <Card className="border p-6" style={{
                  background: 'rgba(15, 23, 42, 0.95)',
                  borderColor: 'rgba(148, 163, 184, 0.35)'
                }}>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <Code2 className="w-5 h-5 text-cyan-400" />
                      <h3 className="text-lg font-bold text-white">Code Input</h3>
                    </div>
                    {code && (
                      <Button
                        onClick={handleCopyCode}
                        variant="ghost"
                        size="sm"
                        className="text-gray-400 hover:text-white"
                      >
                        {copied ? (
                          <>
                            <Check className="w-4 h-4 mr-2" />
                            Copied
                          </>
                        ) : (
                          <>
                            <Copy className="w-4 h-4 mr-2" />
                            Copy
                          </>
                        )}
                      </Button>
                    )}
                  </div>

                  <Textarea
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="Paste your code here...

Example:
const fetchUser = async (id) => {
  const response = await fetch(`/api/users/${id}`);
  return response.json();
};"
                    className="bg-[#0a0e14] border-[#1a1f2e] text-white font-mono text-sm min-h-[400px]"
                    style={{ 
                      fontFamily: 'JetBrains Mono, monospace',
                      lineHeight: '1.6'
                    }}
                  />

                  <div className="mt-4">
                    <Button
                      onClick={handleAnalyze}
                      disabled={analyzing || !code}
                      className="w-full text-white font-bold py-6 text-base"
                      style={{
                        background: analyzing 
                          ? '#4a5568' 
                          : 'linear-gradient(135deg, #4d0d6f, #886E9D)',
                        borderRadius: '999px'
                      }}
                    >
                      {analyzing ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Analyzing code...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-5 h-5 mr-2" />
                          🔥 Analyze code (patterns + price)
                        </>
                      )}
                    </Button>
                  </div>
                </Card>
              </TabsContent>

              {/* TAB 2: Generate Code from Description */}
              <TabsContent value="generate">
                <Card className="border p-6" style={{
                  background: 'rgba(15, 23, 42, 0.95)',
                  borderColor: 'rgba(148, 163, 184, 0.35)'
                }}>
                  <div className="flex items-center gap-2 mb-4">
                    <Wand2 className="w-5 h-5 text-purple-400" />
                    <h3 className="text-lg font-bold text-white">Describe Your Idea</h3>
                  </div>

                  <Textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Describe what code you want to generate...

Example:
'Create a React component that fetches user data from an API and displays it in a table with search and filter functionality'

or

'Build a Python function that validates email addresses using regex and returns True/False'

or

'Generate a Node.js Express API endpoint that handles file uploads to AWS S3'"
                    className="bg-[#0a0e14] border-[#1a1f2e] text-white text-sm min-h-[400px]"
                    style={{ lineHeight: '1.6' }}
                  />

                  <div className="mt-4">
                    <Button
                      onClick={handleGenerateFull}
                      disabled={generating || !description}
                      className="w-full text-white font-bold py-6 text-base"
                      style={{
                        background: generating 
                          ? '#4a5568' 
                          : 'linear-gradient(135deg, #4d0d6f, #886E9D)',
                        borderRadius: '999px'
                      }}
                    >
                      {generating ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Generating code...
                        </>
                      ) : (
                        <>
                          <Wand2 className="w-5 h-5 mr-2" />
                          ✨ Generate + Analyze Code
                        </>
                      )}
                    </Button>
                  </div>

                  <p className="text-xs text-gray-500 mt-3 text-center">
                    AI will generate code, then automatically analyze patterns & estimate value
                  </p>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Right: Results */}
          <div className="space-y-6">
            {!analysis ? (
              <Card className="border p-8 text-center" style={{
                background: 'rgba(15, 23, 42, 0.95)',
                borderColor: 'rgba(148, 163, 184, 0.35)'
              }}>
                <Sparkles className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">Ready to Create</h3>
                <p className="text-gray-400 text-sm mb-4">
                  {activeTab === "analyze" 
                    ? "Paste your code and click analyze to extract patterns, assess quality, and estimate market value."
                    : "Describe your idea and AI will generate production-ready code with automatic analysis."
                  }
                </p>
              </Card>
            ) : (
              <>
                {/* Value Metrics */}
                <Card className="border p-6" style={{
                  background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.1), rgba(36, 228, 255, 0.1))',
                  borderColor: 'rgba(139, 92, 255, 0.4)'
                }}>
                  <div className="flex items-center gap-2 mb-4">
                    <CheckCircle2 className="w-5 h-5 text-green-400" />
                    <h4 className="font-bold text-white">
                      {analysis.generated ? "Generated & Analyzed" : "Analysis Complete"}
                    </h4>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div className="p-3 rounded-xl border text-center" style={{
                      background: 'rgba(5, 8, 22, 0.9)',
                      borderColor: 'rgba(148, 163, 184, 0.25)'
                    }}>
                      <div className="text-2xl font-bold gradient-text mb-1">
                        {analysis.qualityScore}/5
                      </div>
                      <div className="text-xs text-gray-400">Quality</div>
                    </div>

                    <div className="p-3 rounded-xl border text-center" style={{
                      background: 'rgba(5, 8, 22, 0.9)',
                      borderColor: 'rgba(148, 163, 184, 0.25)'
                    }}>
                      <Badge className={`mb-1 ${
                        analysis.complexity === 'low' ? 'bg-green-600/20 text-green-300 border-green-600/30' :
                        analysis.complexity === 'medium' ? 'bg-yellow-600/20 text-yellow-300 border-yellow-600/30' :
                        'bg-red-600/20 text-red-300 border-red-600/30'
                      }`}>
                        {analysis.complexity.toUpperCase()}
                      </Badge>
                      <div className="text-xs text-gray-400">Complexity</div>
                    </div>

                    <div className="p-3 rounded-xl border text-center" style={{
                      background: 'rgba(5, 8, 22, 0.9)',
                      borderColor: 'rgba(148, 163, 184, 0.25)'
                    }}>
                      <div className="flex items-center justify-center gap-1 mb-1">
                        <DollarSign className="w-4 h-4 text-green-400" />
                        <span className="text-lg font-bold text-white">{analysis.estimatedPrice}</span>
                      </div>
                      <div className="text-xs text-gray-400">Est. Value</div>
                    </div>
                  </div>
                </Card>

                {/* Summary */}
                {analysis.summary && (
                  <Card className="border p-4" style={{
                    background: 'rgba(15, 23, 42, 0.95)',
                    borderColor: 'rgba(139, 92, 255, 0.4)'
                  }}>
                    <div className="flex items-center gap-2 mb-3">
                      <Sparkles className="w-4 h-4 text-purple-400" />
                      <h4 className="font-semibold text-white text-sm">Summary</h4>
                    </div>
                    <p className="text-xs text-gray-300 leading-relaxed">
                      {analysis.summary}
                    </p>
                  </Card>
                )}

                {/* Patterns */}
                {analysis.patterns && analysis.patterns.length > 0 && (
                  <Card className="border p-4" style={{
                    background: 'rgba(15, 23, 42, 0.95)',
                    borderColor: 'rgba(36, 228, 255, 0.4)'
                  }}>
                    <div className="flex items-center gap-2 mb-3">
                      <Code2 className="w-4 h-4 text-cyan-400" />
                      <h4 className="font-semibold text-white text-sm">
                        Patterns ({analysis.patterns.length})
                      </h4>
                    </div>
                    <div className="space-y-2">
                      {analysis.patterns.slice(0, 3).map((pattern, idx) => (
                        <div key={idx} className="p-2 rounded-lg border text-xs" style={{
                          background: 'rgba(5, 8, 22, 0.9)',
                          borderColor: 'rgba(148, 163, 184, 0.2)'
                        }}>
                          <div className="font-semibold text-cyan-300 mb-1">
                            <Tag className="w-3 h-3 inline mr-1" />
                            {pattern.name || `Pattern ${idx + 1}`}
                          </div>
                          {pattern.description && (
                            <p className="text-gray-400">{pattern.description}</p>
                          )}
                        </div>
                      ))}
                      {analysis.patterns.length > 3 && (
                        <div className="text-xs text-gray-500 text-center">
                          +{analysis.patterns.length - 3} more patterns
                        </div>
                      )}
                    </div>
                  </Card>
                )}

                {/* Suggestions */}
                {analysis.suggestions && analysis.suggestions.length > 0 && (
                  <Card className="border p-4" style={{
                    background: 'rgba(15, 23, 42, 0.95)',
                    borderColor: 'rgba(255, 184, 77, 0.4)'
                  }}>
                    <div className="flex items-center gap-2 mb-3">
                      <Lightbulb className="w-4 h-4 text-yellow-400" />
                      <h4 className="font-semibold text-white text-sm">
                        Improvements ({analysis.suggestions.length})
                      </h4>
                    </div>
                    <ul className="space-y-2">
                      {analysis.suggestions.slice(0, 3).map((suggestion, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-xs text-gray-300">
                          <TrendingUp className="w-3 h-3 text-yellow-400 mt-0.5 flex-shrink-0" />
                          <span>
                            {typeof suggestion === 'string' ? suggestion : suggestion.text || suggestion.description}
                          </span>
                        </li>
                      ))}
                      {analysis.suggestions.length > 3 && (
                        <li className="text-xs text-gray-500 text-center">
                          +{analysis.suggestions.length - 3} more suggestions
                        </li>
                      )}
                    </ul>
                  </Card>
                )}

                {/* Save Card */}
                <Card className="border p-6" style={{
                  background: 'rgba(15, 23, 42, 0.95)',
                  borderColor: 'rgba(139, 92, 255, 0.5)'
                }}>
                  <div className="flex items-center gap-2 mb-4">
                    <Save className="w-5 h-5 text-purple-400" />
                    <h4 className="font-bold text-white">Save as Asset</h4>
                  </div>
                  
                  <div className="mb-4">
                    <Label className="text-white text-sm mb-2 block">Asset Title</Label>
                    <Input
                      type="text"
                      placeholder="e.g., 'Async Fetch Pattern'"
                      value={assetTitle}
                      onChange={(e) => setAssetTitle(e.target.value)}
                      className="bg-[#141923] border-[#1a1f2e] text-white"
                    />
                  </div>

                  <Button
                    onClick={handleSave}
                    disabled={saving || !assetTitle}
                    className="w-full text-white font-semibold"
                    style={{
                      background: saving 
                        ? '#4a5568'
                        : 'linear-gradient(135deg, rgba(139, 92, 255, 0.2), rgba(36, 228, 255, 0.2))',
                      border: '1px solid rgba(255, 255, 255, 0.2)',
                      borderRadius: '999px'
                    }}
                  >
                    {saving ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4 mr-2" />
                        💎 Save to Pattern Library
                      </>
                    )}
                  </Button>

                  <Link to={createPageUrl("PatternLibrary")} className="block mt-3">
                    <Button
                      variant="ghost"
                      className="w-full text-gray-400 hover:text-white text-sm"
                    >
                      <Package className="w-4 h-4 mr-2" />
                      View Pattern Library
                    </Button>
                  </Link>
                </Card>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}