import React, { useState, useRef, useEffect } from 'react';
import { Search, Shield, Zap, CheckCircle2, Loader2, AlertTriangle, Lock, Eye, Target, Sparkles, ArrowRight } from 'lucide-react';

const MOCK_MODULES = [
  {
    name: "TrendHarvester",
    type: "AI-INTEL",
    status: "live",
    spec: "Ingests external tech/code/news trends and normalizes them into TAC-readable signals. Real-time monitoring with intelligent filtering and pattern extraction.",
    code: "class TrendHarvester {\n  async harvest(sources) {\n    // Fetch and normalize trends\n  }\n}"
  },
  {
    name: "SecuritySentinel",
    type: "GUARD",
    status: "live",
    spec: "Watches TAC runtime, quarantines anomalies, calls repair agents on demand. 24/7 monitoring with automatic threat response and rollback capabilities.",
    code: "class SecuritySentinel {\n  monitorRuntime() {\n    // Security monitoring\n  }\n}"
  },
  {
    name: "MissionDeploy",
    type: "AGENT-OPS",
    status: "live",
    spec: "Sends specialized AI agents on scoped missions with timers and kill-switches. Autonomous deployment with safety boundaries and real-time monitoring.",
    code: "class MissionDeploy {\n  deploy(agent, mission) {\n    // Deploy agent\n  }\n}"
  },
  {
    name: "DebugChamber",
    type: "AI-OPS",
    status: "beta",
    spec: "Dual-layer debugging (OpenAI debug + Demigod practice patterns). Advanced error analysis with AI-powered root cause detection and fix suggestions.",
    code: "class DebugChamber {\n  analyze(error) {\n    // Debug analysis\n  }\n}"
  },
  {
    name: "ChaosArchitect",
    type: "GENESIS",
    status: "live",
    spec: "Generates insane upgrade concepts, logs them into the Chaos Inventory. Creative idea generation with boundary-pushing mutations and radical redesigns.",
    code: "class ChaosArchitect {\n  generate(brief) {\n    // Generate chaos\n  }\n}"
  }
];

export default function ModuleVault() {
  const [modules] = useState(MOCK_MODULES);
  const [selectedModule, setSelectedModule] = useState(MOCK_MODULES[0]);
  const [searchQuery, setSearchQuery] = useState('');
  const [evolvedVersions, setEvolvedVersions] = useState({});
  const [isEvolving, setIsEvolving] = useState(false);
  const [evolutionLog, setEvolutionLog] = useState('idle');
  const [error, setError] = useState(null);

  const filteredModules = modules.filter(m => 
    !searchQuery || 
    m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusColor = (status) => {
    switch (status) {
      case 'live': return '#14f4a8';
      case 'beta': return '#4f7cff';
      case 'experimental': return '#ff4b81';
      default: return '#9094b2';
    }
  };

  const runEvolution = async () => {
    if (!selectedModule || isEvolving) return;

    setIsEvolving(true);
    setError(null);
    setEvolutionLog('running – Paradox evolution in progress...');

    try {
      const response = await fetch('http://localhost:8090/api/evolution/evolve-module', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          moduleName: selectedModule.name,
          currentSpec: selectedModule.spec,
          currentCode: selectedModule.code || '',
          intensity: 7
        })
      });

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      const result = data.result;
      
      // Extract data from all stages
      const harmony = result.stages?.harmony9;
      const distorted = result.stages?.distorted9;
      const hallucinator = result.stages?.hallucinator;
      const paradox = result.stages?.paradox;
      const stabilizer = result.stages?.stabilizer;

      if (stabilizer) {
        const blueprintText = `# ${selectedModule.name} :: vNext (Paradox Evolution)

EVOLUTION TIMESTAMP: ${new Date().toISOString()}

═══════════════════════════════════════════════════════════
FINAL SUMMARY (Stabilizer Stage)
═══════════════════════════════════════════════════════════
${stabilizer.finalSummary}

═══════════════════════════════════════════════════════════
API SPECIFICATION
═══════════════════════════════════════════════════════════
${stabilizer.finalApiSpec}

═══════════════════════════════════════════════════════════
IMPLEMENTATION SKETCH
═══════════════════════════════════════════════════════════
${stabilizer.finalImplementationSketch}

═══════════════════════════════════════════════════════════
CHANGELOG (What Changed from Current Version)
═══════════════════════════════════════════════════════════
${stabilizer.changelog?.map((c, i) => `${i + 1}. ${c}`).join('\n') || 'No specific changes listed'}

═══════════════════════════════════════════════════════════
HIDDEN MODES & EASTER EGGS
═══════════════════════════════════════════════════════════
${stabilizer.hiddenModeNotes?.map((n, i) => `• ${n}`).join('\n') || 'None'}

═══════════════════════════════════════════════════════════
EVOLUTION PIPELINE METADATA
═══════════════════════════════════════════════════════════
Harmony 9 Focus: ${harmony?.focusAreas?.join(', ') || 'N/A'}
Distorted 9 Inversions: ${distorted?.inversions?.length || 0} radical ideas
Hallucinator Wildness: ${hallucinator?.wildness || 'N/A'}/10
Paradox Synthesis: ${paradox?.cycles || 'N/A'} cycles
Stabilizer Status: ${stabilizer?.stabilityScore || 'N/A'}/100

Evolution Quality Score: ${result.qualityScore || 'N/A'}/100
Backend Version: ${data.version || 'Unknown'}`;

        setEvolvedVersions({
          ...evolvedVersions,
          [selectedModule.name]: {
            blueprintText,
            rawResult: result,
            timestamp: new Date()
          }
        });

        setEvolutionLog(`done – vNext blueprint generated for ${selectedModule.name}`);
      } else {
        throw new Error('No stabilizer output from backend');
      }

    } catch (err) {
      console.error('Evolution error:', err);
      setError(err.message);
      setEvolutionLog('error – evolution failed');
    } finally {
      setIsEvolving(false);
    }
  };

  const activateEvolved = () => {
    if (!selectedModule) return;
    
    const evolved = evolvedVersions[selectedModule.name];
    if (!evolved) {
      alert('No evolved version to activate. Run Paradox Evolution first.');
      return;
    }

    setEvolutionLog(`activated – ${selectedModule.name} vNext marked as active (manually wire it in backend)`);
  };

  return (
    <div className="min-h-screen p-4" style={{
      background: 'radial-gradient(circle at top, #111122 0, #030308 55%)'
    }}>
      <style>{`
        .security-wrapper {
          background: linear-gradient(
            135deg,
            rgba(20, 244, 168, 0.12),
            rgba(80, 90, 255, 0.08),
            rgba(0, 0, 0, 0.8)
          );
          padding: 2px;
          box-shadow: 0 0 60px rgba(20, 244, 168, 0.3);
        }

        .gradient-border {
          position: relative;
        }

        .gradient-border::before {
          content: '';
          position: absolute;
          inset: -1px;
          border-radius: inherit;
          padding: 1px;
          background: linear-gradient(135deg, rgba(20, 244, 168, 0.4), transparent);
          -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          -webkit-mask-composite: xor;
          mask-composite: exclude;
        }

        .module-item {
          transition: all 0.2s ease-out;
        }

        .module-item.active {
          box-shadow: 0 0 0 2px rgba(20, 244, 168, 0.7);
        }

        ::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }

        ::-webkit-scrollbar-track {
          background: #05050d;
          border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #14f4a8, #0b6b4f);
          border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, #1fffb3, #14f4a8);
        }
      `}</style>

      <div className="max-w-[1280px] mx-auto security-wrapper rounded-[20px] p-5">
        <div className="rounded-[18px] p-5" style={{ background: '#0a0a14' }}>
          {/* Header */}
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-3">
              <div 
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{
                  background: 'radial-gradient(circle at 20% 0, #ffffff, #14f4a8 40%, #0b6b4f)',
                  boxShadow: '0 0 24px rgba(20, 244, 168, 0.8)'
                }}
              >
                <Shield className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="text-[0.9rem] tracking-[0.2em] uppercase font-bold text-white">
                  MODULE VAULT
                </div>
                <div className="text-[0.7rem] tracking-[0.16em] text-gray-400">
                  TAC Paradoxon Evolution Engine • 9×9 Consensus
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2 px-3 py-1 rounded-full" style={{
              background: 'rgba(20, 244, 168, 0.12)',
              border: '1px solid rgba(20, 244, 168, 0.7)'
            }}>
              <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: '#14f4a8' }} />
              <span className="text-xs font-semibold" style={{ color: '#14f4a8' }}>LIVE ORCHESTRATION</span>
            </div>
          </div>

          {/* Error Display */}
          {error && (
            <div className="mb-4 p-3 rounded-xl border border-red-500/50 bg-red-900/10 flex items-center gap-3">
              <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <div>
                <div className="text-sm font-bold text-red-400">Evolution Error</div>
                <div className="text-xs text-gray-300 mt-0.5">{error}</div>
                <div className="text-xs text-gray-500 mt-1">
                  Ensure backend is running: <code className="bg-black/40 px-1 py-0.5 rounded">node tac-evolution-engine.js</code> on port 8090
                </div>
              </div>
            </div>
          )}

          {/* Main Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Left: Module List */}
            <div className="lg:col-span-3">
              <div className="gradient-border rounded-2xl border p-4" style={{
                background: '#10101a',
                borderColor: '#26263a',
                height: 'calc(100vh - 250px)',
                minHeight: '500px'
              }}>
                <div className="flex items-center justify-between mb-3">
                  <div className="text-xs tracking-[0.08em] uppercase font-semibold text-gray-400">
                    Modules
                  </div>
                  <div className="px-2 py-1 rounded-full text-[9px] border" style={{
                    background: 'rgba(255, 255, 255, 0.02)',
                    borderColor: 'rgba(255, 255, 255, 0.08)',
                    color: '#9094b2'
                  }}>
                    9×9 OVERSIGHT
                  </div>
                </div>

                {/* Search */}
                <div className="relative mb-3">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search modules..."
                    className="w-full pl-9 pr-3 py-2 rounded-full text-xs border outline-none"
                    style={{
                      background: '#080812',
                      borderColor: '#222235',
                      color: '#f4f7ff'
                    }}
                  />
                </div>

                {/* Module List */}
                <div className="space-y-2 overflow-y-auto pr-2" style={{ maxHeight: 'calc(100% - 90px)' }}>
                  {filteredModules.map(module => (
                    <div
                      key={module.name}
                      onClick={() => setSelectedModule(module)}
                      className={`module-item p-3 rounded-xl border cursor-pointer ${
                        selectedModule?.name === module.name ? 'active' : ''
                      }`}
                      style={{
                        background: '#080814',
                        borderColor: selectedModule?.name === module.name ? 'rgba(20, 244, 168, 0.7)' : 'transparent'
                      }}
                    >
                      <div className="text-sm font-semibold text-white mb-1">
                        {module.name}
                      </div>
                      <div className="flex items-center justify-between text-[10px]">
                        <div className="flex items-center gap-2">
                          <div 
                            className="w-2 h-2 rounded-full"
                            style={{ 
                              background: getStatusColor(module.status),
                              boxShadow: module.status === 'live' ? '0 0 9px rgba(20, 244, 168, 0.8)' : 'none'
                            }}
                          />
                          <span className="text-gray-400">{module.type}</span>
                        </div>
                        <div className="px-2 py-0.5 rounded-full border text-[9px] uppercase tracking-wider" style={{
                          background: 'rgba(255, 255, 255, 0.02)',
                          borderColor: 'rgba(255, 255, 255, 0.05)',
                          color: '#9094b2'
                        }}>
                          {module.status}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Center: Current Version */}
            <div className="lg:col-span-5">
              <div className="rounded-2xl border p-4" style={{
                background: '#10101a',
                borderColor: '#26263a',
                height: 'calc(100vh - 250px)',
                minHeight: '500px',
                display: 'flex',
                flexDirection: 'column'
              }}>
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="text-xs tracking-[0.08em] uppercase font-semibold text-gray-400">
                      Current Version
                    </div>
                    <div className="text-[10px] text-gray-500 mt-0.5">
                      {selectedModule ? `${selectedModule.name} • live definition` : 'Select a module'}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1 rounded-full border" style={{
                    background: 'rgba(20, 244, 168, 0.12)',
                    borderColor: 'rgba(20, 244, 168, 0.7)'
                  }}>
                    <div className="w-2 h-2 rounded-full" style={{ background: '#14f4a8' }} />
                    <span className="text-[10px] font-semibold" style={{ color: '#14f4a8' }}>LIVE</span>
                  </div>
                </div>

                {/* Spec Display */}
                <div className="flex-1 rounded-xl border p-4 mb-3 overflow-auto relative" style={{
                  background: '#05050d',
                  borderColor: '#1c1c2c'
                }}>
                  <div className="absolute top-2 right-2 px-2 py-1 rounded-full text-[9px] uppercase tracking-wider border" style={{
                    background: '#101021',
                    color: '#7a7ed0',
                    borderColor: 'rgba(255, 255, 255, 0.08)'
                  }}>
                    LIVE SPEC
                  </div>
                  <pre className="text-[11px] text-gray-300 font-mono leading-relaxed whitespace-pre-wrap">
                    {selectedModule ? selectedModule.spec : '# Waiting for module selection...'}
                  </pre>
                </div>

                {/* Controls */}
                <div className="flex items-center justify-between gap-3 pt-3 border-t" style={{ borderColor: '#1c1c2c' }}>
                  <div className="text-[10px] text-gray-500">
                    This is the version currently wired into your TAC stack.
                  </div>
                  <button
                    onClick={runEvolution}
                    disabled={isEvolving || !selectedModule}
                    className="px-4 py-2 rounded-full text-[11px] font-medium uppercase tracking-wider flex items-center gap-2 transition-all disabled:opacity-40"
                    style={{
                      background: 'radial-gradient(circle at 20% 0, #ffffff, #14f4a8 40%, #06b97c 60%, #028c5b 100%)',
                      color: '#020207',
                      boxShadow: isEvolving ? 'none' : '0 8px 24px rgba(20, 244, 168, 0.5)'
                    }}
                  >
                    {isEvolving ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        RUNNING...
                      </>
                    ) : (
                      <>
                        <Target className="w-4 h-4" />
                        RUN PARADOX EVOLUTION
                      </>
                    )}
                  </button>
                </div>

                {/* Evolution Log */}
                <div className="mt-2 text-[10px] text-gray-500">
                  Evolution log: <strong className="text-[#14f4a8]">{evolutionLog}</strong>
                </div>
              </div>
            </div>

            {/* Right: Evolved Version */}
            <div className="lg:col-span-4">
              <div className="gradient-border rounded-2xl border p-4" style={{
                background: '#10101a',
                borderColor: '#26263a',
                height: 'calc(100vh - 250px)',
                minHeight: '500px',
                display: 'flex',
                flexDirection: 'column'
              }}>
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="text-xs tracking-[0.08em] uppercase font-semibold text-gray-400">
                      Evolved Version
                    </div>
                    <div className="text-[10px] text-gray-500 mt-0.5">
                      Generated via Harmony 9 × Distorted 9 × Hallucinator × Paradox Core
                    </div>
                  </div>
                  <div className="px-2 py-1 rounded-full text-[9px] border" style={{
                    background: 'rgba(255, 255, 255, 0.02)',
                    borderColor: 'rgba(255, 255, 255, 0.08)',
                    color: '#9094b2'
                  }}>
                    vNEXT CANDIDATE
                  </div>
                </div>

                {/* Evolved Spec Display */}
                <div className="flex-1 rounded-xl border p-4 mb-3 overflow-auto relative" style={{
                  background: '#05050d',
                  borderColor: '#1c1c2c'
                }}>
                  <div className="absolute top-2 right-2 px-2 py-1 rounded-full text-[9px] uppercase tracking-wider border" style={{
                    background: '#101021',
                    color: '#7a7ed0',
                    borderColor: 'rgba(255, 255, 255, 0.08)'
                  }}>
                    EVOLVED BLUEPRINT
                  </div>
                  <pre className="text-[11px] text-gray-300 font-mono leading-relaxed whitespace-pre-wrap">
                    {selectedModule && evolvedVersions[selectedModule.name]
                      ? evolvedVersions[selectedModule.name].blueprintText
                      : '# No evolution yet.\n# Run "Paradox Evolution" on a module to see the upgraded version here.\n\n# Backend: http://localhost:8090/api/evolution/evolve-module\n# Make sure tac-evolution-engine.js is running!'}
                  </pre>
                </div>

                {/* Controls */}
                <div className="pt-3 border-t" style={{ borderColor: '#1c1c2c' }}>
                  <div className="text-[10px] text-gray-500 mb-2">
                    When you're ready, you can mark this as the active definition in your system.
                  </div>
                  <div className="flex flex-wrap gap-2 mb-3">
                    <span className="px-2 py-1 rounded-full text-[9px] uppercase tracking-wider border" style={{
                      borderColor: 'rgba(20, 244, 168, 0.7)',
                      color: '#14f4a8',
                      background: 'rgba(20, 244, 168, 0.08)'
                    }}>
                      9×9 CONSENSUS
                    </span>
                    <span className="px-2 py-1 rounded-full text-[9px] uppercase tracking-wider border" style={{
                      background: 'rgba(255, 255, 255, 0.02)',
                      borderColor: 'rgba(255, 255, 255, 0.08)',
                      color: '#9094b2'
                    }}>
                      PARADOX SEAL
                    </span>
                    <span className="px-2 py-1 rounded-full text-[9px] uppercase tracking-wider border" style={{
                      borderColor: 'rgba(255, 84, 132, 0.8)',
                      color: '#ff4b81',
                      background: 'rgba(255, 84, 132, 0.08)'
                    }}>
                      MANUAL APPROVAL
                    </span>
                  </div>
                  <button
                    onClick={activateEvolved}
                    disabled={!selectedModule || !evolvedVersions[selectedModule?.name]}
                    className="w-full px-4 py-2 rounded-full text-[11px] font-medium uppercase tracking-wider flex items-center justify-center gap-2 transition-all disabled:opacity-40 hover:bg-white/5"
                    style={{
                      background: 'rgba(255, 255, 255, 0.03)',
                      color: '#9094b2',
                      border: '1px solid rgba(255, 255, 255, 0.08)'
                    }}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    SET AS ACTIVE
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}