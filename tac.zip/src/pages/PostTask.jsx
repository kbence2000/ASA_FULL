import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Plus, X, Zap, AlertCircle, TrendingUp } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";

export default function PostTask() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    type: "bugfix",
    budget_min: 0,
    budget_max: 0,
    currency: "EUR",
    deadline: "",
    repo_link: "",
    file_link: "",
    is_urgent: false,
    urgent_deadline_hours: 24,
    urgent_starting_bid: 0,
    urgent_max_bid: 0
  });

  const [techStack, setTechStack] = useState([]);
  const [newTech, setNewTech] = useState("");

  const createTaskMutation = useMutation({
    mutationFn: (taskData) => base44.entities.Task.create(taskData),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      toast.success("Feladat sikeresen létrehozva!");
      navigate(createPageUrl("TaskDetail") + `?id=${data.id}`);
    },
    onError: () => {
      toast.error("Hiba történt a feladat létrehozása során!");
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!user) {
      toast.error("Jelentkezz be a feladat feladásához!");
      return;
    }

    if (!formData.title || !formData.description) {
      toast.error("Kérlek töltsd ki az összes kötelező mezőt!");
      return;
    }

    // Validate urgent task settings
    if (formData.is_urgent) {
      if (!formData.urgent_starting_bid || !formData.urgent_max_bid) {
        toast.error("Add meg a kezdő és maximum díjat a sürgős feladathoz!");
        return;
      }
      if (formData.urgent_starting_bid >= formData.urgent_max_bid) {
        toast.error("A maximum díjnak nagyobbnak kell lennie, mint a kezdő díj!");
        return;
      }
    }

    const taskData = {
      ...formData,
      company_id: user.email,
      tech_stack: techStack,
      status: "open"
    };

    // Calculate urgent expiration if urgent task
    if (formData.is_urgent) {
      const expiresAt = new Date();
      expiresAt.setHours(expiresAt.getHours() + formData.urgent_deadline_hours);
      taskData.urgent_expires_at = expiresAt.toISOString();
    }

    createTaskMutation.mutate(taskData);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const addTech = () => {
    if (newTech.trim() && !techStack.includes(newTech.trim())) {
      setTechStack([...techStack, newTech.trim()]);
      setNewTech("");
    }
  };

  const removeTech = (tech) => {
    setTechStack(techStack.filter(t => t !== tech));
  };

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link to={createPageUrl("ExpertMarketplace")}>
          <Button variant="ghost" className="mb-6 text-gray-400 hover:text-white hover:bg-[#1a1f2e]">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Vissza
          </Button>
        </Link>

        <Card className="border border-[#1a1f2e] bg-[#0f1419] p-8">
          <h1 className="text-3xl font-black text-white mb-2">Feladat Feladása</h1>
          <p className="text-gray-400 mb-8">Találj szakértőt a projekted megvalósításához</p>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Urgent Task Toggle */}
            <div className="p-6 bg-gradient-to-r from-red-950/30 to-orange-950/30 rounded-lg border-2 border-red-500/30">
              <div className="flex items-start gap-4">
                <Checkbox
                  id="is_urgent"
                  checked={formData.is_urgent}
                  onCheckedChange={(checked) => handleChange('is_urgent', checked)}
                  className="mt-1"
                />
                <div className="flex-1">
                  <Label htmlFor="is_urgent" className="text-white font-bold text-lg cursor-pointer flex items-center gap-2">
                    <Zap className="w-5 h-5 text-red-500" />
                    Sürgős Feladat (Dinamikus Ár)
                  </Label>
                  <p className="text-gray-400 text-sm mt-2">
                    Aktiváld ezt, ha azonnali segítségre van szükséged! A díj automatikusan növekszik ahogy közeledik a határidő, így gyorsabb választ kaphatsz a szakértőktől.
                  </p>
                  {formData.is_urgent && (
                    <div className="mt-4 p-4 bg-[#0f1419] rounded-lg border border-[#1a1f2e] space-y-4">
                      <div className="flex items-center gap-2 text-yellow-400 text-sm">
                        <AlertCircle className="w-4 h-4" />
                        A díj lineárisan nő az idővel: kezdő díjtól a maximum díjig
                      </div>
                      
                      <div className="grid md:grid-cols-3 gap-4">
                        <div>
                          <Label className="text-white mb-2 block text-sm">Időkeret (órák)</Label>
                          <Select 
                            value={formData.urgent_deadline_hours.toString()} 
                            onValueChange={(value) => handleChange('urgent_deadline_hours', parseInt(value))}
                          >
                            <SelectTrigger className="bg-[#141923] border-[#1a1f2e] text-white">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="12">12 óra</SelectItem>
                              <SelectItem value="24">24 óra</SelectItem>
                              <SelectItem value="48">48 óra</SelectItem>
                              <SelectItem value="72">72 óra</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label className="text-white mb-2 block text-sm">Kezdő Díj ({formData.currency})</Label>
                          <Input
                            type="number"
                            min="0"
                            value={formData.urgent_starting_bid}
                            onChange={(e) => handleChange('urgent_starting_bid', Number(e.target.value))}
                            className="bg-[#141923] border-[#1a1f2e] text-white"
                            placeholder="500"
                          />
                        </div>

                        <div>
                          <Label className="text-white mb-2 block text-sm">Maximum Díj ({formData.currency})</Label>
                          <Input
                            type="number"
                            min="0"
                            value={formData.urgent_max_bid}
                            onChange={(e) => handleChange('urgent_max_bid', Number(e.target.value))}
                            className="bg-[#141923] border-[#1a1f2e] text-white"
                            placeholder="2000"
                          />
                        </div>
                      </div>

                      {formData.urgent_starting_bid > 0 && formData.urgent_max_bid > 0 && (
                        <div className="flex items-center gap-2 p-3 bg-green-600/10 rounded border border-green-600/30">
                          <TrendingUp className="w-4 h-4 text-green-400" />
                          <span className="text-green-400 text-sm font-semibold">
                            A díj {formData.urgent_starting_bid} {formData.currency}-ről 
                            {' '}{formData.urgent_max_bid} {formData.currency}-re fog nőni {formData.urgent_deadline_hours} óra alatt
                          </span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Basic Info */}
            <div className="space-y-6 pb-6 border-b border-[#1a1f2e]">
              <h3 className="text-lg font-bold text-white">Alapinformációk</h3>
              
              <div>
                <Label className="text-white mb-2 block">Feladat Címe *</Label>
                <Input
                  type="text"
                  value={formData.title}
                  onChange={(e) => handleChange('title', e.target.value)}
                  className="bg-[#141923] border-[#1a1f2e] text-white"
                  placeholder="pl. React komponens bug javítása"
                  required
                />
              </div>

              <div>
                <Label className="text-white mb-2 block">Részletes Leírás *</Label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => handleChange('description', e.target.value)}
                  className="bg-[#141923] border-[#1a1f2e] text-white min-h-[150px]"
                  placeholder="Írd le részletesen a feladatot, a problémát és az elvárt megoldást..."
                  required
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label className="text-white mb-2 block">Feladat Típusa *</Label>
                  <Select value={formData.type} onValueChange={(value) => handleChange('type', value)}>
                    <SelectTrigger className="bg-[#141923] border-[#1a1f2e] text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bugfix">Bug Javítás</SelectItem>
                      <SelectItem value="feature">Új Funkció</SelectItem>
                      <SelectItem value="refactor">Refaktorálás</SelectItem>
                      <SelectItem value="innovation">Innováció</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-white mb-2 block">Határidő</Label>
                  <Input
                    type="date"
                    value={formData.deadline}
                    onChange={(e) => handleChange('deadline', e.target.value)}
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                  />
                </div>
              </div>
            </div>

            {/* Budget (only if not urgent) */}
            {!formData.is_urgent && (
              <div className="space-y-6 pb-6 border-b border-[#1a1f2e]">
                <h3 className="text-lg font-bold text-white">Költségvetés</h3>
                
                <div className="grid md:grid-cols-3 gap-6">
                  <div>
                    <Label className="text-white mb-2 block">Minimum</Label>
                    <Input
                      type="number"
                      min="0"
                      value={formData.budget_min}
                      onChange={(e) => handleChange('budget_min', Number(e.target.value))}
                      className="bg-[#141923] border-[#1a1f2e] text-white"
                      placeholder="500"
                    />
                  </div>

                  <div>
                    <Label className="text-white mb-2 block">Maximum</Label>
                    <Input
                      type="number"
                      min="0"
                      value={formData.budget_max}
                      onChange={(e) => handleChange('budget_max', Number(e.target.value))}
                      className="bg-[#141923] border-[#1a1f2e] text-white"
                      placeholder="2000"
                    />
                  </div>

                  <div>
                    <Label className="text-white mb-2 block">Pénznem</Label>
                    <Select value={formData.currency} onValueChange={(value) => handleChange('currency', value)}>
                      <SelectTrigger className="bg-[#141923] border-[#1a1f2e] text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="EUR">EUR</SelectItem>
                        <SelectItem value="USD">USD</SelectItem>
                        <SelectItem value="HUF">HUF</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}

            {/* Tech Stack */}
            <div className="space-y-6 pb-6 border-b border-[#1a1f2e]">
              <h3 className="text-lg font-bold text-white">Technológiai Stack</h3>
              
              <div>
                <Label className="text-white mb-2 block">Szükséges Technológiák</Label>
                <div className="flex gap-2 mb-3">
                  <Input
                    type="text"
                    value={newTech}
                    onChange={(e) => setNewTech(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTech())}
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                    placeholder="pl. React, Node.js, PostgreSQL"
                  />
                  <Button type="button" onClick={addTech} className="bg-[#00E599] text-black hover:bg-[#00E599]/90">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {techStack.map(tech => (
                    <div key={tech} className="flex items-center gap-2 px-3 py-1 bg-[#141923] rounded-lg border border-[#1a1f2e]">
                      <span className="text-white text-sm">{tech}</span>
                      <button type="button" onClick={() => removeTech(tech)} className="text-gray-400 hover:text-white">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Links */}
            <div className="space-y-6">
              <h3 className="text-lg font-bold text-white">További Információk</h3>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label className="text-white mb-2 block">Repository Link</Label>
                  <Input
                    type="url"
                    value={formData.repo_link}
                    onChange={(e) => handleChange('repo_link', e.target.value)}
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                    placeholder="https://github.com/..."
                  />
                </div>

                <div>
                  <Label className="text-white mb-2 block">Dokumentáció / Fájl Link</Label>
                  <Input
                    type="url"
                    value={formData.file_link}
                    onChange={(e) => handleChange('file_link', e.target.value)}
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                    placeholder="https://..."
                  />
                </div>
              </div>
            </div>

            {/* Submit */}
            <div className="flex gap-4 pt-6 border-t border-[#1a1f2e]">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate(createPageUrl("ExpertMarketplace"))}
                className="flex-1 border-[#1a1f2e] text-white hover:bg-[#1a1f2e]"
              >
                Mégse
              </Button>
              <Button
                type="submit"
                disabled={createTaskMutation.isPending}
                className={`flex-1 font-bold ${
                  formData.is_urgent
                    ? 'bg-gradient-to-r from-red-600 to-orange-600 text-white hover:from-red-700 hover:to-orange-700'
                    : 'bg-gradient-to-r from-[#00E599] to-[#00B8D4] text-black hover:opacity-90'
                }`}
              >
                {createTaskMutation.isPending ? 'Létrehozás...' : formData.is_urgent ? (
                  <>
                    <Zap className="w-5 h-5 mr-2" />
                    Sürgős Feladat Feladása
                  </>
                ) : 'Feladat Feladása'}
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
}