import React, { useState } from 'react';
import { Shield, Activity, Zap, AlertTriangle, CheckCircle2, TrendingDown } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function AntiRiftEngine() {
  const [riftReport, setRiftReport] = useState('{\n  "source": "system_monitor",\n  "layers": [\n    {\n      "name": "logic",\n      "baseValue": 0.85,\n      "riftIntensity": 0.42,\n      "drift": 0.12\n    },\n    {\n      "name": "creative",\n      "baseValue": 0.72,\n      "riftIntensity": 0.58,\n      "drift": -0.08\n    },\n    {\n      "name": "resonance",\n      "baseValue": 0.91,\n      "riftIntensity": 0.31,\n      "drift": 0.05\n    }\n  ]\n}');
  const [action, setAction] = useState('harmonize');
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const handleProcess = async () => {
    setIsProcessing(true);
    setError(null);
    setResult(null);

    try {
      const parsedReport = JSON.parse(riftReport);
      const response = await base44.functions.invoke('antiRiftEngine', {
        action,
        riftReport: parsedReport
      });

      setResult(response.data);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const loadExample = (type) => {
    if (type === 'basic') {
      setRiftReport('{\n  "source": "system_monitor",\n  "layers": [\n    {\n      "name": "logic",\n      "baseValue": 0.85,\n      "riftIntensity": 0.42,\n      "drift": 0.12\n    },\n    {\n      "name": "creative",\n      "baseValue": 0.72,\n      "riftIntensity": 0.58,\n      "drift": -0.08\n    },\n    {\n      "name": "resonance",\n      "baseValue": 0.91,\n      "riftIntensity": 0.31,\n      "drift": 0.05\n    }\n  ]\n}');
    } else if (type === 'riftcore') {
      setRiftReport('{\n  "source": "RiftCore_v1",\n  "layers": [\n    {\n      "name": "logic",\n      "baseValue": 0.8,\n      "riftIntensity": 0.6,\n      "drift": 0.2\n    },\n    {\n      "name": "creative",\n      "baseValue": 1.2,\n      "riftIntensity": 0.75,\n      "drift": 0.4\n    },\n    {\n      "name": "resonance",\n      "baseValue": 0.5,\n      "riftIntensity": 0.3,\n      "drift": 0.1\n    },\n    {\n      "name": "silence",\n      "baseValue": 0.1,\n      "riftIntensity": 0.2,\n      "drift": -0.05\n    }\n  ]\n}');
    } else if (type === 'critical') {
      setRiftReport('{\n  "source": "critical_alert",\n  "layers": [\n    {\n      "name": "logic",\n      "baseValue": 1.5,\n      "riftIntensity": 0.85,\n      "drift": 0.6\n    },\n    {\n      "name": "creative",\n      "baseValue": 1.8,\n      "riftIntensity": 0.92,\n      "drift": 0.8\n    }\n  ]\n}');
    }
  };

  const getRiskColor = (level) => {
    if (level === 'low') return { bg: '#4eff8b', text: '#4eff8b', glow: 'rgba(78, 255, 139, 0.4)' };
    if (level === 'medium') return { bg: '#ffcc4b', text: '#ffcc4b', glow: 'rgba(255, 204, 75, 0.4)' };
    if (level === 'high') return { bg: '#ff4b81', text: '#ff4b81', glow: 'rgba(255, 75, 129, 0.4)' };
    return { bg: '#9094b2', text: '#9094b2', glow: 'rgba(144, 148, 178, 0.4)' };
  };

  return (
    <div className="min-h-screen p-4" style={{
      background: 'radial-gradient(circle at top, #0a0a14 0, #030306 55%)'
    }}>
      <style>{`
        .rift-panel {
          background: #0a0a12;
          border: 1px solid #1a1a26;
        }

        .result-panel {
          background: #05050d;
          border: 1px solid #1a1a26;
        }

        .layer-card {
          background: #060612;
          border: 1px solid #1a1a26;
          transition: all 0.2s ease-out;
        }

        .layer-card:hover {
          border-color: rgba(78, 255, 139, 0.3);
        }

        .intensity-bar {
          height: 6px;
          border-radius: 3px;
          overflow: hidden;
          background: #1a1a26;
        }

        .intensity-fill {
          height: 100%;
          transition: width 0.5s ease-out;
        }
      `}</style>

      <div className="max-w-[1400px] mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: 'radial-gradient(circle at 20% 0, #ffffff, #4eff8b 40%, #0b6b4f)',
                boxShadow: '0 0 30px rgba(78, 255, 139, 0.6)'
              }}
            >
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="text-xl font-bold text-white tracking-wide">
                ANTI-RIFT ENGINE
              </div>
              <div className="text-xs text-gray-400 tracking-wider">
                Stability & Harmony Layer
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full" style={{
            background: 'rgba(78, 255, 139, 0.12)',
            border: '1px solid rgba(78, 255, 139, 0.6)'
          }}>
            <div className="w-2 h-2 rounded-full pulse-dot" style={{ background: '#4eff8b' }} />
            <span className="text-xs font-semibold" style={{ color: '#4eff8b' }}>
              ACTIVE
            </span>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-4 p-3 rounded-xl border border-red-500/50 bg-red-900/10 flex items-center gap-3">
            <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Error</div>
              <div className="text-xs text-gray-300 mt-0.5">{error}</div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left: Input & Controls */}
          <div className="lg:col-span-5 space-y-4">
            <div className="rift-panel rounded-2xl p-4">
              <div className="mb-3">
                <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                  Rift Report Input
                </div>
                <div className="text-[10px] text-gray-500">
                  JSON format with layers data
                </div>
              </div>

              <textarea
                value={riftReport}
                onChange={(e) => setRiftReport(e.target.value)}
                className="w-full h-[250px] rounded-xl p-4 text-xs font-mono resize-none"
                style={{
                  background: '#05050d',
                  border: '1px solid #1a1a26',
                  color: '#a3a7cf'
                }}
                placeholder='{\n  "source": "...",\n  "layers": [...]\n}'
              />

              <div className="mt-3 grid grid-cols-3 gap-2">
                <button
                  onClick={() => loadExample('basic')}
                  className="px-2 py-2 rounded-xl text-[9px] font-semibold uppercase tracking-wider transition-all hover:bg-white/5"
                  style={{
                    background: 'rgba(255, 255, 255, 0.02)',
                    color: '#9094b2',
                    border: '1px solid rgba(255, 255, 255, 0.08)'
                  }}
                >
                  Basic
                </button>
                <button
                  onClick={() => loadExample('riftcore')}
                  className="px-2 py-2 rounded-xl text-[9px] font-semibold uppercase tracking-wider transition-all hover:bg-white/5"
                  style={{
                    background: 'rgba(255, 255, 255, 0.02)',
                    color: '#9094b2',
                    border: '1px solid rgba(255, 255, 255, 0.08)'
                  }}
                >
                  RiftCore
                </button>
                <button
                  onClick={() => loadExample('critical')}
                  className="px-2 py-2 rounded-xl text-[9px] font-semibold uppercase tracking-wider transition-all hover:bg-white/5"
                  style={{
                    background: 'rgba(255, 255, 255, 0.02)',
                    color: '#9094b2',
                    border: '1px solid rgba(255, 255, 255, 0.08)'
                  }}
                >
                  Critical
                </button>
              </div>
            </div>

            <div className="rift-panel rounded-2xl p-4">
              <div className="mb-3">
                <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                  Action Mode
                </div>
              </div>

              <div className="space-y-2">
                {[
                  { id: 'analyze', label: 'Analyze Rifts', desc: 'Risk assessment only' },
                  { id: 'stabilize', label: 'Suggest Stabilization', desc: 'Action recommendations' },
                  { id: 'harmonize', label: 'Full Harmonization', desc: 'Smoothed metrics output' }
                ].map(mode => (
                  <button
                    key={mode.id}
                    onClick={() => setAction(mode.id)}
                    className="w-full text-left px-4 py-3 rounded-xl transition-all"
                    style={{
                      background: action === mode.id ? 'rgba(78, 255, 139, 0.1)' : '#060612',
                      border: `1px solid ${action === mode.id ? 'rgba(78, 255, 139, 0.4)' : '#1a1a26'}`,
                      color: action === mode.id ? '#4eff8b' : '#9094b2'
                    }}
                  >
                    <div className="font-semibold text-sm">{mode.label}</div>
                    <div className="text-[10px] mt-0.5 opacity-70">{mode.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleProcess}
              disabled={isProcessing}
              className="w-full px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all disabled:opacity-40"
              style={{
                background: 'radial-gradient(circle at 20% 0, #ffffff, #4eff8b 40%, #0b6b4f 70%)',
                color: '#020206',
                boxShadow: isProcessing ? 'none' : '0 8px 24px rgba(78, 255, 139, 0.6)'
              }}
            >
              {isProcessing ? (
                <>
                  <Activity className="w-4 h-4 animate-spin" />
                  PROCESSING...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  RUN ENGINE
                </>
              )}
            </button>
          </div>

          {/* Right: Results */}
          <div className="lg:col-span-7 space-y-4">
            {!result ? (
              <div className="rift-panel rounded-2xl p-6 h-full flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <Shield className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <div className="text-sm font-semibold">No Results Yet</div>
                  <div className="text-xs mt-1">Process a rift report to see output</div>
                </div>
              </div>
            ) : (
              <>
                {/* Analysis Summary */}
                {result.analysis && (
                  <div className="rift-panel rounded-2xl p-4">
                    <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
                      Risk Analysis
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="result-panel rounded-xl p-3">
                        <div className="text-[10px] text-gray-500 mb-1">Avg Intensity</div>
                        <div className="text-lg font-bold text-white">{result.analysis.avgIntensity}</div>
                      </div>
                      <div className="result-panel rounded-xl p-3">
                        <div className="text-[10px] text-gray-500 mb-1">Max Intensity</div>
                        <div className="text-lg font-bold text-white">{result.analysis.maxIntensity}</div>
                      </div>
                    </div>

                    <div 
                      className="px-6 py-2 rounded-full text-center text-sm font-bold uppercase tracking-wider"
                      style={{
                        background: `${getRiskColor(result.analysis.riskLevel).glow}`,
                        color: getRiskColor(result.analysis.riskLevel).text,
                        border: `2px solid ${getRiskColor(result.analysis.riskLevel).text}`
                      }}
                    >
                      {result.analysis.riskLevel} RISK
                    </div>
                  </div>
                )}

                {/* Stabilization Actions */}
                {result.actions && (
                  <div className="rift-panel rounded-2xl p-4">
                    <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
                      Recommended Actions
                    </div>

                    <div className="space-y-2">
                      {result.actions.map((action, idx) => (
                        <div key={idx} className="layer-card rounded-xl p-3 flex items-center gap-3">
                          <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0" />
                          <span className="text-xs text-gray-300 font-mono">{action}</span>
                        </div>
                      ))}
                    </div>

                    {result.stabilizationStrength !== undefined && (
                      <div className="mt-4 result-panel rounded-xl p-3">
                        <div className="flex items-center justify-between mb-2">
                          <div className="text-[10px] text-gray-500">Stabilization Strength</div>
                          <span className="text-sm font-bold text-cyan-400">{result.stabilizationStrength}</span>
                        </div>
                        <div className="intensity-bar">
                          <div 
                            className="intensity-fill bg-gradient-to-r from-cyan-500 to-green-500"
                            style={{ width: `${result.stabilizationStrength * 100}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Smoothed Layers */}
                {result.smoothedLayers && (
                  <div className="rift-panel rounded-2xl p-4">
                    <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
                      Harmonized Layers
                    </div>

                    <div className="space-y-3">
                      {result.smoothedLayers.map((layer, idx) => (
                        <div key={idx} className="layer-card rounded-xl p-4">
                          <div className="flex items-center justify-between mb-3">
                            <span className="text-sm font-bold text-white">{layer.name}</span>
                            <div className="flex items-center gap-2">
                              <TrendingDown className="w-3 h-3 text-green-400" />
                              <span className="text-[10px] text-green-400 font-semibold">
                                -{((layer.originalRift - layer.smoothedRift) * 100).toFixed(1)}%
                              </span>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-3 text-[10px]">
                            <div>
                              <div className="text-gray-500 mb-1">Original Rift</div>
                              <div className="font-mono text-red-400">{layer.originalRift}</div>
                            </div>
                            <div>
                              <div className="text-gray-500 mb-1">Smoothed Rift</div>
                              <div className="font-mono text-green-400">{layer.smoothedRift}</div>
                            </div>
                            <div>
                              <div className="text-gray-500 mb-1">Original Base</div>
                              <div className="font-mono text-gray-300">{layer.originalBase}</div>
                            </div>
                            <div>
                              <div className="text-gray-500 mb-1">Smoothed Base</div>
                              <div className="font-mono text-cyan-400">{layer.smoothedBase}</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}