import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import RankBadge from "../components/RankBadge";
import ScoreBreakdown from "../components/ScoreBreakdown";
import FeedbackCard from "../components/FeedbackCard";
import FeedbackForm from "../components/FeedbackForm";
import CodeAnalysisPanel from "../components/CodeAnalysisPanel";
import { Github, ExternalLink, MessageSquare, Award, Calendar, TrendingUp, Code2 } from "lucide-react";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";

const BACKEND_URL = import.meta.env.VITE_MDC_BACKEND_URL || "http://localhost:3000";

export default function DemigodProfile() {
  const urlParams = new URLSearchParams(window.location.search);
  const userId = urlParams.get("userId");
  const [activeTab, setActiveTab] = useState("overview");

  const queryClient = useQueryClient();

  // Fetch current user
  const { data: currentUser } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
    initialData: null,
  });

  // Fetch profile
  const { data: profile, isLoading } = useQuery({
    queryKey: ["demigodProfile", userId],
    queryFn: async () => {
      const res = await fetch(`${BACKEND_URL}/api/profile/${userId}`);
      if (!res.ok) throw new Error("Profile not found");
      return res.json();
    },
    enabled: !!userId,
  });

  // Fetch feedback
  const { data: feedbackData } = useQuery({
    queryKey: ["feedback", userId],
    queryFn: async () => {
      const res = await fetch(`${BACKEND_URL}/api/feedback/${userId}`);
      if (!res.ok) throw new Error("Failed to fetch feedback");
      return res.json();
    },
    enabled: !!userId,
  });

  // Submit feedback mutation
  const feedbackMutation = useMutation({
    mutationFn: async (data) => {
      const res = await fetch(`${BACKEND_URL}/api/feedback`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || "Failed to submit feedback");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["feedback", userId] });
      queryClient.invalidateQueries({ queryKey: ["demigodProfile", userId] });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0A0E14] flex items-center justify-center">
        <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-purple-600 border-t-transparent"></div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-[#0A0E14] flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Profile not found</h2>
          <Button onClick={() => window.history.back()}>Go Back</Button>
        </div>
      </div>
    );
  }

  const feedback = feedbackData?.feedback || [];
  const feedbackStats = feedbackData?.feedbackStats || {};
  const isOwnProfile = currentUser?.email === profile.userId;
  const isAdmin = currentUser?.role === 'admin';

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Card */}
        <Card className="border-[#1a1f2e] bg-[#0f1419] p-8 mb-8">
          <div className="flex flex-col lg:flex-row gap-8 items-start">
            {/* Left: Rank Badge */}
            <div className="flex-shrink-0">
              <RankBadge 
                rank={profile.mdcTier.id} 
                size="xl" 
                showName 
                showScore
                score={profile.scores.totalScore}
              />
            </div>

            {/* Middle: User Info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-3 mb-4">
                <h1 className="text-3xl font-black text-white">
                  {profile.github?.username || profile.reddit?.username || profile.userId}
                </h1>
                <Badge className="bg-purple-600/20 text-purple-300 border border-purple-600/30">
                  {profile.mdcTier.name}
                </Badge>
              </div>

              <div className="flex flex-wrap gap-4 text-sm text-gray-400 mb-6">
                {profile.github && (
                  <a 
                    href={profile.github.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 hover:text-white transition-colors"
                  >
                    <Github className="w-4 h-4" />
                    {profile.github.username}
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
                
                {profile.createdAt && (
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Joined {formatDistanceToNow(new Date(profile.createdAt), { addSuffix: true })}
                  </div>
                )}
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {profile.github && (
                  <>
                    <div className="text-center p-3 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                      <div className="text-2xl font-bold text-white">{profile.github.publicRepos}</div>
                      <div className="text-xs text-gray-500">Repos</div>
                    </div>
                    <div className="text-center p-3 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                      <div className="text-2xl font-bold text-white">{profile.github.followers}</div>
                      <div className="text-xs text-gray-500">Followers</div>
                    </div>
                  </>
                )}
                {profile.reddit && (
                  <div className="text-center p-3 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                    <div className="text-2xl font-bold text-white">{profile.reddit.karma}</div>
                    <div className="text-xs text-gray-500">Karma</div>
                  </div>
                )}
                <div className="text-center p-3 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                  <div className="text-2xl font-bold text-white">{feedbackStats.count || 0}</div>
                  <div className="text-xs text-gray-500">Feedback</div>
                </div>
              </div>
            </div>

            {/* Right: Actions */}
            <div className="flex flex-col gap-3">
              <Button className="bg-gradient-to-r from-[#00E599] to-[#00B8D4] text-black font-bold hover:opacity-90">
                <MessageSquare className="w-4 h-4 mr-2" />
                Contact
              </Button>
              <Button variant="outline" className="border-[#1a1f2e] text-white hover:bg-[#1a1f2e]">
                <Award className="w-4 h-4 mr-2" />
                View Portfolio
              </Button>
            </div>
          </div>
        </Card>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-[#0f1419] border border-[#1a1f2e] mb-6">
            <TabsTrigger value="overview" className="data-[state=active]:bg-[#1a1f2e]">
              Overview
            </TabsTrigger>
            <TabsTrigger value="feedback" className="data-[state=active]:bg-[#1a1f2e]">
              Feedback ({feedback.length})
            </TabsTrigger>
            {(isOwnProfile || isAdmin) && (
              <TabsTrigger value="tools" className="data-[state=active]:bg-[#1a1f2e]">
                Dev Tools
              </TabsTrigger>
            )}
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <ScoreBreakdown scores={profile.scores} />

            {/* GitHub Stats */}
            {profile.github && (
              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                  <Github className="w-5 h-5" />
                  GitHub Activity
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-400">Hard Skill Score</span>
                    <span className="text-lg font-bold text-purple-400">{profile.github.metrics.hardSkill}/100</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-400">Consistency</span>
                    <span className="text-lg font-bold text-cyan-400">{profile.github.metrics.consistency}/100</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-400">Impact</span>
                    <span className="text-lg font-bold text-amber-400">{profile.github.metrics.impact}/100</span>
                  </div>
                </div>
              </Card>
            )}

            {/* Reddit Stats */}
            {profile.reddit && (
              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Community Engagement
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-400">Community Score</span>
                    <span className="text-lg font-bold text-green-400">{profile.reddit.metrics.community}/100</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-400">Positivity</span>
                    <span className="text-lg font-bold text-pink-400">{profile.reddit.metrics.positivity}/100</span>
                  </div>
                </div>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="feedback" className="space-y-6">
            {/* Feedback Form */}
            {currentUser && !isOwnProfile && (
              <FeedbackForm
                currentUserRank="R4"
                currentUserId={currentUser.email}
                targetUserId={userId}
                targetUserName={profile.github?.username || profile.userId}
                onSubmit={(data) => feedbackMutation.mutateAsync(data)}
              />
            )}

            {/* Feedback Stats */}
            {feedbackStats.count > 0 && (
              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                <h3 className="text-lg font-bold text-white mb-4">Feedback Statistics</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-400">{feedbackStats.count}</div>
                    <div className="text-xs text-gray-500">Total Feedback</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-cyan-400">{feedbackStats.avgWeight?.toFixed(1) || 0}</div>
                    <div className="text-xs text-gray-500">Avg Weight</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-pink-400">{feedbackStats.peerFeedbackScore || 0}</div>
                    <div className="text-xs text-gray-500">Peer Score</div>
                  </div>
                </div>
              </Card>
            )}

            {/* Feedback List */}
            <div className="space-y-4">
              {feedback.length === 0 ? (
                <Card className="border-[#1a1f2e] bg-[#0f1419] p-8 text-center">
                  <MessageSquare className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">No feedback yet. Be the first to leave feedback!</p>
                </Card>
              ) : (
                feedback.map((fb) => (
                  <FeedbackCard key={fb.id} feedback={fb} />
                ))
              )}
            </div>
          </TabsContent>

          {(isOwnProfile || isAdmin) && (
            <TabsContent value="tools" className="space-y-6">
              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Code2 className="w-6 h-6 text-purple-400" />
                  <div>
                    <h3 className="text-xl font-bold text-white">Code Analysis</h3>
                    <p className="text-sm text-gray-400">
                      {isAdmin ? "Admin tool: Analyze any repository" : "Re-analyze your code to update AI quality score"}
                    </p>
                  </div>
                </div>

                <CodeAnalysisPanel
                  userId={userId}
                  initialRepoUrl={profile.github?.url || ""}
                  onAnalysisComplete={(result) => {
                    if (result.status === "success") {
                      queryClient.invalidateQueries({ queryKey: ["demigodProfile", userId] });
                      toast.success("Analysis complete! Profile will be updated shortly.");
                    }
                  }}
                />
              </Card>
            </TabsContent>
          )}
        </Tabs>
      </div>
    </div>
  );
}