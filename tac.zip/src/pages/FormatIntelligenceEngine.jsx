import React, { useState } from 'react';
import { Hash, Zap, Activity, CheckCircle2, AlertTriangle, Percent } from 'lucide-react';

export default function FormatIntelligenceEngine() {
  const [inputValue, setInputValue] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('http://localhost:3000/format/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input: inputValue })
      });

      if (!response.ok) throw new Error('Analysis failed');
      
      const data = await response.json();
      setResult(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const loadExample = (type) => {
    if (type === 'integer') {
      setInputValue('42');
    } else if (type === 'negative_int') {
      setInputValue('-128');
    } else if (type === 'float') {
      setInputValue('3.14159');
    } else if (type === 'negative_float') {
      setInputValue('-0.5625');
    }
  };

  const getFormatColor = (format) => {
    if (format === '%d') return { bg: '#4eff8b', text: '#4eff8b', glow: 'rgba(78, 255, 139, 0.4)' };
    if (format === '%f') return { bg: '#24e4ff', text: '#24e4ff', glow: 'rgba(36, 228, 255, 0.4)' };
    return { bg: '#9094b2', text: '#9094b2', glow: 'rgba(144, 148, 178, 0.4)' };
  };

  return (
    <div className="min-h-screen p-4" style={{
      background: 'radial-gradient(circle at top, #0a0a14 0, #030306 55%)'
    }}>
      <style>{`
        .format-panel {
          background: #0a0a12;
          border: 1px solid #1a1a26;
        }

        .result-panel {
          background: #05050d;
          border: 1px solid #1a1a26;
        }

        .detection-card {
          background: #060612;
          border: 1px solid #1a1a26;
        }
      `}</style>

      <div className="max-w-[1400px] mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: 'radial-gradient(circle at 20% 0, #ffffff, #4eff8b 40%, #0b6b4f)',
                boxShadow: '0 0 30px rgba(78, 255, 139, 0.6)'
              }}
            >
              <Hash className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="text-xl font-bold text-white tracking-wide">
                FORMAT INTELLIGENCE ENGINE
              </div>
              <div className="text-xs text-gray-400 tracking-wider">
                Automatic Format Detection • %d / %f Analyzer
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full" style={{
            background: 'rgba(78, 255, 139, 0.12)',
            border: '1px solid rgba(78, 255, 139, 0.6)'
          }}>
            <div className="w-2 h-2 rounded-full pulse-dot" style={{ background: '#4eff8b' }} />
            <span className="text-xs font-semibold" style={{ color: '#4eff8b' }}>
              ACTIVE
            </span>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-4 p-3 rounded-xl border border-red-500/50 bg-red-900/10 flex items-center gap-3">
            <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Error</div>
              <div className="text-xs text-gray-300 mt-0.5">{error}</div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left: Input */}
          <div className="lg:col-span-5 space-y-4">
            <div className="format-panel rounded-2xl p-4">
              <div className="mb-3">
                <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                  Input Value
                </div>
                <div className="text-[10px] text-gray-500">
                  Enter numeric string for format detection
                </div>
              </div>

              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                className="w-full rounded-xl px-4 py-3 text-sm font-mono"
                style={{
                  background: '#05050d',
                  border: '1px solid #1a1a26',
                  color: '#a3a7cf'
                }}
                placeholder="Enter number: 42, 3.14, -128, etc."
              />

              <div className="mt-3 grid grid-cols-4 gap-2">
                <button
                  onClick={() => loadExample('integer')}
                  className="px-2 py-2 rounded-xl text-[9px] font-semibold uppercase tracking-wider transition-all hover:bg-white/5"
                  style={{
                    background: 'rgba(255, 255, 255, 0.02)',
                    color: '#9094b2',
                    border: '1px solid rgba(255, 255, 255, 0.08)'
                  }}
                >
                  Integer
                </button>
                <button
                  onClick={() => loadExample('negative_int')}
                  className="px-2 py-2 rounded-xl text-[9px] font-semibold uppercase tracking-wider transition-all hover:bg-white/5"
                  style={{
                    background: 'rgba(255, 255, 255, 0.02)',
                    color: '#9094b2',
                    border: '1px solid rgba(255, 255, 255, 0.08)'
                  }}
                >
                  Negative
                </button>
                <button
                  onClick={() => loadExample('float')}
                  className="px-2 py-2 rounded-xl text-[9px] font-semibold uppercase tracking-wider transition-all hover:bg-white/5"
                  style={{
                    background: 'rgba(255, 255, 255, 0.02)',
                    color: '#9094b2',
                    border: '1px solid rgba(255, 255, 255, 0.08)'
                  }}
                >
                  Float
                </button>
                <button
                  onClick={() => loadExample('negative_float')}
                  className="px-2 py-2 rounded-xl text-[9px] font-semibold uppercase tracking-wider transition-all hover:bg-white/5"
                  style={{
                    background: 'rgba(255, 255, 255, 0.02)',
                    color: '#9094b2',
                    border: '1px solid rgba(255, 255, 255, 0.08)'
                  }}
                >
                  -Float
                </button>
              </div>
            </div>

            <div className="format-panel rounded-2xl p-4">
              <div className="mb-3">
                <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                  Format Types
                </div>
              </div>

              <div className="space-y-2 text-xs text-gray-300">
                <div className="detection-card rounded-xl p-3">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="px-2 py-0.5 rounded text-[9px] font-mono font-bold" style={{
                      background: 'rgba(78, 255, 139, 0.2)',
                      color: '#4eff8b'
                    }}>
                      %d
                    </div>
                    <span className="font-semibold text-white">Integer / Decimal</span>
                  </div>
                  <div className="text-[10px] text-gray-400">
                    Whole numbers without decimal points (42, -128, 0)
                  </div>
                </div>

                <div className="detection-card rounded-xl p-3">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="px-2 py-0.5 rounded text-[9px] font-mono font-bold" style={{
                      background: 'rgba(36, 228, 255, 0.2)',
                      color: '#24e4ff'
                    }}>
                      %f
                    </div>
                    <span className="font-semibold text-white">Floating-Point</span>
                  </div>
                  <div className="text-[10px] text-gray-400">
                    Numbers with decimal precision (3.14159, -0.5625)
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={handleAnalyze}
              disabled={isAnalyzing || !inputValue}
              className="w-full px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all disabled:opacity-40"
              style={{
                background: 'radial-gradient(circle at 20% 0, #ffffff, #4eff8b 40%, #0b6b4f 70%)',
                color: '#020206',
                boxShadow: isAnalyzing ? 'none' : '0 8px 24px rgba(78, 255, 139, 0.6)'
              }}
            >
              {isAnalyzing ? (
                <>
                  <Activity className="w-4 h-4 animate-spin" />
                  ANALYZING...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  DETECT FORMAT
                </>
              )}
            </button>
          </div>

          {/* Right: Results */}
          <div className="lg:col-span-7 space-y-4">
            {!result ? (
              <div className="format-panel rounded-2xl p-6 h-full flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <Hash className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <div className="text-sm font-semibold">No Analysis Yet</div>
                  <div className="text-xs mt-1">Enter a value and detect format</div>
                </div>
              </div>
            ) : (
              <>
                {/* Recommended Format */}
                <div className="format-panel rounded-2xl p-4">
                  <div className="flex items-center justify-between">
                    <div className="text-xs text-gray-400 uppercase tracking-wider">Recommended Format</div>
                    <div 
                      className="px-8 py-3 rounded-full text-2xl font-mono font-bold"
                      style={{
                        background: `${getFormatColor(result.recommendedFormat).glow}`,
                        color: getFormatColor(result.recommendedFormat).text,
                        border: `2px solid ${getFormatColor(result.recommendedFormat).text}`
                      }}
                    >
                      {result.recommendedFormat}
                    </div>
                  </div>
                </div>

                {/* Detection Results */}
                <div className="format-panel rounded-2xl p-4">
                  <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
                    Detection Results
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div className="detection-card rounded-xl p-3">
                      <div className="text-[10px] text-gray-500 mb-1">Integer</div>
                      <div className="flex items-center gap-2">
                        {result.detected.integer ? (
                          <CheckCircle2 className="w-4 h-4 text-green-400" />
                        ) : (
                          <div className="w-4 h-4 rounded-full border-2 border-gray-600" />
                        )}
                        <span className={`text-xs font-semibold ${result.detected.integer ? 'text-green-400' : 'text-gray-500'}`}>
                          {result.detected.integer ? 'YES' : 'NO'}
                        </span>
                      </div>
                    </div>

                    <div className="detection-card rounded-xl p-3">
                      <div className="text-[10px] text-gray-500 mb-1">Float</div>
                      <div className="flex items-center gap-2">
                        {result.detected.float ? (
                          <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                        ) : (
                          <div className="w-4 h-4 rounded-full border-2 border-gray-600" />
                        )}
                        <span className={`text-xs font-semibold ${result.detected.float ? 'text-cyan-400' : 'text-gray-500'}`}>
                          {result.detected.float ? 'YES' : 'NO'}
                        </span>
                      </div>
                    </div>

                    <div className="detection-card rounded-xl p-3">
                      <div className="text-[10px] text-gray-500 mb-1">Decimal</div>
                      <div className="flex items-center gap-2">
                        {result.detected.decimal ? (
                          <CheckCircle2 className="w-4 h-4 text-purple-400" />
                        ) : (
                          <div className="w-4 h-4 rounded-full border-2 border-gray-600" />
                        )}
                        <span className={`text-xs font-semibold ${result.detected.decimal ? 'text-purple-400' : 'text-gray-500'}`}>
                          {result.detected.decimal ? 'YES' : 'NO'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Normalized Value */}
                <div className="format-panel rounded-2xl p-4">
                  <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
                    Normalized Value
                  </div>

                  <div className="result-panel rounded-xl p-4">
                    <div className="text-3xl font-mono font-bold text-white text-center">
                      {result.normalizedValue !== null ? result.normalizedValue : 'null'}
                    </div>
                  </div>
                </div>

                {/* Additional Info */}
                <div className="format-panel rounded-2xl p-4">
                  <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-3">
                    Additional Information
                  </div>

                  <div className="space-y-3">
                    <div className="detection-card rounded-xl p-3">
                      <div className="text-[10px] text-gray-500 mb-1">Numeric Type</div>
                      <div className="text-xs text-white">{result.numericType}</div>
                    </div>

                    <div className="detection-card rounded-xl p-3">
                      <div className="text-[10px] text-gray-500 mb-1">Decimal Precision</div>
                      <div className="flex items-center gap-2">
                        <Percent className="w-4 h-4 text-cyan-400" />
                        <span className="text-xs text-white">{result.precision} digits</span>
                      </div>
                    </div>

                    <div className="detection-card rounded-xl p-3">
                      <div className="text-[10px] text-gray-500 mb-1">Original Input</div>
                      <div className="text-xs font-mono text-gray-300">{result.input}</div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}