import React, { useState, useRef, useEffect } from 'react';
import { Hexagon, Loader2, AlertTriangle, Zap, Activity, TrendingUp, BarChart3, Eye, Copy, Check, Flame, Shield, Radio, Brain, ArrowRightLeft, AlertCircle } from 'lucide-react';

const MODES = [
  { id: 'paradox-fusion', label: 'Paradox Fusion', level: 4, icon: Flame, color: '#ff6ec7', endpoint: '/api/paradox-fusion/analyze' },
  { id: 'antihex-fusion', label: 'Anti-Hex Fusion', level: 3, icon: Shield, color: '#a84cff', endpoint: '/api/antihex-fusion/analyze' },
  { id: 'qhex', label: 'Quantum-HEX', level: 2, icon: Radio, color: '#7cf5ff', endpoint: '/api/qhex/analyze' },
  { id: 'hex-consciousness', label: 'HEX Consciousness', level: 1, icon: Brain, color: '#4cffa8', endpoint: '/api/hex-consciousness/analyze' },
];

export default function ParadoxFusionHexEngine() {
  const [activeMode, setActiveMode] = useState('paradox-fusion');
  const [hallucinationMode, setHallucinationMode] = useState('default'); // 'default' or 'aggressive'
  const [input, setInput] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [copiedField, setCopiedField] = useState(null);
  const canvasRef = useRef(null);

  const currentModeConfig = MODES.find(m => m.id === activeMode);

  // Animated fusion background
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles = [];
    const particleCount = 120;

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
        size: Math.random() * 3 + 1,
        color: currentModeConfig?.color || '#ff6ec7',
        opacity: Math.random() * 0.6 + 0.3
      });
    }

    let animationId;
    const animate = () => {
      ctx.fillStyle = 'rgba(2, 0, 12, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      particles.forEach((p, i) => {
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

        // Draw particle
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.opacity;
        ctx.fill();

        // Draw connections to nearby particles
        particles.slice(i + 1).forEach(p2 => {
          const dx = p2.x - p.x;
          const dy = p2.y - p.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 120) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = p.color;
            ctx.globalAlpha = (1 - dist / 120) * 0.2;
            ctx.stroke();
          }
        });
      });

      ctx.globalAlpha = 1;
      animationId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, [currentModeConfig]);

  const runAnalysis = async () => {
    if (!input.trim() || isRunning) return;

    setIsRunning(true);
    setError(null);
    setResult(null);

    try {
      const endpoint = `http://localhost:9955${currentModeConfig.endpoint}`;
      const body = { input };
      
      if (activeMode === 'paradox-fusion') {
        body.mode = hallucinationMode;
      }

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();

      if (data.status !== 'ok') {
        throw new Error(data.message || 'Analysis failed');
      }

      setResult(data);

    } catch (err) {
      console.error('Paradox Fusion error:', err);
      setError(err.message);
    } finally {
      setIsRunning(false);
    }
  };

  const copyToClipboard = (text, field) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const renderGauge = (label, value, color, maxValue = 1) => {
    const percentage = (value / maxValue) * 100;
    return (
      <div className="p-4 rounded-xl text-center"
        style={{
          background: `${color}15`,
          border: `1px solid ${color}40`
        }}
      >
        <div className="text-xs text-gray-400 mb-2">{label}</div>
        <div className="text-3xl font-black mb-2" style={{ color }}>
          {value.toFixed(3)}
        </div>
        <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
          <div 
            className="h-full transition-all duration-500"
            style={{ 
              width: `${percentage}%`,
              background: `linear-gradient(90deg, ${color}, ${color}dd)`
            }}
          />
        </div>
        <div className="text-xs text-gray-500 mt-1">
          {percentage.toFixed(1)}%
        </div>
      </div>
    );
  };

  return (
    <div className="relative min-h-screen overflow-hidden" style={{
      background: 'radial-gradient(circle at 50% 0%, #2a0f1e 0%, #0a0208 30%, #02000c 70%)'
    }}>
      <style>{`
        @keyframes fusionPulse {
          0%, 100% { opacity: 0.8; transform: scale(1) rotate(0deg); }
          50% { opacity: 1; transform: scale(1.08) rotate(360deg); }
        }

        @keyframes fusionFloat {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-12px) rotate(8deg); }
        }

        .fusion-badge {
          animation: fusionPulse 4s ease-in-out infinite;
        }

        .fusion-card {
          animation: fusionFloat 7s ease-in-out infinite;
        }

        .mode-tab {
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .mode-tab.active {
          box-shadow: 0 0 20px currentColor;
        }
      `}</style>

      {/* Animated Background Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ opacity: 0.5 }}
      />

      {/* Main Content */}
      <div className="relative z-10 max-w-[1800px] mx-auto px-4 py-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-3">
            <Hexagon className="w-16 h-16 fusion-badge" style={{ color: currentModeConfig.color }} />
            <h1 className="text-5xl md:text-6xl font-black tracking-wider uppercase text-white">
              PARADOX FUSION HEX
            </h1>
          </div>
          <p className="text-sm text-gray-400 tracking-wide mb-3">
            4-Layer Hex Analysis Framework · Original × Inverted × Hallucinated
          </p>
          
          {/* Mode Selector Tabs */}
          <div className="flex flex-wrap items-center justify-center gap-2">
            {MODES.map(mode => {
              const Icon = mode.icon;
              const isActive = activeMode === mode.id;
              return (
                <button
                  key={mode.id}
                  onClick={() => setActiveMode(mode.id)}
                  className={`mode-tab flex items-center gap-2 px-4 py-2 rounded-full text-xs uppercase tracking-wider font-semibold ${
                    isActive ? 'active' : ''
                  }`}
                  style={{
                    background: isActive ? mode.color : 'transparent',
                    color: isActive ? '#020309' : mode.color,
                    border: `1px solid ${mode.color}${isActive ? '' : '60'}`,
                    boxShadow: isActive ? `0 0 20px ${mode.color}99` : 'none'
                  }}
                >
                  <Icon className="w-3 h-3" />
                  {mode.label}
                  <span className="opacity-60">L{mode.level}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Info Banner */}
        <div className="mb-6 p-4 rounded-2xl border"
          style={{
            background: `${currentModeConfig.color}15`,
            borderColor: `${currentModeConfig.color}40`
          }}
        >
          <div className="flex items-start gap-3">
            <Eye className="w-5 h-5 mt-0.5 flex-shrink-0" style={{ color: currentModeConfig.color }} />
            <div className="text-xs text-gray-300">
              <span className="font-bold" style={{ color: currentModeConfig.color }}>
                {currentModeConfig.label} (Level {currentModeConfig.level}):
              </span>
              <br />
              {activeMode === 'paradox-fusion' && "Triple-space analysis: Original × Anti-Hex × Hallucinated bytes. Computes paradox index, instability, innovation potential, and risk score."}
              {activeMode === 'antihex-fusion' && "Dual-space analysis: Original × Inverted. Light version focusing on fusion tension and entropy shifts."}
              {activeMode === 'qhex' && "Quantum-HEX seed: Superposition complexity, collapse bias, and timeline spread metrics. Early experimental stage."}
              {activeMode === 'hex-consciousness' && "HEX Consciousness seed: Structural density, life index, and decay analysis. Exploring 'living hex' patterns."}
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 rounded-xl border border-red-500/50 bg-red-900/20 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Backend Connection Error</div>
              <div className="text-xs text-gray-300 mt-1">{error}</div>
              <div className="text-xs text-gray-400 mt-2">
                Backend: <code className="bg-black/40 px-2 py-0.5 rounded">http://localhost:9955</code>
              </div>
            </div>
          </div>
        )}

        {/* Main Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          {/* Left: Input & Controls */}
          <div className="xl:col-span-4 space-y-4">
            <div className="rounded-2xl border p-6"
              style={{
                borderColor: `${currentModeConfig.color}40`,
                background: 'rgba(10, 12, 18, 0.95)',
                boxShadow: `0 0 40px ${currentModeConfig.color}33`
              }}
            >
              <div className="text-xs tracking-widest uppercase mb-4" style={{ color: currentModeConfig.color }}>
                INPUT DATA
              </div>

              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                disabled={isRunning}
                rows={10}
                className="w-full rounded-xl border px-4 py-3 text-sm resize-none font-mono mb-4"
                style={{
                  borderColor: `${currentModeConfig.color}40`,
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#f6fff6'
                }}
                placeholder="Enter text, code, or hex string...\n\nExample:\nHello World\n\nOr hex:\n48656c6c6f20576f726c64"
              />

              {/* Hallucination Mode (only for Paradox Fusion) */}
              {activeMode === 'paradox-fusion' && (
                <div className="mb-4">
                  <div className="text-xs tracking-widest uppercase mb-2" style={{ color: currentModeConfig.color }}>
                    HALLUCINATION MODE
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setHallucinationMode('default')}
                      className="flex-1 py-2 rounded-lg text-xs font-semibold uppercase transition-all"
                      style={{
                        background: hallucinationMode === 'default' ? currentModeConfig.color : 'transparent',
                        color: hallucinationMode === 'default' ? '#020309' : currentModeConfig.color,
                        border: `1px solid ${currentModeConfig.color}${hallucinationMode === 'default' ? '' : '40'}`
                      }}
                    >
                      Default (8%)
                    </button>
                    <button
                      onClick={() => setHallucinationMode('aggressive')}
                      className="flex-1 py-2 rounded-lg text-xs font-semibold uppercase transition-all"
                      style={{
                        background: hallucinationMode === 'aggressive' ? '#ff4b81' : 'transparent',
                        color: hallucinationMode === 'aggressive' ? '#fff' : '#ff4b81',
                        border: `1px solid #ff4b81${hallucinationMode === 'aggressive' ? '' : '40'}`
                      }}
                    >
                      Aggressive (20%)
                    </button>
                  </div>
                </div>
              )}

              {/* Run Button */}
              <button
                onClick={runAnalysis}
                disabled={isRunning || !input.trim()}
                className="w-full py-3 rounded-full text-sm font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                style={{
                  background: `linear-gradient(135deg, ${currentModeConfig.color}, ${currentModeConfig.color}dd)`,
                  color: '#fff',
                  boxShadow: isRunning ? 'none' : `0 0 30px ${currentModeConfig.color}99`
                }}
              >
                {isRunning ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    ANALYZING...
                  </>
                ) : (
                  <>
                    <currentModeConfig.icon className="w-5 h-5" />
                    RUN ANALYSIS
                  </>
                )}
              </button>

              {/* Stats */}
              {result && (
                <div className="mt-6 pt-4 border-t" style={{ borderColor: `${currentModeConfig.color}40` }}>
                  <div className="text-xs text-gray-400 mb-3">Analysis Stats</div>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Mode:</span>
                      <span className="font-semibold" style={{ color: currentModeConfig.color }}>
                        {result.mode}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Input Length:</span>
                      <span className="text-white font-semibold">{result.length} bytes</span>
                    </div>
                    {activeMode === 'paradox-fusion' && (
                      <div className="flex justify-between">
                        <span className="text-gray-500">Hallucination:</span>
                        <span className="text-white font-semibold">{hallucinationMode}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right: Results */}
          <div className="xl:col-span-8">
            {!result && !isRunning && (
              <div className="rounded-2xl border p-12 text-center h-full flex items-center justify-center"
                style={{
                  borderColor: `${currentModeConfig.color}40`,
                  background: 'rgba(10, 12, 18, 0.95)'
                }}
              >
                <div>
                  <currentModeConfig.icon className="w-24 h-24 mx-auto mb-4" style={{ color: `${currentModeConfig.color}44` }} />
                  <p className="text-sm text-gray-500">
                    No analysis result yet.
                    <br />
                    Enter data and run {currentModeConfig.label} analysis.
                  </p>
                </div>
              </div>
            )}

            {isRunning && (
              <div className="rounded-2xl border p-12 text-center h-full flex items-center justify-center"
                style={{
                  borderColor: `${currentModeConfig.color}40`,
                  background: 'rgba(10, 12, 18, 0.95)'
                }}
              >
                <div>
                  <Loader2 className="w-24 h-24 mx-auto mb-4 animate-spin" style={{ color: currentModeConfig.color }} />
                  <p className="text-sm text-gray-400">
                    Running {currentModeConfig.label} analysis...
                  </p>
                </div>
              </div>
            )}

            {result && activeMode === 'paradox-fusion' && (
              <div className="space-y-4">
                {/* Fusion Metrics */}
                <div className="fusion-card rounded-2xl border p-6"
                  style={{
                    borderColor: `${currentModeConfig.color}60`,
                    background: 'rgba(10, 12, 18, 0.95)',
                    boxShadow: `0 0 60px ${currentModeConfig.color}44`,
                    animationDelay: '0s'
                  }}
                >
                  <h3 className="text-lg font-bold uppercase tracking-wider mb-4" style={{ color: currentModeConfig.color }}>
                    <Flame className="w-5 h-5 inline mr-2" />
                    Paradox Fusion Metrics
                  </h3>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {renderGauge('Paradox Index', result.result.fusion.paradoxIndex, '#ff6ec7', 3)}
                    {renderGauge('Instability', result.result.fusion.instabilityIndex, '#ff4b81', 10)}
                    {renderGauge('Innovation', result.result.fusion.innovationPotential, '#4cffa8', 1)}
                    {renderGauge('Risk Score', result.result.fusion.riskScore, '#dc2626', 1)}
                  </div>
                </div>

                {/* Triple-Space Comparison */}
                <div className="fusion-card rounded-2xl border p-6"
                  style={{
                    borderColor: `${currentModeConfig.color}60`,
                    background: 'rgba(10, 12, 18, 0.95)',
                    animationDelay: '0.1s'
                  }}
                >
                  <h3 className="text-sm font-bold uppercase tracking-wider mb-4" style={{ color: currentModeConfig.color }}>
                    <ArrowRightLeft className="w-4 h-4 inline mr-2" />
                    Triple-Space Analysis
                  </h3>

                  <div className="space-y-4">
                    {/* Original */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-xs font-bold text-green-400">ORIGINAL SPACE</div>
                        <button
                          onClick={() => copyToClipboard(result.result.original.hex, 'original')}
                          className="px-2 py-1 rounded-full text-xs"
                          style={{
                            background: 'rgba(76, 255, 168, 0.1)',
                            border: '1px solid rgba(76, 255, 168, 0.3)',
                            color: '#4cffa8'
                          }}
                        >
                          {copiedField === 'original' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                        </button>
                      </div>
                      <div className="flex items-center gap-4 mb-2">
                        <span className="text-xs text-gray-400">Entropy:</span>
                        <span className="text-lg font-bold text-green-400">
                          {result.result.original.entropy.toFixed(4)}
                        </span>
                      </div>
                      <pre className="text-xs font-mono whitespace-pre-wrap break-all bg-black/40 p-3 rounded-lg max-h-[100px] overflow-auto text-gray-300">
                        {result.result.original.hex.substring(0, 300)}
                        {result.result.original.hex.length > 300 && '...'}
                      </pre>
                    </div>

                    {/* Inverted */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-xs font-bold text-purple-400">INVERTED SPACE (Anti-Hex)</div>
                        <button
                          onClick={() => copyToClipboard(result.result.inverted.hex, 'inverted')}
                          className="px-2 py-1 rounded-full text-xs"
                          style={{
                            background: 'rgba(168, 76, 255, 0.1)',
                            border: '1px solid rgba(168, 76, 255, 0.3)',
                            color: '#a84cff'
                          }}
                        >
                          {copiedField === 'inverted' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                        </button>
                      </div>
                      <div className="flex items-center gap-4 mb-2">
                        <span className="text-xs text-gray-400">Entropy:</span>
                        <span className="text-lg font-bold text-purple-400">
                          {result.result.inverted.entropy.toFixed(4)}
                        </span>
                        <span className="text-xs text-gray-500">
                          Δ {((result.result.inverted.entropy - result.result.original.entropy) * 100 / result.result.original.entropy).toFixed(1)}%
                        </span>
                      </div>
                      <pre className="text-xs font-mono whitespace-pre-wrap break-all p-3 rounded-lg max-h-[100px] overflow-auto"
                        style={{
                          background: 'rgba(168, 76, 255, 0.15)',
                          color: '#a84cff'
                        }}
                      >
                        {result.result.inverted.hex.substring(0, 300)}
                        {result.result.inverted.hex.length > 300 && '...'}
                      </pre>
                    </div>

                    {/* Hallucinated */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-xs font-bold text-pink-400">HALLUCINATED SPACE (Paradox)</div>
                        <button
                          onClick={() => copyToClipboard(result.result.hallucinated.hex, 'hallucinated')}
                          className="px-2 py-1 rounded-full text-xs"
                          style={{
                            background: 'rgba(255, 110, 199, 0.1)',
                            border: '1px solid rgba(255, 110, 199, 0.3)',
                            color: '#ff6ec7'
                          }}
                        >
                          {copiedField === 'hallucinated' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                        </button>
                      </div>
                      <div className="flex items-center gap-4 mb-2">
                        <span className="text-xs text-gray-400">Entropy:</span>
                        <span className="text-lg font-bold text-pink-400">
                          {result.result.hallucinated.entropy.toFixed(4)}
                        </span>
                        <span className="text-xs text-gray-500">
                          vs Orig: {(result.result.hallucinated.relationToOriginal.similarity * 100).toFixed(1)}%
                        </span>
                      </div>
                      <pre className="text-xs font-mono whitespace-pre-wrap break-all p-3 rounded-lg max-h-[100px] overflow-auto"
                        style={{
                          background: 'rgba(255, 110, 199, 0.15)',
                          color: '#ff6ec7'
                        }}
                      >
                        {result.result.hallucinated.hex.substring(0, 300)}
                        {result.result.hallucinated.hex.length > 300 && '...'}
                      </pre>
                    </div>
                  </div>
                </div>

                {/* AI Narrative */}
                {result.narrative?.summary && (
                  <div className="fusion-card rounded-2xl border p-6"
                    style={{
                      borderColor: `${currentModeConfig.color}60`,
                      background: 'rgba(10, 12, 18, 0.95)',
                      animationDelay: '0.2s'
                    }}
                  >
                    <h3 className="text-sm font-bold uppercase tracking-wider mb-4" style={{ color: currentModeConfig.color }}>
                      <Brain className="w-4 h-4 inline mr-2" />
                      AI Narrative
                    </h3>
                    
                    <div className="space-y-4">
                      <div>
                        <div className="text-xs font-bold text-gray-400 mb-2">SUMMARY</div>
                        <div className="text-sm text-gray-300 leading-relaxed">
                          {result.narrative.summary}
                        </div>
                      </div>

                      {result.narrative.riskLevel && (
                        <div className="flex items-center gap-3">
                          <div className="text-xs font-bold text-gray-400">RISK LEVEL:</div>
                          <div className="px-3 py-1 rounded-full text-xs font-bold uppercase"
                            style={{
                              background: result.narrative.riskLevel === 'high' 
                                ? 'rgba(220, 38, 38, 0.2)' 
                                : result.narrative.riskLevel === 'medium'
                                  ? 'rgba(255, 204, 75, 0.2)'
                                  : 'rgba(76, 255, 168, 0.2)',
                              border: `1px solid ${
                                result.narrative.riskLevel === 'high' 
                                  ? '#dc2626' 
                                  : result.narrative.riskLevel === 'medium'
                                    ? '#ffcc4b'
                                    : '#4cffa8'
                              }`,
                              color: result.narrative.riskLevel === 'high' 
                                ? '#ef4444' 
                                : result.narrative.riskLevel === 'medium'
                                  ? '#ffcc4b'
                                  : '#4cffa8'
                            }}
                          >
                            {result.narrative.riskLevel}
                          </div>
                        </div>
                      )}

                      {result.narrative.architectureHint && (
                        <div>
                          <div className="text-xs font-bold text-gray-400 mb-2">ARCHITECTURE HINT</div>
                          <div className="text-sm text-gray-300">
                            {result.narrative.architectureHint}
                          </div>
                        </div>
                      )}

                      {result.narrative.recommendations?.length > 0 && (
                        <div>
                          <div className="text-xs font-bold text-gray-400 mb-2">RECOMMENDATIONS</div>
                          <ul className="space-y-1">
                            {result.narrative.recommendations.map((rec, idx) => (
                              <li key={idx} className="text-sm text-gray-300 flex items-start gap-2">
                                <span style={{ color: currentModeConfig.color }}>•</span>
                                <span>{rec}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* ANTI-HEX FUSION RESULTS */}
            {result && activeMode === 'antihex-fusion' && (
              <div className="space-y-4">
                <div className="fusion-card rounded-2xl border p-6"
                  style={{
                    borderColor: `${currentModeConfig.color}60`,
                    background: 'rgba(10, 12, 18, 0.95)',
                    animationDelay: '0s'
                  }}
                >
                  <h3 className="text-sm font-bold uppercase tracking-wider mb-4" style={{ color: currentModeConfig.color }}>
                    Fusion Tension: {result.result.fusionTension?.toFixed(3)}
                  </h3>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-xs text-gray-400 mb-2">Original Entropy</div>
                      <div className="text-2xl font-bold text-green-400">
                        {result.result.original.entropy.toFixed(4)}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-400 mb-2">Inverted Entropy</div>
                      <div className="text-2xl font-bold text-purple-400">
                        {result.result.inverted.entropy.toFixed(4)}
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-xs text-gray-400 mb-2">Similarity</div>
                      <div className="text-xl font-bold text-cyan-400">
                        {(result.result.relations.similarity * 100).toFixed(1)}%
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-400 mb-2">Difference</div>
                      <div className="text-xl font-bold text-red-400">
                        {(result.result.relations.differenceRatio * 100).toFixed(1)}%
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Q-HEX RESULTS */}
            {result && activeMode === 'qhex' && (
              <div className="space-y-4">
                <div className="fusion-card rounded-2xl border p-6"
                  style={{
                    borderColor: `${currentModeConfig.color}60`,
                    background: 'rgba(10, 12, 18, 0.95)',
                    animationDelay: '0s'
                  }}
                >
                  <h3 className="text-sm font-bold uppercase tracking-wider mb-4" style={{ color: currentModeConfig.color }}>
                    Quantum-HEX Metrics (Experimental)
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {renderGauge('Superposition', result.result.superpositionComplexity, '#7cf5ff', 1)}
                    {renderGauge('Collapse Bias', result.result.collapseBias, '#ffdb7c', 1)}
                    {renderGauge('Timeline Spread', result.result.timelineSpread, '#a84cff', 1)}
                  </div>

                  <div className="mt-4 text-xs text-gray-400">
                    <AlertCircle className="w-3 h-3 inline mr-1" />
                    Seed version - Metrics are experimental and require further calibration.
                  </div>
                </div>
              </div>
            )}

            {/* HEX CONSCIOUSNESS RESULTS */}
            {result && activeMode === 'hex-consciousness' && (
              <div className="space-y-4">
                <div className="fusion-card rounded-2xl border p-6"
                  style={{
                    borderColor: `${currentModeConfig.color}60`,
                    background: 'rgba(10, 12, 18, 0.95)',
                    animationDelay: '0s'
                  }}
                >
                  <h3 className="text-sm font-bold uppercase tracking-wider mb-4" style={{ color: currentModeConfig.color }}>
                    HEX Consciousness Metrics (Experimental)
                  </h3>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {renderGauge('Entropy', result.result.entropy, '#4cffa8', 8)}
                    {renderGauge('Structural Density', result.result.structuralDensity, '#7cf5ff', 1)}
                    {renderGauge('Life Index', result.result.lifeIndex, '#32e67c', 1)}
                    {renderGauge('Decay Index', result.result.decayIndex, '#dc2626', 1)}
                  </div>

                  <div className="mt-4 text-xs text-gray-400">
                    <AlertCircle className="w-3 h-3 inline mr-1" />
                    Seed version - Exploring "living hex" patterns and data consciousness.
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer Info */}
        <div className="mt-6 text-center text-xs text-gray-500">
          <p>Paradox Fusion HEX Engine :: 4-Layer Analysis Framework</p>
          <p className="mt-1">Backend: http://localhost:9955</p>
          <p className="mt-1" style={{ color: currentModeConfig.color }}>
            Active: {currentModeConfig.label} (Level {currentModeConfig.level})
          </p>
        </div>
      </div>
    </div>
  );
}