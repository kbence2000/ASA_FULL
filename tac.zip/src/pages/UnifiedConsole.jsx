import React, { useEffect, useState } from "react";

const API_BASE = import.meta.env.VITE_MDC_BACKEND_URL || "http://localhost:3000";

const STYLE = `
.mdc-root {
  min-height: 100vh;
  padding: 24px;
  background: radial-gradient(circle at top, #18093f 0, #050313 45%, #02010a 100%);
  color: #f7f1ff;
  font-family: Inter, system-ui, sans-serif;
}

/* HEADER */
.mdc-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 16px;
  margin-bottom: 20px;
}
.mdc-title-area h1 {
  margin: 0;
  font-size: 30px;
  background: linear-gradient(90deg, #b57bff, #ff6ceb);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.mdc-title-area p {
  margin: 4px 0 0;
  font-size: 14px;
  opacity: 0.8;
}

/* USER CARD */
.mdc-user-card {
  background: rgba(9, 6, 21, 0.95);
  border-radius: 12px;
  border: 1px solid #312652;
  padding: 12px 14px;
  min-width: 260px;
  backdrop-filter: blur(10px);
}
.mdc-user-card-title {
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 1px;
  opacity: 0.8;
}
.mdc-row {
  display: flex;
  gap: 8px;
  margin-top: 6px;
}
.mdc-input {
  flex: 1;
  background: #090618;
  border-radius: 6px;
  border: 1px solid #352a58;
  padding: 6px 8px;
  color: #f7f1ff;
  font-size: 13px;
  outline: none;
}
.mdc-input:focus {
  border-color: #9669ff;
}
.mdc-checkbox-row {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 8px;
  font-size: 12px;
  opacity: 0.85;
}
.mdc-btn {
  margin-top: 8px;
  border-radius: 8px;
  border: 1px solid #3b345d;
  background: linear-gradient(135deg,#7d5dff,#d84cff);
  color: #fff;
  padding: 6px 10px;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  box-shadow: 0 0 10px #7c5bff66;
}
.mdc-btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 0 14px #b280ffaa;
}
.mdc-tier-badge {
  margin-top: 6px;
  font-size: 11px;
  border-radius: 999px;
  border: 1px solid #3d325a;
  background: linear-gradient(135deg,#191628,#251c3c);
  padding: 4px 8px;
  display: inline-flex;
  gap: 6px;
  align-items: center;
}
.mdc-status {
  margin-top: 6px;
  font-size: 12px;
}
.mdc-status.ok {
  color: #78ffd6;
}
.mdc-status.err {
  color: #ff9c9c;
}

/* LAYOUT MAIN */
.mdc-main {
  display: grid;
  grid-template-columns: minmax(0, 1.4fr) minmax(0, 1.3fr);
  gap: 16px;
}
@media(max-width: 1100px) {
  .mdc-main {
    grid-template-columns: 1fr;
  }
}

/* PANELS */
.mdc-panel {
  background: rgba(6,4,18,0.97);
  border-radius: 12px;
  border: 1px solid #2b2348;
  padding: 14px 14px 16px;
  backdrop-filter: blur(10px);
}
.mdc-panel h2 {
  margin: 0 0 8px;
  font-size: 18px;
}
.mdc-panel p {
  margin: 0 0 10px;
  font-size: 12px;
  opacity: 0.8;
}

.mdc-field {
  margin-bottom: 8px;
}
.mdc-field label {
  display: block;
  font-size: 12px;
  opacity: 0.85;
  margin-bottom: 3px;
}
.mdc-textarea {
  width: 100%;
  min-height: 80px;
  background: #070416;
  border-radius: 8px;
  border: 1px solid #32284f;
  padding: 7px;
  color: #f7f1ff;
  font-size: 13px;
  outline: none;
  resize: vertical;
}
.mdc-textarea:focus {
  border-color: #9368ff;
}
.mdc-select {
  width: 100%;
}

/* INVENTORY LIST */
.mdc-inv-list {
  margin-top: 8px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.mdc-inv-card {
  padding: 8px 10px;
  border-radius: 10px;
  border: 1px solid #332a53;
  background: radial-gradient(circle at top left, #24163f 0, #130f23 40%, #090515 100%);
  font-size: 13px;
}
.mdc-inv-title {
  font-weight: 600;
}
.mdc-inv-meta {
  font-size: 11px;
  opacity: 0.8;
}
.mdc-chip {
  display: inline-block;
  font-size: 11px;
  border-radius: 999px;
  border: 1px solid #43355e;
  padding: 2px 7px;
  margin-top: 4px;
  margin-right: 4px;
  background: #1c1432;
}
.mdc-inv-actions {
  margin-top: 6px;
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.mdc-btn-secondary {
  border-radius: 6px;
  border: 1px solid #3c345a;
  background: #171228;
  color: #f5efff;
  padding: 4px 8px;
  font-size: 12px;
  cursor: pointer;
}
.mdc-btn-secondary:hover {
  background: #211834;
}

/* EVAL RESULT */
.mdc-eval {
  margin-top: 6px;
  font-size: 12px;
}
.mdc-stars {
  color: #ffd36c;
  font-weight: 600;
}
.mdc-eval-row {
  margin-top: 2px;
}
.mdc-eval-expl {
  margin-top: 4px;
  background: #090518;
  border-radius: 8px;
  border: 1px solid #392b5a;
  padding: 6px;
}

/* TIP MODAL */
.mdc-modal-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(3, 2, 8, 0.8);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 40;
}
.mdc-modal {
  background: #0b0719;
  border-radius: 12px;
  border: 1px solid #3a2a58;
  padding: 16px;
  max-width: 520px;
  width: 100%;
  max-height: 80vh;
  overflow: auto;
}
.mdc-modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.mdc-modal-header h3 {
  margin: 0;
  font-size: 18px;
}
.mdc-modal-close {
  cursor: pointer;
  font-size: 18px;
}
.mdc-tip-price-options {
  display: flex;
  gap: 8px;
  margin: 6px 0 4px;
}
.mdc-tagline {
  margin-top: 4px;
  font-size: 11px;
  opacity: 0.75;
}

/* DEMIGOD INBOX */
.mdc-inbox-list {
  margin-top: 6px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.mdc-inbox-card {
  border-radius: 10px;
  border: 1px solid #362b56;
  background: #100823;
  padding: 8px 10px;
  font-size: 12px;
}
.mdc-inbox-head {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.mdc-inbox-head span {
  font-size: 11px;
  opacity: 0.8;
}
.mdc-inbox-question {
  margin-top: 4px;
}
.mdc-code-snippet-box {
  margin-top: 4px;
  background: #070415;
  border-radius: 6px;
  border: 1px solid #2b2246;
  padding: 6px;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: "JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
}
.mdc-inbox-answer-box {
  margin-top: 6px;
}
.mdc-inbox-answer {
  background: #070416;
  border-radius: 6px;
  border: 1px solid #3a2c5e;
  padding: 6px;
  min-height: 60px;
  color: #f7f1ff;
  font-size: 12px;
  resize: vertical;
  outline: none;
  width: 100%;
}

/* EARNINGS PANEL */
.mdc-earnings {
  margin-top: 6px;
  font-size: 13px;
}
.mdc-earnings strong {
  color: #e1d0ff;
}

/* MY TIPS */
.mdc-my-tips-list {
  margin-top: 6px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.mdc-my-tip-card {
  border-radius: 8px;
  border: 1px solid #382b56;
  background: #10071f;
  padding: 6px 8px;
  font-size: 12px;
}
.mdc-my-tip-status {
  font-size: 11px;
  opacity: 0.75;
}
.mdc-my-tip-answer {
  margin-top: 4px;
  background: #060316;
  border-radius: 6px;
  border: 1px solid #2c2145;
  padding: 5px;
}
`;

function StyleInject() {
  useEffect(() => {
    const el = document.createElement("style");
    el.innerHTML = STYLE;
    document.head.appendChild(el);
    return () => {
      document.head.removeChild(el);
    };
  }, []);
  return null;
}

export default function MDCUnifiedConsole() {
  // ---------- USER & PROFILE ----------
  const [userId, setUserId] = useState("user_demo");
  const [username, setUsername] = useState("demo_user");
  const [score, setScore] = useState(75);
  const [isDemigodOverride, setIsDemigodOverride] = useState(false);
  const [isAvailable, setIsAvailable] = useState(false);
  const [activeUser, setActiveUser] = useState(null);
  const [userMessage, setUserMessage] = useState("");
  const [userError, setUserError] = useState("");
  const [savingUser, setSavingUser] = useState(false);

  // ---------- INVENTORY ----------
  const [invTitle, setInvTitle] = useState("");
  const [invLang, setInvLang] = useState("javascript");
  const [invLines, setInvLines] = useState(200);
  const [invCategory, setInvCategory] = useState("dev-tool");
  const [invTags, setInvTags] = useState("devtool,saas");
  const [invComplexity, setInvComplexity] = useState(3);
  const [invQuality, setInvQuality] = useState(70);
  const [invTests, setInvTests] = useState(0);
  const [invHasDocs, setInvHasDocs] = useState(true);
  const [invIsTemplate, setInvIsTemplate] = useState(false);
  const [invIsLibrary, setInvIsLibrary] = useState(false);
  const [invDescription, setInvDescription] = useState("");
  const [inventory, setInventory] = useState([]);

  // ---------- MARKET EVAL ----------
  const [evalLoadingId, setEvalLoadingId] = useState(null);

  // ---------- ASK DEMIGOD MODAL ----------
  const [tipModalOpen, setTipModalOpen] = useState(false);
  const [tipProjectId, setTipProjectId] = useState(null);
  const [tipPriceTier, setTipPriceTier] = useState("micro");
  const [tipCustomPrice, setTipCustomPrice] = useState("");
  const [tipQuestion, setTipQuestion] = useState("");
  const [tipSending, setTipSending] = useState(false);
  const [tipModalMessage, setTipModalMessage] = useState("");

  // ---------- DEMIGOD INBOX ----------
  const [inbox, setInbox] = useState([]);
  const [inboxLoading, setInboxLoading] = useState(false);
  const [answerDrafts, setAnswerDrafts] = useState({});

  // ---------- DEMIGOD EARNINGS ----------
  const [earnings, setEarnings] = useState(null);
  const [earningsLoading, setEarningsLoading] = useState(false);

  // ---------- MY TIPS (requester) ----------
  const [myTips, setMyTips] = useState([]);
  const [myTipsLoading, setMyTipsLoading] = useState(false);

  // ---------- HELPERS ----------
  function parseTags(str) {
    return str
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
  }

  function updateInventoryItem(id, patch) {
    setInventory((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...patch } : item))
    );
  }

  // ---------- USER SAVE ----------
  async function handleSaveUser() {
    setSavingUser(true);
    setUserMessage("");
    setUserError("");
    try {
      const res = await fetch(`${API_BASE}/api/user/upsert`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: userId,
          username,
          score: Number(score),
          isDemigod: isDemigodOverride || undefined,
          isAvailable: isAvailable
        })
      });
      const data = await res.json();
      if (!res.ok) {
        setUserError(data.error || "User save failed");
      } else {
        setActiveUser(data);
        setUserMessage(
          `User set: ${data.username} (${data.tier.id} – ${data.tier.name})`
        );
      }
    } catch (e) {
      setUserError("Network error while saving user");
    } finally {
      setSavingUser(false);
    }
  }

  // ---------- INVENTORY ADD ----------
  function handleAddToInventory() {
    if (!invTitle.trim()) return;
    const id = `proj_${Math.random().toString(36).slice(2, 8)}`;
    const tagsArr = parseTags(invTags);
    const newItem = {
      id,
      ownerId: userId,
      title: invTitle,
      language: invLang,
      linesOfCode: Number(invLines),
      category: invCategory,
      tags: tagsArr,
      complexity: Number(invComplexity),
      qualityScore: Number(invQuality),
      testCoverage: Number(invTests),
      hasDocs: invHasDocs,
      isTemplate: invIsTemplate,
      isLibrary: invIsLibrary,
      description: invDescription,
      evalResult: null
    };
    setInventory((prev) => [newItem, ...prev]);

    setInvTitle("");
    setInvDescription("");
  }

  // ---------- MARKET EVALUATE ----------
  async function handleEvaluateProject(projectId) {
    const project = inventory.find((p) => p.id === projectId);
    if (!project) return;
    setEvalLoadingId(projectId);
    try {
      const res = await fetch(`${API_BASE}/api/market/evaluate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: project.title,
          description: project.description,
          linesOfCode: project.linesOfCode,
          language: project.language,
          category: project.category,
          tags: project.tags,
          complexity: project.complexity,
          qualityScore: project.qualityScore,
          testCoverage: project.testCoverage,
          hasDocs: project.hasDocs,
          isTemplate: project.isTemplate,
          isLibrary: project.isLibrary
        })
      });
      const data = await res.json();
      if (!res.ok) {
        updateInventoryItem(projectId, {
          evalResult: {
            error: data.error || "Evaluation failed"
          }
        });
      } else {
        updateInventoryItem(projectId, {
          evalResult: data
        });
      }
    } catch (e) {
      updateInventoryItem(projectId, {
        evalResult: {
          error: "Network error on evaluation"
        }
      });
    } finally {
      setEvalLoadingId(null);
    }
  }

  // ---------- ASK DEMIGOD MODAL ----------
  function openTipModal(projectId) {
    setTipProjectId(projectId);
    setTipQuestion("");
    setTipCustomPrice("");
    setTipPriceTier("micro");
    setTipModalMessage("");
    setTipModalOpen(true);
  }

  function closeTipModal() {
    setTipModalOpen(false);
  }

  async function handleSendTipRequest() {
    if (!activeUser || !activeUser.id) {
      setTipModalMessage("Save user profile first (Set / Update User).");
      return;
    }
    if (!tipProjectId) {
      setTipModalMessage("Missing project.");
      return;
    }
    const project = inventory.find((p) => p.id === tipProjectId);
    if (!project) {
      setTipModalMessage("Unknown project.");
      return;
    }
    if (!tipQuestion.trim()) {
      setTipModalMessage("Write a specific question for the demigod.");
      return;
    }

    setTipSending(true);
    setTipModalMessage("");
    try {
      const res = await fetch(`${API_BASE}/api/tip/request`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requesterId: activeUser.id,
          codeSnippet: project.description || project.title,
          question: tipQuestion,
          priceTier: tipPriceTier,
          customPriceEUR: tipCustomPrice
            ? Number(tipCustomPrice)
            : undefined
        })
      });
      const data = await res.json();
      if (!res.ok) {
        setTipModalMessage(data.error || "Tip request error.");
      } else {
        setTipModalMessage(
          `Tip created! Price: €${data.paymentInfo.priceEUR} (Demigod: €${data.paymentInfo.demigodShareEUR}, Platform: €${data.paymentInfo.platformShareEUR})`
        );
        setMyTips((prev) => [data.tip, ...prev]);
      }
    } catch (e) {
      setTipModalMessage("Network error on tip request.");
    } finally {
      setTipSending(false);
    }
  }

  // ---------- LOAD INBOX (DEMIGOD SIDE) ----------
  async function loadInbox() {
    if (!activeUser || !activeUser.id) return;
    setInboxLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/tip/user/${activeUser.id}`);
      const data = await res.json();
      if (!res.ok) {
        // ignore
      } else {
        const ownTips = data.filter(
          (t) =>
            t.assignedDemigodId === activeUser.id &&
            (t.status === "pending-answer" || t.status === "answered")
        );
        setInbox(ownTips);
      }
    } catch (e) {
      // ignore
    } finally {
      setInboxLoading(false);
    }
  }

  // ---------- LOAD MY TIPS (REQUESTER SIDE) ----------
  async function loadMyTips() {
    if (!activeUser || !activeUser.id) return;
    setMyTipsLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/tip/user/${activeUser.id}`);
      const data = await res.json();
      if (!res.ok) {
        // ignore
      } else {
        const reqTips = data.filter((t) => t.requesterId === activeUser.id);
        setMyTips(reqTips);
      }
    } catch (e) {
      // ignore
    } finally {
      setMyTipsLoading(false);
    }
  }

  // ---------- LOAD DEMIGOD EARNINGS ----------
  async function loadEarnings() {
    if (!activeUser || !activeUser.id) return;
    setEarningsLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/ledger/${activeUser.id}`);
      const data = await res.json();
      if (!res.ok) {
        // ignore
      } else {
        setEarnings(data);
      }
    } catch (e) {
      // ignore
    } finally {
      setEarningsLoading(false);
    }
  }

  // ---------- DEMIGOD ANSWER TIP ----------
  function setAnswerDraft(tipId, text) {
    setAnswerDrafts((prev) => ({ ...prev, [tipId]: text }));
  }

  async function handleAnswerTip(tipId) {
    if (!activeUser || !activeUser.id) return;
    const text = answerDrafts[tipId];
    if (!text || !text.trim()) return;
    try {
      const res = await fetch(`${API_BASE}/api/tip/answer`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tipId,
          demigodId: activeUser.id,
          answerText: text
        })
      });
      const data = await res.json();
      if (!res.ok) {
        // error handling
      } else {
        setInbox((prev) =>
          prev.map((t) => (t.id === tipId ? data.tip : t))
        );
        setEarnings(data.demigodEarnings);
        setAnswerDrafts((prev) => {
          const copy = { ...prev };
          delete copy[tipId];
          return copy;
        });
      }
    } catch (e) {
      // ignore
    }
  }

  return (
    <>
      <StyleInject />
      <div className="mdc-root">
        {/* HEADER */}
        <header className="mdc-header">
          <div className="mdc-title-area">
            <h1>MDC — Marketplace & Demigod Console</h1>
            <p>
              Inventory + AI valuation + Ask a Demigod + Inbox + Earnings unified.
            </p>
          </div>

          <div className="mdc-user-card">
            <div className="mdc-user-card-title">User Profile</div>
            <div className="mdc-row">
              <input
                className="mdc-input"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                placeholder="userId"
              />
            </div>
            <div className="mdc-row">
              <input
                className="mdc-input"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="username"
              />
            </div>
            <div className="mdc-row">
              <input
                className="mdc-input"
                type="number"
                value={score}
                onChange={(e) => setScore(Number(e.target.value))}
                placeholder="score (0-100)"
              />
            </div>
            <div className="mdc-checkbox-row">
              <input
                type="checkbox"
                checked={isDemigodOverride}
                onChange={(e) => setIsDemigodOverride(e.target.checked)}
              />
              <span>Force demigod (R6/R7 override)</span>
            </div>
            <div className="mdc-checkbox-row">
              <input
                type="checkbox"
                checked={isAvailable}
                onChange={(e) => setIsAvailable(e.target.checked)}
              />
              <span>Available for tips (inbox)</span>
            </div>
            <button
              className="mdc-btn"
              onClick={handleSaveUser}
              disabled={savingUser}
            >
              {savingUser ? "Saving..." : "Set / Update User"}
            </button>
            {activeUser && (
              <div className="mdc-tier-badge">
                <span>{activeUser.tier.id}</span>
                <span>{activeUser.tier.name}</span>
                <span>• score: {activeUser.score}</span>
                {activeUser.isDemigod && <span>• Demigod</span>}
                {activeUser.isAvailable && <span>• On-Duty</span>}
              </div>
            )}
            {userMessage && <div className="mdc-status ok">{userMessage}</div>}
            {userError && <div className="mdc-status err">{userError}</div>}
          </div>
        </header>

        {/* MAIN LAYOUT */}
        <main className="mdc-main">
          {/* LEFT: INVENTORY + MY TIPS */}
          <section className="mdc-panel">
            <h2>📦 Your Inventory & Valuation</h2>
            <p>
              Add project metadata, run market evaluation, and ask demigod tips for €1–5.
            </p>

            <div className="mdc-field">
              <label>Project title</label>
              <input
                className="mdc-input"
                value={invTitle}
                onChange={(e) => setInvTitle(e.target.value)}
                placeholder="e.g. Async API Orchestrator"
              />
            </div>
            <div className="mdc-field">
              <label>Language</label>
              <select
                className="mdc-input mdc-select"
                value={invLang}
                onChange={(e) => setInvLang(e.target.value)}
              >
                <option>javascript</option>
                <option>typescript</option>
                <option>python</option>
                <option>rust</option>
                <option>go</option>
                <option>java</option>
                <option>c++</option>
                <option>other</option>
              </select>
            </div>
            <div className="mdc-field">
              <label>Lines of code (approx)</label>
              <input
                className="mdc-input"
                type="number"
                value={invLines}
                onChange={(e) => setInvLines(Number(e.target.value))}
              />
            </div>
            <div className="mdc-field">
              <label>Category</label>
              <select
                className="mdc-input mdc-select"
                value={invCategory}
                onChange={(e) => setInvCategory(e.target.value)}
              >
                <option value="dev-tool">Dev tool</option>
                <option value="ai-tool">AI tool</option>
                <option value="niche-saas">Niche SaaS</option>
                <option value="general-saas">General SaaS</option>
                <option value="template">Template</option>
                <option value="script">Script</option>
                <option value="backend-service">Backend service</option>
                <option value="fullstack-app">Fullstack app</option>
              </select>
            </div>
            <div className="mdc-field">
              <label>Tags (comma separated)</label>
              <input
                className="mdc-input"
                value={invTags}
                onChange={(e) => setInvTags(e.target.value)}
                placeholder="e.g. ai,devtool,saas"
              />
            </div>
            <div className="mdc-field">
              <label>Complexity (1-5)</label>
              <input
                className="mdc-input"
                type="number"
                value={invComplexity}
                onChange={(e) => setInvComplexity(Number(e.target.value))}
              />
            </div>
            <div className="mdc-field">
              <label>Quality score (0-100)</label>
              <input
                className="mdc-input"
                type="number"
                value={invQuality}
                onChange={(e) => setInvQuality(Number(e.target.value))}
              />
            </div>
            <div className="mdc-field">
              <label>Test coverage (0-100%)</label>
              <input
                className="mdc-input"
                type="number"
                value={invTests}
                onChange={(e) => setInvTests(Number(e.target.value))}
              />
            </div>
            <div className="mdc-checkbox-row">
              <input
                type="checkbox"
                checked={invHasDocs}
                onChange={(e) => setInvHasDocs(e.target.checked)}
              />
              <span>Has docs / README</span>
            </div>
            <div className="mdc-checkbox-row">
              <input
                type="checkbox"
                checked={invIsTemplate}
                onChange={(e) => setInvIsTemplate(e.target.checked)}
              />
              <span>Template-like (reusable)</span>
            </div>
            <div className="mdc-checkbox-row">
              <input
                type="checkbox"
                checked={invIsLibrary}
                onChange={(e) => setInvIsLibrary(e.target.checked)}
              />
              <span>Library / package</span>
            </div>
            <div className="mdc-field">
              <label>Short description / code summary</label>
              <textarea
                className="mdc-textarea"
                value={invDescription}
                onChange={(e) => setInvDescription(e.target.value)}
                placeholder="Summary of what this code does..."
              />
            </div>
            <button className="mdc-btn" onClick={handleAddToInventory}>
              Add to Inventory
            </button>

            <div className="mdc-inv-list">
              {inventory.map((proj) => (
                <div key={proj.id} className="mdc-inv-card">
                  <div className="mdc-inv-title">{proj.title}</div>
                  <div className="mdc-inv-meta">
                    Lang: {proj.language} • LOC: {proj.linesOfCode} • Cat:{" "}
                    {proj.category}
                  </div>
                  {proj.tags && proj.tags.length > 0 && (
                    <div>
                      {proj.tags.map((t) => (
                        <span key={t} className="mdc-chip">
                          #{t}
                        </span>
                      ))}
                    </div>
                  )}

                  <div className="mdc-inv-actions">
                    <button
                      className="mdc-btn-secondary"
                      onClick={() => handleEvaluateProject(proj.id)}
                      disabled={evalLoadingId === proj.id}
                    >
                      {evalLoadingId === proj.id
                        ? "Evaluating..."
                        : "Evaluate Market Value"}
                    </button>
                    <button
                      className="mdc-btn-secondary"
                      onClick={() => openTipModal(proj.id)}
                    >
                      Ask a Demigod Tip (€1–5)
                    </button>
                  </div>

                  {proj.evalResult && (
                    <div className="mdc-eval">
                      {proj.evalResult.error ? (
                        <div className="mdc-eval-row">
                          Error: {proj.evalResult.error}
                        </div>
                      ) : (
                        <>
                          <div className="mdc-eval-row">
                            <span className="mdc-stars">
                              {"★".repeat(proj.evalResult.stars)}
                              {"☆".repeat(5 - proj.evalResult.stars)}
                            </span>{" "}
                            • Score: {proj.evalResult.score}/100 • Category:{" "}
                            {proj.evalResult.marketCategory}
                          </div>
                          <div className="mdc-eval-row">
                            Value: €{proj.evalResult.price.min} – €
                            {proj.evalResult.price.max} (base ~€
                            {proj.evalResult.price.base})
                          </div>
                          <div className="mdc-eval-expl">
                            <strong>AI Summary:</strong>{" "}
                            {proj.evalResult.explanation?.summary ||
                              "n/a"}
                            {proj.evalResult.explanation?.pricingRationale && (
                              <>
                                <br />
                                <br />
                                <strong>Pricing rationale:</strong>{" "}
                                {proj.evalResult.explanation.pricingRationale}
                              </>
                            )}
                          </div>
                        </>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* MY TIPS */}
            <h2 style={{ marginTop: 18 }}>💬 Your Demigod Tips</h2>
            <p>
              Your sent tip requests – pending or answered.
            </p>
            <button
              className="mdc-btn-secondary"
              onClick={loadMyTips}
              disabled={myTipsLoading || !activeUser}
            >
              {myTipsLoading ? "Loading..." : "Refresh My Tips"}
            </button>
            <div className="mdc-my-tips-list">
              {myTips.map((t) => (
                <div key={t.id} className="mdc-my-tip-card">
                  <div>
                    <strong>Q:</strong> {t.question}
                  </div>
                  <div className="mdc-my-tip-status">
                    Status: {t.status} • Price: €{t.priceEUR} • Demigod:{" "}
                    {t.assignedDemigodName || "TBD"}
                  </div>
                  {t.answerText && (
                    <div className="mdc-my-tip-answer">
                      <strong>Demigod answer:</strong> {t.answerText}
                    </div>
                  )}
                </div>
              ))}
              {!myTips.length && (
                <div className="mdc-my-tip-status">
                  No tips yet or not loaded (Refresh My Tips).
                </div>
              )}
            </div>
          </section>

          {/* RIGHT: DEMIGOD INBOX + EARNINGS */}
          <section className="mdc-panel">
            <h2>🧙 Demigod Inbox & Earnings</h2>
            <p>
              If you're a demigod, see assigned tip requests and earnings.
            </p>

            <button
              className="mdc-btn-secondary"
              onClick={loadInbox}
              disabled={inboxLoading || !activeUser}
            >
              {inboxLoading ? "Loading inbox..." : "Load Demigod Inbox"}
            </button>
            <button
              className="mdc-btn-secondary"
              style={{ marginLeft: 6 }}
              onClick={loadEarnings}
              disabled={earningsLoading || !activeUser}
            >
              {earningsLoading ? "Loading earnings..." : "Load Earnings"}
            </button>

            {earnings && (
              <div className="mdc-earnings">
                <div>
                  <strong>Demigod:</strong> {earnings.demigodName} (
                  {earnings.demigodId})
                </div>
                <div>
                  <strong>Total tips:</strong> {earnings.totalTips}
                </div>
                <div>
                  <strong>Answered tips:</strong> {earnings.totalAnswered}
                </div>
                <div>
                  <strong>Total earned:</strong> €{earnings.totalEarnedEUR}
                </div>
              </div>
            )}

            <h2 style={{ marginTop: 16 }}>📥 Inbox</h2>
            <p>
              Pending + answered tips assigned to your demigod profile.
            </p>

            <div className="mdc-inbox-list">
              {inbox.map((t) => (
                <div key={t.id} className="mdc-inbox-card">
                  <div className="mdc-inbox-head">
                    <div>
                      <strong>{t.requesterName}</strong> asks
                    </div>
                    <span>
                      Tip: €{t.priceEUR} • Status: {t.status}
                    </span>
                  </div>
                  <div className="mdc-inbox-question">
                    <strong>Q:</strong> {t.question}
                  </div>
                  <div className="mdc-code-snippet-box">
                    <strong>Snippet / Summary:</strong>
                    <br />
                    {t.codeSnippet}
                  </div>

                  {t.status === "pending-answer" && activeUser?.isDemigod && (
                    <div className="mdc-inbox-answer-box">
                      <div style={{ fontSize: 11, opacity: 0.8 }}>
                        Answer: give a 1–5 sentence concrete tip.
                      </div>
                      <textarea
                        className="mdc-inbox-answer"
                        value={answerDrafts[t.id] || ""}
                        onChange={(e) =>
                          setAnswerDraft(t.id, e.target.value)
                        }
                        placeholder="Your demigod-level insight..."
                      />
                      <button
                        className="mdc-btn-secondary"
                        style={{ marginTop: 4 }}
                        onClick={() => handleAnswerTip(t.id)}
                      >
                        Send Answer & Earn
                      </button>
                    </div>
                  )}

                  {t.status === "answered" && (
                    <div className="mdc-my-tip-answer" style={{ marginTop: 6 }}>
                      <strong>Your answer:</strong> {t.answerText}
                    </div>
                  )}
                </div>
              ))}
              {!inbox.length && (
                <div className="mdc-my-tip-status">
                  Inbox empty or not loaded. Enable "Available for tips" if demigod.
                </div>
              )}
            </div>
          </section>
        </main>

        {/* TIP MODAL */}
        {tipModalOpen && (
          <div className="mdc-modal-backdrop">
            <div className="mdc-modal">
              <div className="mdc-modal-header">
                <h3>Ask a Demigod Tip</h3>
                <div
                  className="mdc-modal-close"
                  onClick={closeTipModal}
                >
                  ✕
                </div>
              </div>
              <p className="mdc-tagline">
                Choose price, write question, get expert answer from available demigod.
              </p>

              <div className="mdc-field">
                <label>Tip tier</label>
                <div className="mdc-tip-price-options">
                  <button
                    className="mdc-btn-secondary"
                    style={{
                      borderColor:
                        tipPriceTier === "micro" ? "#c98eff" : "#3c345a"
                    }}
                    onClick={() => setTipPriceTier("micro")}
                  >
                    Micro (€1)
                  </button>
                  <button
                    className="mdc-btn-secondary"
                    style={{
                      borderColor:
                        tipPriceTier === "mini" ? "#c98eff" : "#3c345a"
                    }}
                    onClick={() => setTipPriceTier("mini")}
                  >
                    Mini (€3)
                  </button>
                  <button
                    className="mdc-btn-secondary"
                    style={{
                      borderColor:
                        tipPriceTier === "deep" ? "#c98eff" : "#3c345a"
                    }}
                    onClick={() => setTipPriceTier("deep")}
                  >
                    Deep (€5)
                  </button>
                </div>
              </div>

              <div className="mdc-field">
                <label>Custom price (optional)</label>
                <input
                  className="mdc-input"
                  type="number"
                  value={tipCustomPrice}
                  onChange={(e) => setTipCustomPrice(e.target.value)}
                  placeholder="e.g. 2.5"
                />
              </div>

              <div className="mdc-field">
                <label>Your question</label>
                <textarea
                  className="mdc-textarea"
                  value={tipQuestion}
                  onChange={(e) => setTipQuestion(e.target.value)}
                  placeholder="Ask a specific question: performance tuning, architecture, async pattern, etc."
                />
              </div>

              <button
                className="mdc-btn"
                onClick={handleSendTipRequest}
                disabled={tipSending}
              >
                {tipSending ? "Sending..." : "Send Tip Request"}
              </button>

              {tipModalMessage && (
                <div
                  className="mdc-status"
                  style={{ marginTop: 8 }}
                >
                  {tipModalMessage}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </>
  );
}