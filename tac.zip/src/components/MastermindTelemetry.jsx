/**
 * Mastermind Telemetry Utility
 * Base44-compatible version
 * 
 * Use this to report metrics from any module (FutureMind, CodeForge, etc.)
 */

/**
 * Log a metric to the Mastermind system
 * 
 * @param {string} moduleName - Name of the reporting module
 * @param {Object} payload - Metric data
 * @param {string} payload.role - Module role (pattern, generator, matcher, etc.)
 * @param {number} payload.latencyMs - Operation latency in milliseconds
 * @param {boolean} payload.success - Whether operation succeeded
 * @param {string} payload.errorCode - Error code if failed
 * @param {Object} payload.meta - Additional metadata
 * 
 * @returns {Promise<boolean>} - Success status
 * 
 * @example
 * // Basic success metric
 * await logMetric('FutureMind', {
 *   role: 'pattern',
 *   latencyMs: 450,
 *   success: true
 * });
 * 
 * @example
 * // Error metric with details
 * await logMetric('CodeForge', {
 *   role: 'generator',
 *   latencyMs: 1200,
 *   success: false,
 *   errorCode: 'TIMEOUT',
 *   meta: { attempted_lines: 150 }
 * });
 * 
 * @example
 * // With metadata
 * await logMetric('ValueAnalyst', {
 *   role: 'pricing',
 *   latencyMs: 800,
 *   success: true,
 *   meta: {
 *     estimated_price: 500,
 *     complexity: 'high',
 *     language: 'javascript'
 *   }
 * });
 */
export async function logMetric(moduleName, payload = {}) {
  if (!moduleName) {
    console.warn('[Mastermind] logMetric called without moduleName');
    return false;
  }

  try {
    const response = await fetch('/api/mastermind/metric', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        moduleName,
        role: payload.role || 'unknown',
        latencyMs: typeof payload.latencyMs === 'number' ? payload.latencyMs : null,
        success: typeof payload.success === 'boolean' ? payload.success : true,
        errorCode: payload.errorCode || null,
        meta: payload.meta || {}
      })
    });

    if (!response.ok) {
      console.error('[Mastermind] Failed to log metric:', response.status);
      return false;
    }

    return true;
  } catch (error) {
    console.error('[Mastermind] Error logging metric:', error);
    return false;
  }
}

/**
 * Wrapper to track an async operation and automatically log metrics
 * 
 * @param {string} moduleName - Name of the module
 * @param {string} role - Module role
 * @param {Function} operation - Async function to execute
 * @param {Object} extraMeta - Additional metadata to log
 * 
 * @returns {Promise<any>} - Result of the operation
 * 
 * @example
 * const result = await trackOperation('FutureMind', 'pattern', async () => {
 *   return await extractPatterns(code);
 * }, { code_length: code.length });
 */
export async function trackOperation(moduleName, role, operation, extraMeta = {}) {
  const start = Date.now();
  
  try {
    const result = await operation();
    
    await logMetric(moduleName, {
      role,
      latencyMs: Date.now() - start,
      success: true,
      meta: extraMeta
    });
    
    return result;
  } catch (error) {
    await logMetric(moduleName, {
      role,
      latencyMs: Date.now() - start,
      success: false,
      errorCode: error.code || error.name || 'UNKNOWN',
      meta: {
        ...extraMeta,
        error_message: error.message
      }
    });
    
    throw error; // Re-throw to maintain error handling chain
  }
}

/**
 * Create a telemetry-enabled wrapper for a module
 * 
 * @param {string} moduleName - Name of the module
 * @param {string} defaultRole - Default role for the module
 * 
 * @returns {Object} - Telemetry logger with bound module name
 * 
 * @example
 * const telemetry = createModuleTelemetry('FutureMind', 'pattern');
 * 
 * // Log success
 * await telemetry.log({ latencyMs: 450, success: true });
 * 
 * // Track operation
 * const patterns = await telemetry.track(async () => {
 *   return await extractPatterns(code);
 * });
 */
export function createModuleTelemetry(moduleName, defaultRole = 'unknown') {
  return {
    /**
     * Log a metric for this module
     */
    log: async (payload = {}) => {
      return await logMetric(moduleName, {
        role: defaultRole,
        ...payload
      });
    },
    
    /**
     * Track an operation for this module
     */
    track: async (operation, extraMeta = {}) => {
      return await trackOperation(moduleName, defaultRole, operation, extraMeta);
    },
    
    /**
     * Log success metric
     */
    logSuccess: async (latencyMs, meta = {}) => {
      return await logMetric(moduleName, {
        role: defaultRole,
        latencyMs,
        success: true,
        meta
      });
    },
    
    /**
     * Log error metric
     */
    logError: async (latencyMs, errorCode, meta = {}) => {
      return await logMetric(moduleName, {
        role: defaultRole,
        latencyMs,
        success: false,
        errorCode,
        meta
      });
    }
  };
}

/**
 * Batch log multiple metrics at once (fire and forget)
 * 
 * @param {Array<{moduleName: string, payload: Object}>} metrics
 * 
 * @example
 * await batchLogMetrics([
 *   { moduleName: 'FutureMind', payload: { role: 'pattern', latencyMs: 450, success: true } },
 *   { moduleName: 'CodeForge', payload: { role: 'generator', latencyMs: 1200, success: true } }
 * ]);
 */
export async function batchLogMetrics(metrics) {
  if (!Array.isArray(metrics) || metrics.length === 0) {
    return;
  }

  try {
    await Promise.all(
      metrics.map(({ moduleName, payload }) => logMetric(moduleName, payload))
    );
  } catch (error) {
    console.error('[Mastermind] Batch logging failed:', error);
  }
}

// Export default for convenience
export default {
  logMetric,
  trackOperation,
  createModuleTelemetry,
  batchLogMetrics
};