import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, Download, CheckCircle2, Award, Play, Gift } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const categoryNames = {
  productivity: "Productivity",
  development: "Development",
  design: "Design",
  business: "Business",
  games: "Games",
  education: "Education",
  utilities: "Utilities",
  other: "Other"
};

const licenseNames = {
  BASIC: "Basic",
  EXTENDED: "Extended",
  EXCLUSIVE: "Exclusive"
};

export default function AppCard({ app, showTryButton = false }) {
  return (
    <Link to={createPageUrl("AppDetail") + `?id=${app.id}`}>
      <Card className="border transition-all hover:shadow-lg hover:scale-[1.02] cursor-pointer h-full flex flex-col" style={{
        borderColor: 'rgba(148, 163, 184, 0.35)',
        background: 'rgba(15, 23, 42, 0.95)'
      }}>
        <div className="p-4 flex-1 flex flex-col">
          {/* Icon & Title */}
          <div className="flex items-start gap-3 mb-3">
            <div className="w-14 h-14 flex-shrink-0 rounded-xl flex items-center justify-center" style={{
              background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.2), rgba(36, 228, 255, 0.2))',
              border: '1px solid rgba(148, 163, 184, 0.3)'
            }}>
              {app.icon_url ? (
                <img src={app.icon_url} alt={app.name} className="w-full h-full object-contain rounded-lg" />
              ) : (
                <div className="w-full h-full rounded-lg flex items-center justify-center text-2xl font-black" style={{
                  background: 'linear-gradient(to bottom right, var(--accent), var(--accent-alt))',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent'
                }}>
                  {app.name.charAt(0).toUpperCase()}
                </div>
              )}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-bold text-white text-sm truncate">{app.name}</h3>
                {app.verified && (
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
                )}
                {app.featured && (
                  <Award className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" />
                )}
              </div>
              <p className="text-xs text-gray-400 truncate">{app.developer}</p>
            </div>
          </div>

          {/* Description */}
          <p className="text-xs text-gray-300 mb-3 line-clamp-2 leading-relaxed">
            {app.description}
          </p>

          {/* Stats */}
          <div className="flex items-center gap-3 mb-3 text-xs">
            <div className="flex items-center gap-1">
              <Star className="w-3.5 h-3.5 text-yellow-400" />
              <span className="text-white font-semibold">
                {app.rating ? app.rating.toFixed(1) : '0.0'}
              </span>
            </div>
            <div className="flex items-center gap-1 text-gray-400">
              <Download className="w-3.5 h-3.5" />
              <span>{app.downloads || 0}</span>
            </div>
            {app.innovation_score && (
              <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30 text-[0.65rem] px-1.5 py-0">
                Innovation {app.innovation_score}
              </Badge>
            )}
          </div>

          {/* Bounty Badge (if exists) */}
          {app.active_bounties && app.active_bounties > 0 && (
            <div className="mb-3">
              <Badge className="bg-green-600/20 text-green-300 border-green-600/30 text-[0.65rem] w-full justify-center">
                <Gift className="w-3 h-3 mr-1" />
                {app.active_bounties} Active {app.active_bounties === 1 ? 'Bounty' : 'Bounties'}
              </Badge>
            </div>
          )}

          {/* Tags */}
          <div className="flex flex-wrap gap-1 mb-3">
            <Badge className="text-[0.65rem] px-1.5 py-0" style={{ 
              background: 'rgba(148, 163, 184, 0.15)', 
              color: 'var(--text-muted)',
              border: '1px solid rgba(148, 163, 184, 0.25)'
            }}>
              {categoryNames[app.category]}
            </Badge>
            <Badge className="text-[0.65rem] px-1.5 py-0 bg-purple-600/20 text-purple-300 border-purple-600/30">
              {licenseNames[app.license_type || 'BASIC']}
            </Badge>
            {app.tech_stack && app.tech_stack.slice(0, 2).map((tech, idx) => (
              <Badge key={idx} className="text-[0.65rem] px-1.5 py-0" style={{ 
                background: 'rgba(36, 228, 255, 0.15)', 
                color: 'var(--accent-alt)',
                border: '1px solid rgba(36, 228, 255, 0.25)'
              }}>
                {tech}
              </Badge>
            ))}
          </div>

          {/* Price & Try Button */}
          <div className="mt-auto pt-3 border-t" style={{ borderColor: 'rgba(148, 163, 184, 0.2)' }}>
            <div className="flex items-center justify-between gap-2">
              <div className="text-lg font-bold" style={{ 
                color: app.price === 0 ? 'var(--accent-alt)' : 'white' 
              }}>
                {app.price === 0 ? 'FREE' : `${app.price} ${app.currency || 'Ft'}`}
              </div>
              {showTryButton && app.demo_url && (
                <Button 
                  size="sm" 
                  className="text-xs px-2 py-1 h-7"
                  style={{ 
                    background: 'rgba(36, 228, 255, 0.2)',
                    color: 'var(--accent-alt)',
                    border: '1px solid rgba(36, 228, 255, 0.4)'
                  }}
                  onClick={(e) => {
                    e.preventDefault();
                    window.open(app.demo_url, '_blank');
                  }}
                >
                  <Play className="w-3 h-3 mr-1" />
                  Try
                </Button>
              )}
            </div>
          </div>
        </div>
      </Card>
    </Link>
  );
}