import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Trophy, Sparkles, Target, Zap, 
  Shield, Award, Lightbulb, ChevronDown, ChevronUp 
} from "lucide-react";

const DIMENSION_CONFIG = {
  quality: { icon: Target, color: "text-blue-400", label: "Quality" },
  performance: { icon: Zap, color: "text-green-400", label: "Performance" },
  safety: { icon: Shield, color: "text-red-400", label: "Safety" },
  elegance: { icon: Award, color: "text-purple-400", label: "Elegance" },
  innovation: { icon: Lightbulb, color: "text-yellow-400", label: "Innovation" }
};

function PlayerScoreRow({ entry, index, isWinner, isTop3, isFinished, onToggleExpand, isExpanded }) {
  const Icon = isWinner ? Trophy : Sparkles;
  
  return (
    <div
      className={`rounded-lg border transition-all ${
        isWinner 
          ? 'bg-gradient-to-r from-purple-600/20 to-pink-600/20 border-purple-500/50' 
          : 'bg-[#0a0a0f] border-[#1a1f2e]'
      }`}
    >
      <div className="flex items-center justify-between p-3">
        <div className="flex items-center gap-3 flex-1">
          <div className={`flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold ${
            isWinner 
              ? 'bg-purple-500 text-white'
              : isTop3
              ? 'bg-gray-600 text-white'
              : 'bg-[#141923] text-gray-400'
          }`}>
            {index + 1}
          </div>
          
          <div className="flex-1">
            <div className={`text-sm font-semibold ${
              isWinner ? 'text-purple-400' : 'text-white'
            }`}>
              {entry.username}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Badge className={
            entry.totalScore >= 80 
              ? 'bg-green-600/20 text-green-400 border-green-600/30'
              : entry.totalScore >= 60
              ? 'bg-yellow-600/20 text-yellow-400 border-yellow-600/30'
              : 'bg-gray-600/20 text-gray-400 border-gray-600/30'
          }>
            {entry.totalScore} pts
          </Badge>
          
          {isWinner && <Icon className="w-5 h-5 text-yellow-400" />}
          
          {entry.breakdown && (
            <Button
              onClick={onToggleExpand}
              size="sm"
              variant="ghost"
              className="p-1 h-6 w-6"
            >
              {isExpanded ? (
                <ChevronUp className="w-4 h-4 text-gray-400" />
              ) : (
                <ChevronDown className="w-4 h-4 text-gray-400" />
              )}
            </Button>
          )}
        </div>
      </div>

      {/* Breakdown (expanded) */}
      {isExpanded && entry.breakdown && (
        <div className="px-3 pb-3 pt-0 grid grid-cols-5 gap-2">
          {Object.entries(DIMENSION_CONFIG).map(([key, cfg]) => {
            const DimIcon = cfg.icon;
            const value = entry.breakdown[key] || 0;
            
            return (
              <div key={key} className="p-2 rounded bg-[#141923] border border-[#1a1f2e] text-center">
                <DimIcon className={`w-3 h-3 ${cfg.color} mx-auto mb-1`} />
                <div className="text-xs font-bold text-white">{value}</div>
                <div className="text-[0.6rem] text-gray-500">{cfg.label}</div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default function InnovationScoreboard({ scores, matchFinishedData, isFinished }) {
  const [expandedPlayers, setExpandedPlayers] = useState(new Set());

  const displayScores = isFinished && matchFinishedData?.finalScores 
    ? matchFinishedData.finalScores 
    : scores;

  if (!displayScores || displayScores.length === 0) {
    return (
      <Card className="border-[#1a1f2e] bg-[#141923] p-4">
        <h3 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-purple-400" />
          Innovation Scores
        </h3>
        <div className="text-xs text-gray-500 text-center py-4">
          No submissions yet. Submit your innovative solution to appear on the board!
        </div>
      </Card>
    );
  }

  const sortedScores = [...displayScores].sort((a, b) => b.totalScore - a.totalScore);

  const toggleExpand = (playerId) => {
    setExpandedPlayers(prev => {
      const newSet = new Set(prev);
      if (newSet.has(playerId)) {
        newSet.delete(playerId);
      } else {
        newSet.add(playerId);
      }
      return newSet;
    });
  };

  return (
    <Card className="border-[#1a1f2e] bg-[#141923] p-4">
      <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
        {isFinished ? (
          <>
            <Trophy className="w-4 h-4 text-yellow-400" />
            Final Innovation Rankings
          </>
        ) : (
          <>
            <Sparkles className="w-4 h-4 text-purple-400" />
            Live Innovation Scores
          </>
        )}
      </h3>

      <div className="space-y-2">
        {sortedScores.map((entry, index) => {
          const isWinner = index === 0 && isFinished;
          const isTop3 = index < 3;
          const isExpanded = expandedPlayers.has(entry.playerId);
          
          return (
            <PlayerScoreRow
              key={entry.playerId}
              entry={entry}
              index={index}
              isWinner={isWinner}
              isTop3={isTop3}
              isFinished={isFinished}
              isExpanded={isExpanded}
              onToggleExpand={() => toggleExpand(entry.playerId)}
            />
          );
        })}
      </div>

      {!isFinished && (
        <div className="mt-3 p-2 rounded bg-[#0a0a0f] border border-[#1a1f2e]">
          <div className="flex items-center gap-2">
            <Sparkles className="w-3 h-3 text-purple-400" />
            <span className="text-xs text-gray-400">
              Click arrows to see innovation breakdown across 5 dimensions
            </span>
          </div>
        </div>
      )}
    </Card>
  );
}