import React from 'react';

export default function CodeRepoSidebar({ selectedRepo, onRepoSelect, onFileSelect }) {
  const repos = [
    {
      id: 'tac-core-system',
      icon: '📁',
      name: 'tac-core-system',
      desc: 'Core AI orchestration'
    },
    {
      id: 'ai-modules',
      icon: '🧠',
      name: 'ai-modules',
      desc: 'Paradox · Chaos · Hallucinator'
    },
    {
      id: 'paradox-engine',
      icon: '🌀',
      name: 'paradox-engine',
      desc: 'Recursive reasoning core'
    },
    {
      id: 'chaos-architect',
      icon: '🔮',
      name: 'chaos-architect',
      desc: 'Insane idea generator'
    },
    {
      id: 'hallucinator',
      icon: '👁️',
      name: 'hallucinator',
      desc: 'What-if dimension explorer'
    }
  ];

  return (
    <section className="panel-3d panel-3d-base w-full md:w-64 bg-[#0c0217] border border-purple-900/80 rounded-2xl shadow-depth p-4">
      <div className="glow-outline inline-flex items-center gap-2 px-2.5 py-1 rounded-full border bg-black/60 mb-4">
        <span className="w-1.5 h-1.5 rounded-full bg-green-500 shadow-glowNeon"></span>
        <span className="text-[11px] uppercase tracking-[0.22em] text-purple-100">Repos</span>
      </div>

      <ul className="space-y-2 text-[13px]">
        {repos.map((repo) => (
          <li
            key={repo.id}
            onClick={() => {
              onRepoSelect(repo.id);
              onFileSelect('src/paradoxEngine.js');
            }}
            className={`rounded-xl border px-3 py-2 cursor-pointer transition-all ${
              selectedRepo === repo.id
                ? 'border-purple-700/80 bg-black/60 shadow-glowSoft'
                : 'border-slate-700/70 bg-black/50 hover:shadow-glow'
            }`}
          >
            <div className="flex items-center gap-2">
              <span>{repo.icon}</span>
              <div>
                <p className="font-medium text-slate-100">{repo.name}</p>
                <p className="text-[11px] text-slate-400">{repo.desc}</p>
              </div>
            </div>
          </li>
        ))}
      </ul>

      <style jsx>{`
        .shadow-glowNeon {
          box-shadow: 0 0 14px rgba(34,197,94,0.9);
        }
        .shadow-glowSoft {
          box-shadow: 0 0 12px rgba(168,85,247,0.55);
        }
        .shadow-glow {
          box-shadow: 0 0 18px rgba(168,85,247,0.85);
        }
        .glow-outline {
          box-shadow: 0 0 12px rgba(168,85,247,0.9);
          border-color: rgba(196,181,253,0.85);
        }
        .shadow-depth {
          box-shadow: 0 25px 45px rgba(0,0,0,0.85);
        }
      `}</style>
    </section>
  );
}