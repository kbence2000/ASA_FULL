import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  ArrowLeft, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  AlertTriangle,
  Loader2,
  Code2,
  Zap,
  DollarSign,
  Timer,
  Terminal,
  RefreshCw
} from "lucide-react";
import ReactMarkdown from "react-markdown";
import { formatDistanceToNow } from "date-fns";
import MissionLogs from "./MissionLogs";
import MissionFailureAnalysis from "./MissionFailureAnalysis";

export default function MissionDetail({ mission, onBack }) {
  const getStatusIcon = (status) => {
    switch (status) {
      case "completed": return <CheckCircle2 className="w-6 h-6 text-green-400" />;
      case "running": return <Loader2 className="w-6 h-6 text-blue-400 animate-spin" />;
      case "failed": return <XCircle className="w-6 h-6 text-red-400" />;
      case "expired": return <AlertTriangle className="w-6 h-6 text-orange-400" />;
      case "pending": return <Clock className="w-6 h-6 text-gray-400" />;
      default: return <Clock className="w-6 h-6 text-gray-400" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "completed": return "text-green-400";
      case "running": return "text-blue-400";
      case "failed": return "text-red-400";
      case "expired": return "text-orange-400";
      default: return "text-gray-400";
    }
  };

  const formatTTL = (ms) => {
    if (!ms) return "N/A";
    const minutes = Math.floor(ms / 60000);
    if (minutes < 60) return `${minutes} minutes`;
    const hours = Math.floor(minutes / 60);
    const remainingMins = minutes % 60;
    return `${hours}h ${remainingMins}m`;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button
          onClick={onBack}
          variant="outline"
          size="icon"
          className="border-[#1a1f2e] text-gray-400 hover:text-white"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex-1">
          <h2 className="text-2xl font-bold text-white">Mission Details</h2>
          <p className="text-sm text-gray-400">ID: {mission.missionId}</p>
        </div>
      </div>

      {/* Status Card */}
      <Card className="border p-6" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <div className="flex items-start gap-4">
          {getStatusIcon(mission.status)}
          <div className="flex-1">
            <h3 className="text-xl font-bold text-white mb-2">
              {mission.description}
            </h3>
            <div className="flex flex-wrap gap-2">
              <Badge className={`${getStatusColor(mission.status)} border-current text-xs`}>
                {mission.status.toUpperCase()}
              </Badge>
              <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30 text-xs">
                {mission.complexity} complexity
              </Badge>
              {mission.budget && (
                <Badge className="bg-cyan-600/20 text-cyan-300 border-cyan-600/30 text-xs">
                  ${mission.budget} budget
                </Badge>
              )}
              {mission.freeRetry && (
                <Badge className="bg-orange-600/20 text-orange-300 border-orange-600/30 text-xs">
                  <RefreshCw className="w-3 h-3 mr-1" />
                  Free Retry
                </Badge>
              )}
              {mission.retries > 0 && (
                <Badge className="bg-yellow-600/20 text-yellow-300 border-yellow-600/30 text-xs">
                  Retry #{mission.retries}
                </Badge>
              )}
            </div>
          </div>
        </div>
      </Card>

      {/* Timeline */}
      <Card className="border p-6" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <Timer className="w-5 h-5 text-purple-400" />
          Timeline
        </h3>
        <div className="space-y-3 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-gray-400">Created:</span>
            <span className="text-white">
              {mission.created_date 
                ? formatDistanceToNow(new Date(mission.created_date), { addSuffix: true })
                : "just now"
              }
            </span>
          </div>
          {mission.startedAt && (
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Started:</span>
              <span className="text-white">
                {formatDistanceToNow(new Date(mission.startedAt), { addSuffix: true })}
              </span>
            </div>
          )}
          {mission.completedAt && (
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Completed:</span>
              <span className="text-green-400">
                {formatDistanceToNow(new Date(mission.completedAt), { addSuffix: true })}
              </span>
            </div>
          )}
          <div className="flex items-center justify-between">
            <span className="text-gray-400">TTL:</span>
            <span className="text-cyan-400">{formatTTL(mission.ttlMs)}</span>
          </div>
          {mission.expiresAt && mission.status !== "completed" && (
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Expires:</span>
              <span className="text-orange-400">
                {formatDistanceToNow(new Date(mission.expiresAt), { addSuffix: true })}
              </span>
            </div>
          )}
          {mission.retryOf && (
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Retry of:</span>
              <span className="text-purple-400 font-mono text-xs">{mission.retryOf}</span>
            </div>
          )}
        </div>
      </Card>

      {/* Sandbox Info */}
      {mission.sandboxConfig && (
        <Card className="border p-6" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Terminal className="w-5 h-5 text-cyan-400" />
            Sandbox
          </h3>
          <div className="space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Sandbox ID:</span>
              <span className="text-white font-mono">{mission.sandboxId}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Config Path:</span>
              <span className="text-cyan-400 font-mono text-xs">
                {mission.sandboxConfig.firecrackerConfigPath}
              </span>
            </div>
          </div>
        </Card>
      )}

      {/* Failure Analysis */}
      {mission.failureAnalysis && (
        <MissionFailureAnalysis 
          analysis={mission.failureAnalysis} 
          mission={mission}
        />
      )}

      {/* Logs */}
      {mission.logs && mission.logs.length > 0 && (
        <MissionLogs logs={mission.logs} />
      )}

      {/* Code Payload */}
      {mission.payload?.code && (
        <Card className="border p-6" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Code2 className="w-5 h-5 text-green-400" />
            Code Snippet
          </h3>
          <pre className="bg-[#0f0a1f] border border-[#1a1f2e] rounded-lg p-4 text-xs overflow-x-auto font-mono text-gray-300">
            {mission.payload.code}
          </pre>
        </Card>
      )}

      {/* Result */}
      {mission.result?.text && (
        <Card className="border p-6" style={{
          background: 'linear-gradient(135deg, rgba(34, 197, 94, 0.05), rgba(59, 130, 246, 0.05))',
          borderColor: 'rgba(34, 197, 94, 0.3)'
        }}>
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Zap className="w-5 h-5 text-green-400" />
            Mission Result
          </h3>
          <ReactMarkdown 
            className="prose prose-sm prose-invert max-w-none"
            components={{
              h1: ({children}) => <h1 className="text-xl font-bold text-green-300 mb-3">{children}</h1>,
              h2: ({children}) => <h2 className="text-lg font-bold text-cyan-300 mb-2 mt-4">{children}</h2>,
              h3: ({children}) => <h3 className="text-base font-bold text-white mb-2 mt-3">{children}</h3>,
              p: ({children}) => <p className="text-gray-300 mb-3 leading-relaxed">{children}</p>,
              code: ({inline, children}) => 
                inline 
                  ? <code className="px-1.5 py-0.5 rounded bg-[#0f0a1f] text-cyan-300 text-xs">{children}</code>
                  : <code className="block bg-[#0f0a1f] rounded p-3 text-xs overflow-x-auto text-gray-300">{children}</code>,
              ul: ({children}) => <ul className="list-disc ml-6 mb-3 text-gray-300">{children}</ul>,
              ol: ({children}) => <ol className="list-decimal ml-6 mb-3 text-gray-300">{children}</ol>,
              li: ({children}) => <li className="mb-1">{children}</li>,
            }}
          >
            {mission.result.text}
          </ReactMarkdown>

          {mission.tokensUsed && (
            <div className="mt-4 pt-4 border-t border-green-600/30 text-sm text-gray-400">
              Tokens used: <span className="text-green-400 font-semibold">{mission.tokensUsed}</span>
            </div>
          )}
        </Card>
      )}

      {/* Error */}
      {mission.error && (
        <Card className="border p-6" style={{
          background: 'linear-gradient(135deg, rgba(239, 68, 68, 0.05), rgba(220, 38, 38, 0.05))',
          borderColor: 'rgba(239, 68, 68, 0.3)'
        }}>
          <h3 className="text-lg font-bold text-red-400 mb-4 flex items-center gap-2">
            <XCircle className="w-5 h-5" />
            Error
          </h3>
          <p className="text-gray-300">{mission.error.message}</p>
          {mission.error.at && (
            <p className="text-sm text-gray-500 mt-2">
              {formatDistanceToNow(new Date(mission.error.at), { addSuffix: true })}
            </p>
          )}
        </Card>
      )}
    </div>
  );
}