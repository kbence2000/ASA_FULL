import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Users, Clock, DollarSign, AlertTriangle,
  Sparkles, Zap, Target
} from "lucide-react";

const PACKAGE_CONFIG = {
  smart_budget: { 
    icon: Target, 
    color: "text-blue-400", 
    gradient: "from-blue-600 to-cyan-600" 
  },
  balanced_power: { 
    icon: Sparkles, 
    color: "text-purple-400", 
    gradient: "from-purple-600 to-pink-600" 
  },
  premium_speedrun: { 
    icon: Zap, 
    color: "text-yellow-400", 
    gradient: "from-yellow-600 to-orange-600" 
  }
};

const RISK_CONFIG = {
  low: { color: "text-green-400", bg: "bg-green-600/20", border: "border-green-600/30" },
  medium: { color: "text-yellow-400", bg: "bg-yellow-600/20", border: "border-yellow-600/30" },
  "medium-high": { color: "text-orange-400", bg: "bg-orange-600/20", border: "border-orange-600/30" },
  high: { color: "text-red-400", bg: "bg-red-600/20", border: "border-red-600/30" }
};

export default function DealPackageCard({ package: pkg }) {
  const pkgCfg = PACKAGE_CONFIG[pkg.id] || PACKAGE_CONFIG.balanced_power;
  const riskCfg = RISK_CONFIG[pkg.riskLevel] || RISK_CONFIG.medium;
  const Icon = pkgCfg.icon;

  return (
    <Card className="border-[#1a1f2e] bg-[#141923] p-4 hover:border-purple-500/50 transition-all">
      <div className="flex items-start gap-3 mb-3">
        <div className={`p-2 rounded-lg bg-gradient-to-br ${pkgCfg.gradient} bg-opacity-20`}>
          <Icon className={`w-5 h-5 ${pkgCfg.color}`} />
        </div>
        
        <div className="flex-1">
          <h3 className="font-bold text-white text-lg mb-1">{pkg.label}</h3>
          <p className="text-xs text-gray-400 leading-relaxed">
            {pkg.description}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="p-3 rounded-lg bg-[#0a0a0f] border border-[#1a1f2e]">
          <div className="flex items-center gap-1 mb-1">
            <Users className="w-3 h-3 text-cyan-400" />
            <span className="text-xs text-gray-400">Team Size</span>
          </div>
          <div className="text-lg font-bold text-white">
            {pkg.teamSize} {pkg.teamSize === 1 ? 'dev' : 'devs'}
          </div>
        </div>

        <div className="p-3 rounded-lg bg-[#0a0a0f] border border-[#1a1f2e]">
          <div className="flex items-center gap-1 mb-1">
            <Clock className="w-3 h-3 text-blue-400" />
            <span className="text-xs text-gray-400">Timeline</span>
          </div>
          <div className="text-lg font-bold text-white">
            {pkg.estimatedWeeks} weeks
          </div>
        </div>

        <div className="p-3 rounded-lg bg-[#0a0a0f] border border-[#1a1f2e] col-span-2">
          <div className="flex items-center gap-1 mb-1">
            <DollarSign className="w-3 h-3 text-green-400" />
            <span className="text-xs text-gray-400">Cost Estimate</span>
          </div>
          <div className="text-xl font-bold text-green-400">
            €{pkg.estimatedCostRange.min.toLocaleString()} - €{pkg.estimatedCostRange.max.toLocaleString()}
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <AlertTriangle className={`w-4 h-4 ${riskCfg.color}`} />
          <span className="text-xs text-gray-400">Risk Level:</span>
          <Badge className={`${riskCfg.bg} ${riskCfg.color} border ${riskCfg.border} text-xs`}>
            {pkg.riskLevel}
          </Badge>
        </div>
      </div>

      <div className="pt-3 border-t border-[#1a1f2e]">
        <div className="text-xs text-gray-400 mb-2">
          Recommended Developers: {pkg.targetDevelopers.length}
        </div>
        <div className="flex flex-wrap gap-1">
          {pkg.targetDevelopers.slice(0, 3).map((devId, idx) => (
            <Badge key={idx} className="bg-purple-600/20 text-purple-300 border-purple-600/30 text-xs">
              {devId.replace(/_/g, ' ')}
            </Badge>
          ))}
          {pkg.targetDevelopers.length > 3 && (
            <Badge className="bg-gray-600/20 text-gray-400 border-gray-600/30 text-xs">
              +{pkg.targetDevelopers.length - 3} more
            </Badge>
          )}
        </div>
      </div>
    </Card>
  );
}