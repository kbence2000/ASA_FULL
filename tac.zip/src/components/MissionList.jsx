import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  CheckCircle2, 
  Clock, 
  XCircle, 
  AlertTriangle,
  Loader2,
  ChevronRight,
  Rocket
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { formatDistanceToNow } from "date-fns";

export default function MissionList({ onSelectMission }) {
  const [filter, setFilter] = useState("all");

  const { data: missions, isLoading } = useQuery({
    queryKey: ['missions'],
    queryFn: () => base44.entities.Mission.list('-created_date', 100),
    initialData: [],
    refetchInterval: 5000 // Auto-refresh every 5s
  });

  const getStatusIcon = (status) => {
    switch (status) {
      case "completed": return <CheckCircle2 className="w-4 h-4 text-green-400" />;
      case "running": return <Loader2 className="w-4 h-4 text-blue-400 animate-spin" />;
      case "failed": return <XCircle className="w-4 h-4 text-red-400" />;
      case "expired": return <AlertTriangle className="w-4 h-4 text-orange-400" />;
      case "pending": return <Clock className="w-4 h-4 text-gray-400" />;
      default: return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusBadge = (status) => {
    const config = {
      completed: { bg: 'bg-green-600/20', text: 'text-green-300', border: 'border-green-600/30' },
      running: { bg: 'bg-blue-600/20', text: 'text-blue-300', border: 'border-blue-600/30' },
      failed: { bg: 'bg-red-600/20', text: 'text-red-300', border: 'border-red-600/30' },
      expired: { bg: 'bg-orange-600/20', text: 'text-orange-300', border: 'border-orange-600/30' },
      pending: { bg: 'bg-gray-600/20', text: 'text-gray-300', border: 'border-gray-600/30' }
    };

    const style = config[status] || config.pending;

    return (
      <Badge className={`${style.bg} ${style.text} ${style.border} text-xs`}>
        {status}
      </Badge>
    );
  };

  const getComplexityColor = (complexity) => {
    switch (complexity) {
      case "low": return "text-green-400";
      case "medium": return "text-yellow-400";
      case "high": return "text-orange-400";
      case "extreme": return "text-red-400";
      default: return "text-gray-400";
    }
  };

  const filteredMissions = missions.filter(mission => {
    if (filter === "all") return true;
    return mission.status === filter;
  });

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        {["all", "running", "completed", "failed", "expired"].map(status => (
          <Button
            key={status}
            onClick={() => setFilter(status)}
            variant={filter === status ? "default" : "outline"}
            size="sm"
            className={filter === status 
              ? "bg-purple-600 hover:bg-purple-700" 
              : "border-[#1a1f2e] text-gray-400 hover:text-white"
            }
          >
            {status === "all" ? "All" : status.charAt(0).toUpperCase() + status.slice(1)}
            <span className="ml-2 text-xs">
              ({status === "all" 
                ? missions.length 
                : missions.filter(m => m.status === status).length
              })
            </span>
          </Button>
        ))}
      </div>

      {/* Mission Cards */}
      {isLoading ? (
        <Card className="border p-12 text-center" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-purple-400" />
          <p className="text-gray-400">Loading missions...</p>
        </Card>
      ) : filteredMissions.length === 0 ? (
        <Card className="border p-12 text-center" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <Rocket className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-white mb-2">No Missions Found</h3>
          <p className="text-gray-400">
            {filter === "all" 
              ? "Create your first mission to get started"
              : `No ${filter} missions at the moment`
            }
          </p>
        </Card>
      ) : (
        <div className="grid gap-4">
          {filteredMissions.map(mission => (
            <Card
              key={mission.id}
              className="border p-5 hover:shadow-lg transition-all cursor-pointer group"
              style={{
                background: 'rgba(15, 23, 42, 0.95)',
                borderColor: 'rgba(148, 163, 184, 0.35)'
              }}
              onClick={() => onSelectMission(mission)}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-start gap-3 flex-1">
                  <div className="mt-1">
                    {getStatusIcon(mission.status)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-bold text-white text-lg leading-tight">
                        {mission.description}
                      </h3>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      {getStatusBadge(mission.status)}
                      <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30 text-xs">
                        <span className={getComplexityColor(mission.complexity)}>
                          {mission.complexity}
                        </span>
                      </Badge>
                      {mission.budget && (
                        <Badge className="bg-cyan-600/20 text-cyan-300 border-cyan-600/30 text-xs">
                          ${mission.budget}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-white transition-colors" />
              </div>

              <div className="flex items-center gap-4 text-xs text-gray-400">
                <span>ID: {mission.missionId}</span>
                <span>•</span>
                <span>
                  {mission.created_date 
                    ? formatDistanceToNow(new Date(mission.created_date), { addSuffix: true })
                    : "just now"
                  }
                </span>
                {mission.expiresAt && mission.status === "running" && (
                  <>
                    <span>•</span>
                    <span className="text-orange-400">
                      Expires {formatDistanceToNow(new Date(mission.expiresAt), { addSuffix: true })}
                    </span>
                  </>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}