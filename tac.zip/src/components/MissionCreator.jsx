import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Rocket, Loader2, Zap, Clock, DollarSign } from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";

export default function MissionCreator() {
  const [description, setDescription] = useState("");
  const [complexity, setComplexity] = useState("medium");
  const [budget, setBudget] = useState("");
  const [code, setCode] = useState("");
  const [executing, setExecuting] = useState(false);

  const queryClient = useQueryClient();

  const estimateTTL = (complexity) => {
    switch (complexity) {
      case "low": return 5 * 60 * 1000; // 5 min
      case "high": return 45 * 60 * 1000; // 45 min
      case "extreme": return 90 * 60 * 1000; // 1.5 hours
      case "medium":
      default: return 20 * 60 * 1000; // 20 min
    }
  };

  const formatTTL = (ms) => {
    const minutes = Math.floor(ms / 60000);
    if (minutes < 60) return `${minutes} minutes`;
    const hours = Math.floor(minutes / 60);
    const remainingMins = minutes % 60;
    return `${hours}h ${remainingMins}m`;
  };

  const appendLog = async (missionId, level, phase, message, meta = null) => {
    try {
      const missions = await base44.entities.Mission.filter({ missionId }, null, 1);
      if (missions.length > 0) {
        const mission = missions[0];
        const logs = mission.logs || [];
        logs.push({
          at: new Date().toISOString(),
          level,
          phase,
          message,
          meta
        });
        await base44.entities.Mission.update(mission.id, { logs });
      }
    } catch (error) {
      console.error("Failed to append log:", error);
    }
  };

  const analyzeFailure = async (mission) => {
    try {
      const analysisPrompt = `You are a MISSION FAILURE ANALYST AI for MDC.
You receive a mission object, its logs and error, and your job is to:
1) Explain briefly what most likely went wrong.
2) Suggest improvements to the AI pipeline.
3) Decide if a free retry is worth attempting.

Return ONLY a JSON object with this exact structure:
{
  "rootCause": "string explanation",
  "improvementHint": "string suggestion",
  "retryRecommended": boolean,
  "retryAdjustment": "string adjustment for retry"
}

Mission data:
- Description: ${mission.description}
- Complexity: ${mission.complexity}
- Status: ${mission.status}
- Error: ${mission.error?.message || 'Unknown'}
- Logs: ${JSON.stringify(mission.logs || [], null, 2)}`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: analysisPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            rootCause: { type: "string" },
            improvementHint: { type: "string" },
            retryRecommended: { type: "boolean" },
            retryAdjustment: { type: "string" }
          }
        }
      });

      return response;
    } catch (error) {
      console.error("Failure analysis error:", error);
      return {
        rootCause: "Unknown (analysis failed)",
        improvementHint: "",
        retryRecommended: false,
        retryAdjustment: ""
      };
    }
  };

  const createRetryMission = async (originalMission, analysis) => {
    try {
      const now = Date.now();
      const retryMissionId = `msn-${now}`;
      const ttlMs = estimateTTL(originalMission.complexity);
      const expiresAt = new Date(now + ttlMs).toISOString();

      const retryDescription = originalMission.description + 
        "\n\n[RETRY NOTE]: " + 
        (analysis.retryAdjustment || "Attempting a refined retry based on previous failure.");

      const retryMission = await base44.entities.Mission.create({
        missionId: retryMissionId,
        description: retryDescription,
        complexity: originalMission.complexity,
        budget: originalMission.budget,
        payload: {
          ...originalMission.payload,
          previousMissionId: originalMission.missionId,
          previousError: originalMission.error,
          previousLogs: originalMission.logs || []
        },
        ttlMs,
        expiresAt,
        status: "pending",
        sandboxId: `vm-${retryMissionId}`,
        sandboxConfig: {
          createdAt: new Date().toISOString(),
          firecrackerConfigPath: `/var/lib/mdc/firecracker/vm-${retryMissionId}.json`
        },
        startedAt: new Date().toISOString(),
        logs: [],
        retries: (originalMission.retries || 0) + 1,
        retryOf: originalMission.missionId,
        freeRetry: true,
        failureAnalysis: analysis
      });

      toast.info("Auto-retry mission created!");
      
      // Execute retry mission (same flow as original)
      executeRetryMission(retryMission);

      return retryMission;
    } catch (error) {
      console.error("Failed to create retry mission:", error);
      toast.error("Failed to create retry mission");
    }
  };

  const executeRetryMission = async (mission) => {
    try {
      await appendLog(mission.missionId, "info", "retry-start", "Free retry mission started.");
      
      await base44.entities.Mission.update(mission.id, { status: "running" });

      const prompt = `You are an MDC MISSION AGENT.
You receive a mission description and optional code/context.
You must produce a high-quality, concise but powerful response.
Focus on: solving the task, explaining briefly, suggesting next steps.

Mission description:
${mission.description}
${mission.payload?.code ? `\n\nAttached code snippet:\n${mission.payload.code}` : ''}

This is a RETRY mission. Learn from previous failure:
${mission.payload?.previousError?.message || 'Previous attempt failed'}

If you see multiple ways to solve it, pick the most robust.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt
      });

      await base44.entities.Mission.update(mission.id, {
        status: "completed",
        result: {
          text: response,
          completedAt: new Date().toISOString()
        }
      });

      await appendLog(mission.missionId, "info", "complete", "Retry mission completed successfully.");
      
      queryClient.invalidateQueries(['missions']);
      toast.success("Retry mission completed!");

    } catch (error) {
      console.error("Retry mission execution failed:", error);
      
      await base44.entities.Mission.update(mission.id, {
        status: "failed",
        error: {
          message: error.message || "Retry mission failed",
          at: new Date().toISOString()
        }
      });

      await appendLog(mission.missionId, "error", "runtime", "Retry mission failed: " + error.message);
      
      queryClient.invalidateQueries(['missions']);
      toast.error("Retry mission failed");
    }
  };

  const handleCreateMission = async () => {
    if (!description.trim()) {
      toast.error("Please provide a mission description!");
      return;
    }

    setExecuting(true);

    try {
      const now = Date.now();
      const missionId = `msn-${now}`;
      const ttlMs = estimateTTL(complexity);
      const expiresAt = new Date(now + ttlMs).toISOString();

      // Create mission record
      const mission = await base44.entities.Mission.create({
        missionId,
        description,
        complexity,
        budget: budget ? parseFloat(budget) : null,
        payload: {
          code: code || null,
          extra: {}
        },
        ttlMs,
        expiresAt,
        status: "pending",
        sandboxId: `vm-${missionId}`,
        sandboxConfig: {
          createdAt: new Date().toISOString(),
          firecrackerConfigPath: `/var/lib/mdc/firecracker/vm-${missionId}.json`
        },
        startedAt: new Date().toISOString(),
        logs: [],
        retries: 0,
        retryOf: null,
        freeRetry: false,
        failureAnalysis: null
      });

      await appendLog(missionId, "info", "start", "Mission started and sandbox created.");

      toast.success("Mission created! Launching sandbox...");

      // Update to running
      await base44.entities.Mission.update(mission.id, {
        status: "running"
      });

      await appendLog(missionId, "info", "orchestrator", "Running AI workload for mission.");

      // Execute AI workload
      const prompt = `You are an MDC MISSION AGENT.
You receive a mission description and optional code/context.
You must produce a high-quality, concise but powerful response.
Focus on: solving the task, explaining briefly, suggesting next steps.

Mission description:
${description}
${code ? `\n\nAttached code snippet:\n${code}` : ''}

If you see multiple ways to solve it, pick the most robust.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt
      });

      // Update with results
      await base44.entities.Mission.update(mission.id, {
        status: "completed",
        result: {
          text: response,
          completedAt: new Date().toISOString()
        }
      });

      await appendLog(missionId, "info", "complete", "Mission completed successfully.");

      toast.success("Mission completed successfully!");

      // Reset form
      setDescription("");
      setCode("");
      setBudget("");
      setComplexity("medium");

      // Refresh missions list
      queryClient.invalidateQueries(['missions']);

    } catch (error) {
      console.error("Mission execution failed:", error);
      
      try {
        const missions = await base44.entities.Mission.filter({ missionId }, null, 1);
        if (missions.length > 0) {
          const mission = missions[0];
          
          await base44.entities.Mission.update(mission.id, {
            status: "failed",
            error: {
              message: error.message || "Mission failed",
              at: new Date().toISOString()
            }
          });

          await appendLog(mission.missionId, "error", "runtime", "Mission failed: " + error.message);

          // Analyze failure and potentially retry
          if ((mission.retries || 0) < 1) {
            await appendLog(mission.missionId, "info", "analysis", "Analyzing failure...");
            
            const analysis = await analyzeFailure(mission);
            
            await base44.entities.Mission.update(mission.id, {
              failureAnalysis: analysis
            });

            await appendLog(mission.missionId, "info", "analysis", "Failure analyzed. Root cause: " + analysis.rootCause);

            if (analysis.retryRecommended) {
              await createRetryMission(mission, analysis);
            }
          }
        }
      } catch (updateError) {
        console.error("Failed to update mission after error:", updateError);
      }

      toast.error("Mission failed: " + error.message);
      queryClient.invalidateQueries(['missions']);
    } finally {
      setExecuting(false);
    }
  };

  const ttlMs = estimateTTL(complexity);

  return (
    <Card className="border p-6" style={{
      background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
      borderColor: 'rgba(139, 92, 255, 0.3)'
    }}>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br from-purple-500 to-pink-500">
          <Rocket className="w-6 h-6 text-white" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-white">Create Mission</h3>
          <p className="text-sm text-gray-400">Deploy AI-powered sandbox workload</p>
        </div>
      </div>

      <div className="space-y-4">
        {/* Description */}
        <div>
          <label className="text-sm text-gray-300 mb-2 block">Mission Description *</label>
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe the mission task... (e.g., 'Bugfix this function that crashes on null input')"
            className="bg-[#141923] border-[#1a1f2e] text-white min-h-[100px]"
          />
        </div>

        {/* Code Snippet */}
        <div>
          <label className="text-sm text-gray-300 mb-2 block">Code Snippet (Optional)</label>
          <Textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="Paste code to analyze..."
            className="bg-[#141923] border-[#1a1f2e] text-white font-mono text-sm min-h-[120px]"
          />
        </div>

        {/* Complexity & Budget */}
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="text-sm text-gray-300 mb-2 block">Complexity</label>
            <Select value={complexity} onValueChange={setComplexity}>
              <SelectTrigger className="bg-[#141923] border-[#1a1f2e] text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low (5 min)</SelectItem>
                <SelectItem value="medium">Medium (20 min)</SelectItem>
                <SelectItem value="high">High (45 min)</SelectItem>
                <SelectItem value="extreme">Extreme (1.5 hours)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm text-gray-300 mb-2 block">Budget (Optional)</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                type="number"
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                placeholder="120"
                className="pl-10 bg-[#141923] border-[#1a1f2e] text-white"
              />
            </div>
          </div>
        </div>

        {/* TTL Info */}
        <div className="flex items-center gap-2 px-4 py-3 rounded-lg border" style={{
          background: 'rgba(5, 8, 22, 0.9)',
          borderColor: 'rgba(148, 163, 184, 0.2)'
        }}>
          <Clock className="w-4 h-4 text-cyan-400" />
          <span className="text-sm text-gray-300">
            TTL: <span className="text-cyan-400 font-semibold">{formatTTL(ttlMs)}</span>
          </span>
        </div>

        {/* Submit */}
        <Button
          onClick={handleCreateMission}
          disabled={executing || !description.trim()}
          className="w-full h-12 text-base font-semibold"
          style={{
            background: executing ? '#4a5568' : 'linear-gradient(135deg, #8b5cff, #24e4ff)',
            color: 'white'
          }}
        >
          {executing ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Executing Mission...
            </>
          ) : (
            <>
              <Zap className="w-5 h-5 mr-2" />
              Launch Mission
            </>
          )}
        </Button>
      </div>
    </Card>
  );
}