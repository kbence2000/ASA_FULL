import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Brain, Sparkles, AlertCircle, CheckCircle2, 
  Code2, TestTube, Users, Award, Zap, Layers
} from "lucide-react";
import { toast } from "sonner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import RankBadge from "./RankBadge";

const BACKEND_URL = import.meta.env.VITE_MDC_BACKEND_URL || "http://localhost:3000";

const LANGUAGES = [
  "javascript", "typescript", "python", "java", "go", 
  "rust", "cpp", "csharp", "php", "ruby"
];

export default function DualDebugPanel({ userId, onAnalysisComplete }) {
  const [language, setLanguage] = useState("javascript");
  const [code, setCode] = useState("");
  const [errorDescription, setErrorDescription] = useState("");
  const [extraContext, setExtraContext] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState(null);

  const handleAnalyze = async () => {
    if (!code.trim()) {
      toast.error("Please enter code to analyze");
      return;
    }

    setIsAnalyzing(true);
    setResult(null);

    try {
      const response = await fetch(`${BACKEND_URL}/api/debug/analyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: userId || 'anonymous',
          language,
          code: code.trim(),
          errorDescription: errorDescription.trim() || undefined,
          extraContext: extraContext.trim() || undefined,
        }),
      });

      if (!response.ok) {
        throw new Error("Debug analysis failed");
      }

      const data = await response.json();
      setResult(data);

      const demigodUsed = data.demigodContext?.length || 0;
      if (demigodUsed > 0) {
        toast.success(`✨ Analysis complete! Used ${demigodUsed} Demigod insights`);
      } else {
        toast.success("✅ Core analysis complete");
      }

      if (onAnalysisComplete) {
        onAnalysisComplete(data);
      }
    } catch (error) {
      console.error("Analysis error:", error);
      toast.error("Failed to analyze: " + error.message);
      setResult({ 
        error: error.message,
        coreAnalysis: "Analysis failed",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const loadExample = (type) => {
    const examples = {
      async: `async function fetchData(urls) {
  let result = {};
  urls.forEach(async (url) => {
    const res = await fetch(url);
    result[url] = await res.json();
  });
  return result;
}`,
      memory: `function processLargeArray(data) {
  const results = [];
  for (let i = 0; i < data.length; i++) {
    results.push(data.slice(0, i).join(''));
  }
  return results;
}`,
      security: `function login(req, res) {
  const { username, password } = req.body;
  const query = \`SELECT * FROM users WHERE username='\${username}' AND password='\${password}'\`;
  db.query(query, (err, user) => {
    if (user) res.json({ success: true });
  });
}`,
    };

    const descriptions = {
      async: "Race condition in async forEach - results return empty",
      memory: "Memory leak / performance issue with large arrays",
      security: "SQL injection vulnerability in login endpoint",
    };

    setCode(examples[type]);
    setErrorDescription(descriptions[type]);
  };

  return (
    <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 rounded-lg bg-gradient-to-br from-purple-500/20 to-indigo-500/20">
          <Layers className="w-6 h-6 text-purple-400" />
        </div>
        <div className="flex-1">
          <h3 className="text-xl font-black text-white">Dual-Layer Debug Engine</h3>
          <p className="text-sm text-gray-400">OpenAI Core + Demigod Enhanced Analysis</p>
        </div>
      </div>

      <div className="space-y-4">
        {/* Language & Examples */}
        <div className="flex gap-3">
          <Select value={language} onValueChange={setLanguage}>
            <SelectTrigger className="w-40 bg-[#141923] border-[#1a1f2e] text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {LANGUAGES.map(lang => (
                <SelectItem key={lang} value={lang}>
                  {lang}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="flex gap-2 flex-1">
            <Button
              variant="outline"
              size="sm"
              onClick={() => loadExample('async')}
              className="border-[#1a1f2e] text-gray-300 text-xs"
            >
              Async Bug
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => loadExample('memory')}
              className="border-[#1a1f2e] text-gray-300 text-xs"
            >
              Memory Leak
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => loadExample('security')}
              className="border-[#1a1f2e] text-gray-300 text-xs"
            >
              Security
            </Button>
          </div>
        </div>

        {/* Code Input */}
        <div>
          <label className="text-xs text-gray-400 block mb-1">
            Code to Analyze
          </label>
          <Textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="bg-[#0a0a0f] border-[#1a1f2e] text-white font-mono text-sm h-64 resize-none"
            placeholder="Paste your code here..."
            disabled={isAnalyzing}
          />
        </div>

        {/* Error Description */}
        <div>
          <label className="text-xs text-gray-400 block mb-1">
            Error / Issue Description (optional)
          </label>
          <Input
            type="text"
            placeholder="e.g. Race condition, returns empty object..."
            value={errorDescription}
            onChange={(e) => setErrorDescription(e.target.value)}
            className="bg-[#141923] border-[#1a1f2e] text-white text-sm"
            disabled={isAnalyzing}
          />
        </div>

        {/* Extra Context */}
        <div>
          <label className="text-xs text-gray-400 block mb-1">
            Extra Context (optional)
          </label>
          <Input
            type="text"
            placeholder="e.g. Node.js v18, Express 4.x, production environment..."
            value={extraContext}
            onChange={(e) => setExtraContext(e.target.value)}
            className="bg-[#141923] border-[#1a1f2e] text-white text-sm"
            disabled={isAnalyzing}
          />
        </div>

        {/* Info */}
        <div className="p-3 rounded-lg bg-gradient-to-r from-purple-600/10 to-indigo-600/10 border border-purple-600/30">
          <div className="flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-purple-400 mt-0.5 flex-shrink-0" />
            <p className="text-xs text-purple-300 leading-relaxed">
              <strong>Dual-Layer System:</strong> OpenAI analyzes your code for bugs, anti-patterns, security issues. 
              Demigod examples (R6/R7 tier) enhance the analysis with proven patterns. Credits are distributed to contributing demigods.
            </p>
          </div>
        </div>

        {/* Analyze Button */}
        <Button
          onClick={handleAnalyze}
          disabled={isAnalyzing || !code.trim()}
          className="w-full bg-gradient-to-r from-purple-600 to-indigo-700 hover:from-purple-700 hover:to-indigo-800 text-white font-bold text-lg py-6"
        >
          {isAnalyzing ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
              Analyzing with AI + Demigods...
            </>
          ) : (
            <>
              <Brain className="w-5 h-5 mr-2" />
              Run Dual-Layer Analysis
            </>
          )}
        </Button>

        {/* Results */}
        {result && !result.error && (
          <div className="space-y-4 pt-4 border-t border-[#1a1f2e]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-400" />
                <span className="text-sm font-semibold text-white">Analysis Complete</span>
              </div>
              {result.demigodContext?.length > 0 && (
                <Badge className="bg-purple-600/20 text-purple-300 border border-purple-600/30 flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  {result.demigodContext.length} Demigod insights
                </Badge>
              )}
            </div>

            {/* Demigod Contributors */}
            {result.demigodContext?.length > 0 && (
              <div className="p-4 rounded-lg bg-gradient-to-br from-purple-600/10 to-indigo-600/10 border border-purple-600/30">
                <div className="flex items-center gap-2 mb-3">
                  <Users className="w-4 h-4 text-purple-400" />
                  <span className="text-sm font-bold text-white">Contributing Demigods</span>
                </div>
                <div className="space-y-2">
                  {result.demigodContext.map((ctx, idx) => (
                    <div key={idx} className="flex items-center justify-between bg-[#0a0a0f] rounded-lg p-2 border border-[#1a1f2e]">
                      <div className="flex items-center gap-2">
                        <Award className="w-3 h-3 text-purple-400" />
                        <span className="text-xs font-semibold text-white">{ctx.authorName}</span>
                        <RankBadge rank={ctx.tierId} size="xs" />
                      </div>
                      <div className="flex items-center gap-2">
                        {ctx.tags?.slice(0, 2).map((tag, i) => (
                          <Badge key={i} variant="outline" className="border-purple-600/30 text-purple-400 text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
                {result.demigodRoyalty?.totalAllocated > 0 && (
                  <div className="mt-2 text-xs text-gray-400 flex items-center gap-1">
                    <Zap className="w-3 h-3 text-purple-400" />
                    {result.demigodRoyalty.totalAllocated.toFixed(2)} credits distributed
                  </div>
                )}
              </div>
            )}

            {/* Core Analysis */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <AlertCircle className="w-4 h-4 text-red-400" />
                <span className="text-xs text-gray-400">Issues Found</span>
              </div>
              <div className="bg-[#0a0a0f] border border-[#1a1f2e] rounded-lg p-4">
                <p className="text-sm text-gray-300 leading-relaxed whitespace-pre-wrap">
                  {result.coreAnalysis}
                </p>
              </div>
            </div>

            {/* Suggested Fix */}
            {result.suggestedFix && (
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle2 className="w-4 h-4 text-green-400" />
                  <span className="text-xs text-gray-400">Suggested Fix</span>
                </div>
                <div className="bg-[#0a0a0f] border border-[#1a1f2e] rounded-lg p-4">
                  <p className="text-sm text-green-300 leading-relaxed whitespace-pre-wrap">
                    {result.suggestedFix}
                  </p>
                </div>
              </div>
            )}

            {/* Improved Code */}
            {result.improvedCode && (
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Code2 className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs text-gray-400">Refactored Code</span>
                </div>
                <pre className="bg-[#0a0a0f] border border-[#1a1f2e] rounded-lg p-4 text-sm text-cyan-300 font-mono overflow-x-auto">
                  {result.improvedCode}
                </pre>
              </div>
            )}

            {/* Tests to Run */}
            {result.testsToRun && (
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <TestTube className="w-4 h-4 text-yellow-400" />
                  <span className="text-xs text-gray-400">Recommended Tests</span>
                </div>
                <div className="bg-[#0a0a0f] border border-[#1a1f2e] rounded-lg p-4">
                  <p className="text-sm text-yellow-300 leading-relaxed whitespace-pre-wrap">
                    {result.testsToRun}
                  </p>
                </div>
              </div>
            )}

            {/* Demigod Influence */}
            {result.demigodInfluence && (
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  <span className="text-xs text-gray-400">Demigod Enhancement</span>
                </div>
                <div className="bg-gradient-to-r from-purple-600/10 to-indigo-600/10 border border-purple-600/30 rounded-lg p-4">
                  <p className="text-sm text-purple-300 leading-relaxed whitespace-pre-wrap">
                    {result.demigodInfluence}
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Error State */}
        {result?.error && (
          <div className="p-4 rounded-lg bg-red-600/10 border border-red-600/30">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 mt-0.5" />
              <div>
                <div className="text-sm font-semibold text-red-400 mb-1">Analysis Failed</div>
                <div className="text-xs text-red-300">{result.error}</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}