import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Sparkles, Loader2, CheckCircle2, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";

export default function APCIngestButton() {
  const [ingesting, setIngesting] = useState(false);
  const [result, setResult] = useState(null);

  const handleIngest = async () => {
    setIngesting(true);
    setResult(null);

    try {
      // 1. Fetch trending snippets
      const snippets = await base44.entities.TrendingSnippet.list('-created_date', 50);

      if (snippets.length === 0) {
        toast.error('No trending snippets available');
        setIngesting(false);
        return;
      }

      // 2. Prepare data for AI analysis
      const limited = snippets.slice(0, 12).map((s, i) => ({
        idx: i,
        title: s.title,
        source: s.source,
        code: s.code,
        language: s.language
      }));

      // 3. AI Pattern Extraction
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are APC (Almighty Pattern Collector). Extract reusable code patterns from these trending snippets.

Analyze the code and identify:
- Common patterns (async handling, state management, UI patterns, etc.)
- Reusable concepts
- Innovation level (0-100)
- Usage frequency estimate (0-100)

Merge similar patterns and provide distinct, valuable patterns only.

Snippets:
${JSON.stringify(limited, null, 2)}`,
        response_json_schema: {
          type: "object",
          properties: {
            patterns: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  description: { type: "string" },
                  category: { type: "string" },
                  language: { type: "string" },
                  example_code: { type: "string" },
                  innovationScore: { type: "number" },
                  usageScore: { type: "number" },
                  tags: {
                    type: "array",
                    items: { type: "string" }
                  }
                }
              }
            }
          }
        }
      });

      const aiPatterns = response.patterns || [];

      // 4. Load existing patterns
      const existingPatterns = await base44.entities.APCPattern.list('-created_date', 1000);
      const existingIndex = {};
      existingPatterns.forEach(p => {
        existingIndex[p.patternId] = p;
      });

      const now = new Date().toISOString();
      let newCount = 0;
      let updatedCount = 0;

      // 5. Merge/Update patterns
      for (const p of aiPatterns) {
        const patternId = `${p.language || 'generic'}-${p.name}`
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-');

        const existing = existingIndex[patternId];

        if (existing) {
          // Update existing
          const newInnovation = Math.round(
            ((existing.innovationScore || 0) + (p.innovationScore || 0)) / 2
          );
          const newUsage = Math.min(
            100,
            (existing.usageScore || 0) + (p.usageScore || 10) / 10
          );

          await base44.entities.APCPattern.update(existing.id, {
            description: p.description || existing.description,
            category: p.category || existing.category,
            exampleCode: p.example_code || existing.exampleCode,
            innovationScore: newInnovation,
            usageScore: newUsage,
            tags: Array.from(new Set([...(existing.tags || []), ...(p.tags || [])])),
            lastSeen: now,
            seenCount: (existing.seenCount || 1) + 1
          });

          updatedCount++;
        } else {
          // Create new
          await base44.entities.APCPattern.create({
            patternId,
            name: p.name,
            description: p.description,
            category: p.category,
            language: p.language,
            exampleCode: p.example_code || "",
            innovationScore: p.innovationScore || 0,
            usageScore: p.usageScore || 0,
            tags: p.tags || [],
            firstSeen: now,
            lastSeen: now,
            seenCount: 1
          });

          newCount++;
        }
      }

      const totalPatterns = existingPatterns.length + newCount;

      setResult({
        success: true,
        analyzed: limited.length,
        newPatterns: newCount,
        updatedPatterns: updatedCount,
        totalPatterns
      });

      toast.success(`✨ Ingested ${aiPatterns.length} patterns! (${newCount} new, ${updatedCount} updated)`);
    } catch (error) {
      console.error('APC Ingest failed:', error);
      setResult({
        success: false,
        error: error.message
      });
      toast.error('Pattern ingestion failed!');
    } finally {
      setIngesting(false);
    }
  };

  return (
    <Card className="border p-6" style={{
      background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
      borderColor: 'rgba(139, 92, 255, 0.3)'
    }}>
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-5 h-5 text-purple-400" />
            <h3 className="font-bold text-white">APC Ingest</h3>
          </div>
          <p className="text-sm text-gray-400">
            Extract patterns from trending snippets using AI
          </p>
        </div>

        <Button
          onClick={handleIngest}
          disabled={ingesting}
          className="flex items-center gap-2"
          style={{
            background: ingesting ? '#4a5568' : 'linear-gradient(135deg, #8b5cff, #24e4ff)',
            color: 'white'
          }}
        >
          {ingesting ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Ingesting...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              Ingest Patterns
            </>
          )}
        </Button>
      </div>

      {result && (
        <div className={`p-4 rounded-lg border mt-4 ${
          result.success 
            ? 'bg-green-600/10 border-green-600/30' 
            : 'bg-red-600/10 border-red-600/30'
        }`}>
          {result.success ? (
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2 text-green-300 font-bold">
                <CheckCircle2 className="w-4 h-4" />
                Ingestion Complete
              </div>
              <div className="text-gray-300">
                <div>• Analyzed: {result.analyzed} snippets</div>
                <div>• New patterns: {result.newPatterns}</div>
                <div>• Updated patterns: {result.updatedPatterns}</div>
                <div>• Total patterns: {result.totalPatterns}</div>
              </div>
            </div>
          ) : (
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2 text-red-300 font-bold">
                <AlertTriangle className="w-4 h-4" />
                Ingestion Failed
              </div>
              <div className="text-gray-300">{result.error}</div>
            </div>
          )}
        </div>
      )}
    </Card>
  );
}