import React, { useState, useEffect } from 'react';
import { X, Sparkles, Zap, RefreshCw, Loader2, Brain } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function ChaosArchitectPanel({ isOpen, onClose }) {
  const [loading, setLoading] = useState(false);
  const [chaosSeeds, setChaosSeeds] = useState([]);
  const [radicalIdeas, setRadicalIdeas] = useState([]);
  const [promptPreview, setPromptPreview] = useState('');
  const [useAI, setUseAI] = useState(false);

  // Chaos word lists for local generation
  const chaosSubjects = [
    "Mission Control UI",
    "Marketplace grid",
    "Neural Core orb",
    "Demigod profile page",
    "For You feed",
    "Agent swarm visualizer",
    "Debug timeline",
    "Talent discovery map",
    "Company portal dashboard",
    "Code snippet detail view"
  ];

  const chaosActions = [
    "morphs dynamically based on user focus",
    "unfolds like a holographic neural tree",
    "projects data as floating shards in 3D space",
    "reacts to AI agent emotions in real time",
    "shifts layout according to mission intensity",
    "rewires itself when a new agent spawns",
    "fades inactive elements into the background like memory",
    "clusters similar tasks into living constellations",
    "pulses with neon accents during critical events",
    "removes all borders and behaves like liquid information"
  ];

  const chaosStyles = [
    "cyberpunk OS aesthetic",
    "minimal Apple-like chrome with hidden depth",
    "NVIDIA tech-demo level neon lighting",
    "clean Neuralink-lab style",
    "holographic command center look",
    "retro-futuristic terminal vibes in 3D",
    "elegant financial-trading interface energy",
    "AI cathedral interior feel",
    "blade-runner city-light reflection theme",
    "dark glass with quantum particles drifting behind"
  ];

  const chaosMetaphors = [
    "like a living organism learning in real time",
    "like a control room from a sci-fi movie",
    "like a neural dream rendered into UI",
    "like the brain of a benevolent AI god",
    "like a tactical HUD from a space fleet",
    "like an observatory staring into human creativity",
    "like a music visualizer for code and intent",
    "like MRI scans of an AI mind projected onto glass",
    "like a galaxy map, but every star is a task",
    "like a nervous system visualized in slow motion"
  ];

  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

  const generateLocalChaosWave = () => {
    // Generate 3 concept seed bubbles
    const seeds = [];
    for (let i = 0; i < 3; i++) {
      const subject = pick(chaosSubjects);
      const style = pick(chaosStyles);
      const seedNum = Math.floor(Math.random() * 99).toString().padStart(2, "0");

      seeds.push({
        title: `Concept Seed #${seedNum}`,
        description: `${subject} with ${style}`,
        pos: {
          top: `${15 + Math.random() * 60}%`,
          left: `${10 + Math.random() * 70}%`
        }
      });
    }

    // Generate 5 radical ideas
    const ideas = [];
    const collected = [];
    for (let i = 0; i < 5; i++) {
      const subject = pick(chaosSubjects);
      const action = pick(chaosActions);
      const style = pick(chaosStyles);
      const meta = pick(chaosMetaphors);

      const idea = `${subject} ${action}, styled as ${style}, ${meta}.`;
      ideas.push(idea);
      collected.push(idea);
    }

    // Generate prompt preview
    const basePrompt = `You are CHAOS ARCHITECT, an unleashed creative UI/UX + system design AI for MDC (MadDevCity).
Your job: propose 5 radically original, visually striking, but still implementable UI/UX concepts
for a next-generation AI developer OS. Focus on:
- neural visual metaphors
- living, evolving interfaces
- mission control aesthetics
- market-ready, but never-seen-before flows.

Here are some idea fragments already generated locally:
${collected.map((c, i) => `[${i + 1}] ${c}`).join("\n")}

Now, refine and expand them or generate better ones. 
Reply in numbered bullet points, short but vivid.`;

    setChaosSeeds(seeds);
    setRadicalIdeas(ideas);
    setPromptPreview(basePrompt.trim());
  };

  const generateAIChaosWave = async () => {
    setLoading(true);

    const prompt = `You are the "CHAOS ARCHITECT" - a radical UX innovation engine for a sci-fi quantum neural OS interface.

Your task: Generate experimental, boundary-pushing UI/UX concepts that challenge conventional thinking.

Output MUST be valid JSON with this exact structure:
{
  "seeds": [
    {"title": "Concept Seed #X", "description": "short wild idea"},
    {"title": "Prototype #Y", "description": "another crazy concept"},
    {"title": "Wild Idea", "description": "experimental UI thought"}
  ],
  "radical_ideas": [
    "First radical UI reimagining (one sentence)",
    "Second experimental interaction pattern (one sentence)",
    "Third boundary-breaking concept (one sentence)",
    "Fourth innovative approach (one sentence)",
    "Fifth wild UX pattern (one sentence)"
  ]
}

Focus areas:
- Neural network metaphors
- Quantum computing aesthetics
- Organic/living UI elements
- Non-traditional navigation
- 3D/spatial interfaces
- AI-driven adaptive layouts

Keep it WILD but implementable. Push boundaries. Be creative. Output ONLY valid JSON.`;

    setPromptPreview(prompt);

    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            seeds: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  title: { type: 'string' },
                  description: { type: 'string' }
                }
              }
            },
            radical_ideas: {
              type: 'array',
              items: { type: 'string' }
            }
          }
        }
      });

      // Assign random positions to seeds
      const seedsWithPositions = (response.seeds || []).map((seed) => ({
        ...seed,
        pos: {
          top: `${15 + Math.random() * 60}%`,
          left: `${10 + Math.random() * 70}%`
        }
      }));

      setChaosSeeds(seedsWithPositions);
      setRadicalIdeas(response.radical_ideas || []);
    } catch (error) {
      console.error('AI chaos generation failed, falling back to local generation:', error);
      generateLocalChaosWave();
    } finally {
      setLoading(false);
    }
  };

  const generateChaosWave = () => {
    if (useAI) {
      generateAIChaosWave();
    } else {
      generateLocalChaosWave();
    }
  };

  // Load initial chaos wave on mount
  useEffect(() => {
    if (isOpen && chaosSeeds.length === 0) {
      generateChaosWave();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[200]"
        onClick={onClose}
      />

      {/* Panel */}
      <div 
        className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[420px] max-w-[90vw] h-[580px] max-h-[85vh] z-[201] overflow-y-auto"
        style={{
          background: 'rgba(10, 3, 18, 0.92)',
          borderRadius: '18px',
          border: '1px solid rgba(255, 0, 180, 0.18)',
          backdropFilter: 'blur(16px)',
          boxShadow: '0 0 80px rgba(255, 0, 180, 0.4)',
          padding: '20px',
          animation: 'panelSlideIn 0.35s ease-out'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <style>{`
          @keyframes panelSlideIn {
            from {
              opacity: 0;
              transform: translate(-50%, -50%) scale(0.9);
            }
            to {
              opacity: 1;
              transform: translate(-50%, -50%) scale(1);
            }
          }

          @keyframes floating {
            0%, 100% {
              transform: translateY(0);
              opacity: 0.85;
            }
            50% {
              transform: translateY(-14px);
              opacity: 1;
            }
          }

          .chaos-bubble {
            position: absolute;
            background: rgba(255, 0, 180, 0.20);
            border: 1px solid rgba(255, 0, 180, 0.40);
            padding: 10px 14px;
            border-radius: 18px;
            color: #fff;
            font-size: 0.7rem;
            animation: floating 6s infinite ease-in-out;
            backdrop-filter: blur(10px);
          }

          .chaos-bubble span {
            display: block;
            font-size: 0.6rem;
            color: #ffe4fb;
          }

          .chaos-bubble:nth-child(2) {
            animation-delay: 2s;
          }

          .chaos-bubble:nth-child(3) {
            animation-delay: 4s;
          }

          .chaos-generate-btn {
            background: linear-gradient(135deg, rgba(255, 0, 180, 0.9), rgba(123, 63, 246, 0.95));
            border: none;
            color: #fff;
            font-size: 0.72rem;
            padding: 8px 12px;
            border-radius: 999px;
            cursor: pointer;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            box-shadow: 0 0 18px rgba(255, 0, 180, 0.65);
            transition: transform 0.15s ease-out, box-shadow 0.15s ease-out, opacity 0.15s;
          }

          .chaos-generate-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 0 26px rgba(255, 0, 210, 0.9);
          }

          .chaos-generate-btn:active {
            transform: translateY(0);
            opacity: 0.85;
          }

          .chaos-generate-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
          }

          .chaos-section h3 {
            color: #ff8ae8;
          }
        `}</style>

        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <div className="text-[0.9rem] tracking-[0.2em] uppercase" style={{ color: '#ff66e7' }}>
            CHAOS ARCHITECT
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Toggle */}
        <div className="mb-3 flex items-center justify-between">
          <div className="text-[0.7rem] tracking-[0.12em] uppercase" style={{ color: '#ffbdf3' }}>
            Experimental Idea Engine
          </div>
          <button
            onClick={() => setUseAI(!useAI)}
            className="flex items-center gap-1.5 px-2 py-1 rounded-full text-[0.65rem] font-semibold transition-all hover:scale-105"
            style={{
              background: useAI ? 'rgba(123, 63, 246, 0.3)' : 'rgba(255, 0, 180, 0.2)',
              border: `1px solid ${useAI ? 'rgba(123, 63, 246, 0.5)' : 'rgba(255, 0, 180, 0.3)'}`,
              color: '#fff'
            }}
          >
            <Brain className="w-3 h-3" />
            {useAI ? 'AI MODE' : 'DEMO MODE'}
          </button>
        </div>

        {/* Action Row */}
        <div className="flex justify-between items-center mb-3">
          <div className="text-[0.65rem] text-gray-400">
            {useAI ? '⚡ Using real AI generation' : '🎲 Using local word lists'}
          </div>
          <button
            onClick={generateChaosWave}
            disabled={loading}
            className="chaos-generate-btn flex items-center gap-1.5"
          >
            {loading ? (
              <>
                <Loader2 className="w-3 h-3 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <RefreshCw className="w-3 h-3" />
                Generate new wave
              </>
            )}
          </button>
        </div>

        {/* Floating Chaos Seeds */}
        <div className="relative h-[200px] mb-6">
          {loading ? (
            <div className="absolute inset-0 flex items-center justify-center">
              <Loader2 className="w-8 h-8 animate-spin text-pink-400" />
            </div>
          ) : (
            chaosSeeds.map((seed, idx) => (
              <div
                key={idx}
                className="chaos-bubble cursor-default"
                style={{
                  top: seed.pos.top,
                  left: seed.pos.left,
                  maxWidth: '140px'
                }}
              >
                <div className="font-semibold">{seed.title}</div>
                <span>"{seed.description}"</span>
              </div>
            ))
          )}
        </div>

        {/* Radical Ideas */}
        <div className="mb-6 chaos-section">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-3 font-semibold">
            RADICAL IDEAS
          </h3>
          {loading ? (
            <div className="text-center text-gray-400 text-xs py-4">
              <Loader2 className="w-4 h-4 animate-spin inline mr-2" />
              Channeling chaos...
            </div>
          ) : (
            <ul className="space-y-2">
              {radicalIdeas.map((idea, idx) => (
                <li key={idx} className="flex items-start gap-2 text-xs" style={{ color: '#ffa8ff' }}>
                  <Sparkles className="w-3 h-3 text-pink-400 mt-0.5 flex-shrink-0" />
                  <span>{idea}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Experimental Features */}
        <div className="mb-6 chaos-section">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-3 font-semibold">
            EXPERIMENTAL QUEUE
          </h3>
          <div className="space-y-2">
            <div className="p-3 rounded-xl border" style={{
              background: 'rgba(255, 0, 180, 0.05)',
              borderColor: 'rgba(255, 0, 180, 0.2)'
            }}>
              <div className="text-xs font-semibold text-white mb-1">Neural Tentacles v0.3</div>
              <div className="text-[0.65rem] text-gray-400">Status: Prototype</div>
            </div>
            <div className="p-3 rounded-xl border" style={{
              background: 'rgba(255, 0, 180, 0.05)',
              borderColor: 'rgba(255, 0, 180, 0.2)'
            }}>
              <div className="text-xs font-semibold text-white mb-1">Fractal Menu System</div>
              <div className="text-[0.65rem] text-gray-400">Status: Concept</div>
            </div>
          </div>
        </div>

        {/* Prompt Preview (for founders/devs) */}
        <div className="mb-6 chaos-section">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-2 font-semibold">
            UNDERLYING PROMPT (FOR REAL AI)
          </h3>
          <div 
            className="p-3 rounded-lg text-[0.68rem] leading-relaxed max-h-32 overflow-y-auto"
            style={{
              background: 'rgba(255, 0, 180, 0.05)',
              border: '1px solid rgba(255, 0, 180, 0.15)',
              color: '#ffdaf7',
              opacity: 0.8,
              fontFamily: 'monospace'
            }}
          >
            {promptPreview || 'Generate a chaos wave to see the prompt...'}
          </div>
        </div>

        {/* Chaos Meter */}
        <div className="mb-4">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-3 font-semibold" style={{ color: '#ff8ae8' }}>
            CHAOS METER
          </h3>
          <div>
            <div className="h-2 bg-[#1a0a14] rounded-full overflow-hidden mb-2">
              <div 
                className="h-full bg-gradient-to-r from-pink-600 to-purple-600 transition-all duration-1000"
                style={{ width: loading ? '50%' : '92%' }}
              />
            </div>
            <p className="text-xs text-gray-400">
              <Zap className="w-3 h-3 inline mr-1 text-pink-400" />
              Innovation level: {loading ? 'CHARGING...' : 'EXTREME'}
            </p>
          </div>
        </div>

        {/* Action Button */}
        <button 
          onClick={generateChaosWave}
          disabled={loading}
          className="w-full py-3 rounded-xl font-semibold text-sm transition-all hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed"
          style={{
            background: 'linear-gradient(135deg, rgba(255, 0, 180, 0.6), rgba(180, 0, 255, 0.4))',
            border: '1px solid rgba(255, 0, 180, 0.6)',
            boxShadow: '0 0 20px rgba(255, 0, 180, 0.5)',
            color: '#fff'
          }}
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 inline mr-2 animate-spin" />
              Unleashing Chaos...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 inline mr-2" />
              Unleash Chaos Mode
            </>
          )}
        </button>
      </div>
    </>
  );
}