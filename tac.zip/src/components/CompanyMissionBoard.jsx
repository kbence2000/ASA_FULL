import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Briefcase, Plus, DollarSign, Loader2, Target, ChevronRight } from "lucide-react";
import { toast } from "sonner";
import { companyAPI } from "./CompanyAPIClient";

export default function CompanyMissionBoard({ companyId, onSelectMission }) {
  const [missions, setMissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [creating, setCreating] = useState(false);
  
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    bounty: "",
    complexity: "medium",
    aiMode: "ai-only"
  });

  useEffect(() => {
    if (companyId) {
      fetchMissions();
    }
  }, [companyId]);

  const fetchMissions = async () => {
    try {
      const data = await companyAPI.getCompanyMissions(companyId);
      setMissions(data.missions || []);
    } catch (error) {
      console.error("Failed to fetch missions:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async () => {
    if (!formData.title || !formData.description) {
      toast.error("Title and description are required");
      return;
    }

    setCreating(true);

    try {
      await companyAPI.createCompanyMission(companyId, {
        title: formData.title,
        description: formData.description,
        bounty: formData.bounty ? parseFloat(formData.bounty) : 0,
        complexity: formData.complexity,
        aiMode: formData.aiMode,
      });

      toast.success("Mission created successfully!");
      
      // Reset form
      setFormData({
        title: "",
        description: "",
        bounty: "",
        complexity: "medium",
        aiMode: "ai-only"
      });
      setShowCreate(false);
      
      // Refresh list
      fetchMissions();
    } catch (error) {
      console.error("Failed to create mission:", error);
      toast.error("Failed to create mission: " + error.message);
    } finally {
      setCreating(false);
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "open": return "bg-green-600/20 text-green-300 border-green-600/30";
      case "draft": return "bg-gray-600/20 text-gray-300 border-gray-600/30";
      case "running": return "bg-blue-600/20 text-blue-300 border-blue-600/30";
      case "completed": return "bg-purple-600/20 text-purple-300 border-purple-600/30";
      case "cancelled": return "bg-red-600/20 text-red-300 border-red-600/30";
      default: return "bg-gray-600/20 text-gray-300 border-gray-600/30";
    }
  };

  const getComplexityColor = (complexity) => {
    switch (complexity) {
      case "low": return "text-green-400";
      case "medium": return "text-yellow-400";
      case "high": return "text-orange-400";
      case "extreme": return "text-red-400";
      default: return "text-gray-400";
    }
  };

  const getAIModeBadge = (mode) => {
    switch (mode) {
      case "ai-only": return "bg-purple-600/20 text-purple-300 border-purple-600/30";
      case "ai+talent": return "bg-cyan-600/20 text-cyan-300 border-cyan-600/30";
      default: return "bg-gray-600/20 text-gray-300 border-gray-600/30";
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <Briefcase className="w-5 h-5 text-purple-400" />
          Company Missions
          <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30 text-xs">
            {missions.length}
          </Badge>
        </h3>
        <Button
          onClick={() => setShowCreate(!showCreate)}
          size="sm"
          className="bg-purple-600 hover:bg-purple-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create Mission
        </Button>
      </div>

      {/* Create Form */}
      {showCreate && (
        <Card className="border p-6" style={{
          background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
          borderColor: 'rgba(139, 92, 255, 0.3)'
        }}>
          <h4 className="text-lg font-bold text-white mb-4">New Mission</h4>

          <div className="space-y-4">
            <div>
              <label className="text-sm text-gray-300 mb-2 block">Title *</label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                placeholder="e.g., Refactor legacy auth flow"
                className="bg-[#0f0a1f] border-[#1a1f2e] text-white"
              />
            </div>

            <div>
              <label className="text-sm text-gray-300 mb-2 block">Description *</label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Detailed description of the mission..."
                className="bg-[#0f0a1f] border-[#1a1f2e] text-white min-h-[100px]"
              />
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm text-gray-300 mb-2 block">Bounty (EUR)</label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    type="number"
                    value={formData.bounty}
                    onChange={(e) => setFormData(prev => ({ ...prev, bounty: e.target.value }))}
                    placeholder="500"
                    className="pl-10 bg-[#0f0a1f] border-[#1a1f2e] text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-sm text-gray-300 mb-2 block">Complexity</label>
                <Select value={formData.complexity} onValueChange={(value) => setFormData(prev => ({ ...prev, complexity: value }))}>
                  <SelectTrigger className="bg-[#0f0a1f] border-[#1a1f2e] text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="extreme">Extreme</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm text-gray-300 mb-2 block">AI Mode</label>
                <Select value={formData.aiMode} onValueChange={(value) => setFormData(prev => ({ ...prev, aiMode: value }))}>
                  <SelectTrigger className="bg-[#0f0a1f] border-[#1a1f2e] text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ai-only">AI Only</SelectItem>
                    <SelectItem value="ai+talent">AI + Talent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                onClick={handleCreate}
                disabled={creating || !formData.title || !formData.description}
                className="flex-1"
                style={{
                  background: creating ? '#4a5568' : 'linear-gradient(135deg, #8b5cff, #24e4ff)',
                  color: 'white'
                }}
              >
                {creating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Creating...
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Mission
                  </>
                )}
              </Button>
              <Button
                onClick={() => setShowCreate(false)}
                variant="outline"
                className="border-[#1a1f2e] text-gray-400"
              >
                Cancel
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* Missions List */}
      {loading ? (
        <Card className="border p-12 text-center" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-3 text-purple-400" />
          <p className="text-gray-400">Loading missions...</p>
        </Card>
      ) : missions.length === 0 ? (
        <Card className="border p-12 text-center" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <Target className="w-12 h-12 text-gray-600 mx-auto mb-3" />
          <p className="text-gray-400">No missions yet. Create your first one!</p>
        </Card>
      ) : (
        <div className="grid gap-4">
          {missions.map((mission) => (
            <Card
              key={mission.id}
              onClick={() => onSelectMission && onSelectMission(mission)}
              className="border p-5 hover:shadow-lg transition-all cursor-pointer group"
              style={{
                background: 'rgba(15, 23, 42, 0.95)',
                borderColor: 'rgba(148, 163, 184, 0.35)'
              }}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h4 className="font-bold text-white text-lg mb-2 group-hover:text-cyan-400 transition-colors">
                    {mission.title}
                  </h4>
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <Badge className={getStatusBadge(mission.status)}>
                      {mission.status}
                    </Badge>
                    <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30">
                      <span className={getComplexityColor(mission.complexity)}>
                        {mission.complexity}
                      </span>
                    </Badge>
                    <Badge className={getAIModeBadge(mission.aiMode)}>
                      {mission.aiMode}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-400 line-clamp-2">
                    {mission.description}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="text-2xl font-bold text-cyan-400">
                      €{mission.bounty}
                    </div>
                    <div className="text-xs text-gray-400">Bounty</div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-white transition-colors" />
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}