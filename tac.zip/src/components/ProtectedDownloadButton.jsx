import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Download, Loader2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import backendClient from "./BackendClient";

/**
 * Protected Download Button
 * Requests download token from backend and provides secure download link
 */
export default function ProtectedDownloadButton({ 
  app,
  user,
  hasPurchased,
  className = "" 
}) {
  const [loading, setLoading] = useState(false);
  const [downloadLink, setDownloadLink] = useState(null);

  const handleDownloadRequest = async () => {
    if (!user) {
      toast.error("Jelentkezz be a letöltéshez!");
      return;
    }

    if (!hasPurchased) {
      toast.error("Először vásárold meg a programot!");
      return;
    }

    setLoading(true);
    
    try {
      const response = await backendClient.requestDownload({
        appId: app.id,
        userEmail: user.email
      });

      if (response.ok && response.downloadLink) {
        setDownloadLink(response.downloadLink);
        toast.success("Letöltési link elküldve emailben!");
        
        // Open download link in new tab
        window.open(response.downloadLink, '_blank');
      } else {
        throw new Error(response.error || 'Failed to generate download link');
      }
    } catch (error) {
      console.error('Download request error:', error);
      
      if (error.message.includes('No purchase found')) {
        toast.error('Nem található vásárlás ehhez a termékhez');
      } else if (error.message.includes('No download URL')) {
        toast.error('Letöltés még nem elérhető');
      } else {
        toast.error('Hiba a letöltési link generálásakor');
      }
    } finally {
      setLoading(false);
    }
  };

  if (!hasPurchased) {
    return null;
  }

  return (
    <div className="space-y-2">
      <Button
        onClick={handleDownloadRequest}
        disabled={loading}
        className={`flex items-center gap-2 ${className}`}
      >
        {loading ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            Generálás...
          </>
        ) : downloadLink ? (
          <>
            <CheckCircle2 className="w-5 h-5" />
            Link Elküldve
          </>
        ) : (
          <>
            <Download className="w-5 h-5" />
            Letöltés Kérése
          </>
        )}
      </Button>
      
      {downloadLink && (
        <p className="text-xs text-gray-500">
          A letöltési link emailben is megkapod (24 órán át érvényes)
        </p>
      )}
    </div>
  );
}