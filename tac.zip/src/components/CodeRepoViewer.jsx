import React from 'react';

export default function CodeRepoViewer({ selectedRepo, selectedFile }) {
  const repoInfo = {
    'tac-core-system': {
      name: 'tac-core-system',
      desc: "TAC's primary AI orchestration repository – paradox routing, chaos mutation and mission chains.",
      lastUpdate: '3 hours ago'
    },
    'ai-modules': {
      name: 'ai-modules',
      desc: 'Collection of advanced AI reasoning modules for TAC platform.',
      lastUpdate: '5 hours ago'
    },
    'paradox-engine': {
      name: 'paradox-engine',
      desc: 'Multi-layer recursive reasoning engine with 9-mind consensus.',
      lastUpdate: '1 day ago'
    },
    'chaos-architect': {
      name: 'chaos-architect',
      desc: 'Extreme idea exploration and mutation generator.',
      lastUpdate: '2 days ago'
    },
    'hallucinator': {
      name: 'hallucinator',
      desc: 'Hypothetical branch generator for what-if scenarios.',
      lastUpdate: '3 days ago'
    }
  };

  const currentRepo = repoInfo[selectedRepo] || repoInfo['tac-core-system'];

  return (
    <section className="panel-3d panel-3d-center w-full md:w-[34rem] bg-[#0c0217] border border-purple-900/80 rounded-3xl shadow-depth">
      <style jsx>{`
        .shadow-depth {
          box-shadow: 0 25px 45px rgba(0,0,0,0.85);
        }
        .shadow-glowSoft {
          box-shadow: 0 0 12px rgba(168,85,247,0.55);
        }
        .shadow-glowNeon {
          box-shadow: 0 0 14px rgba(34,197,94,0.9);
        }
      `}</style>

      {/* README Header */}
      <div className="p-5 border-b border-purple-900/70 bg-black/70 rounded-t-3xl">
        <div className="flex items-center justify-between gap-3">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full border border-purple-500/80 shadow-glowSoft">
              <span className="w-1.5 h-1.5 rounded-full bg-purple-300 shadow-glowSoft"></span>
              <span className="text-[11px] uppercase tracking-[0.22em] text-purple-100">
                {currentRepo.name}
              </span>
            </div>
            <p className="mt-2 text-[13px] text-slate-200">
              {currentRepo.desc}
            </p>
          </div>
          <div className="text-right">
            <p className="text-[11px] text-slate-400">Last updated</p>
            <p className="text-[12px] text-slate-100">{currentRepo.lastUpdate}</p>
          </div>
        </div>
      </div>

      {/* README Content */}
      <div className="px-5 pt-4 pb-4 border-b border-purple-900/70 bg-gradient-to-b from-[#120326] to-[#050009]">
        <h2 className="text-[15px] font-semibold mb-2 text-purple-300">README.md</h2>
        <p className="text-[13px] text-slate-200 leading-relaxed">
          This repo wires up TAC's <strong>end-to-end AI layer</strong>, including:
        </p>
        <ul className="mt-2 text-[13px] text-slate-300 space-y-1.5 list-disc list-inside">
          <li>Paradox Engine – multi-layer recursive reasoning.</li>
          <li>Chaos Architect – extreme idea exploration & mutations.</li>
          <li>Hallucinator – hypothetical branch generator.</li>
          <li>Agent Orchestrator – mission routing & delegation.</li>
        </ul>
      </div>

      {/* Code Viewer */}
      <div className="p-4 bg-black/80 rounded-b-3xl">
        <div className="flex items-center justify-between mb-2">
          <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full border border-purple-600/80 shadow-glowSoft">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500 shadow-glowNeon"></span>
            <span className="text-[11px] uppercase tracking-[0.2em] text-purple-100">
              {selectedFile}
            </span>
          </div>
          <span className="text-[11px] text-slate-400">core-module</span>
        </div>

        <div className="relative border border-purple-800/80 rounded-2xl bg-gradient-to-br from-black via-[#050012] to-[#180022] shadow-glowSoft overflow-hidden">
          {/* Hologram edges */}
          <div className="absolute inset-x-6 top-0 h-px bg-gradient-to-r from-transparent via-purple-300/60 to-transparent opacity-70"></div>
          <div className="absolute inset-y-4 left-0 w-px bg-gradient-to-b from-transparent via-purple-300/60 to-transparent opacity-50"></div>

          <pre className="p-4 text-[12px] leading-relaxed overflow-x-auto">
            <code>
              <span className="text-slate-500">// TAC — Paradox Engine Core</span>{'\n'}
              <span className="text-slate-500">// Generates recursive multi-layer reasoning waves.</span>{'\n\n'}
              
              <span className="text-sky-400">export</span> <span className="text-sky-400">function</span> <span className="text-emerald-300">paradoxEngine</span>(input) {'{\n'}
              {'  '}<span className="text-sky-400">const</span> layers = <span className="text-amber-300">9</span>;       <span className="text-slate-500">// nine-mind recursion</span>{'\n'}
              {'  '}<span className="text-sky-400">let</span> state = input;{'\n\n'}
              
              {'  '}<span className="text-sky-400">for</span> (<span className="text-sky-400">let</span> i = <span className="text-amber-300">0</span>; i {'<'} layers; i++) {'{\n'}
              {'    '}state = <span className="text-emerald-300">deepFold</span>(state);{'\n'}
              {'  }}\n'}
              {'  '}<span className="text-sky-400">return</span> <span className="text-emerald-300">finalize</span>(state);{'\n'}
              {'}\n\n'}
              
              <span className="text-sky-400">function</span> <span className="text-emerald-300">deepFold</span>(data) {'{\n'}
              {'  '}<span className="text-sky-400">return</span> {'{\n'}
              {'    '}value: <span className="text-sky-400">Math</span>.tanh(<span className="text-sky-400">Math</span>.random() * <span className="text-amber-300">9999</span>) *{'\n'}
              {'      '}<span className="text-sky-400">JSON</span>.stringify(data).length,{'\n'}
              {'    '}entropy: <span className="text-sky-400">Math</span>.random(),{'\n'}
              {'    '}signature: <span className="text-emerald-300">cryptoSignature</span>(data){'\n'}
              {'  };\n'}
              {'}\n\n'}
              
              <span className="text-sky-400">function</span> <span className="text-emerald-300">cryptoSignature</span>(data) {'{\n'}
              {'  '}<span className="text-sky-400">return</span> btoa({'\n'}
              {'    '}[...<span className="text-sky-400">JSON</span>.stringify(data)]{'\n'}
              {'      '}.map(x {'=>'} x.charCodeAt(<span className="text-amber-300">0</span>).toString(<span className="text-amber-300">16</span>)){'\n'}
              {'      '}.join(<span className="text-amber-200">""</span>){'\n'}
              {'  '});{'\n'}
              {'}\n\n'}
              
              <span className="text-sky-400">function</span> <span className="text-emerald-300">finalize</span>(result) {'{\n'}
              {'  '}<span className="text-sky-400">return</span> {'{\n'}
              {'    '}output: result,{'\n'}
              {'    '}timestamp: <span className="text-sky-400">Date</span>.now(),{'\n'}
              {'    '}certified: <span className="text-amber-300">true</span>,{'\n'}
              {'  };\n'}
              {'}'}
            </code>
          </pre>
        </div>
      </div>
    </section>
  );
}