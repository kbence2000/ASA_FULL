import React, { useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Target, TrendingUp, Zap } from "lucide-react";
import AppCard from "./AppCard";

/**
 * AI-powered app recommendations based on user profile
 * Analyzes: skills, rank, past projects, PvP performance, Elite Feed activity
 */
export default function AIAppRecommendations({ user, allApps }) {
  const recommendations = useMemo(() => {
    if (!user || !allApps || allApps.length === 0) {
      return {
        forYou: [],
        trending: [],
        innovative: [],
        quickWins: []
      };
    }

    // Mock scoring algorithm (in production, call AI service)
    const scoreApp = (app) => {
      let score = 0;
      
      // Tech stack match (if user has tech stack data)
      if (user.tech_stack && app.tech_stack) {
        const matches = app.tech_stack.filter(t => 
          user.tech_stack.some(ut => ut.toLowerCase().includes(t.toLowerCase()))
        ).length;
        score += matches * 15;
      }

      // Category preference (mock - could track from browsing history)
      if (app.category === 'development') score += 10;
      
      // Innovation boost for high-rank users
      if ((user.rankLabel === 'Demigod' || user.rankLabel === 'Godlike') && app.innovation_score) {
        score += app.innovation_score * 0.3;
      }

      // Quality signals
      if (app.verified) score += 20;
      if (app.featured) score += 15;
      if (app.rating) score += app.rating * 5;
      
      // Popularity (but not too much weight)
      score += Math.min((app.downloads || 0) / 100, 10);

      // Price preference (free apps get slight boost)
      if (app.price === 0) score += 5;

      return score;
    };

    const scoredApps = allApps.map(app => ({
      ...app,
      aiScore: scoreApp(app)
    }));

    return {
      forYou: scoredApps
        .sort((a, b) => b.aiScore - a.aiScore)
        .slice(0, 8),
      
      trending: allApps
        .filter(app => (app.downloads || 0) > 10)
        .sort((a, b) => (b.downloads || 0) - (a.downloads || 0))
        .slice(0, 6),
      
      innovative: allApps
        .filter(app => app.innovation_score)
        .sort((a, b) => (b.innovation_score || 0) - (a.innovation_score || 0))
        .slice(0, 6),
      
      quickWins: allApps
        .filter(app => app.price === 0)
        .sort((a, b) => (b.rating || 0) - (a.rating || 0))
        .slice(0, 6)
    };
  }, [user, allApps]);

  if (!user) {
    return (
      <div className="text-center py-20">
        <Sparkles className="w-16 h-16 text-purple-500 mx-auto mb-4" />
        <h3 className="text-2xl font-bold text-white mb-2">Sign in for AI Recommendations</h3>
        <p className="text-gray-400">
          Get personalized app suggestions based on your skills, rank, and activity
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-12">
      {/* Hero Card */}
      <Card className="border-purple-600/50 bg-gradient-to-br from-purple-600/10 to-pink-600/10 p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-black text-white">AI Recommendations for {user.username}</h2>
            <p className="text-sm text-purple-200">
              Personalized based on your <Badge className="bg-purple-600/30 text-purple-200 border-purple-600/50">
                {user.rankLabel}
              </Badge> rank and activity
            </p>
          </div>
        </div>
        <p className="text-sm text-gray-300">
          Our AI analyzed your profile, skills, PvP performance, and Elite Feed contributions to curate these recommendations.
        </p>
      </Card>

      {/* For You Section */}
      <div>
        <div className="flex items-center gap-3 mb-6">
          <Target className="w-6 h-6 text-cyan-400" />
          <h3 className="text-2xl font-bold text-white">Perfect Match For You</h3>
        </div>
        <p className="text-sm text-gray-400 mb-6">
          Top apps that match your tech stack, interests, and skill level
        </p>
        {recommendations.forYou.length === 0 ? (
          <p className="text-gray-500 text-center py-8">No recommendations yet. Browse apps to help AI learn your preferences.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {recommendations.forYou.map(app => (
              <AppCard key={app.id} app={app} showTryButton={true} />
            ))}
          </div>
        )}
      </div>

      {/* Trending Section */}
      <div>
        <div className="flex items-center gap-3 mb-6">
          <TrendingUp className="w-6 h-6 text-green-400" />
          <h3 className="text-2xl font-bold text-white">Trending Now</h3>
        </div>
        <p className="text-sm text-gray-400 mb-6">
          Most downloaded apps in the community
        </p>
        {recommendations.trending.length === 0 ? (
          <p className="text-gray-500 text-center py-8">No trending apps yet</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {recommendations.trending.map(app => (
              <AppCard key={app.id} app={app} showTryButton={true} />
            ))}
          </div>
        )}
      </div>

      {/* Innovative Section */}
      <div>
        <div className="flex items-center gap-3 mb-6">
          <Zap className="w-6 h-6 text-yellow-400" />
          <h3 className="text-2xl font-bold text-white">Most Innovative</h3>
        </div>
        <p className="text-sm text-gray-400 mb-6">
          Apps with highest innovation scores from our AI analysis
        </p>
        {recommendations.innovative.length === 0 ? (
          <p className="text-gray-500 text-center py-8">No innovation-scored apps yet</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {recommendations.innovative.map(app => (
              <AppCard key={app.id} app={app} showTryButton={true} />
            ))}
          </div>
        )}
      </div>

      {/* Quick Wins (Free) */}
      <div>
        <div className="flex items-center gap-3 mb-6">
          <Sparkles className="w-6 h-6 text-purple-400" />
          <h3 className="text-2xl font-bold text-white">Quick Wins (Free)</h3>
        </div>
        <p className="text-sm text-gray-400 mb-6">
          Top-rated free apps to boost your productivity immediately
        </p>
        {recommendations.quickWins.length === 0 ? (
          <p className="text-gray-500 text-center py-8">No free apps available yet</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {recommendations.quickWins.map(app => (
              <AppCard key={app.id} app={app} showTryButton={true} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}