import React from 'react';
import { X, Sparkles, TrendingUp, Brain, Eye, Zap, Lock, Clock, Layers, GitBranch } from 'lucide-react';
import { useTriMind } from './TriMindContext';

export default function TriMindDashboardPanel({ isOpen, onClose }) {
  const triMind = useTriMind();

  if (!isOpen) return null;

  const neuroState = triMind?.neuroState;
  const chaosIdeas = triMind?.chaosIdeas || [];
  const blueprint = triMind?.blueprint;
  const glitchState = triMind?.glitchState;
  const shadowState = triMind?.shadowState;
  const temporalState = triMind?.temporalState;
  const parallelState = triMind?.parallelState;
  const fractalState = triMind?.fractalState;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[200]"
        onClick={onClose}
      />

      {/* Panel */}
      <div 
        className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[520px] max-w-[90vw] h-[600px] max-h-[85vh] z-[201] overflow-y-auto"
        style={{
          background: 'rgba(18, 12, 4, 0.96)',
          borderRadius: '18px',
          border: '1px solid rgba(255, 220, 120, 0.4)',
          backdropFilter: 'blur(16px)',
          boxShadow: '0 0 80px rgba(255, 224, 131, 0.4)',
          padding: '20px',
          animation: 'panelSlideIn 0.35s ease-out'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <style>{`
          @keyframes panelSlideIn {
            from {
              opacity: 0;
              transform: translate(-50%, -50%) scale(0.9);
            }
            to {
              opacity: 1;
              transform: translate(-50%, -50%) scale(1);
            }
          }
        `}</style>

        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <div className="text-[0.9rem] tracking-[0.2em] uppercase" style={{ color: '#ffe083' }}>
            MULTI-MIND COUNCIL
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Primary Minds (Tri-Mind) */}
        <div className="mb-4">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-3 font-semibold" style={{ color: '#ffe083' }}>
            PRIMARY MINDS (TRI-MIND)
          </h3>
          <div className="space-y-3">
            <div 
              className="p-3 rounded-xl border"
              style={{
                background: 'rgba(18, 12, 4, 0.96)',
                borderColor: 'rgba(255, 220, 120, 0.4)'
              }}
            >
              <h4 className="text-xs font-semibold uppercase tracking-wide mb-2 flex items-center gap-2" style={{ color: '#ffe083' }}>
                <TrendingUp className="w-4 h-4" />
                NEURO EVOLUTION
              </h4>
              <p className="text-[0.7rem]" style={{ color: '#f8f0cf' }}>
                {neuroState ? (
                  <>
                    Opens: {neuroState.opens}, depth: {neuroState.depth}, efficiency: {neuroState.efficiency}%.
                    {neuroState.forecast && ` Forecast: ${neuroState.forecast}`}
                  </>
                ) : (
                  'Waiting for Neuro data...'
                )}
              </p>
            </div>

            <div 
              className="p-3 rounded-xl border"
              style={{
                background: 'rgba(18, 12, 4, 0.96)',
                borderColor: 'rgba(255, 220, 120, 0.4)'
              }}
            >
              <h4 className="text-xs font-semibold uppercase tracking-wide mb-2 flex items-center gap-2" style={{ color: '#ffe083' }}>
                <Brain className="w-4 h-4" />
                CHAOS ARCHITECT
              </h4>
              <p className="text-[0.7rem]" style={{ color: '#f8f0cf' }}>
                {chaosIdeas.length > 0 ? (
                  <>
                    Latest: "{chaosIdeas[0]}"
                    {chaosIdeas.length > 1 && ` (${chaosIdeas.length} total ideas)`}
                  </>
                ) : (
                  'Waiting for Chaos wave...'
                )}
              </p>
            </div>

            <div 
              className="p-3 rounded-xl border"
              style={{
                background: 'rgba(18, 12, 4, 0.96)',
                borderColor: 'rgba(255, 220, 120, 0.4)'
              }}
            >
              <h4 className="text-xs font-semibold uppercase tracking-wide mb-2 flex items-center gap-2" style={{ color: '#ffe083' }}>
                <Eye className="w-4 h-4" />
                DREAM RENDERER
              </h4>
              <p className="text-[0.7rem]" style={{ color: '#f8f0cf' }}>
                {blueprint ? (
                  <>
                    Blueprint "{blueprint.name}" → "{blueprint.target}" in "{blueprint.style}".
                  </>
                ) : (
                  'No blueprint generated yet...'
                )}
              </p>
            </div>
          </div>
        </div>

        {/* Extended Minds */}
        <div className="mb-4">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-3 font-semibold" style={{ color: '#ffe083' }}>
            EXTENDED MINDS
          </h3>
          <div className="space-y-2">
            <div 
              className="p-2.5 rounded-lg border"
              style={{
                background: 'rgba(18, 12, 4, 0.96)',
                borderColor: 'rgba(255, 220, 120, 0.3)'
              }}
            >
              <h4 className="text-[0.65rem] font-semibold uppercase tracking-wide mb-1 flex items-center gap-2" style={{ color: '#ffd9a8' }}>
                <Zap className="w-3 h-3" />
                GLITCH ENGINEER
              </h4>
              <p className="text-[0.65rem]" style={{ color: '#f8f0cf' }}>
                {glitchState ? `Latest: ${glitchState.label}` : 'No glitch pattern committed.'}
              </p>
            </div>

            <div 
              className="p-2.5 rounded-lg border"
              style={{
                background: 'rgba(18, 12, 4, 0.96)',
                borderColor: 'rgba(255, 220, 120, 0.3)'
              }}
            >
              <h4 className="text-[0.65rem] font-semibold uppercase tracking-wide mb-1 flex items-center gap-2" style={{ color: '#ffd9a8' }}>
                <Lock className="w-3 h-3" />
                SHADOW ARCHIVIST
              </h4>
              <p className="text-[0.65rem]" style={{ color: '#f8f0cf' }}>
                {shadowState ? `Last route: ${shadowState.routeName}` : 'Archive dormant.'}
              </p>
            </div>

            <div 
              className="p-2.5 rounded-lg border"
              style={{
                background: 'rgba(18, 12, 4, 0.96)',
                borderColor: 'rgba(255, 220, 120, 0.3)'
              }}
            >
              <h4 className="text-[0.65rem] font-semibold uppercase tracking-wide mb-1 flex items-center gap-2" style={{ color: '#ffd9a8' }}>
                <Clock className="w-3 h-3" />
                TEMPORAL ENGINE
              </h4>
              <p className="text-[0.65rem]" style={{ color: '#f8f0cf' }}>
                {temporalState ? `Window: ${temporalState.windowLabel}.` : 'No time anomaly defined.'}
              </p>
            </div>

            <div 
              className="p-2.5 rounded-lg border"
              style={{
                background: 'rgba(18, 12, 4, 0.96)',
                borderColor: 'rgba(255, 220, 120, 0.3)'
              }}
            >
              <h4 className="text-[0.65rem] font-semibold uppercase tracking-wide mb-1 flex items-center gap-2" style={{ color: '#ffd9a8' }}>
                <Layers className="w-3 h-3" />
                PARALLEL ARCHITECT
              </h4>
              <p className="text-[0.65rem]" style={{ color: '#f8f0cf' }}>
                {parallelState ? `Realities: ${parallelState.count}, focus: ${parallelState.focus}.` : 'No parallel layouts generated.'}
              </p>
            </div>

            <div 
              className="p-2.5 rounded-lg border"
              style={{
                background: 'rgba(18, 12, 4, 0.96)',
                borderColor: 'rgba(255, 220, 120, 0.3)'
              }}
            >
              <h4 className="text-[0.65rem] font-semibold uppercase tracking-wide mb-1 flex items-center gap-2" style={{ color: '#ffd9a8' }}>
                <GitBranch className="w-3 h-3" />
                FRACTAL ENGINEER
              </h4>
              <p className="text-[0.65rem]" style={{ color: '#f8f0cf' }}>
                {fractalState ? `Depth: ${fractalState.depth}, nodes: ${fractalState.nodes}.` : 'Fractal recursion idle.'}
              </p>
            </div>
          </div>
        </div>

        {/* System Status */}
        <div className="mb-4">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-3 font-semibold" style={{ color: '#ffe083' }}>
            SYSTEM STATUS
          </h3>
          <div className="grid grid-cols-4 gap-2">
            {[
              { label: 'NEURO', active: !!neuroState, color: '#9fa8ff' },
              { label: 'CHAOS', active: chaosIdeas.length > 0, color: '#ff66e7' },
              { label: 'DREAM', active: !!blueprint, color: '#3bd3ff' },
              { label: 'GLITCH', active: !!glitchState, color: '#ff4b5c' },
              { label: 'SHADOW', active: !!shadowState, color: '#9b9bbb' },
              { label: 'TIME', active: !!temporalState, color: '#b788ff' },
              { label: 'PARALLEL', active: !!parallelState, color: '#24e4ff' },
              { label: 'FRACTAL', active: !!fractalState, color: '#4eff8b' },
            ].map((brain, idx) => (
              <div 
                key={idx}
                className="p-2 rounded-lg border text-center"
                style={{
                  background: 'rgba(18, 12, 4, 0.8)',
                  borderColor: brain.active ? `${brain.color}66` : 'rgba(255, 220, 120, 0.2)'
                }}
              >
                <div className="text-[0.6rem] font-semibold" style={{ color: '#ffe083' }}>{brain.label}</div>
                <div 
                  className="w-2 h-2 rounded-full mx-auto mt-1"
                  style={{ 
                    background: brain.active ? brain.color : '#666',
                    boxShadow: brain.active ? `0 0 8px ${brain.color}` : 'none'
                  }}
                />
              </div>
            ))}
          </div>
        </div>

        {/* Council Synthesis */}
        <div 
          className="p-3 rounded-lg"
          style={{
            background: 'rgba(255, 224, 131, 0.1)',
            border: '1px solid rgba(255, 224, 131, 0.3)'
          }}
        >
          <div className="flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <span className="font-semibold text-white">Multi-Mind Council Synthesis:</span> 
              {neuroState && chaosIdeas.length > 0 && blueprint && glitchState && shadowState ? (
                <> All 8 brains are online and synchronized. The Council operates at maximum cognitive capacity - logic, creativity, vision, corruption, secrets, time, multiverse, and recursion all unified.</>
              ) : (
                <> Activate all 8 minds to unlock full Council synthesis. Each brain contributes a unique perspective to the collective intelligence.</>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}