/**
 * Backend API Client
 * Handles all communication with the Node.js backend
 */

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL || 'https://codemarket-backend.vercel.app';

class BackendClient {
  constructor(baseURL = BACKEND_URL) {
    this.baseURL = baseURL;
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    
    const config = {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      },
      credentials: 'include'
    };

    try {
      const response = await fetch(url, config);
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || `HTTP ${response.status}`);
      }
      
      return data;
    } catch (error) {
      console.error('Backend API error:', error);
      throw error;
    }
  }

  // Health check
  async healthCheck() {
    return this.request('/health');
  }

  // Generate Revolut payment link
  async generateRevolutLink({ appId, amount, currency, buyerEmail, sellerEmail, licenseType, affiliateCode }) {
    return this.request('/api/revolut/generate-link', {
      method: 'POST',
      body: JSON.stringify({
        appId,
        amount,
        currency,
        buyerEmail,
        sellerEmail,
        licenseType,
        affiliateCode
      })
    });
  }

  // Request download token
  async requestDownload({ appId, userEmail }) {
    return this.request('/api/download/request', {
      method: 'POST',
      body: JSON.stringify({
        appId,
        userEmail
      })
    });
  }

  // Get backend status
  async getStatus() {
    try {
      const health = await this.healthCheck();
      return {
        online: true,
        ...health
      };
    } catch (error) {
      return {
        online: false,
        error: error.message
      };
    }
  }
}

export const backendClient = new BackendClient();
export default backendClient;