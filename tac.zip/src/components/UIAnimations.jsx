/**
 * MDC UI Animation Utilities
 * Smooth transitions, pulse effects, and card animations
 */

export const UI = {
  /**
   * Apply pulsing glow animation to logo
   */
  applyPulseLogo() {
    const logo = document.getElementById("mdcLogo");
    if (!logo) return;

    logo.style.animation = "pulseGlow 3.2s infinite ease-in-out";
  },

  /**
   * Set global CSS transition variables
   */
  applyGlobalTransitions() {
    const root = document.documentElement;

    root.style.setProperty("--transition-fast", "0.18s ease");
    root.style.setProperty("--transition-mid", "0.34s ease");
    root.style.setProperty("--transition-slow", "0.75s ease");

    document.body.classList.add("smooth-ui");
  },

  /**
   * Animate panels/cards with staggered fade-in
   */
  animatePanels() {
    const cards = document.querySelectorAll(".card, [data-animate='card']");
    cards.forEach((c, i) => {
      c.style.opacity = "0";
      c.style.transform = "translateY(10px)";
      setTimeout(() => {
        c.style.transition = "0.4s ease";
        c.style.opacity = "1";
        c.style.transform = "translateY(0px)";
      }, 120 * i);
    });
  },

  /**
   * Animate feed items with staggered entrance
   */
  animateFeedItems(selector = ".feedItem") {
    const items = document.querySelectorAll(selector);
    items.forEach((item, i) => {
      item.style.opacity = "0";
      item.style.transform = "translateX(-20px)";
      setTimeout(() => {
        item.style.transition = "0.5s cubic-bezier(0.4, 0, 0.2, 1)";
        item.style.opacity = "1";
        item.style.transform = "translateX(0)";
      }, 80 * i);
    });
  },

  /**
   * Apply hover glow effect to element
   */
  applyHoverGlow(element, color = "rgba(139, 92, 255, 0.6)") {
    if (!element) return;
    
    element.addEventListener("mouseenter", () => {
      element.style.boxShadow = `0 0 20px ${color}`;
      element.style.transform = "translateY(-2px)";
    });
    
    element.addEventListener("mouseleave", () => {
      element.style.boxShadow = "";
      element.style.transform = "";
    });
  },

  /**
   * Smooth scroll to element
   */
  smoothScrollTo(elementId, offset = 80) {
    const element = document.getElementById(elementId);
    if (!element) return;

    const top = element.getBoundingClientRect().top + window.pageYOffset - offset;
    window.scrollTo({
      top,
      behavior: "smooth"
    });
  },

  /**
   * Initialize all animations on page load
   */
  initAll() {
    this.applyGlobalTransitions();
    
    // Wait for DOM to be fully loaded
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => {
        this.applyPulseLogo();
        this.animatePanels();
      });
    } else {
      this.applyPulseLogo();
      this.animatePanels();
    }
  }
};

// Export individual functions for tree-shaking
export const applyPulseLogo = UI.applyPulseLogo.bind(UI);
export const applyGlobalTransitions = UI.applyGlobalTransitions.bind(UI);
export const animatePanels = UI.animatePanels.bind(UI);
export const animateFeedItems = UI.animateFeedItems.bind(UI);
export const applyHoverGlow = UI.applyHoverGlow.bind(UI);
export const smoothScrollTo = UI.smoothScrollTo.bind(UI);

export default UI;