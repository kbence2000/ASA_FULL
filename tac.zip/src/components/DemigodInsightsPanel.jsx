import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, TrendingUp, Target, Zap, Award, Code2 } from "lucide-react";
import { demigodAPI } from "./DemigodAPIClient";

export default function DemigodInsightsPanel({ userId }) {
  const [insights, setInsights] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (userId) {
      fetchInsights();
    }
  }, [userId]);

  const fetchInsights = async () => {
    try {
      const data = await demigodAPI.getInsights(userId);
      setInsights(data);
    } catch (error) {
      console.error("Failed to fetch insights:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card className="border p-6 text-center" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <p className="text-gray-400">Loading insights...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Overview */}
      <Card className="border p-6" style={{
        background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
        borderColor: 'rgba(139, 92, 255, 0.3)'
      }}>
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <Brain className="w-5 h-5 text-purple-400" />
          AI Insights
        </h3>

        <div className="grid md:grid-cols-3 gap-4">
          <div className="text-center p-4 rounded-lg" style={{
            background: 'rgba(59, 130, 246, 0.1)',
            border: '1px solid rgba(59, 130, 246, 0.3)'
          }}>
            <Code2 className="w-6 h-6 text-blue-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-blue-400">
              {insights?.codeQuality || "N/A"}
            </div>
            <div className="text-xs text-gray-400">Code Quality</div>
          </div>

          <div className="text-center p-4 rounded-lg" style={{
            background: 'rgba(34, 197, 94, 0.1)',
            border: '1px solid rgba(34, 197, 94, 0.3)'
          }}>
            <TrendingUp className="w-6 h-6 text-green-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-green-400">
              {insights?.growth || "N/A"}%
            </div>
            <div className="text-xs text-gray-400">Growth Rate</div>
          </div>

          <div className="text-center p-4 rounded-lg" style={{
            background: 'rgba(168, 85, 247, 0.1)',
            border: '1px solid rgba(168, 85, 247, 0.3)'
          }}>
            <Zap className="w-6 h-6 text-purple-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-purple-400">
              {insights?.velocity || "N/A"}
            </div>
            <div className="text-xs text-gray-400">Dev Velocity</div>
          </div>
        </div>
      </Card>

      {/* Strengths */}
      {insights?.strengths && insights.strengths.length > 0 && (
        <Card className="border p-6" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <h4 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Award className="w-5 h-5 text-green-400" />
            Your Strengths
          </h4>

          <div className="space-y-3">
            {insights.strengths.map((strength, idx) => (
              <div
                key={idx}
                className="p-3 rounded-lg border"
                style={{
                  background: 'rgba(34, 197, 94, 0.05)',
                  borderColor: 'rgba(34, 197, 94, 0.3)'
                }}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-green-300">{strength.skill}</span>
                  <Badge className="bg-green-600/20 text-green-300 border-green-600/30">
                    {strength.level || "Expert"}
                  </Badge>
                </div>
                <p className="text-sm text-gray-400">{strength.description}</p>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Growth Areas */}
      {insights?.growthAreas && insights.growthAreas.length > 0 && (
        <Card className="border p-6" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <h4 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Target className="w-5 h-5 text-orange-400" />
            Growth Opportunities
          </h4>

          <div className="space-y-3">
            {insights.growthAreas.map((area, idx) => (
              <div
                key={idx}
                className="p-3 rounded-lg border"
                style={{
                  background: 'rgba(251, 146, 60, 0.05)',
                  borderColor: 'rgba(251, 146, 60, 0.3)'
                }}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-orange-300">{area.skill}</span>
                  <Badge className="bg-orange-600/20 text-orange-300 border-orange-600/30">
                    {area.priority || "Medium"}
                  </Badge>
                </div>
                <p className="text-sm text-gray-400">{area.recommendation}</p>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Recommendations */}
      {insights?.recommendations && (
        <Card className="border p-6" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <h4 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Brain className="w-5 h-5 text-cyan-400" />
            AI Recommendations
          </h4>

          <div className="space-y-2">
            {insights.recommendations.map((rec, idx) => (
              <div
                key={idx}
                className="p-3 rounded-lg border text-sm"
                style={{
                  background: 'rgba(5, 8, 22, 0.5)',
                  borderColor: 'rgba(148, 163, 184, 0.2)'
                }}
              >
                <p className="text-gray-300 leading-relaxed">{rec}</p>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}