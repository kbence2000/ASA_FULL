import React, { useState, useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Swords, Trophy, Target, TrendingUp, Sparkles, ChevronRight } from "lucide-react";
import AppCard from "./AppCard";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

/**
 * App Battle Royale - Innovation PvP themed competition
 * Apps compete in innovation, quality, and community votes
 */
export default function AppBattleRoyale({ apps }) {
  const [activeBattle, setActiveBattle] = useState("innovation");

  const battles = useMemo(() => {
    if (!apps || apps.length === 0) return {};

    // Innovation Battle (highest innovation_score)
    const innovationTop = apps
      .filter(app => app.innovation_score)
      .sort((a, b) => (b.innovation_score || 0) - (a.innovation_score || 0))
      .slice(0, 6);

    // Quality Battle (highest rating)
    const qualityTop = apps
      .filter(app => (app.rating || 0) > 0)
      .sort((a, b) => (b.rating || 0) - (a.rating || 0))
      .slice(0, 6);

    // Popularity Battle (most downloads)
    const popularityTop = apps
      .filter(app => (app.downloads || 0) > 0)
      .sort((a, b) => (b.downloads || 0) - (a.downloads || 0))
      .slice(0, 6);

    // Rising Stars (newest with good ratings)
    const risingStars = apps
      .filter(app => {
        const age = Date.now() - new Date(app.created_date).getTime();
        const daysSince = age / (1000 * 60 * 60 * 24);
        return daysSince < 30 && (app.rating || 0) >= 4;
      })
      .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
      .slice(0, 6);

    return {
      innovation: innovationTop,
      quality: qualityTop,
      popularity: popularityTop,
      rising: risingStars
    };
  }, [apps]);

  const battleConfig = {
    innovation: {
      title: "Innovation Battle",
      icon: Sparkles,
      color: "text-purple-400",
      bg: "bg-purple-600/10",
      border: "border-purple-600/30",
      description: "Apps competing on AI-measured innovation scores. Most creative, cutting-edge implementations win.",
      metric: "Innovation Score"
    },
    quality: {
      title: "Quality Battle",
      icon: Target,
      color: "text-cyan-400",
      bg: "bg-cyan-600/10",
      border: "border-cyan-600/30",
      description: "Battle of craftsmanship. Highest user ratings and code quality dominate.",
      metric: "Rating"
    },
    popularity: {
      title: "Popularity Battle",
      icon: TrendingUp,
      color: "text-green-400",
      bg: "bg-green-600/10",
      border: "border-green-600/30",
      description: "Community's favorites. Most downloaded and actively used apps reign supreme.",
      metric: "Downloads"
    },
    rising: {
      title: "Rising Stars",
      icon: Trophy,
      color: "text-yellow-400",
      bg: "bg-yellow-600/10",
      border: "border-yellow-600/30",
      description: "Newest apps making waves. Fresh talent breaking into the scene.",
      metric: "Age & Rating"
    }
  };

  const currentBattle = battleConfig[activeBattle];
  const currentApps = battles[activeBattle] || [];
  const Icon = currentBattle.icon;

  return (
    <div className="space-y-8">
      {/* Hero Card */}
      <Card className="border-orange-600/50 bg-gradient-to-br from-orange-600/10 to-red-600/10 p-6">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-orange-600 to-red-600 flex items-center justify-center">
            <Swords className="w-8 h-8 text-white" />
          </div>
          <div>
            <h2 className="text-3xl font-black text-white">App Battle Royale</h2>
            <p className="text-sm text-orange-200">
              Where apps compete in <strong>innovation, quality, and popularity</strong>
            </p>
          </div>
        </div>
        <p className="text-sm text-gray-300 leading-relaxed">
          Inspired by <strong className="text-orange-300">Innovation PvP</strong>, App Battle Royale pits the best apps against each other.
          Winners get <Badge className="bg-orange-600/30 text-orange-200 border-orange-600/50">Battle Champion</Badge> badges and featured placement.
        </p>
      </Card>

      {/* Battle Type Selector */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {Object.entries(battleConfig).map(([key, config]) => {
          const BattleIcon = config.icon;
          const isActive = activeBattle === key;
          return (
            <button
              key={key}
              onClick={() => setActiveBattle(key)}
              className={`p-4 rounded-xl border-2 transition-all ${
                isActive 
                  ? `${config.border} ${config.bg}` 
                  : 'border-[#1a1f2e] bg-[#0f1419] hover:border-[#2a2f3e]'
              }`}
            >
              <BattleIcon className={`w-8 h-8 ${isActive ? config.color : 'text-gray-500'} mx-auto mb-2`} />
              <div className={`text-sm font-bold ${isActive ? 'text-white' : 'text-gray-400'}`}>
                {config.title}
              </div>
            </button>
          );
        })}
      </div>

      {/* Current Battle Arena */}
      <Card className={`border ${currentBattle.border} ${currentBattle.bg} p-6`}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Icon className={`w-6 h-6 ${currentBattle.color}`} />
            <div>
              <h3 className="text-2xl font-black text-white">{currentBattle.title}</h3>
              <p className="text-sm text-gray-300">{currentBattle.description}</p>
            </div>
          </div>
          <Badge className={`${currentBattle.bg} ${currentBattle.color} border ${currentBattle.border} text-sm px-3 py-1`}>
            {currentApps.length} Competitors
          </Badge>
        </div>

        {currentApps.length === 0 ? (
          <div className="text-center py-12">
            <Icon className={`w-16 h-16 ${currentBattle.color} mx-auto mb-4 opacity-50`} />
            <p className="text-gray-500">No apps in this battle yet. Be the first to compete!</p>
            <Link to={createPageUrl("AddApp")}>
              <Button className="mt-4 bg-gradient-to-r from-orange-600 to-red-600">
                Upload App
              </Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Top 3 Podium */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {currentApps.slice(0, 3).map((app, idx) => (
                <Card 
                  key={app.id}
                  className={`p-4 border-2 ${
                    idx === 0 ? 'border-yellow-500 bg-gradient-to-br from-yellow-600/10 to-orange-600/10' :
                    idx === 1 ? 'border-gray-400 bg-gradient-to-br from-gray-600/10 to-slate-600/10' :
                    'border-orange-700 bg-gradient-to-br from-orange-800/10 to-red-800/10'
                  }`}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center text-xl font-black ${
                      idx === 0 ? 'bg-yellow-500 text-black' :
                      idx === 1 ? 'bg-gray-400 text-black' :
                      'bg-orange-700 text-white'
                    }`}>
                      {idx + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-white truncate">{app.name}</div>
                      <div className="text-xs text-gray-400">{app.developer}</div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">{currentBattle.metric}:</span>
                    <span className={`font-bold ${currentBattle.color}`}>
                      {activeBattle === 'innovation' && app.innovation_score}
                      {activeBattle === 'quality' && app.rating?.toFixed(1)}
                      {activeBattle === 'popularity' && app.downloads}
                      {activeBattle === 'rising' && `${app.rating?.toFixed(1)} ⭐`}
                    </span>
                  </div>
                  <Link to={createPageUrl("AppDetail") + `?id=${app.id}`}>
                    <Button size="sm" className="w-full mt-3" variant="outline">
                      View Details
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </Card>
              ))}
            </div>

            {/* Remaining Competitors */}
            {currentApps.length > 3 && (
              <div>
                <h4 className="text-lg font-bold text-white mb-4">More Competitors</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {currentApps.slice(3).map(app => (
                    <AppCard key={app.id} app={app} showTryButton={true} />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </Card>

      {/* Battle Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-[#1a1f2e] bg-[#0f1419] p-4">
          <div className="text-xs text-gray-400 mb-1">Total Battles</div>
          <div className="text-2xl font-bold text-white">4</div>
        </Card>
        <Card className="border-[#1a1f2e] bg-[#0f1419] p-4">
          <div className="text-xs text-gray-400 mb-1">Active Competitors</div>
          <div className="text-2xl font-bold text-white">{apps.length}</div>
        </Card>
        <Card className="border-[#1a1f2e] bg-[#0f1419] p-4">
          <div className="text-xs text-gray-400 mb-1">Champions Crowned</div>
          <div className="text-2xl font-bold text-yellow-400">{Math.min(apps.length, 12)}</div>
        </Card>
        <Card className="border-[#1a1f2e] bg-[#0f1419] p-4">
          <div className="text-xs text-gray-400 mb-1">Prize Pool</div>
          <div className="text-2xl font-bold text-green-400">Featured</div>
        </Card>
      </div>
    </div>
  );
}