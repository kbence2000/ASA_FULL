import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Trophy, Star, Code2, DollarSign, 
  ChevronDown, ChevronUp, Target, Sparkles,
  Shield, TrendingUp, Users
} from "lucide-react";

const EXPERIENCE_CONFIG = {
  junior: { color: "text-blue-400", bg: "bg-blue-600/20", border: "border-blue-600/30" },
  mid: { color: "text-green-400", bg: "bg-green-600/20", border: "border-green-600/30" },
  senior: { color: "text-yellow-400", bg: "bg-yellow-600/20", border: "border-yellow-600/30" },
  demigod: { color: "text-purple-400", bg: "bg-purple-600/20", border: "border-purple-600/30" }
};

export default function DeveloperMatchCard({ match, rank }) {
  const [expanded, setExpanded] = useState(false);
  const expCfg = EXPERIENCE_CONFIG[match.experienceLevel] || EXPERIENCE_CONFIG.mid;
  
  const isTop3 = rank <= 3;
  const isTeam = match.id.startsWith("team_");

  return (
    <Card className={`border transition-all ${
      isTop3 
        ? 'border-purple-500/50 bg-gradient-to-br from-purple-600/5 to-pink-600/5' 
        : 'border-[#1a1f2e] bg-[#141923]'
    } p-4`}>
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-3 flex-1">
          {/* Rank Badge */}
          <div className={`flex items-center justify-center w-8 h-8 rounded-full text-sm font-bold ${
            rank === 1 
              ? 'bg-yellow-500 text-black'
              : rank === 2
              ? 'bg-gray-300 text-black'
              : rank === 3
              ? 'bg-orange-600 text-white'
              : 'bg-[#0a0a0f] text-gray-400 border border-[#1a1f2e]'
          }`}>
            {rank}
          </div>

          <div className="flex-1">
            {/* Name & Experience */}
            <div className="flex items-center gap-2 mb-2">
              <h3 className="font-bold text-white">{match.name}</h3>
              <Badge className={`${expCfg.bg} ${expCfg.color} border ${expCfg.border} text-xs`}>
                {match.experienceLevel}
              </Badge>
              {isTeam && (
                <Badge className="bg-cyan-600/20 text-cyan-400 border-cyan-600/30 text-xs">
                  <Users className="w-3 h-3 mr-1" />
                  Team
                </Badge>
              )}
            </div>

            {/* Tech Stack */}
            <div className="flex flex-wrap gap-1 mb-3">
              {match.techStack.slice(0, 4).map((tech, idx) => (
                <span 
                  key={idx}
                  className="text-xs px-2 py-0.5 rounded bg-[#0a0a0f] text-gray-400 border border-[#1a1f2e]"
                >
                  {tech}
                </span>
              ))}
              {match.techStack.length > 4 && (
                <span className="text-xs text-gray-500">
                  +{match.techStack.length - 4} more
                </span>
              )}
            </div>

            {/* Key Metrics */}
            <div className="flex items-center gap-4 text-xs mb-3">
              <div className="flex items-center gap-1">
                <Star className="w-3 h-3 text-yellow-400" />
                <span className="text-white font-semibold">{match.matchScore}</span>
                <span className="text-gray-500">match</span>
              </div>

              <div className="flex items-center gap-1">
                <DollarSign className="w-3 h-3 text-green-400" />
                <span className="text-white font-semibold">€{match.hourlyRate}/h</span>
              </div>
            </div>

            {/* Tags */}
            {match.tags && match.tags.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {match.tags.slice(0, 3).map((tag, idx) => (
                  <span 
                    key={idx}
                    className="text-xs px-2 py-0.5 rounded-full border border-purple-600/30 text-purple-300 bg-purple-600/10"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Expand/Collapse */}
        <Button
          onClick={() => setExpanded(!expanded)}
          size="sm"
          variant="ghost"
          className="p-1"
        >
          {expanded ? (
            <ChevronUp className="w-4 h-4 text-gray-400" />
          ) : (
            <ChevronDown className="w-4 h-4 text-gray-400" />
          )}
        </Button>
      </div>

      {/* Expanded Details */}
      {expanded && match.details && (
        <div className="mt-4 pt-4 border-t border-[#1a1f2e]">
          <div className="grid grid-cols-2 gap-3">
            <div className="p-2 rounded bg-[#0a0a0f] border border-[#1a1f2e]">
              <div className="flex items-center gap-1 mb-1">
                <Target className="w-3 h-3 text-blue-400" />
                <span className="text-xs text-gray-400">Tech Fit</span>
              </div>
              <div className="text-base font-bold text-blue-400">
                {match.details.techFit}%
              </div>
            </div>

            <div className="p-2 rounded bg-[#0a0a0f] border border-[#1a1f2e]">
              <div className="flex items-center gap-1 mb-1">
                <Sparkles className="w-3 h-3 text-purple-400" />
                <span className="text-xs text-gray-400">Innovation</span>
              </div>
              <div className="text-base font-bold text-purple-400">
                {match.details.innovation}
              </div>
            </div>

            <div className="p-2 rounded bg-[#0a0a0f] border border-[#1a1f2e]">
              <div className="flex items-center gap-1 mb-1">
                <Shield className="w-3 h-3 text-green-400" />
                <span className="text-xs text-gray-400">Quality</span>
              </div>
              <div className="text-base font-bold text-green-400">
                {match.details.quality}
              </div>
            </div>

            <div className="p-2 rounded bg-[#0a0a0f] border border-[#1a1f2e]">
              <div className="flex items-center gap-1 mb-1">
                <TrendingUp className="w-3 h-3 text-cyan-400" />
                <span className="text-xs text-gray-400">Availability</span>
              </div>
              <div className="text-base font-bold text-cyan-400">
                +{match.details.availabilityBonus}
              </div>
            </div>
          </div>

          {match.details.ratePenalty > 0 && (
            <div className="mt-3 p-2 rounded bg-yellow-600/10 border border-yellow-600/30">
              <div className="text-xs text-yellow-300">
                ⚠ Rate may exceed budget (penalty: -{match.details.ratePenalty})
              </div>
            </div>
          )}
        </div>
      )}
    </Card>
  );
}