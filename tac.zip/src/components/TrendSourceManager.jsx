import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Plus, 
  Trash2, 
  Power, 
  Edit2, 
  Check, 
  X, 
  Code2,
  Globe,
  Brain
} from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

export default function TrendSourceManager() {
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    sourceId: "",
    label: "",
    mode: "ai-only",
    url: "",
    topic: "",
    maxSnippets: 3
  });

  const queryClient = useQueryClient();

  const { data: sources, isLoading } = useQuery({
    queryKey: ['trendSources'],
    queryFn: () => base44.entities.TrendSource.list('-created_date'),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.TrendSource.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trendSources'] });
      toast.success("Source added successfully!");
      resetForm();
    },
    onError: () => {
      toast.error("Failed to add source!");
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.TrendSource.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trendSources'] });
      toast.success("Source updated successfully!");
      setEditingId(null);
    },
    onError: () => {
      toast.error("Failed to update source!");
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.TrendSource.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trendSources'] });
      toast.success("Source deleted successfully!");
    },
    onError: () => {
      toast.error("Failed to delete source!");
    }
  });

  const toggleMutation = useMutation({
    mutationFn: ({ id, enabled }) => base44.entities.TrendSource.update(id, { enabled }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trendSources'] });
      toast.success("Source status updated!");
    },
    onError: () => {
      toast.error("Failed to update status!");
    }
  });

  const resetForm = () => {
    setFormData({
      sourceId: "",
      label: "",
      mode: "ai-only",
      url: "",
      topic: "",
      maxSnippets: 3
    });
    setIsAdding(false);
    setEditingId(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.label || !formData.mode) {
      toast.error("Label and mode are required!");
      return;
    }

    if (formData.mode === "html" && !formData.url) {
      toast.error("URL is required for HTML mode!");
      return;
    }

    if (formData.mode === "ai-only" && !formData.topic) {
      toast.error("Topic is required for AI-only mode!");
      return;
    }

    const data = {
      ...formData,
      sourceId: formData.sourceId || formData.label.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
      enabled: true
    };

    if (editingId) {
      updateMutation.mutate({ id: editingId, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (source) => {
    setFormData({
      sourceId: source.sourceId,
      label: source.label,
      mode: source.mode,
      url: source.url || "",
      topic: source.topic || "",
      maxSnippets: source.maxSnippets || 3
    });
    setEditingId(source.id);
    setIsAdding(true);
  };

  const handleToggle = (source) => {
    toggleMutation.mutate({ 
      id: source.id, 
      enabled: !source.enabled 
    });
  };

  const handleDelete = (id) => {
    if (confirm("Are you sure you want to delete this source?")) {
      deleteMutation.mutate(id);
    }
  };

  return (
    <Card className="border p-6" style={{
      background: 'rgba(15, 23, 42, 0.95)',
      borderColor: 'rgba(148, 163, 184, 0.35)'
    }}>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold text-white mb-1">Trend Sources</h2>
          <p className="text-sm text-gray-400">Manage snippet harvest sources</p>
        </div>

        <Button
          onClick={() => {
            setIsAdding(!isAdding);
            if (!isAdding) resetForm();
          }}
          variant={isAdding ? "outline" : "default"}
          style={isAdding ? {} : {
            background: 'linear-gradient(135deg, #8b5cff, #24e4ff)',
            color: 'white'
          }}
        >
          {isAdding ? (
            <>
              <X className="w-4 h-4 mr-2" />
              Cancel
            </>
          ) : (
            <>
              <Plus className="w-4 h-4 mr-2" />
              Add Source
            </>
          )}
        </Button>
      </div>

      {/* Add/Edit Form */}
      {isAdding && (
        <Card className="border p-6 mb-6" style={{
          background: 'rgba(5, 8, 22, 0.9)',
          borderColor: 'rgba(139, 92, 255, 0.3)'
        }}>
          <h3 className="text-lg font-bold text-white mb-4">
            {editingId ? 'Edit Source' : 'Add New Source'}
          </h3>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label className="text-white mb-2 block">Label *</Label>
                <Input
                  value={formData.label}
                  onChange={(e) => setFormData(prev => ({ ...prev, label: e.target.value }))}
                  placeholder="e.g., dev.to/javascript"
                  className="bg-[#141923] border-[#1a1f2e] text-white"
                  required
                />
              </div>

              <div>
                <Label className="text-white mb-2 block">Mode *</Label>
                <Select 
                  value={formData.mode} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, mode: value }))}
                >
                  <SelectTrigger className="bg-[#141923] border-[#1a1f2e] text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ai-only">AI-Only (Safe)</SelectItem>
                    <SelectItem value="html">HTML Scraping (Use with caution)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {formData.mode === "html" && (
              <div>
                <Label className="text-white mb-2 block">URL *</Label>
                <Input
                  value={formData.url}
                  onChange={(e) => setFormData(prev => ({ ...prev, url: e.target.value }))}
                  placeholder="https://example.com"
                  className="bg-[#141923] border-[#1a1f2e] text-white"
                  required={formData.mode === "html"}
                />
                <p className="text-xs text-yellow-400 mt-1">
                  ⚠️ Only use URLs you have permission to scrape
                </p>
              </div>
            )}

            {formData.mode === "ai-only" && (
              <div>
                <Label className="text-white mb-2 block">Topic *</Label>
                <Input
                  value={formData.topic}
                  onChange={(e) => setFormData(prev => ({ ...prev, topic: e.target.value }))}
                  placeholder="e.g., GitHub trending repos today"
                  className="bg-[#141923] border-[#1a1f2e] text-white"
                  required={formData.mode === "ai-only"}
                />
              </div>
            )}

            <div>
              <Label className="text-white mb-2 block">Max Snippets</Label>
              <Input
                type="number"
                min="1"
                max="10"
                value={formData.maxSnippets}
                onChange={(e) => setFormData(prev => ({ ...prev, maxSnippets: parseInt(e.target.value) }))}
                className="bg-[#141923] border-[#1a1f2e] text-white"
              />
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                onClick={resetForm}
                variant="outline"
                className="flex-1 border-[#1a1f2e] text-white"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createMutation.isPending || updateMutation.isPending}
                className="flex-1"
                style={{
                  background: 'linear-gradient(135deg, #8b5cff, #24e4ff)',
                  color: 'white'
                }}
              >
                {editingId ? (
                  <>
                    <Check className="w-4 h-4 mr-2" />
                    Update
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4 mr-2" />
                    Add
                  </>
                )}
              </Button>
            </div>
          </form>
        </Card>
      )}

      {/* Sources List */}
      {isLoading ? (
        <div className="text-center py-8">
          <p className="text-gray-400">Loading sources...</p>
        </div>
      ) : sources.length === 0 ? (
        <div className="text-center py-12">
          <Code2 className="w-12 h-12 text-gray-600 mx-auto mb-3" />
          <p className="text-gray-400">No sources configured yet</p>
        </div>
      ) : (
        <div className="space-y-3">
          {sources.map(source => (
            <Card key={source.id} className="border p-4 hover:shadow-lg transition-all" style={{
              background: 'rgba(5, 8, 22, 0.6)',
              borderColor: source.enabled ? 'rgba(139, 92, 255, 0.3)' : 'rgba(148, 163, 184, 0.2)'
            }}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 flex-1">
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{
                    background: source.mode === "html" 
                      ? 'linear-gradient(135deg, #f59e0b, #d97706)' 
                      : 'linear-gradient(135deg, #8b5cff, #24e4ff)'
                  }}>
                    {source.mode === "html" ? (
                      <Globe className="w-5 h-5 text-white" />
                    ) : (
                      <Brain className="w-5 h-5 text-white" />
                    )}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-bold text-white">{source.label}</h3>
                      <Badge className={
                        source.mode === "html"
                          ? "bg-orange-600/20 text-orange-300 border-orange-600/30"
                          : "bg-purple-600/20 text-purple-300 border-purple-600/30"
                      }>
                        {source.mode}
                      </Badge>
                      {source.enabled ? (
                        <Badge className="bg-green-600/20 text-green-300 border-green-600/30">
                          Active
                        </Badge>
                      ) : (
                        <Badge className="bg-gray-600/20 text-gray-400 border-gray-600/30">
                          Disabled
                        </Badge>
                      )}
                    </div>

                    <div className="text-sm text-gray-400 space-y-1">
                      <div className="flex items-center gap-2">
                        <Code2 className="w-3 h-3" />
                        <span className="text-xs">Max: {source.maxSnippets} snippets</span>
                      </div>
                      {source.url && (
                        <div className="text-xs text-cyan-400 truncate max-w-md">
                          {source.url}
                        </div>
                      )}
                      {source.topic && (
                        <div className="text-xs text-gray-500 truncate max-w-md">
                          {source.topic}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    onClick={() => handleToggle(source)}
                    variant="ghost"
                    size="icon"
                    className={source.enabled ? "text-green-400" : "text-gray-500"}
                    disabled={toggleMutation.isPending}
                  >
                    <Power className="w-4 h-4" />
                  </Button>

                  <Button
                    onClick={() => handleEdit(source)}
                    variant="ghost"
                    size="icon"
                    className="text-cyan-400"
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>

                  <Button
                    onClick={() => handleDelete(source.id)}
                    variant="ghost"
                    size="icon"
                    className="text-red-400"
                    disabled={deleteMutation.isPending}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </Card>
  );
}