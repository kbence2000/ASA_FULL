import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { RefreshCw, CheckCircle2, AlertTriangle, Sparkles } from "lucide-react";
import { toast } from "sonner";

export default function TrendingSnippetsRefresh() {
  const [refreshing, setRefreshing] = useState(false);
  const [lastRefresh, setLastRefresh] = useState(null);

  const handleRefresh = async () => {
    setRefreshing(true);
    
    try {
      // Call the harvest function
      const response = await fetch('/api/trending/harvest', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error('Failed to harvest snippets');
      }

      const result = await response.json();
      
      setLastRefresh(new Date().toISOString());
      toast.success(`✨ Harvested ${result.count || 0} trending snippets!`);
      
      // Reload the page to show new snippets
      setTimeout(() => {
        window.location.reload();
      }, 1500);
    } catch (error) {
      console.error('Refresh error:', error);
      toast.error('Failed to harvest trending snippets!');
    } finally {
      setRefreshing(false);
    }
  };

  return (
    <Card 
      className="border p-6"
      style={{
        background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
        borderColor: 'rgba(139, 92, 255, 0.3)'
      }}
    >
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-5 h-5 text-purple-400" />
            <h3 className="font-bold text-white">Trending Snippets</h3>
          </div>
          <p className="text-sm text-gray-400">
            Harvest fresh code snippets from GitHub, Dev.to, Reddit & LinkedIn
          </p>
          {lastRefresh && (
            <p className="text-xs text-gray-500 mt-2">
              Last refreshed: {new Date(lastRefresh).toLocaleTimeString()}
            </p>
          )}
        </div>

        <Button
          onClick={handleRefresh}
          disabled={refreshing}
          className="flex items-center gap-2"
          style={{
            background: refreshing ? '#4a5568' : 'linear-gradient(135deg, #8b5cff, #24e4ff)',
            color: 'white'
          }}
        >
          <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
          {refreshing ? 'Harvesting...' : 'Harvest Now'}
        </Button>
      </div>
    </Card>
  );
}