/**
 * MDC Demigod API Client
 * Type-safe wrapper for all Demigod API endpoints
 */

class DemigodAPIClient {
  constructor(baseURL = '/api/demigods') {
    this.baseURL = baseURL;
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    if (options.body && typeof options.body === 'object') {
      config.body = JSON.stringify(options.body);
    }

    const response = await fetch(url, config);
    
    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: response.statusText }));
      throw new Error(error.error || error.message || 'API request failed');
    }

    return response.json();
  }

  // ============================================
  // PROFILE
  // ============================================

  /**
   * Get demigod profile by ID
   * @param {string} profileId - Profile identifier
   * @returns {Promise<Object>} Profile data
   */
  async getProfile(profileId) {
    return this.request(`/profile/${profileId}`, {
      method: 'GET',
    });
  }

  /**
   * Update demigod profile
   * @param {string} profileId - Profile identifier
   * @param {Object} updates - Profile updates
   * @returns {Promise<Object>} Updated profile
   */
  async updateProfile(profileId, updates) {
    return this.request(`/profile/${profileId}`, {
      method: 'PUT',
      body: updates,
    });
  }

  // ============================================
  // RANK SYSTEM
  // ============================================

  /**
   * Get current rank for a demigod
   * @param {string} userId - User identifier
   * @returns {Promise<Object>} Rank data
   */
  async getRank(userId) {
    return this.request(`/rank?userId=${userId}`, {
      method: 'GET',
    });
  }

  /**
   * Get rank history for a demigod
   * @param {string} userId - User identifier
   * @param {Object} params - Query parameters
   * @returns {Promise<Array>} Rank history
   */
  async getRankHistory(userId, params = {}) {
    const query = new URLSearchParams({ userId, ...params }).toString();
    return this.request(`/rank/history?${query}`, {
      method: 'GET',
    });
  }

  // ============================================
  // MENTORING
  // ============================================

  /**
   * Book a mentoring session
   * @param {Object} params
   * @param {string} params.mentorId - Mentor user ID
   * @param {string} params.datetime - Session datetime
   * @param {string} params.topic - Session topic
   * @returns {Promise<Object>} Booking confirmation
   */
  async bookMentoring(params) {
    return this.request('/mentoring/book', {
      method: 'POST',
      body: params,
    });
  }

  /**
   * Get mentoring session details
   * @param {string} sessionId - Session identifier
   * @returns {Promise<Object>} Session data
   */
  async getMentoringSession(sessionId) {
    return this.request(`/mentoring/session?sessionId=${sessionId}`, {
      method: 'GET',
    });
  }

  /**
   * Update mentoring session
   * @param {string} sessionId - Session identifier
   * @param {Object} updates - Session updates
   * @returns {Promise<Object>} Updated session
   */
  async updateMentoringSession(sessionId, updates) {
    return this.request('/mentoring/session', {
      method: 'PUT',
      body: { sessionId, ...updates },
    });
  }

  // ============================================
  // SPOTLIGHT
  // ============================================

  /**
   * Get spotlight feed
   * @param {Object} params - Query parameters
   * @returns {Promise<Array>} Spotlight items
   */
  async getSpotlight(params = {}) {
    const query = new URLSearchParams(params).toString();
    return this.request(`/spotlight${query ? '?' + query : ''}`, {
      method: 'GET',
    });
  }

  /**
   * Submit content to spotlight
   * @param {Object} content - Content data
   * @returns {Promise<Object>} Submission result
   */
  async submitToSpotlight(content) {
    return this.request('/spotlight', {
      method: 'POST',
      body: content,
    });
  }

  // ============================================
  // ASSETS & SHOWCASE
  // ============================================

  /**
   * Get demigod assets
   * @param {string} userId - User identifier
   * @returns {Promise<Array>} Assets list
   */
  async getAssets(userId) {
    return this.request(`/assets?userId=${userId}`, {
      method: 'GET',
    });
  }

  /**
   * Get demigod showcase
   * @param {string} userId - User identifier
   * @returns {Promise<Object>} Showcase data
   */
  async getShowcase(userId) {
    return this.request(`/showcase?userId=${userId}`, {
      method: 'GET',
    });
  }

  /**
   * Update showcase
   * @param {string} userId - User identifier
   * @param {Object} showcase - Showcase data
   * @returns {Promise<Object>} Updated showcase
   */
  async updateShowcase(userId, showcase) {
    return this.request('/showcase', {
      method: 'PUT',
      body: { userId, ...showcase },
    });
  }

  // ============================================
  // PVP BATTLES
  // ============================================

  /**
   * Get PvP battle details
   * @param {string} battleId - Battle identifier
   * @returns {Promise<Object>} Battle data
   */
  async getBattle(battleId) {
    return this.request(`/pvp/battle?battleId=${battleId}`, {
      method: 'GET',
    });
  }

  /**
   * Create new PvP battle
   * @param {Object} params
   * @param {string} params.type - Battle type (coding/innovation)
   * @param {string} params.challengerId - Challenger user ID
   * @param {string} params.opponentId - Opponent user ID (optional)
   * @returns {Promise<Object>} Battle created
   */
  async createBattle(params) {
    return this.request('/pvp/battle', {
      method: 'POST',
      body: params,
    });
  }

  /**
   * Submit PvP solution
   * @param {Object} params
   * @param {string} params.battleId - Battle identifier
   * @param {string} params.userId - User identifier
   * @param {string} params.solution - Solution code/content
   * @returns {Promise<Object>} Submission result
   */
  async submitPvPSolution(params) {
    return this.request('/pvp/submit', {
      method: 'POST',
      body: params,
    });
  }

  // ============================================
  // INSIGHTS
  // ============================================

  /**
   * Get demigod insights
   * @param {string} userId - User identifier
   * @param {Object} params - Query parameters
   * @returns {Promise<Object>} Insights data
   */
  async getInsights(userId, params = {}) {
    const query = new URLSearchParams({ userId, ...params }).toString();
    return this.request(`/insights?${query}`, {
      method: 'GET',
    });
  }
}

// Export singleton instance
export const demigodAPI = new DemigodAPIClient();

// Also export class for custom instances
export default DemigodAPIClient;