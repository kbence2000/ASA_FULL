import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Building, Briefcase, CheckCircle2, Clock, Loader2, Sparkles } from "lucide-react";
import { companyAPI } from "./CompanyAPIClient";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function CompanyDashboardView({ companyId }) {
  const [dashboard, setDashboard] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (companyId) {
      fetchDashboard();
    }
  }, [companyId]);

  const fetchDashboard = async () => {
    try {
      const data = await companyAPI.getCompanyDashboard(companyId);
      setDashboard(data);
    } catch (error) {
      console.error("Failed to fetch dashboard:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card className="border p-12 text-center" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <Loader2 className="w-8 h-8 animate-spin mx-auto mb-3 text-purple-400" />
        <p className="text-gray-400">Loading dashboard...</p>
      </Card>
    );
  }

  const stats = dashboard?.stats || {};
  const company = dashboard?.company || {};
  const latestMissions = dashboard?.latestMissions || [];

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border p-4" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(34, 197, 94, 0.5)'
        }}>
          <div className="flex items-center gap-3">
            <Briefcase className="w-8 h-8 text-green-400" />
            <div>
              <div className="text-2xl font-bold text-white">{stats.open || 0}</div>
              <div className="text-xs text-gray-400">Open</div>
            </div>
          </div>
        </Card>

        <Card className="border p-4" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(59, 130, 246, 0.5)'
        }}>
          <div className="flex items-center gap-3">
            <Clock className="w-8 h-8 text-blue-400" />
            <div>
              <div className="text-2xl font-bold text-white">{stats.running || 0}</div>
              <div className="text-xs text-gray-400">Running</div>
            </div>
          </div>
        </Card>

        <Card className="border p-4" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(168, 85, 247, 0.5)'
        }}>
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-8 h-8 text-purple-400" />
            <div>
              <div className="text-2xl font-bold text-white">{stats.completed || 0}</div>
              <div className="text-xs text-gray-400">Completed</div>
            </div>
          </div>
        </Card>

        <Card className="border p-4" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.5)'
        }}>
          <div className="flex items-center gap-3">
            <Building className="w-8 h-8 text-gray-400" />
            <div>
              <div className="text-2xl font-bold text-white">{stats.total || 0}</div>
              <div className="text-xs text-gray-400">Total</div>
            </div>
          </div>
        </Card>
      </div>

      {/* AI Insight */}
      {dashboard?.aiNote && (
        <Card className="border p-6" style={{
          background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
          borderColor: 'rgba(139, 92, 255, 0.3)'
        }}>
          <div className="flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-purple-400 mt-0.5" />
            <div>
              <h4 className="font-semibold text-white mb-2">AI Quick Insight</h4>
              <p className="text-gray-300 leading-relaxed">{dashboard.aiNote}</p>
            </div>
          </div>
        </Card>
      )}

      {/* Latest Missions */}
      {latestMissions.length > 0 && (
        <Card className="border p-6" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <h3 className="text-lg font-bold text-white mb-4">Recent Missions</h3>
          
          <div className="space-y-3">
            {latestMissions.map((mission) => (
              <div
                key={mission.id}
                className="p-4 rounded-lg border hover:shadow-lg transition-all"
                style={{
                  background: 'rgba(5, 8, 22, 0.5)',
                  borderColor: 'rgba(148, 163, 184, 0.2)'
                }}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="font-bold text-white mb-1">{mission.title}</h4>
                    <div className="flex items-center gap-2">
                      <Badge className={
                        mission.status === "open" ? "bg-green-600/20 text-green-300 border-green-600/30" :
                        mission.status === "running" ? "bg-blue-600/20 text-blue-300 border-blue-600/30" :
                        mission.status === "completed" ? "bg-purple-600/20 text-purple-300 border-purple-600/30" :
                        "bg-gray-600/20 text-gray-300 border-gray-600/30"
                      }>
                        {mission.status}
                      </Badge>
                      <Badge className="bg-yellow-600/20 text-yellow-300 border-yellow-600/30">
                        {mission.complexity}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-bold text-cyan-400">€{mission.bounty}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}