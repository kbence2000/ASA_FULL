import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Code2, 
  TrendingUp, 
  Zap, 
  Tag, 
  Copy, 
  Check,
  ChevronDown,
  ChevronUp,
  Search,
  Filter
} from "lucide-react";
import { toast } from "sonner";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export default function APCPatternList() {
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("usage");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [expandedPatterns, setExpandedPatterns] = useState({});
  const [copiedPatterns, setCopiedPatterns] = useState({});

  const { data: patterns, isLoading } = useQuery({
    queryKey: ['apcPatterns'],
    queryFn: () => base44.entities.APCPattern.list('-created_date', 200),
    initialData: [],
  });

  const toggleExpanded = (patternId) => {
    setExpandedPatterns(prev => ({
      ...prev,
      [patternId]: !prev[patternId]
    }));
  };

  const handleCopyCode = (pattern) => {
    if (pattern.exampleCode) {
      navigator.clipboard.writeText(pattern.exampleCode);
      setCopiedPatterns(prev => ({ ...prev, [pattern.id]: true }));
      toast.success("Code copied to clipboard!");
      setTimeout(() => {
        setCopiedPatterns(prev => ({ ...prev, [pattern.id]: false }));
      }, 2000);
    }
  };

  // Get unique categories
  const categories = Array.from(
    new Set(patterns.map(p => p.category).filter(Boolean))
  ).sort();

  // Filter and sort
  const filteredPatterns = patterns
    .filter(pattern => {
      const matchesSearch = !searchQuery || 
        pattern.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        pattern.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        pattern.tags?.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchesCategory = categoryFilter === "all" || 
        pattern.category === categoryFilter;
      
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      if (sortBy === "usage") {
        return (b.usageScore || 0) - (a.usageScore || 0);
      }
      if (sortBy === "innovation") {
        return (b.innovationScore || 0) - (a.innovationScore || 0);
      }
      if (sortBy === "recent") {
        return new Date(b.lastSeen || 0) - new Date(a.lastSeen || 0);
      }
      if (sortBy === "seen") {
        return (b.seenCount || 0) - (a.seenCount || 0);
      }
      return 0;
    });

  const getScoreColor = (score) => {
    if (score >= 70) return 'text-green-400';
    if (score >= 40) return 'text-yellow-400';
    return 'text-orange-400';
  };

  return (
    <div className="space-y-6">
      {/* Search & Filters */}
      <Card className="border p-4" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Search patterns, tags, languages..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-[#141923] border-[#1a1f2e] text-white"
            />
          </div>

          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-48 bg-[#141923] border-[#1a1f2e] text-white">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map(cat => (
                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-48 bg-[#141923] border-[#1a1f2e] text-white">
              <TrendingUp className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="usage">Most Used</SelectItem>
              <SelectItem value="innovation">Most Innovative</SelectItem>
              <SelectItem value="recent">Recently Seen</SelectItem>
              <SelectItem value="seen">Most Seen</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Patterns List */}
      {isLoading ? (
        <Card className="border p-12 text-center" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <p className="text-gray-400">Loading patterns...</p>
        </Card>
      ) : filteredPatterns.length === 0 ? (
        <Card className="border p-12 text-center" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <Sparkles className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-white mb-2">No Patterns Found</h3>
          <p className="text-gray-400">
            {searchQuery || categoryFilter !== "all" 
              ? "Try adjusting your filters"
              : "Click 'Ingest Patterns' to extract patterns from trending code"}
          </p>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {filteredPatterns.map(pattern => (
            <Card key={pattern.id} className="border p-5 hover:shadow-lg transition-all group" style={{
              background: 'rgba(15, 23, 42, 0.95)',
              borderColor: 'rgba(148, 163, 184, 0.35)'
            }}>
              {/* Header */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h3 className="font-bold text-white text-lg mb-1">
                    {pattern.name}
                  </h3>
                  <div className="flex items-center gap-2 flex-wrap">
                    {pattern.language && (
                      <Badge className="bg-blue-600/20 text-blue-300 border-blue-600/30 text-xs">
                        {pattern.language}
                      </Badge>
                    )}
                    {pattern.category && (
                      <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30 text-xs">
                        {pattern.category}
                      </Badge>
                    )}
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={() => handleCopyCode(pattern)}
                    variant="ghost"
                    size="sm"
                    className="text-xs text-gray-400 hover:text-white"
                  >
                    {copiedPatterns[pattern.id] ? (
                      <>
                        <Check className="w-3 h-3 mr-1" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3 mr-1" />
                        Copy
                      </>
                    )}
                  </Button>
                </div>
              </div>

              {/* Description */}
              <p className="text-sm text-gray-300 mb-4 leading-relaxed">
                {pattern.description}
              </p>

              {/* Scores */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                <div className="p-2 rounded-lg border text-center" style={{
                  background: 'rgba(5, 8, 22, 0.9)',
                  borderColor: 'rgba(148, 163, 184, 0.2)'
                }}>
                  <div className={`text-sm font-bold ${getScoreColor(pattern.usageScore || 0)}`}>
                    {pattern.usageScore || 0}
                  </div>
                  <div className="text-xs text-gray-500">Usage</div>
                </div>

                <div className="p-2 rounded-lg border text-center" style={{
                  background: 'rgba(5, 8, 22, 0.9)',
                  borderColor: 'rgba(148, 163, 184, 0.2)'
                }}>
                  <div className={`text-sm font-bold ${getScoreColor(pattern.innovationScore || 0)}`}>
                    {pattern.innovationScore || 0}
                  </div>
                  <div className="text-xs text-gray-500">Innovation</div>
                </div>

                <div className="p-2 rounded-lg border text-center" style={{
                  background: 'rgba(5, 8, 22, 0.9)',
                  borderColor: 'rgba(148, 163, 184, 0.2)'
                }}>
                  <div className="text-sm font-bold text-cyan-400">
                    {pattern.seenCount || 1}
                  </div>
                  <div className="text-xs text-gray-500">Seen</div>
                </div>
              </div>

              {/* Tags */}
              {pattern.tags && pattern.tags.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mb-3">
                  {pattern.tags.map((tag, idx) => (
                    <Badge key={idx} className="text-xs bg-cyan-600/20 text-cyan-300 border-cyan-600/30">
                      <Tag className="w-3 h-3 mr-1" />
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}

              {/* Code Preview (Expandable) */}
              {pattern.exampleCode && (
                <div className="mt-3 pt-3 border-t" style={{ borderColor: 'rgba(148, 163, 184, 0.2)' }}>
                  <button
                    onClick={() => toggleExpanded(pattern.id)}
                    className="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors w-full"
                  >
                    <Code2 className="w-4 h-4" />
                    <span>Example Code</span>
                    {expandedPatterns[pattern.id] ? (
                      <ChevronUp className="w-4 h-4 ml-auto" />
                    ) : (
                      <ChevronDown className="w-4 h-4 ml-auto" />
                    )}
                  </button>
                  
                  {expandedPatterns[pattern.id] && (
                    <pre className="mt-2 p-3 rounded border text-xs overflow-x-auto font-mono" style={{
                      background: 'rgba(5, 8, 22, 0.9)',
                      borderColor: 'rgba(148, 163, 184, 0.2)',
                      maxHeight: '300px',
                      overflowY: 'auto'
                    }}>
                      <code className="text-gray-300">{pattern.exampleCode}</code>
                    </pre>
                  )}
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}