import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Play, CheckCircle2, XCircle, Clock, 
  Terminal, Code2, Zap, AlertCircle, Award 
} from "lucide-react";
import { toast } from "sonner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const BACKEND_URL = import.meta.env.VITE_MDC_BACKEND_URL || "http://localhost:3000";

const CODE_TEMPLATES = {
  hello: `function main() {
  console.log("Hello from MDC Cloud Runtime!");
  return "Hello, Code Demigod! 🔥";
}`,
  
  fibonacci: `function main() {
  function fibonacci(n) {
    if (n <= 1) return n;
    return fibonacci(n - 1) + fibonacci(n - 2);
  }
  
  const n = 10;
  console.log(\`Calculating fibonacci(\${n})...\`);
  const result = fibonacci(n);
  console.log(\`Result: \${result}\`);
  return result;
}`,

  async: `async function main() {
  console.log("Starting async task...");
  
  let counter = 0;
  for (let i = 0; i < 5; i++) {
    counter += i;
    console.log(\`Step \${i}: counter = \${counter}\`);
  }
  
  return { 
    counter, 
    message: "Async complete!",
    timestamp: Date.now()
  };
}`,

  dataProcessing: `function main() {
  const data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  console.log("Input data:", JSON.stringify(data));
  
  const processed = data
    .filter(x => x > 5)
    .map(x => x * 2)
    .reduce((sum, x) => sum + x, 0);
  
  console.log("Filtered > 5, doubled, summed");
  return processed;
}`,

  advanced: `async function main() {
  // Advanced algorithm demo
  console.log("Running advanced computation...");
  
  function isPrime(n) {
    if (n <= 1) return false;
    if (n <= 3) return true;
    if (n % 2 === 0 || n % 3 === 0) return false;
    
    for (let i = 5; i * i <= n; i += 6) {
      if (n % i === 0 || n % (i + 2) === 0) return false;
    }
    return true;
  }
  
  const primes = [];
  for (let i = 2; i <= 100; i++) {
    if (isPrime(i)) primes.push(i);
  }
  
  console.log(\`Found \${primes.length} primes under 100\`);
  return { count: primes.length, primes };
}`,
};

export default function CloudRuntimePanel({ 
  userId,
  onExecutionComplete 
}) {
  const [code, setCode] = useState(CODE_TEMPLATES.hello);
  const [language, setLanguage] = useState("javascript");
  const [entryPoint, setEntryPoint] = useState("main");
  const [timeoutMs, setTimeoutMs] = useState(5000);
  const [isRunning, setIsRunning] = useState(false);
  const [result, setResult] = useState(null);
  const [runtimeScore, setRuntimeScore] = useState(null);

  const handleExecute = async () => {
    if (!code.trim()) {
      toast.error("Please enter some code to execute");
      return;
    }

    setIsRunning(true);
    setResult(null);
    setRuntimeScore(null);

    try {
      const response = await fetch(`${BACKEND_URL}/api/runtime/run-snippet`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: userId || 'anonymous',
          language: language.toLowerCase(),
          code: code.trim(),
          entryPoint: entryPoint.trim() || "main",
          timeoutMs: parseInt(timeoutMs) || 5000,
        }),
      });

      if (!response.ok) {
        throw new Error("Runtime execution failed");
      }

      const data = await response.json();
      setResult(data.runtimeResult);
      setRuntimeScore(data.user?.runtime?.runtimeScore || null);

      if (data.runtimeResult.status === "ok") {
        toast.success(`✅ Executed in ${data.runtimeResult.durationMs}ms • Score: ${data.user?.runtime?.runtimeScore || 0}`);
        if (onExecutionComplete) {
          onExecutionComplete(data);
        }
      } else if (data.runtimeResult.status === "timeout") {
        toast.warning("⏱️ Execution timed out");
      } else {
        toast.error("❌ Execution failed");
      }
    } catch (error) {
      console.error("Execution error:", error);
      toast.error("Failed to execute: " + error.message);
      setResult({ 
        status: "invoke_error", 
        error: error.message, 
        stdout: "",
        stderr: "",
        durationMs: 0 
      });
    } finally {
      setIsRunning(false);
    }
  };

  const loadTemplate = (template) => {
    setCode(CODE_TEMPLATES[template]);
    setResult(null);
    setRuntimeScore(null);
  };

  const getStatusIcon = () => {
    if (!result) return null;
    if (result.status === "ok") return <CheckCircle2 className="w-5 h-5 text-green-400" />;
    if (result.status === "timeout") return <Clock className="w-5 h-5 text-yellow-400" />;
    return <XCircle className="w-5 h-5 text-red-400" />;
  };

  const getStatusBadge = () => {
    if (!result) return null;
    
    const configs = {
      ok: { label: "Success", className: "bg-green-600/20 text-green-400 border-green-600/30" },
      timeout: { label: "Timeout", className: "bg-yellow-600/20 text-yellow-400 border-yellow-600/30" },
      error: { label: "Error", className: "bg-red-600/20 text-red-400 border-red-600/30" },
      invoke_error: { label: "Invoke Error", className: "bg-red-600/20 text-red-400 border-red-600/30" },
    };

    const config = configs[result.status] || { label: result.status, className: "bg-gray-600/20 text-gray-400 border-gray-600/30" };

    return (
      <Badge className={`border ${config.className}`}>
        {config.label} • {result.durationMs || 0}ms
      </Badge>
    );
  };

  return (
    <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 rounded-lg bg-gradient-to-br from-cyan-500/20 to-blue-500/20">
          <Zap className="w-6 h-6 text-cyan-400" />
        </div>
        <div className="flex-1">
          <h3 className="text-xl font-black text-white">AWS Lambda Runtime</h3>
          <p className="text-sm text-gray-400">Serverless code execution • Instant scoring</p>
        </div>
        {runtimeScore !== null && (
          <Badge className="bg-purple-600/20 text-purple-300 border border-purple-600/30 flex items-center gap-1">
            <Award className="w-3 h-3" />
            Score: {runtimeScore}
          </Badge>
        )}
      </div>

      <div className="space-y-4">
        {/* Language & Templates */}
        <div className="flex gap-3">
          <Select value={language} onValueChange={setLanguage}>
            <SelectTrigger className="w-40 bg-[#141923] border-[#1a1f2e] text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="javascript">JavaScript</SelectItem>
              <SelectItem value="typescript">TypeScript</SelectItem>
            </SelectContent>
          </Select>

          <Select onValueChange={loadTemplate}>
            <SelectTrigger className="flex-1 bg-[#141923] border-[#1a1f2e] text-white">
              <SelectValue placeholder="Load template..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="hello">Hello World</SelectItem>
              <SelectItem value="fibonacci">Fibonacci</SelectItem>
              <SelectItem value="async">Async Example</SelectItem>
              <SelectItem value="dataProcessing">Data Processing</SelectItem>
              <SelectItem value="advanced">Prime Numbers</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Entry Point & Timeout */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs text-gray-400 block mb-1">
              Entry Point Function
            </label>
            <Input
              type="text"
              placeholder="main"
              value={entryPoint}
              onChange={(e) => setEntryPoint(e.target.value)}
              className="bg-[#141923] border-[#1a1f2e] text-white font-mono text-sm"
              disabled={isRunning}
            />
          </div>
          
          <div>
            <label className="text-xs text-gray-400 block mb-1">
              Timeout (ms)
            </label>
            <Input
              type="number"
              placeholder="5000"
              value={timeoutMs}
              onChange={(e) => setTimeoutMs(e.target.value)}
              className="bg-[#141923] border-[#1a1f2e] text-white"
              disabled={isRunning}
            />
          </div>
        </div>

        {/* Code Editor */}
        <div>
          <label className="text-xs text-gray-400 block mb-1">
            Code Editor
          </label>
          <Textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="bg-[#0a0a0f] border-[#1a1f2e] text-white font-mono text-sm h-72 resize-none"
            placeholder="function main() {\n  // Your code here\n  return 'Hello World';\n}"
            disabled={isRunning}
          />
        </div>

        {/* Info */}
        <div className="p-3 rounded-lg bg-blue-600/10 border border-blue-600/30">
          <p className="text-xs text-blue-300 leading-relaxed">
            <strong>AWS Lambda Sandbox:</strong> Code runs serverless with timeout protection. 
            Define an entry point function (default: <code className="bg-blue-900/30 px-1 rounded">main</code>). 
            Use <code className="bg-blue-900/30 px-1 rounded">console.log()</code> for output. 
            Return value captured automatically.
          </p>
        </div>

        {/* Run Button */}
        <Button
          onClick={handleExecute}
          disabled={isRunning || !code.trim()}
          className="w-full bg-gradient-to-r from-cyan-600 to-blue-700 hover:from-cyan-700 hover:to-blue-800 text-white font-bold text-lg py-6"
        >
          {isRunning ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
              Executing on Lambda...
            </>
          ) : (
            <>
              <Play className="w-5 h-5 mr-2" />
              Execute Code
            </>
          )}
        </Button>

        {/* Results */}
        {result && (
          <div className="space-y-3 pt-4 border-t border-[#1a1f2e]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {getStatusIcon()}
                <span className="text-sm font-semibold text-white">Execution Result</span>
              </div>
              {getStatusBadge()}
            </div>

            {/* Runtime Score Earned */}
            {runtimeScore !== null && result.status === "ok" && (
              <div className="p-4 rounded-lg bg-gradient-to-r from-purple-600/20 to-indigo-600/20 border border-purple-600/30">
                <div className="flex items-center gap-3">
                  <Award className="w-6 h-6 text-purple-400" />
                  <div>
                    <div className="text-sm font-bold text-white">Runtime Score Updated</div>
                    <div className="text-xs text-gray-400">
                      New runtime score: <span className="text-purple-400 font-bold">{runtimeScore}/100</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Error */}
            {(result.error || result.stderr) && (
              <div className="p-3 rounded-lg bg-red-600/10 border border-red-600/30">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <div className="text-xs font-semibold text-red-400 mb-1">
                      {result.status === "timeout" ? "Execution Timeout" : "Runtime Error"}
                    </div>
                    <pre className="text-xs text-red-300 font-mono overflow-x-auto whitespace-pre-wrap">
                      {result.error || result.stderr}
                    </pre>
                  </div>
                </div>
              </div>
            )}

            {/* Return Value */}
            {result.result !== null && result.result !== undefined && (
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Code2 className="w-4 h-4 text-gray-400" />
                  <span className="text-xs text-gray-400">Return Value</span>
                </div>
                <pre className="bg-[#0a0a0f] border border-[#1a1f2e] rounded-lg p-3 text-sm text-green-400 font-mono overflow-x-auto">
                  {typeof result.result === 'object' 
                    ? JSON.stringify(result.result, null, 2) 
                    : String(result.result)}
                </pre>
              </div>
            )}

            {/* Stdout Logs */}
            {result.stdout && result.stdout.trim() && (
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Terminal className="w-4 h-4 text-gray-400" />
                  <span className="text-xs text-gray-400">Console Output</span>
                </div>
                <div className="bg-[#0a0a0f] border border-[#1a1f2e] rounded-lg p-3 font-mono text-xs space-y-1 max-h-48 overflow-y-auto">
                  {result.stdout.split('\n').map((log, idx) => (
                    <div key={idx} className="text-gray-300">
                      {log}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Duration */}
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-gray-500">
                <Clock className="w-3 h-3" />
                Execution time: {result.durationMs || 0}ms
              </div>
              {result.status === "ok" && result.durationMs < 100 && (
                <Badge className="bg-green-600/20 text-green-400 border-green-600/30">
                  ⚡ Lightning Fast
                </Badge>
              )}
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}