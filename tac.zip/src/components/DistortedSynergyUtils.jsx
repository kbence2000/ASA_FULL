// DistortedSynergyUtils.jsx
// Frontend-only utilities for Dual Loop system

// Nine Minds Metadata
export const NineMindsMetadata = [
  { id: 1, name: "Architect", role: "Structure", color: "#00ff8a" },
  { id: 2, name: "Analyst", role: "Logic", color: "#4f7cff" },
  { id: 3, name: "Creator", role: "Innovation", color: "#ff6ec7" },
  { id: 4, name: "Guardian", role: "Safety", color: "#ffdb7c" },
  { id: 5, name: "Explorer", role: "Discovery", color: "#a84cff" },
  { id: 6, name: "Mediator", role: "Balance", color: "#4cffa8" },
  { id: 7, name: "Visionary", role: "Future", color: "#24e4ff" },
  { id: 8, name: "Optimizer", role: "Efficiency", color: "#ff9966" },
  { id: 9, name: "Synthesizer", role: "Unity", color: "#b788ff" }
];

// Distorted Synergy Metadata (corrupted versions)
export const DistortedSynergyMetadata = [
  { id: 1, name: "Destroyer", role: "Chaos", color: "#ff4b81" },
  { id: 2, name: "Glitch", role: "Error", color: "#8c4fff" },
  { id: 3, name: "Mutator", role: "Corruption", color: "#ff0066" },
  { id: 4, name: "Void", role: "Erasure", color: "#666699" },
  { id: 5, name: "Anomaly", role: "Unknown", color: "#ff66cc" },
  { id: 6, name: "Distorter", role: "Warp", color: "#cc0099" },
  { id: 7, name: "Inverter", role: "Reverse", color: "#ff3366" },
  { id: 8, name: "Fragmenter", role: "Break", color: "#990066" },
  { id: 9, name: "Absorber", role: "Consume", color: "#ff0099" }
];

// Distorted Synergy Bridge
export function distortedSynergyBridge(input) {
  const original = input || "";
  const chars = original.split('');
  
  // Apply distortion: reverse, shuffle, inject noise
  const reversed = chars.reverse().join('');
  const noisy = reversed.split('').map((c, i) => {
    if (i % 3 === 0) return c.toUpperCase();
    if (i % 5 === 0) return '▓';
    return c;
  }).join('');
  
  const distorted = noisy + " [CORRUPTED]";
  
  return {
    original,
    distorted,
    bridge: `BRIDGE_${Date.now()}`,
    timestamp: new Date().toISOString()
  };
}

// Simulate brain processing (frontend only)
export async function simulateBrainProcessing(brainName, input, delayMs = 200) {
  await new Promise(resolve => setTimeout(resolve, delayMs));
  
  const transformations = {
    "Architect": (str) => `[STRUCT:${str.length}] ${str.substring(0, 50)}...`,
    "Analyst": (str) => `ANALYZED: ${str.split(' ').length} tokens`,
    "Creator": (str) => `💡 ${str.split('').reverse().join('')}`,
    "Guardian": (str) => `✓ SAFE: ${str}`,
    "Explorer": (str) => `🔍 ${str.toUpperCase()}`,
    "Mediator": (str) => `⚖️ ${str.toLowerCase()}`,
    "Visionary": (str) => `🔮 FUTURE(${str})`,
    "Optimizer": (str) => `⚡ ${str.replace(/\s+/g, '_')}`,
    "Synthesizer": (str) => `🔗 UNIFIED(${str.substring(0, 30)}...)`,
    
    "Destroyer": (str) => `💥 ${str.split('').filter((_, i) => i % 2 === 0).join('')}`,
    "Glitch": (str) => `⚠️ ${str.replace(/[aeiou]/gi, '█')}`,
    "Mutator": (str) => `🧬 ${str.split('').map(c => Math.random() > 0.5 ? c : '?').join('')}`,
    "Void": (str) => `◼️ ${str.substring(0, 10)}...`,
    "Anomaly": (str) => `❓ ${str.split('').sort().join('')}`,
    "Distorter": (str) => `〰️ ${str.split('').map((c, i) => i % 2 ? c.toUpperCase() : c.toLowerCase()).join('')}`,
    "Inverter": (str) => `🔄 ${str.split('').reverse().join('')}`,
    "Fragmenter": (str) => `💔 ${str.split(' ').join('...')}`,
    "Absorber": (str) => `🕳️ ${str.substring(0, 5)}[ABSORBED]`
  };
  
  const transform = transformations[brainName] || ((s) => s);
  return transform(input);
}

// Dual Loop analysis
export function dualLoop(input) {
  const original = input || "";
  const bridge = distortedSynergyBridge(original);
  const distorted = bridge.distorted;
  
  const lengthDiff = Math.abs(original.length - distorted.length);
  const distortionLevel = Math.min(lengthDiff / Math.max(original.length, 1), 1);
  
  // Calculate coherence (how similar they are)
  let matches = 0;
  const minLen = Math.min(original.length, distorted.length);
  for (let i = 0; i < minLen; i++) {
    if (original[i]?.toLowerCase() === distorted[i]?.toLowerCase()) {
      matches++;
    }
  }
  const coherence = minLen > 0 ? matches / minLen : 0;
  
  // Calculate entropy (randomness)
  const entropy = distortionLevel * (1 - coherence);
  
  // Determine relation
  let relation = "divergent";
  if (coherence > 0.7) relation = "convergent";
  else if (coherence > 0.4) relation = "parallel";
  
  return {
    original,
    distorted,
    delta: {
      lengthDifference: lengthDiff,
      distortionLevel,
      coherence,
      entropy,
      relation
    }
  };
}