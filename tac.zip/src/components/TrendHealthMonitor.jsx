import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  HeartPulse, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle,
  TrendingUp,
  Globe,
  Brain
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export default function TrendHealthMonitor() {
  const { data: sources, isLoading } = useQuery({
    queryKey: ['trendSources'],
    queryFn: () => base44.entities.TrendSource.list('-created_date'),
    initialData: [],
    refetchInterval: 30000 // Auto-refresh every 30s
  });

  const { data: snippets } = useQuery({
    queryKey: ['trendingSnippets'],
    queryFn: () => base44.entities.TrendingSnippet.list('-created_date', 100),
    initialData: [],
  });

  // Calculate health metrics for each source
  const sourceHealth = sources.map(source => {
    const sourceSnippets = snippets.filter(s => s.originId === source.sourceId);
    const recentSnippets = sourceSnippets.filter(s => {
      const age = Date.now() - new Date(s.created_date).getTime();
      return age < 24 * 60 * 60 * 1000; // Last 24 hours
    });

    let status = 'unknown';
    let message = 'No data';

    if (!source.enabled) {
      status = 'disabled';
      message = 'Source disabled';
    } else if (recentSnippets.length === 0 && sourceSnippets.length === 0) {
      status = 'warning';
      message = 'No snippets harvested';
    } else if (recentSnippets.length === 0) {
      status = 'warning';
      message = 'No recent activity (24h)';
    } else if (recentSnippets.length < (source.maxSnippets || 3)) {
      status = 'ok';
      message = `${recentSnippets.length}/${source.maxSnippets || 3} snippets`;
    } else {
      status = 'healthy';
      message = `${recentSnippets.length} snippets in 24h`;
    }

    return {
      ...source,
      snippetCount: sourceSnippets.length,
      recentCount: recentSnippets.length,
      status,
      message
    };
  });

  const getStatusConfig = (status) => {
    switch (status) {
      case 'healthy':
        return {
          icon: <CheckCircle2 className="w-5 h-5 text-green-400" />,
          badge: 'bg-green-600/20 text-green-300 border-green-600/30',
          text: 'Healthy'
        };
      case 'ok':
        return {
          icon: <TrendingUp className="w-5 h-5 text-blue-400" />,
          badge: 'bg-blue-600/20 text-blue-300 border-blue-600/30',
          text: 'OK'
        };
      case 'warning':
        return {
          icon: <AlertTriangle className="w-5 h-5 text-yellow-400" />,
          badge: 'bg-yellow-600/20 text-yellow-300 border-yellow-600/30',
          text: 'Warning'
        };
      case 'disabled':
        return {
          icon: <XCircle className="w-5 h-5 text-gray-500" />,
          badge: 'bg-gray-600/20 text-gray-400 border-gray-600/30',
          text: 'Disabled'
        };
      default:
        return {
          icon: <AlertTriangle className="w-5 h-5 text-gray-400" />,
          badge: 'bg-gray-600/20 text-gray-400 border-gray-600/30',
          text: 'Unknown'
        };
    }
  };

  const healthyCounts = {
    healthy: sourceHealth.filter(s => s.status === 'healthy').length,
    ok: sourceHealth.filter(s => s.status === 'ok').length,
    warning: sourceHealth.filter(s => s.status === 'warning').length,
    disabled: sourceHealth.filter(s => s.status === 'disabled').length
  };

  const overallHealth = 
    healthyCounts.healthy === sources.length ? 'excellent' :
    healthyCounts.warning === 0 && healthyCounts.disabled === 0 ? 'good' :
    healthyCounts.warning > healthyCounts.healthy ? 'degraded' :
    'fair';

  return (
    <Card className="border p-6" style={{
      background: 'rgba(15, 23, 42, 0.95)',
      borderColor: 'rgba(148, 163, 184, 0.35)'
    }}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <HeartPulse className="w-8 h-8 text-pink-400" />
          <div>
            <h3 className="font-bold text-white text-lg">Source Health Monitor</h3>
            <p className="text-xs text-gray-400">Real-time source performance tracking</p>
          </div>
        </div>

        <Badge className={
          overallHealth === 'excellent' ? 'bg-green-600/20 text-green-300 border-green-600/30' :
          overallHealth === 'good' ? 'bg-blue-600/20 text-blue-300 border-blue-600/30' :
          overallHealth === 'fair' ? 'bg-yellow-600/20 text-yellow-300 border-yellow-600/30' :
          'bg-orange-600/20 text-orange-300 border-orange-600/30'
        }>
          {overallHealth.toUpperCase()}
        </Badge>
      </div>

      {/* Health Summary */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        <div className="p-3 rounded-lg border text-center" style={{
          background: 'rgba(5, 8, 22, 0.9)',
          borderColor: 'rgba(34, 197, 94, 0.3)'
        }}>
          <div className="text-2xl font-bold text-green-400">{healthyCounts.healthy}</div>
          <div className="text-xs text-gray-400">Healthy</div>
        </div>

        <div className="p-3 rounded-lg border text-center" style={{
          background: 'rgba(5, 8, 22, 0.9)',
          borderColor: 'rgba(59, 130, 246, 0.3)'
        }}>
          <div className="text-2xl font-bold text-blue-400">{healthyCounts.ok}</div>
          <div className="text-xs text-gray-400">OK</div>
        </div>

        <div className="p-3 rounded-lg border text-center" style={{
          background: 'rgba(5, 8, 22, 0.9)',
          borderColor: 'rgba(245, 158, 11, 0.3)'
        }}>
          <div className="text-2xl font-bold text-yellow-400">{healthyCounts.warning}</div>
          <div className="text-xs text-gray-400">Warning</div>
        </div>

        <div className="p-3 rounded-lg border text-center" style={{
          background: 'rgba(5, 8, 22, 0.9)',
          borderColor: 'rgba(107, 114, 128, 0.3)'
        }}>
          <div className="text-2xl font-bold text-gray-400">{healthyCounts.disabled}</div>
          <div className="text-xs text-gray-400">Disabled</div>
        </div>
      </div>

      {/* Source Health List */}
      {isLoading ? (
        <div className="text-center py-8 text-gray-400">Loading health data...</div>
      ) : sources.length === 0 ? (
        <div className="text-center py-8 text-gray-400">No sources to monitor</div>
      ) : (
        <div className="space-y-3">
          {sourceHealth.map(source => {
            const config = getStatusConfig(source.status);
            
            return (
              <div 
                key={source.id} 
                className="flex items-center gap-3 p-4 rounded-lg border hover:bg-[#0a0514] transition-colors"
                style={{
                  background: 'rgba(5, 8, 22, 0.6)',
                  borderColor: 'rgba(148, 163, 184, 0.2)'
                }}
              >
                <div className="flex-shrink-0">
                  {config.icon}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-bold text-white text-sm truncate">
                      {source.label}
                    </span>
                    <Badge className="text-xs bg-purple-600/20 text-purple-300 border-purple-600/30">
                      {source.mode === 'html' ? (
                        <><Globe className="w-3 h-3 mr-1" /> HTML</>
                      ) : (
                        <><Brain className="w-3 h-3 mr-1" /> AI</>
                      )}
                    </Badge>
                  </div>
                  <div className="text-xs text-gray-400">
                    {source.message}
                  </div>
                </div>

                <div className="flex-shrink-0">
                  <Badge className={config.badge}>
                    {config.text}
                  </Badge>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </Card>
  );
}