import React, { useState, useEffect } from 'react';
import { X, TrendingUp, Target, Zap, Activity } from 'lucide-react';
import { useTriMind } from './TriMindContext';

export default function NeuroEvolutionPanel({ isOpen, onClose }) {
  const triMind = useTriMind();
  const [metrics, setMetrics] = useState(null);
  const [recommendations, setRecommendations] = useState([]);
  const [forecast, setForecast] = useState({ percentage: 0, text: '' });

  const generateNeuroState = () => {
    const opens = 800 + Math.floor(Math.random() * 600);
    const depth = (3 + Math.random() * 3).toFixed(1);
    const efficiency = (75 + Math.random() * 20).toFixed(0);
    const forecastValue = (10 + Math.random() * 15).toFixed(1);

    const newMetrics = { opens, depth, efficiency };
    const newForecast = {
      percentage: 50 + parseFloat(forecastValue),
      text: `+${forecastValue}% projected system efficiency if changes applied.`
    };

    setMetrics(newMetrics);
    setForecast(newForecast);

    const recs = [
      "Reduce clicks to reach Mission Orchestrator from 3 to 2.",
      "Move Swarm Engine slightly closer to the Neural Core in radial layout.",
      "Pre-cache FutureMind responses for repeated queries.",
      "Highlight Tri-Mind Dashboard after intense agent activity."
    ];
    setRecommendations(recs);

    // Update Tri-Mind state
    if (triMind) {
      triMind.setNeuroState({
        opens,
        depth,
        efficiency,
        forecast: newForecast.text
      });
    }
  };

  useEffect(() => {
    if (isOpen && !metrics) {
      generateNeuroState();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[200]"
        onClick={onClose}
      />

      {/* Panel */}
      <div 
        className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[460px] max-w-[90vw] h-[540px] max-h-[85vh] z-[201] overflow-y-auto"
        style={{
          background: 'rgba(7, 7, 18, 0.92)',
          borderRadius: '18px',
          border: '1px solid rgba(255, 255, 255, 0.12)',
          backdropFilter: 'blur(16px)',
          boxShadow: '0 0 40px rgba(0, 0, 0, 0.7), 0 0 120px rgba(123, 63, 246, 0.5)',
          padding: '20px',
          animation: 'panelSlideIn 0.35s ease-out'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <style>{`
          @keyframes panelSlideIn {
            from {
              opacity: 0;
              transform: translate(-50%, -50%) scale(0.9);
            }
            to {
              opacity: 1;
              transform: translate(-50%, -50%) scale(1);
            }
          }
        `}</style>

        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <div className="text-[0.9rem] tracking-[0.2em] uppercase" style={{ color: '#9fa8ff' }}>
            NEURO EVOLUTION ENGINE
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Usage Metrics */}
        <div className="mb-6">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-3 font-semibold" style={{ color: '#9fa8ff' }}>
            USAGE METRICS (SYNTHETIC)
          </h3>
          {metrics ? (
            <div className="grid grid-cols-3 gap-3">
              <div 
                className="p-3 rounded-xl border"
                style={{
                  background: 'rgba(255, 255, 255, 0.04)',
                  borderColor: 'rgba(255, 255, 255, 0.06)'
                }}
              >
                <label className="text-[0.6rem] text-gray-500 uppercase">Module Opens</label>
                <p className="text-base font-semibold mt-1 text-white">{metrics.opens}</p>
              </div>
              <div 
                className="p-3 rounded-xl border"
                style={{
                  background: 'rgba(255, 255, 255, 0.04)',
                  borderColor: 'rgba(255, 255, 255, 0.06)'
                }}
              >
                <label className="text-[0.6rem] text-gray-500 uppercase">Avg Flow Depth</label>
                <p className="text-base font-semibold mt-1 text-white">{metrics.depth}</p>
              </div>
              <div 
                className="p-3 rounded-xl border"
                style={{
                  background: 'rgba(255, 255, 255, 0.04)',
                  borderColor: 'rgba(255, 255, 255, 0.06)'
                }}
              >
                <label className="text-[0.6rem] text-gray-500 uppercase">Workflow Efficiency</label>
                <p className="text-base font-semibold mt-1 text-white">{metrics.efficiency}%</p>
              </div>
            </div>
          ) : (
            <div className="text-center text-gray-400 text-xs py-4">
              <Activity className="w-4 h-4 animate-spin inline mr-2" />
              Analyzing system behavior...
            </div>
          )}
        </div>

        {/* UI & System Recommendations */}
        <div className="mb-6">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-3 font-semibold" style={{ color: '#9fa8ff' }}>
            UI & SYSTEM RECOMMENDATIONS
          </h3>
          <ul className="space-y-2">
            {recommendations.map((rec, idx) => (
              <li key={idx} className="flex items-start gap-2 text-xs text-gray-300">
                <Target className="w-3 h-3 text-purple-400 mt-0.5 flex-shrink-0" />
                <span>{rec}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Performance Forecast */}
        <div className="mb-6">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-3 font-semibold" style={{ color: '#9fa8ff' }}>
            PERFORMANCE FORECAST
          </h3>
          <div>
            <div 
              className="h-2 rounded-full overflow-hidden mb-2"
              style={{ background: '#111' }}
            >
              <div 
                className="h-full bg-gradient-to-r from-purple-600 to-cyan-400 transition-all duration-1000"
                style={{ width: `${forecast.percentage}%` }}
              />
            </div>
            <p className="text-xs text-gray-400">
              <Zap className="w-3 h-3 inline mr-1 text-purple-400" />
              {forecast.text}
            </p>
          </div>
        </div>

        {/* Real-time Monitoring */}
        <div className="mb-4">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-3 font-semibold" style={{ color: '#9fa8ff' }}>
            REAL-TIME MONITORING
          </h3>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex justify-between">
              <span className="text-gray-400">Network Load:</span>
              <span className="text-cyan-400 font-semibold">62%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Active Agents:</span>
              <span className="text-green-400 font-semibold">160</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Avg Latency:</span>
              <span className="text-yellow-400 font-semibold">12ms</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Uptime:</span>
              <span className="text-green-400 font-semibold">99.9%</span>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <button 
          onClick={generateNeuroState}
          className="w-full py-3 rounded-xl font-semibold text-sm transition-all hover:scale-[1.02]"
          style={{
            background: 'linear-gradient(135deg, rgba(123, 63, 246, 0.6), rgba(59, 211, 255, 0.4))',
            border: '1px solid rgba(123, 63, 246, 0.6)',
            boxShadow: '0 0 20px rgba(123, 63, 246, 0.5)',
            color: '#fff'
          }}
        >
          <TrendingUp className="w-4 h-4 inline mr-2" />
          Refresh Neuro Analysis
        </button>
      </div>
    </>
  );
}