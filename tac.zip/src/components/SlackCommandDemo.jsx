import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Terminal, Send, Loader2 } from "lucide-react";

const DEMO_RESPONSES = {
  "match": {
    delay: 1500,
    response: (query) => ({
      type: "candidates",
      title: "🤖 AI Recruiter – Top Matches",
      subtitle: `Role: ${query || "unspecified"}`,
      candidates: [
        {
          name: "Nova",
          rank: "Demigod",
          score: 96,
          summary: "Senior Node + TS + scalable backend · built 3 SaaS from scratch"
        },
        {
          name: "Lyra",
          rank: "Elite",
          score: 91,
          summary: "Fullstack React/Next + Node dev · strong in DX & frontend polish"
        },
        {
          name: "Oberon",
          rank: "Rising",
          score: 87,
          summary: "Fast problem-solver, excellent in prototyping & AI API integration"
        }
      ]
    })
  },
  "value": {
    delay: 1200,
    response: (query) => {
      const desc = query || "your project";
      const base = Math.min(2000, 400 + desc.length * 2);
      const price = Math.round(base * 0.4);
      const tier = base > 1600 ? "Enterprise-grade" :
                   base > 1100 ? "Advanced" :
                   base > 800 ? "Startup-ready" : "Prototype";
      
      return {
        type: "valuation",
        title: "💰 MDC Project Valuation",
        data: {
          project: desc,
          complexity: base,
          tier: tier,
          budget: `€${price}`
        }
      };
    }
  },
  "help": {
    delay: 500,
    response: () => ({
      type: "help",
      title: "MDC Slack Commands",
      commands: [
        { cmd: "/mdc match <role>", desc: "AI-jelölt lista (demigod talent poolból)" },
        { cmd: "/mdc value <project>", desc: "Project valuation AI" },
        { cmd: "/mdc snippet", desc: "Snippet analyzer (coming soon)" }
      ]
    })
  }
};

export default function SlackCommandDemo() {
  const [command, setCommand] = useState("");
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState(null);
  const [history, setHistory] = useState([]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!command.trim() || loading) return;

    const trimmed = command.trim();
    const [cmd, ...rest] = trimmed.replace(/^\/mdc\s*/, '').split(' ');
    const query = rest.join(' ');

    // Add to history
    setHistory(prev => [...prev, { type: 'command', text: trimmed }]);
    setCommand("");
    setLoading(true);
    setResponse(null);

    // Simulate API delay
    const demoData = DEMO_RESPONSES[cmd];
    if (demoData) {
      setTimeout(() => {
        const resp = demoData.response(query);
        setResponse(resp);
        setHistory(prev => [...prev, { type: 'response', data: resp }]);
        setLoading(false);
      }, demoData.delay);
    } else {
      setTimeout(() => {
        const resp = {
          type: "error",
          title: "Unknown command",
          message: "Try /mdc help for available commands"
        };
        setResponse(resp);
        setHistory(prev => [...prev, { type: 'response', data: resp }]);
        setLoading(false);
      }, 500);
    }
  };

  const renderResponse = (data) => {
    if (!data) return null;

    if (data.type === "candidates") {
      return (
        <div className="bg-[#130d24] rounded-lg p-4 border border-purple-500/30">
          <div className="font-semibold text-white mb-1">{data.title}</div>
          <div className="text-sm text-gray-400 mb-3">{data.subtitle}</div>
          <div className="space-y-3">
            {data.candidates.map((candidate, idx) => (
              <div key={idx}>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-white font-bold">{idx + 1}. {candidate.name}</span>
                  <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30 text-xs">
                    {candidate.rank}
                  </Badge>
                  <span className="text-cyan-400 text-sm ml-auto">Score: {candidate.score}</span>
                </div>
                <div className="text-sm text-gray-400">{candidate.summary}</div>
              </div>
            ))}
          </div>
        </div>
      );
    }

    if (data.type === "valuation") {
      return (
        <div className="bg-[#130d24] rounded-lg p-4 border border-purple-500/30">
          <div className="font-semibold text-white mb-3">{data.title}</div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-400">Project:</span>
              <span className="text-white font-semibold">{data.data.project}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Complexity:</span>
              <span className="text-cyan-400 font-semibold">{data.data.complexity}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Tier:</span>
              <span className="text-purple-400 font-semibold">{data.data.tier}</span>
            </div>
            <div className="flex justify-between pt-2 border-t border-purple-500/20">
              <span className="text-gray-400">Suggested budget:</span>
              <span className="text-green-400 font-bold text-lg">{data.data.budget}</span>
            </div>
          </div>
        </div>
      );
    }

    if (data.type === "help") {
      return (
        <div className="bg-[#130d24] rounded-lg p-4 border border-purple-500/30">
          <div className="font-semibold text-white mb-3">{data.title}</div>
          <div className="space-y-2">
            {data.commands.map((cmd, idx) => (
              <div key={idx} className="flex gap-3">
                <code className="text-purple-300 text-sm font-mono">{cmd.cmd}</code>
                <span className="text-gray-400 text-sm">– {cmd.desc}</span>
              </div>
            ))}
          </div>
        </div>
      );
    }

    if (data.type === "error") {
      return (
        <div className="bg-red-900/20 rounded-lg p-4 border border-red-500/30">
          <div className="font-semibold text-red-400 mb-1">{data.title}</div>
          <div className="text-sm text-red-300">{data.message}</div>
        </div>
      );
    }

    return null;
  };

  return (
    <Card className="border-purple-500/30 bg-[#0b0816] overflow-hidden">
      {/* Header */}
      <div className="bg-[#0f0a1f] border-b border-purple-500/20 px-4 py-3 flex items-center gap-3">
        <Terminal className="w-5 h-5 text-purple-400" />
        <span className="font-semibold text-white">MDC Command Simulator</span>
        <Badge className="ml-auto bg-green-600/20 text-green-300 border-green-600/30">
          Demo Mode
        </Badge>
      </div>

      {/* Messages Area */}
      <div className="p-4 space-y-4 min-h-[300px] max-h-[500px] overflow-y-auto">
        {history.length === 0 && (
          <div className="text-center text-gray-500 py-12">
            <Terminal className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p className="text-sm">Try: /mdc match senior developer</p>
          </div>
        )}

        {history.map((item, idx) => (
          <div key={idx}>
            {item.type === 'command' ? (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                  U
                </div>
                <div>
                  <div className="text-sm font-semibold text-white mb-1">You</div>
                  <div className="text-sm text-gray-400 font-mono">{item.text}</div>
                </div>
              </div>
            ) : (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded bg-gradient-to-br from-purple-500 via-pink-500 to-cyan-500 flex items-center justify-center text-white font-bold flex-shrink-0">
                  M
                </div>
                <div className="flex-1">
                  <div className="text-sm font-semibold text-purple-400 mb-2">MDC Bot</div>
                  {renderResponse(item.data)}
                </div>
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded bg-gradient-to-br from-purple-500 via-pink-500 to-cyan-500 flex items-center justify-center text-white font-bold flex-shrink-0">
              M
            </div>
            <div className="flex items-center gap-2 text-gray-400">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span className="text-sm">MDC is thinking...</span>
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <form onSubmit={handleSubmit} className="border-t border-purple-500/20 p-4">
        <div className="flex gap-2">
          <Input
            value={command}
            onChange={(e) => setCommand(e.target.value)}
            placeholder="/mdc match senior fullstack dev"
            className="bg-[#0f0a1f] border-purple-500/30 text-white font-mono"
            disabled={loading}
          />
          <Button
            type="submit"
            disabled={loading || !command.trim()}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500"
          >
            {loading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </Button>
        </div>
        <div className="text-xs text-gray-500 mt-2">
          Try: <code className="text-purple-400">/mdc match</code>, <code className="text-purple-400">/mdc value</code>, or <code className="text-purple-400">/mdc help</code>
        </div>
      </form>
    </Card>
  );
}