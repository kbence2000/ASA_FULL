/**
 * MDC AI Utilities
 * Client-side AI helpers for snippet analysis, recruiter matching, and project valuation
 */

export const AI = {
  /**
   * Analyze code snippet quality and provide score + tips
   * @param {string} code - Code snippet to analyze
   * @returns {Promise<{score: number, label: string, tips: string[]}>}
   */
  async snippetAnalyzer(code) {
    const lengthScore = Math.min(50, Math.floor(code.length / 10));
    const cleanScore = code.includes(";") ? 20 : 10;
    const structureScore = code.includes("function") || code.includes("=>") ? 30 : 10;

    const final = lengthScore + cleanScore + structureScore;

    return {
      score: final,
      label:
        final > 85 ? "Godlike clarity" :
        final > 70 ? "Demigod-grade snippet" :
        final > 50 ? "Clean but improvable" :
        "Rough concept – needs refinement",
      tips: [
        "Use modular structure",
        "Add comments for clarity",
        "Keep functions small",
        "Optimize loops & conditions"
      ]
    };
  },

  /**
   * Rank users/developers based on activity and match criteria
   * @param {object} criteria - Matching criteria (not used in simple version)
   * @param {array} userList - List of user objects with stats
   * @returns {Promise<array>} Top 10 ranked users
   */
  async miniRecruiter(criteria, userList) {
    const ranked = userList
      .map(u => ({
        ...u,
        match:
          (u.stats?.snippets || 0) * 3 +
          (u.stats?.showcases || 0) * 4 +
          (u.stats?.avgSnippetScore || 0) * 2
      }))
      .sort((a, b) => b.match - a.match)
      .slice(0, 10);

    return ranked;
  },

  /**
   * Calculate project valuation based on complexity factors
   * @param {object} projectData - Project details (linesOfCode, features, usesAI)
   * @returns {Promise<{value: number, tier: string, recommendedPriceEUR: number}>}
   */
  async projectValuation(projectData) {
    const complexity = (projectData.linesOfCode || 0) * 0.5;
    const features = (projectData.features?.length || 0) * 120;
    const aiDepth = projectData.usesAI ? 400 : 80;

    const total = Math.round(complexity + features + aiDepth);

    return {
      value: total,
      tier:
        total > 2000 ? "Enterprise-grade" :
        total > 1200 ? "Advanced" :
        total > 600 ? "Startup-ready" : "Prototype",
      recommendedPriceEUR: Math.round(total * 0.35)
    };
  }
};

// Export individual functions for convenience
export const snippetAnalyzer = AI.snippetAnalyzer.bind(AI);
export const miniRecruiter = AI.miniRecruiter.bind(AI);
export const projectValuation = AI.projectValuation.bind(AI);

export default AI;