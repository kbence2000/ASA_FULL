import React from "react";
import { Shield, Crown, Flame, Zap, Star, Sparkles, Lock } from "lucide-react";
import { cn } from "@/lib/utils";

const RANK_CONFIG = {
  R1: {
    name: "Rookie",
    icon: Shield,
    color: "#6B7280",
    gradient: "from-gray-600 to-gray-700",
    glow: "rgba(107, 116, 128, 0.4)",
    bgPattern: "rgba(107, 116, 128, 0.1)",
  },
  R2: {
    name: "Builder",
    icon: Zap,
    color: "#3B82F6",
    gradient: "from-blue-500 to-blue-600",
    glow: "rgba(59, 130, 246, 0.5)",
    bgPattern: "rgba(59, 130, 246, 0.15)",
  },
  R3: {
    name: "Architect",
    icon: Star,
    color: "#8B5CF6",
    gradient: "from-violet-500 to-purple-600",
    glow: "rgba(139, 92, 246, 0.5)",
    bgPattern: "rgba(139, 92, 246, 0.15)",
  },
  R4: {
    name: "Shadow Elite",
    icon: Flame,
    color: "#8C46FF",
    gradient: "from-purple-600 to-indigo-700",
    glow: "rgba(140, 70, 255, 0.6)",
    bgPattern: "rgba(140, 70, 255, 0.2)",
  },
  R5: {
    name: "Mythic",
    icon: Sparkles,
    color: "#A855F7",
    gradient: "from-purple-500 to-fuchsia-600",
    glow: "rgba(168, 85, 247, 0.7)",
    bgPattern: "rgba(168, 85, 247, 0.25)",
  },
  R6: {
    name: "Code Demigod",
    icon: Crown,
    color: "#F4C76A",
    gradient: "from-yellow-500 to-amber-600",
    glow: "rgba(244, 199, 106, 0.8)",
    bgPattern: "rgba(244, 199, 106, 0.3)",
  },
  R7: {
    name: "Vault Tier",
    icon: Lock,
    color: "#FFE38A",
    gradient: "from-amber-400 to-yellow-500",
    glow: "rgba(255, 227, 138, 0.9)",
    bgPattern: "rgba(255, 227, 138, 0.35)",
  },
};

export default function RankBadge({ 
  rank = "R1", 
  size = "md", 
  showName = true, 
  showScore = false,
  score = 0,
  animated = true,
  className = ""
}) {
  const config = RANK_CONFIG[rank] || RANK_CONFIG.R1;
  const Icon = config.icon;

  const sizeClasses = {
    xs: "w-6 h-6",
    sm: "w-8 h-8",
    md: "w-12 h-12",
    lg: "w-16 h-16",
    xl: "w-20 h-20",
  };

  const iconSizes = {
    xs: "w-3 h-3",
    sm: "w-4 h-4",
    md: "w-6 h-6",
    lg: "w-8 h-8",
    xl: "w-10 h-10",
  };

  const textSizes = {
    xs: "text-[0.6rem]",
    sm: "text-xs",
    md: "text-sm",
    lg: "text-base",
    xl: "text-lg",
  };

  return (
    <div className={cn("inline-flex items-center gap-2", className)}>
      <div 
        className={cn(
          "relative rounded-full flex items-center justify-center border-2 transition-all",
          sizeClasses[size],
          animated && "hover:scale-110"
        )}
        style={{
          background: `radial-gradient(circle at 30% 30%, ${config.bgPattern}, transparent 70%), linear-gradient(135deg, ${config.color}, rgba(0,0,0,0.3))`,
          borderColor: config.color,
          boxShadow: `0 0 20px ${config.glow}, inset 0 0 10px rgba(255,255,255,0.1)`,
        }}
      >
        <Icon 
          className={cn(iconSizes[size], "relative z-10")} 
          style={{ color: rank === "R6" || rank === "R7" ? "#000" : "#fff" }}
        />
        
        {/* Animated glow pulse for high ranks */}
        {(rank === "R6" || rank === "R7") && animated && (
          <div 
            className="absolute inset-0 rounded-full animate-pulse"
            style={{
              background: `radial-gradient(circle, ${config.glow}, transparent 70%)`,
            }}
          />
        )}
      </div>

      {(showName || showScore) && (
        <div className="flex flex-col">
          {showName && (
            <div 
              className={cn(
                "font-bold tracking-wide uppercase leading-none",
                textSizes[size]
              )}
              style={{ 
                background: `linear-gradient(135deg, ${config.color}, ${config.glow})`,
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              {config.name}
            </div>
          )}
          {showScore && (
            <div className={cn("text-gray-400 font-mono", textSizes[size])}>
              {score}/100
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export { RANK_CONFIG };