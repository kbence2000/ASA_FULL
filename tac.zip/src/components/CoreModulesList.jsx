import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Grid3x3, Shield, Brain, TrendingUp, Sparkles } from "lucide-react";

export default function CoreModulesList() {
  const [modules, setModules] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchModules();
  }, []);

  const fetchModules = async () => {
    try {
      const response = await fetch('/api/core/modules');
      const data = await response.json();
      setModules(data || []);
    } catch (error) {
      console.error("Failed to fetch modules:", error);
    } finally {
      setLoading(false);
    }
  };

  const getTierIcon = (tier) => {
    switch (tier) {
      case "core": return <Brain className="w-5 h-5 text-purple-400" />;
      case "defense": return <Shield className="w-5 h-5 text-cyan-400" />;
      case "intel": return <TrendingUp className="w-5 h-5 text-green-400" />;
      case "creation": return <Sparkles className="w-5 h-5 text-yellow-400" />;
      default: return <Grid3x3 className="w-5 h-5 text-gray-400" />;
    }
  };

  const getTierBadge = (tier) => {
    switch (tier) {
      case "core": return "bg-purple-600/20 text-purple-300 border-purple-600/30";
      case "defense": return "bg-cyan-600/20 text-cyan-300 border-cyan-600/30";
      case "intel": return "bg-green-600/20 text-green-300 border-green-600/30";
      case "creation": return "bg-yellow-600/20 text-yellow-300 border-yellow-600/30";
      default: return "bg-gray-600/20 text-gray-300 border-gray-600/30";
    }
  };

  if (loading) {
    return (
      <Card className="border p-6 text-center" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <p className="text-gray-400">Loading modules...</p>
      </Card>
    );
  }

  return (
    <Card className="border p-6" style={{
      background: 'rgba(15, 23, 42, 0.95)',
      borderColor: 'rgba(148, 163, 184, 0.35)'
    }}>
      <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <Grid3x3 className="w-5 h-5 text-purple-400" />
        Core Modules
        <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30 text-xs ml-auto">
          {modules.length} active
        </Badge>
      </h3>

      <div className="grid md:grid-cols-2 gap-3">
        {modules.map((module) => (
          <div
            key={module.id}
            className="p-4 rounded-lg border hover:shadow-lg transition-all"
            style={{
              background: 'rgba(5, 8, 22, 0.5)',
              borderColor: 'rgba(148, 163, 184, 0.2)'
            }}
          >
            <div className="flex items-start gap-3">
              <div className="mt-0.5">
                {getTierIcon(module.tier)}
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-bold text-white">{module.id}</h4>
                  <Badge className={getTierBadge(module.tier)}>
                    {module.tier}
                  </Badge>
                </div>
                <p className="text-sm text-gray-400">{module.role}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}