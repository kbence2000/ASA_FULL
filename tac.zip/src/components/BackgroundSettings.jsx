import React, { useState } from 'react';
import { Settings, X, Zap, Sparkles, Minimize2, Check, Box } from 'lucide-react';
import { useBackgroundSettings } from './BackgroundSettingsContext';

export default function BackgroundSettings() {
  const [isOpen, setIsOpen] = useState(false);
  const { settings, updateSettings, hasWebGPU } = useBackgroundSettings();

  return (
    <>
      {/* Settings Button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-20 right-6 w-12 h-12 rounded-full flex items-center justify-center transition-all z-50 hover:scale-110 group"
        style={{
          background: 'rgba(139, 92, 255, 0.2)',
          border: '1px solid rgba(139, 92, 255, 0.4)',
          backdropFilter: 'blur(10px)',
          boxShadow: '0 0 20px rgba(139, 92, 255, 0.3)'
        }}
      >
        <Settings className="w-5 h-5 text-purple-300 group-hover:rotate-90 transition-transform duration-300" />
      </button>

      {/* Settings Panel */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <div 
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setIsOpen(false)}
          />

          {/* Panel */}
          <div 
            className="relative w-full max-w-md rounded-2xl border p-6 animate-slide-up"
            style={{
              background: 'rgba(8, 8, 18, 0.95)',
              borderColor: 'rgba(139, 92, 255, 0.3)',
              boxShadow: '0 0 40px rgba(139, 92, 255, 0.4)'
            }}
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <Settings className="w-6 h-6 text-purple-400" />
                <h3 className="text-xl font-bold text-white">Background Settings</h3>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors"
                style={{ border: '1px solid rgba(255, 255, 255, 0.2)' }}
              >
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>

            {/* Background Type */}
            <div className="mb-6">
              <label className="text-sm font-semibold text-gray-300 mb-3 block">
                Background Type
              </label>
              <div className="space-y-2">
                {/* 3D Neural Net Option */}
                <button
                  onClick={() => updateSettings({ type: '3d-neural' })}
                  disabled={!hasWebGPU}
                  className={`w-full p-4 rounded-xl border transition-all text-left ${
                    settings.type === '3d-neural' 
                      ? 'border-purple-500 bg-purple-900/20' 
                      : 'border-white/10 hover:border-white/20'
                  } ${!hasWebGPU ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Box className="w-5 h-5 text-pink-400" />
                      <span className="font-semibold text-white">3D Neural Network</span>
                    </div>
                    {settings.type === '3d-neural' && (
                      <Check className="w-5 h-5 text-green-400" />
                    )}
                  </div>
                  <p className="text-xs text-gray-400">
                    Rotating 3D neuron field with depth-based fading
                  </p>
                  {!hasWebGPU && (
                    <p className="text-xs text-orange-400 mt-2">
                      ⚠️ WebGPU not available in this browser
                    </p>
                  )}
                </button>

                {/* WebGPU 2D Neural Field Option */}
                <button
                  onClick={() => updateSettings({ type: 'webgpu' })}
                  disabled={!hasWebGPU}
                  className={`w-full p-4 rounded-xl border transition-all text-left ${
                    settings.type === 'webgpu' 
                      ? 'border-purple-500 bg-purple-900/20' 
                      : 'border-white/10 hover:border-white/20'
                  } ${!hasWebGPU ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Zap className="w-5 h-5 text-cyan-400" />
                      <span className="font-semibold text-white">2D Neural Field</span>
                    </div>
                    {settings.type === 'webgpu' && (
                      <Check className="w-5 h-5 text-green-400" />
                    )}
                  </div>
                  <p className="text-xs text-gray-400">
                    GPU-accelerated 2D neural patterns
                  </p>
                  {!hasWebGPU && (
                    <p className="text-xs text-orange-400 mt-2">
                      ⚠️ WebGPU not available in this browser
                    </p>
                  )}
                </button>

                {/* Particles Option */}
                <button
                  onClick={() => updateSettings({ type: 'particles' })}
                  className={`w-full p-4 rounded-xl border transition-all text-left cursor-pointer ${
                    settings.type === 'particles'
                      ? 'border-purple-500 bg-purple-900/20'
                      : 'border-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-purple-400" />
                      <span className="font-semibold text-white">Quantum Particles</span>
                    </div>
                    {settings.type === 'particles' && (
                      <Check className="w-5 h-5 text-green-400" />
                    )}
                  </div>
                  <p className="text-xs text-gray-400">
                    Classic 2D particle network with connections
                  </p>
                </button>

                {/* Minimal Option */}
                <button
                  onClick={() => updateSettings({ type: 'minimal' })}
                  className={`w-full p-4 rounded-xl border transition-all text-left cursor-pointer ${
                    settings.type === 'minimal'
                      ? 'border-purple-500 bg-purple-900/20'
                      : 'border-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Minimize2 className="w-5 h-5 text-gray-400" />
                      <span className="font-semibold text-white">Minimal</span>
                    </div>
                    {settings.type === 'minimal' && (
                      <Check className="w-5 h-5 text-green-400" />
                    )}
                  </div>
                  <p className="text-xs text-gray-400">
                    Static gradient for maximum performance
                  </p>
                </button>
              </div>
            </div>

            {/* Performance Info */}
            <div className="p-3 rounded-lg" style={{ background: 'rgba(59, 211, 255, 0.1)', border: '1px solid rgba(59, 211, 255, 0.3)' }}>
              <div className="flex items-start gap-2">
                <Zap className="w-4 h-4 text-cyan-400 mt-0.5 flex-shrink-0" />
                <div className="text-xs text-gray-300">
                  {settings.type === '3d-neural' && (
                    <><span className="font-semibold text-white">3D Neural Network:</span> Most immersive. Rotating 3D sphere with depth-based effects.</>
                  )}
                  {settings.type === 'webgpu' && (
                    <><span className="font-semibold text-white">2D Neural Field:</span> Best performance. GPU-accelerated organic patterns.</>
                  )}
                  {settings.type === 'particles' && (
                    <><span className="font-semibold text-white">Quantum Particles:</span> Compatible fallback. Works on all browsers.</>
                  )}
                  {settings.type === 'minimal' && (
                    <><span className="font-semibold text-white">Minimal Mode:</span> Zero background rendering. Maximum battery life.</>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}