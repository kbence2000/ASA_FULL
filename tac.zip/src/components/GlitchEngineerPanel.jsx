import React, { useState } from 'react';
import { X, Zap, Code } from 'lucide-react';
import { useTriMind } from './TriMindContext';

export default function GlitchEngineerPanel({ isOpen, onClose }) {
  const triMind = useTriMind();
  const [glitchConcept, setGlitchConcept] = useState('No glitch generated yet.');
  const [glitchCode, setGlitchCode] = useState('–');

  const concepts = [
    "Buttons rendering as double-exposed ghosts that misalign on hover.",
    "Navigation items that jitter one pixel every frame, like a broken CRT.",
    "A code panel that randomly hides one character and reappears on scroll.",
    "Glitch stripes passing across the UI that temporarily invert colors.",
    "Text that splits into RGB layers when hovered, like chromatic aberration.",
    "Panels that briefly phase through each other during transitions."
  ];

  const codeSnippets = [
    `// Glitch: jitter transform
.element {
  position: relative;
  animation: glitch-jitter 80ms infinite alternate;
}
@keyframes glitch-jitter {
  0% { transform: translate(0,0); }
  100% { transform: translate(1px,-1px); }
}`,
    `// Glitch: ghost duplicate
.element::after {
  content: attr(data-label);
  position: absolute;
  left: 2px;
  top: -1px;
  opacity: 0.4;
  color: #00ff8a;
}`,
    `// Glitch: random char hide (concept)
const chars = text.split("");
if (Math.random() < 0.05) chars[i] = " ";
return chars.join("");`,
    `// Glitch: RGB split on hover
.element:hover {
  text-shadow: 
    -2px 0 #ff00de,
    2px 0 #00ffff;
}`,
    `// Glitch: scanline effect
.element::before {
  content: "";
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    0deg,
    rgba(0,0,0,0.1) 0px,
    transparent 2px,
    transparent 4px
  );
  pointer-events: none;
}`
  ];

  const generateGlitch = () => {
    const concept = concepts[Math.floor(Math.random() * concepts.length)];
    const snippet = codeSnippets[Math.floor(Math.random() * codeSnippets.length)];

    setGlitchConcept(concept);
    setGlitchCode(snippet);

    // Update Tri-Mind state
    if (triMind) {
      triMind.setGlitchState({
        label: concept.slice(0, 60) + '...',
        concept,
        code: snippet
      });
    }
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[200]"
        onClick={onClose}
      />

      {/* Panel */}
      <div 
        className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[460px] max-w-[90vw] h-[540px] max-h-[85vh] z-[201] overflow-y-auto"
        style={{
          background: 'rgba(18, 5, 8, 0.96)',
          borderRadius: '18px',
          border: '1px solid rgba(255, 75, 92, 0.3)',
          backdropFilter: 'blur(16px)',
          boxShadow: '0 0 80px rgba(255, 75, 92, 0.4)',
          padding: '20px',
          animation: 'panelSlideIn 0.35s ease-out'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <style>{`
          @keyframes panelSlideIn {
            from {
              opacity: 0;
              transform: translate(-50%, -50%) scale(0.9);
            }
            to {
              opacity: 1;
              transform: translate(-50%, -50%) scale(1);
            }
          }
        `}</style>

        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <div className="text-[0.9rem] tracking-[0.2em] uppercase" style={{ color: '#ff4b5c' }}>
            GLITCH ENGINEER
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Glitch Concept */}
        <div className="mb-6">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-3 font-semibold" style={{ color: '#ff8a94' }}>
            GLITCH CONCEPT
          </h3>
          <div 
            className="p-3 rounded-lg text-sm"
            style={{
              background: 'rgba(0, 0, 0, 0.5)',
              border: '1px solid rgba(255, 75, 92, 0.3)',
              color: '#ffdde0'
            }}
          >
            {glitchConcept}
          </div>
        </div>

        {/* Generated Code Fragment */}
        <div className="mb-6">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-3 font-semibold" style={{ color: '#ff8a94' }}>
            GENERATED CODE FRAGMENT
          </h3>
          <pre 
            className="p-3 rounded-lg text-xs overflow-x-auto"
            style={{
              background: 'rgba(0, 0, 0, 0.5)',
              border: '1px solid rgba(255, 75, 92, 0.3)',
              color: '#ffdde0',
              fontFamily: 'monospace',
              whiteSpace: 'pre-wrap'
            }}
          >
            {glitchCode}
          </pre>
        </div>

        {/* Info */}
        <div 
          className="p-3 rounded-lg mb-6"
          style={{
            background: 'rgba(255, 75, 92, 0.1)',
            border: '1px solid rgba(255, 75, 92, 0.3)'
          }}
        >
          <div className="flex items-start gap-2">
            <Zap className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <span className="font-semibold text-white">Glitch Engineer:</span> Generates controlled UI corruption patterns - intentional visual glitches that add character and experimental aesthetics to the interface without breaking functionality.
            </div>
          </div>
        </div>

        {/* Action Button */}
        <button 
          onClick={generateGlitch}
          className="w-full py-3 rounded-xl font-semibold text-sm transition-all hover:scale-[1.02]"
          style={{
            background: 'linear-gradient(135deg, rgba(255, 75, 92, 0.6), rgba(255, 110, 199, 0.4))',
            border: '1px solid rgba(255, 75, 92, 0.6)',
            boxShadow: '0 0 20px rgba(255, 75, 92, 0.5)',
            color: '#fff'
          }}
        >
          <Code className="w-4 h-4 inline mr-2" />
          Generate Glitch Pattern
        </button>
      </div>
    </>
  );
}