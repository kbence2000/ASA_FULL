import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Crown, Zap, Target } from "lucide-react";
import { demigodAPI } from "./DemigodAPIClient";
import { formatDistanceToNow } from "date-fns";

export default function DemigodRankTracker({ userId }) {
  const [rank, setRank] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (userId) {
      fetchRankData();
    }
  }, [userId]);

  const fetchRankData = async () => {
    try {
      const [rankData, historyData] = await Promise.all([
        demigodAPI.getRank(userId),
        demigodAPI.getRankHistory(userId, { limit: 10 }),
      ]);
      
      setRank(rankData);
      setHistory(historyData.history || []);
    } catch (error) {
      console.error("Failed to fetch rank data:", error);
    } finally {
      setLoading(false);
    }
  };

  const getRankColor = (tier) => {
    switch (tier?.toLowerCase()) {
      case "mortal": return "text-gray-400";
      case "ascendant": return "text-blue-400";
      case "demigod": return "text-purple-400";
      case "titan": return "text-orange-400";
      case "olympian": return "text-yellow-400";
      default: return "text-gray-400";
    }
  };

  const getRankBadge = (tier) => {
    switch (tier?.toLowerCase()) {
      case "mortal": return "bg-gray-600/20 text-gray-300 border-gray-600/30";
      case "ascendant": return "bg-blue-600/20 text-blue-300 border-blue-600/30";
      case "demigod": return "bg-purple-600/20 text-purple-300 border-purple-600/30";
      case "titan": return "bg-orange-600/20 text-orange-300 border-orange-600/30";
      case "olympian": return "bg-yellow-600/20 text-yellow-300 border-yellow-600/30";
      default: return "bg-gray-600/20 text-gray-300 border-gray-600/30";
    }
  };

  if (loading) {
    return (
      <Card className="border p-6 text-center" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <p className="text-gray-400">Loading rank data...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Current Rank */}
      <Card className="border p-6" style={{
        background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
        borderColor: 'rgba(139, 92, 255, 0.3)'
      }}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <Crown className="w-5 h-5 text-yellow-400" />
            Current Rank
          </h3>
          <Badge className={getRankBadge(rank?.tier)}>
            {rank?.tier || "UNKNOWN"}
          </Badge>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <div className={`text-3xl font-bold ${getRankColor(rank?.tier)}`}>
              #{rank?.position || "N/A"}
            </div>
            <div className="text-xs text-gray-400 mt-1">Position</div>
          </div>

          <div className="text-center">
            <div className="text-3xl font-bold text-cyan-400">
              {rank?.score || 0}
            </div>
            <div className="text-xs text-gray-400 mt-1">Score</div>
          </div>

          <div className="text-center">
            <div className="text-3xl font-bold text-purple-400">
              {rank?.level || 1}
            </div>
            <div className="text-xs text-gray-400 mt-1">Level</div>
          </div>
        </div>

        {rank?.nextTier && (
          <div className="mt-4 pt-4 border-t" style={{ borderColor: 'rgba(148, 163, 184, 0.2)' }}>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Progress to {rank.nextTier}:</span>
              <span className="text-cyan-400 font-semibold">
                {rank.progressPercentage || 0}%
              </span>
            </div>
            <div className="mt-2 h-2 bg-gray-800 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-purple-500 to-cyan-500 transition-all duration-500"
                style={{ width: `${rank.progressPercentage || 0}%` }}
              />
            </div>
          </div>
        )}
      </Card>

      {/* Rank History */}
      {history.length > 0 && (
        <Card className="border p-6" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Target className="w-5 h-5 text-cyan-400" />
            Rank History
          </h3>

          <div className="space-y-3 max-h-64 overflow-y-auto">
            {history.map((entry, idx) => {
              const isUp = idx > 0 && entry.position < history[idx - 1].position;
              const isDown = idx > 0 && entry.position > history[idx - 1].position;

              return (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 rounded-lg border"
                  style={{
                    background: 'rgba(5, 8, 22, 0.5)',
                    borderColor: 'rgba(148, 163, 184, 0.2)'
                  }}
                >
                  <div className="flex items-center gap-3">
                    {isUp ? (
                      <TrendingUp className="w-4 h-4 text-green-400" />
                    ) : isDown ? (
                      <TrendingDown className="w-4 h-4 text-red-400" />
                    ) : (
                      <Zap className="w-4 h-4 text-gray-400" />
                    )}
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-white font-semibold">#{entry.position}</span>
                        <Badge className={getRankBadge(entry.tier)}>
                          {entry.tier}
                        </Badge>
                      </div>
                      <div className="text-xs text-gray-400 mt-0.5">
                        Score: {entry.score}
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-xs text-gray-500">
                      {entry.timestamp 
                        ? formatDistanceToNow(new Date(entry.timestamp), { addSuffix: true })
                        : 'Recent'
                      }
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      )}
    </div>
  );
}