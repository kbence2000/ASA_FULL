import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Sparkles, TrendingUp, DollarSign, Target } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { AI } from "./AppAI";

export default function AIValuator({ onValuationComplete }) {
  const [linesOfCode, setLinesOfCode] = useState("");
  const [fileCount, setFileCount] = useState("");
  const [techStack, setTechStack] = useState("");
  const [dependencies, setDependencies] = useState("");
  const [description, setDescription] = useState("");
  const [usesAI, setUsesAI] = useState(false);
  const [usesWeb3, setUsesWeb3] = useState(false);
  
  const [valuing, setValuing] = useState(false);
  const [valuation, setValuation] = useState(null);

  const handleValuate = async () => {
    if (!description && !techStack) {
      toast.error("Adj meg legalább leírást vagy tech stacket!");
      return;
    }

    setValuing(true);
    
    try {
      // Parse features from description
      const features = description
        .toLowerCase()
        .split(/[,.\n]/)
        .map(s => s.trim())
        .filter(s => s.length > 3 && s.length < 30);

      // Use local AI for quick valuation
      const projectData = {
        linesOfCode: parseInt(linesOfCode) || 1000,
        features: features,
        usesAI: usesAI
      };

      const localValuation = await AI.projectValuation(projectData);

      // Optionally call backend LLM for detailed analysis
      const llmResult = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this software project and provide market valuation:

Lines of Code: ${linesOfCode || "unknown"}
Files: ${fileCount || "unknown"}
Tech Stack: ${techStack || "modern web stack"}
Dependencies: ${dependencies || "standard"}
Description: ${description}
Uses AI: ${usesAI ? "Yes" : "No"}
Uses Web3/Blockchain: ${usesWeb3 ? "Yes" : "No"}

Provide:
1. Complexity level (1-10)
2. Estimated development hours (range)
3. Market value in USD (low, mid, high range)
4. Target buyer type (indie dev, startup, enterprise)
5. Key risks or concerns
6. Pricing recommendation`,
        add_context_from_internet: false
      });

      const combinedValuation = {
        ...localValuation,
        llmAnalysis: llmResult,
        estimated_value_usd: {
          low: Math.round(localValuation.recommendedPriceEUR * 1.1 * 0.8),
          mid: Math.round(localValuation.recommendedPriceEUR * 1.1),
          high: Math.round(localValuation.recommendedPriceEUR * 1.1 * 1.3)
        }
      };

      setValuation(combinedValuation);
      
      if (onValuationComplete) {
        onValuationComplete(combinedValuation);
      }
      
      toast.success("AI értékelés kész!");
    } catch (error) {
      console.error("Valuation error:", error);
      toast.error("Hiba történt az AI értékelés során");
    } finally {
      setValuing(false);
    }
  };

  const getComplexityColor = (tier) => {
    if (tier === "Enterprise-grade") return "text-purple-400 bg-purple-600/20 border-purple-600/30";
    if (tier === "Advanced") return "text-cyan-400 bg-cyan-600/20 border-cyan-600/30";
    if (tier === "Startup-ready") return "text-green-400 bg-green-600/20 border-green-600/30";
    return "text-gray-400 bg-gray-600/20 border-gray-600/30";
  };

  return (
    <Card className="border-purple-600/50 bg-gradient-to-br from-purple-600/10 to-pink-600/10 p-6 mb-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="text-lg font-bold text-white">AI Projekt Értékelő</h3>
          <p className="text-xs text-purple-200">Gyors AI-alapú árbecslés projektedhez</p>
        </div>
      </div>

      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-white text-xs mb-1 block">Kódsorok száma</Label>
            <Input
              type="number"
              value={linesOfCode}
              onChange={(e) => setLinesOfCode(e.target.value)}
              placeholder="1000"
              className="bg-[#141923] border-[#1a1f2e] text-white"
            />
          </div>
          <div>
            <Label className="text-white text-xs mb-1 block">Fájlok száma</Label>
            <Input
              type="number"
              value={fileCount}
              onChange={(e) => setFileCount(e.target.value)}
              placeholder="50"
              className="bg-[#141923] border-[#1a1f2e] text-white"
            />
          </div>
        </div>

        <div>
          <Label className="text-white text-xs mb-1 block">Tech Stack (pl. React, Node.js, PostgreSQL)</Label>
          <Input
            value={techStack}
            onChange={(e) => setTechStack(e.target.value)}
            placeholder="React, Node.js, PostgreSQL"
            className="bg-[#141923] border-[#1a1f2e] text-white"
          />
        </div>

        <div>
          <Label className="text-white text-xs mb-1 block">Dependencies (opcionális)</Label>
          <Input
            value={dependencies}
            onChange={(e) => setDependencies(e.target.value)}
            placeholder="Stripe, OpenAI, AWS S3"
            className="bg-[#141923] border-[#1a1f2e] text-white"
          />
        </div>

        <div>
          <Label className="text-white text-xs mb-1 block">Projekt Leírás</Label>
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Írd le röviden a projekt funkcióit és célját..."
            className="bg-[#141923] border-[#1a1f2e] text-white h-24"
          />
        </div>

        <div className="flex gap-4">
          <label className="flex items-center gap-2 text-sm text-white cursor-pointer">
            <input
              type="checkbox"
              checked={usesAI}
              onChange={(e) => setUsesAI(e.target.checked)}
              className="w-4 h-4"
            />
            Használ AI/ML-t
          </label>
          <label className="flex items-center gap-2 text-sm text-white cursor-pointer">
            <input
              type="checkbox"
              checked={usesWeb3}
              onChange={(e) => setUsesWeb3(e.target.checked)}
              className="w-4 h-4"
            />
            Használ Web3/Blockchain-t
          </label>
        </div>

        <Button
          onClick={handleValuate}
          disabled={valuing}
          className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold"
        >
          {valuing ? (
            <>
              <Sparkles className="w-4 h-4 mr-2 animate-pulse" />
              AI Elemez...
            </>
          ) : (
            <>
              <Target className="w-4 h-4 mr-2" />
              AI Értékelés
            </>
          )}
        </Button>

        {/* Valuation Results */}
        {valuation && (
          <div className="mt-4 p-4 rounded-lg bg-[#0a0a0f] border border-purple-600/30 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-300">Komplexitás:</span>
              <Badge className={getComplexityColor(valuation.tier)}>
                {valuation.tier}
              </Badge>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-300">Érték Pontszám:</span>
              <span className="text-xl font-bold text-purple-400">{valuation.value}</span>
            </div>

            <div className="p-3 rounded-lg bg-green-600/10 border border-green-600/30">
              <div className="flex items-center gap-2 mb-1">
                <DollarSign className="w-4 h-4 text-green-400" />
                <span className="text-xs text-green-300 font-semibold">Ajánlott Ár (USD)</span>
              </div>
              <div className="text-sm text-white">
                <span className="text-green-400 font-bold">${valuation.estimated_value_usd?.low || 0}</span>
                {' - '}
                <span className="text-green-400 font-bold">${valuation.estimated_value_usd?.high || 0}</span>
              </div>
              <div className="text-xs text-green-200 mt-1">
                Best: ${valuation.estimated_value_usd?.mid || valuation.recommendedPriceEUR}
              </div>
            </div>

            {valuation.llmAnalysis && (
              <div className="text-xs text-gray-300 bg-[#05050a] p-3 rounded border border-[#1a1f2e]">
                <strong className="text-purple-300">AI Elemzés:</strong>
                <p className="mt-1 whitespace-pre-wrap">{valuation.llmAnalysis}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </Card>
  );
}