import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle,
  Clock,
  Filter,
  ChevronRight
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export default function DevGuardianTaskList({ onSelectTask }) {
  const [statusFilter, setStatusFilter] = useState("all");
  const [severityFilter, setSeverityFilter] = useState("all");

  const { data: tasks, isLoading } = useQuery({
    queryKey: ['devGuardianTasks'],
    queryFn: () => base44.entities.DevGuardianTask.list('-created_date', 100),
    initialData: [],
    refetchInterval: 30000,
  });

  const filteredTasks = tasks.filter(task => {
    const matchesStatus = statusFilter === "all" || task.status === statusFilter;
    const matchesSeverity = severityFilter === "all" || task.severity === severityFilter;
    return matchesStatus && matchesSeverity;
  });

  const getTypeIcon = (type) => {
    switch (type) {
      case 'daily': return '📅';
      case 'post-release': return '🚀';
      case 'on-issue': return '🐛';
      case 'manual': return '🔍';
      default: return '📋';
    }
  };

  const getSeverityBadge = (severity) => {
    switch (severity) {
      case 'critical':
        return <Badge className="bg-red-600/20 text-red-300 border-red-600/30">Critical</Badge>;
      case 'high':
        return <Badge className="bg-orange-600/20 text-orange-300 border-orange-600/30">High</Badge>;
      case 'medium':
        return <Badge className="bg-yellow-600/20 text-yellow-300 border-yellow-600/30">Medium</Badge>;
      case 'low':
        return <Badge className="bg-blue-600/20 text-blue-300 border-blue-600/30">Low</Badge>;
      default:
        return <Badge className="bg-gray-600/20 text-gray-300 border-gray-600/30">Unknown</Badge>;
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-yellow-600/20 text-yellow-300 border-yellow-600/30"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case 'approved':
        return <Badge className="bg-green-600/20 text-green-300 border-green-600/30"><CheckCircle2 className="w-3 h-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge className="bg-red-600/20 text-red-300 border-red-600/30"><XCircle className="w-3 h-3 mr-1" />Rejected</Badge>;
      case 'implemented':
        return <Badge className="bg-cyan-600/20 text-cyan-300 border-cyan-600/30"><CheckCircle2 className="w-3 h-3 mr-1" />Implemented</Badge>;
      default:
        return <Badge className="bg-gray-600/20 text-gray-300 border-gray-600/30">Unknown</Badge>;
    }
  };

  const formatDate = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };

  return (
    <div className="space-y-4">
      {/* Filters */}
      <Card className="border p-4" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <div className="flex items-center gap-4">
          <Filter className="w-5 h-5 text-gray-400" />
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40 bg-[#141923] border-[#1a1f2e] text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
              <SelectItem value="implemented">Implemented</SelectItem>
            </SelectContent>
          </Select>

          <Select value={severityFilter} onValueChange={setSeverityFilter}>
            <SelectTrigger className="w-40 bg-[#141923] border-[#1a1f2e] text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Severity</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </SelectContent>
          </Select>

          <div className="text-sm text-gray-400 ml-auto">
            {filteredTasks.length} tasks
          </div>
        </div>
      </Card>

      {/* Tasks List */}
      {isLoading ? (
        <Card className="border p-12 text-center" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <p className="text-gray-400">Loading tasks...</p>
        </Card>
      ) : filteredTasks.length === 0 ? (
        <Card className="border p-12 text-center" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <Shield className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-white mb-2">No Tasks Found</h3>
          <p className="text-gray-400">
            {statusFilter !== "all" || severityFilter !== "all" 
              ? "Try adjusting your filters"
              : "Run an audit to generate improvement tasks"}
          </p>
        </Card>
      ) : (
        <div className="space-y-3">
          {filteredTasks.map(task => (
            <Card 
              key={task.id} 
              className="border p-5 hover:shadow-lg transition-all cursor-pointer group"
              style={{
                background: 'rgba(15, 23, 42, 0.95)',
                borderColor: task.severity === 'critical' 
                  ? 'rgba(239, 68, 68, 0.3)'
                  : task.severity === 'high'
                  ? 'rgba(251, 146, 60, 0.3)'
                  : 'rgba(148, 163, 184, 0.35)'
              }}
              onClick={() => onSelectTask && onSelectTask(task)}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <div className="text-3xl mt-1">
                    {getTypeIcon(task.type)}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-bold text-white text-lg group-hover:text-cyan-400 transition-colors">
                        {task.title}
                      </h3>
                      {getSeverityBadge(task.severity)}
                      {getStatusBadge(task.status)}
                    </div>

                    <p className="text-sm text-gray-400 mb-3 line-clamp-2">
                      {task.summary}
                    </p>

                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span>📅 {formatDate(task.created_date)}</span>
                      {task.improvementPlan && task.improvementPlan.length > 0 && (
                        <span>📋 {task.improvementPlan.length} steps</span>
                      )}
                      {task.patches && task.patches.length > 0 && (
                        <span>🔧 {task.patches.length} patches</span>
                      )}
                    </div>
                  </div>
                </div>

                <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-cyan-400 group-hover:translate-x-1 transition-all" />
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}