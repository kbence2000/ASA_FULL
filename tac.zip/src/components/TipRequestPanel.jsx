import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Sparkles, Zap, DollarSign, Clock,
  MessageSquare, AlertCircle, CheckCircle2
} from "lucide-react";
import { toast } from "sonner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const TIP_API = import.meta.env.VITE_TIP_BACKEND_URL || "http://localhost:3004";

const PRICE_TIERS = {
  micro: { price: 1, label: "Micro Tip", desc: "Quick 1-2 sentence answer" },
  mini: { price: 3, label: "Mini Tip", desc: "3-5 sentence guidance" },
  deep: { price: 5, label: "Deep Tip", desc: "Detailed pattern/refactor advice" }
};

export default function TipRequestPanel({ userId, userName, onTipCreated }) {
  const [codeSnippet, setCodeSnippet] = useState("");
  const [question, setQuestion] = useState("");
  const [priceTier, setPriceTier] = useState("micro");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [result, setResult] = useState(null);

  const handleSubmit = async () => {
    if (!userId) {
      toast.error("User ID required");
      return;
    }
    
    if (!codeSnippet.trim()) {
      toast.error("Please provide code snippet");
      return;
    }

    setIsSubmitting(true);
    setResult(null);

    try {
      const res = await fetch(`${TIP_API}/api/tip/request`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requesterId: userId,
          codeSnippet: codeSnippet.trim(),
          question: question.trim(),
          priceTier,
        })
      });

      const data = await res.json();
      
      if (!res.ok) {
        toast.error(data.error || "Failed to create tip request");
        return;
      }

      setResult(data);
      toast.success(`Tip request created! Assigned to ${data.tip.assignedDemigodName || 'a demigod'}`);
      
      // Clear form
      setCodeSnippet("");
      setQuestion("");
      setPriceTier("micro");

      if (onTipCreated) {
        onTipCreated(data);
      }
    } catch (error) {
      console.error("Tip request error:", error);
      toast.error("Network error");
    } finally {
      setIsSubmitting(false);
    }
  };

  const selectedTier = PRICE_TIERS[priceTier];

  return (
    <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 rounded-lg bg-gradient-to-br from-green-500/20 to-emerald-500/20">
          <DollarSign className="w-6 h-6 text-green-400" />
        </div>
        <div className="flex-1">
          <h3 className="text-xl font-black text-white">Request Demigod Tip</h3>
          <p className="text-sm text-gray-400">Get expert advice from R6/R7 developers</p>
        </div>
      </div>

      <div className="space-y-4">
        {/* Price Tier Selection */}
        <div>
          <label className="text-xs text-gray-400 block mb-2">Select Tip Tier</label>
          <div className="grid grid-cols-3 gap-3">
            {Object.entries(PRICE_TIERS).map(([key, tier]) => (
              <button
                key={key}
                onClick={() => setPriceTier(key)}
                className={`p-3 rounded-lg border-2 transition-all text-left ${
                  priceTier === key
                    ? 'border-green-500 bg-green-500/10'
                    : 'border-[#1a1f2e] hover:border-gray-600'
                }`}
              >
                <div className="text-sm font-bold text-white mb-1">€{tier.price}</div>
                <div className="text-xs text-gray-400">{tier.label}</div>
              </button>
            ))}
          </div>
          <div className="mt-2 p-3 rounded-lg bg-[#141923] border border-[#1a1f2e]">
            <div className="text-xs text-gray-400">{selectedTier.desc}</div>
            <div className="flex items-center justify-between mt-2 text-xs">
              <span className="text-gray-500">Platform (20%)</span>
              <span className="text-gray-400">€{(selectedTier.price * 0.2).toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-500">Demigod (80%)</span>
              <span className="text-green-400 font-bold">€{(selectedTier.price * 0.8).toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Code Snippet */}
        <div>
          <label className="text-xs text-gray-400 block mb-1">
            Code Snippet *
          </label>
          <Textarea
            value={codeSnippet}
            onChange={(e) => setCodeSnippet(e.target.value)}
            className="bg-[#0a0a0f] border-[#1a1f2e] text-white font-mono text-sm h-40 resize-none"
            placeholder="Paste the code you need help with..."
            disabled={isSubmitting}
          />
        </div>

        {/* Question */}
        <div>
          <label className="text-xs text-gray-400 block mb-1">
            Specific Question (optional)
          </label>
          <Textarea
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            className="bg-[#141923] border-[#1a1f2e] text-white text-sm h-24 resize-none"
            placeholder="What specifically do you need help with?"
            disabled={isSubmitting}
          />
        </div>

        {/* Info */}
        <div className="p-3 rounded-lg bg-blue-600/10 border border-blue-600/30">
          <div className="flex items-start gap-2">
            <Clock className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
            <p className="text-xs text-blue-300 leading-relaxed">
              Demigods typically respond within <strong>1 hour</strong>. 
              Platform fee 20%, demigod earns 80%.
            </p>
          </div>
        </div>

        {/* Submit */}
        <Button
          onClick={handleSubmit}
          disabled={isSubmitting || !codeSnippet.trim()}
          className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-bold text-lg py-6"
        >
          {isSubmitting ? (
            <>
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
              Creating Request...
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5 mr-2" />
              Request Tip (€{selectedTier.price})
            </>
          )}
        </Button>

        {/* Result */}
        {result && (
          <div className="p-4 rounded-lg bg-green-600/10 border border-green-600/30">
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-400 flex-shrink-0" />
              <div className="flex-1">
                <div className="text-sm font-bold text-green-400 mb-2">Tip Request Created!</div>
                <div className="text-xs text-gray-300 space-y-1">
                  <div>ID: <span className="font-mono">{result.tip.id}</span></div>
                  <div>Assigned to: <strong>{result.tip.assignedDemigodName || 'Demigod'}</strong></div>
                  <div>Status: <Badge className="bg-yellow-600/20 text-yellow-400 border-yellow-600/30 text-xs">Pending Answer</Badge></div>
                  <div className="text-gray-400 mt-2">
                    You'll be notified when the demigod responds.
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}