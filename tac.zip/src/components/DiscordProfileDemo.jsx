import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  MessageCircle, Users, Shield, Crown, 
  CheckCircle2, Link as LinkIcon, ExternalLink
} from "lucide-react";

export default function DiscordProfileDemo() {
  const [showConnected, setShowConnected] = useState(false);

  const demoProfile = {
    before: {
      username: "demo_user",
      email: "demo@example.com",
      rank: "Rising",
      rankScore: 750,
      discordLinked: false
    },
    after: {
      username: "demo_user",
      email: "demo@example.com",
      rank: "Elite",
      rankScore: 892,
      discordLinked: true,
      discord: {
        username: "CodeDemigod",
        discriminator: "7890",
        avatar: "https://cdn.discordapp.com/embed/avatars/0.png",
        guilds: [
          { id: "1", name: "React Developers", icon: "⚛️", members: "45K" },
          { id: "2", name: "TypeScript Community", icon: "📘", members: "32K" },
          { id: "3", name: "AI Engineers Hub", icon: "🤖", members: "18K" },
          { id: "4", name: "Indie Hackers", icon: "🚀", members: "67K" }
        ]
      }
    }
  };

  const profile = showConnected ? demoProfile.after : demoProfile.before;

  return (
    <div className="space-y-6">
      {/* Toggle Demo State */}
      <div className="text-center">
        <Button
          onClick={() => setShowConnected(!showConnected)}
          className="btn-secondary"
          size="sm"
        >
          {showConnected ? '← View Before Connection' : 'See After Connection →'}
        </Button>
      </div>

      {/* Profile Card */}
      <div className="premium-card relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-cyan-500/5" />
        
        <div className="relative">
          {/* Header */}
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-center gap-4">
              {/* Avatar */}
              <div className={`w-20 h-20 rounded-xl flex items-center justify-center text-3xl font-black ${
                showConnected 
                  ? 'bg-gradient-to-br from-purple-500 via-pink-500 to-[#5865F2]' 
                  : 'bg-gradient-to-br from-purple-500 to-pink-500'
              }`}>
                {showConnected ? (
                  <img 
                    src={profile.discord.avatar} 
                    alt="avatar" 
                    className="w-full h-full rounded-xl"
                  />
                ) : (
                  <span className="text-white">{profile.username.charAt(0).toUpperCase()}</span>
                )}
              </div>

              {/* Info */}
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-xl font-bold text-white">{profile.username}</h3>
                  {showConnected && (
                    <Badge className="bg-[#5865F2]/20 text-[#5865F2] border-[#5865F2]/30">
                      <MessageCircle className="w-3 h-3 mr-1" />
                      Discord Verified
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-gray-400">{profile.email}</p>
                {showConnected && (
                  <p className="text-sm text-[#5865F2] font-mono">
                    {profile.discord.username}#{profile.discord.discriminator}
                  </p>
                )}
              </div>
            </div>

            {/* Rank Badge */}
            <Badge className={`text-lg px-4 py-2 ${
              showConnected 
                ? 'bg-cyan-600/20 text-cyan-300 border-cyan-600/30' 
                : 'bg-purple-600/20 text-purple-300 border-purple-600/30'
            }`}>
              <Crown className="w-4 h-4 mr-2" />
              {profile.rank}
            </Badge>
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="glass-card p-4 text-center">
              <div className="text-2xl font-bold gradient-text">{profile.rankScore}</div>
              <div className="text-xs text-gray-500 mt-1">Rank Score</div>
              {showConnected && (
                <div className="text-xs text-green-400 font-semibold mt-1">
                  +{profile.rankScore - demoProfile.before.rankScore} ⬆
                </div>
              )}
            </div>

            <div className="glass-card p-4 text-center">
              <div className="text-2xl font-bold gradient-text">42</div>
              <div className="text-xs text-gray-500 mt-1">Projects</div>
            </div>

            <div className="glass-card p-4 text-center">
              <div className="text-2xl font-bold gradient-text">
                {showConnected ? profile.discord.guilds.length : '0'}
              </div>
              <div className="text-xs text-gray-500 mt-1">Discord Guilds</div>
              {showConnected && (
                <div className="text-xs text-green-400 font-semibold mt-1">
                  +{profile.discord.guilds.length} verified
                </div>
              )}
            </div>
          </div>

          {/* Discord Connection Status */}
          <div className={`rounded-xl p-4 border ${
            showConnected 
              ? 'bg-[#5865F2]/10 border-[#5865F2]/30' 
              : 'bg-gray-500/10 border-gray-500/30'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {showConnected ? (
                  <CheckCircle2 className="w-5 h-5 text-[#5865F2]" />
                ) : (
                  <LinkIcon className="w-5 h-5 text-gray-500" />
                )}
                <div>
                  <div className="font-semibold text-white text-sm">
                    {showConnected ? 'Discord Connected' : 'Discord Not Connected'}
                  </div>
                  <div className="text-xs text-gray-400">
                    {showConnected 
                      ? 'Your guild activity boosts your demigod rank' 
                      : 'Connect to unlock enhanced ranking features'
                    }
                  </div>
                </div>
              </div>
              
              {!showConnected && (
                <Button size="sm" className="bg-[#5865F2] hover:bg-[#4752C4]">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Connect
                </Button>
              )}
            </div>
          </div>

          {/* Discord Guilds Display (only when connected) */}
          {showConnected && (
            <div className="mt-6">
              <div className="flex items-center gap-2 mb-4">
                <Users className="w-5 h-5 text-purple-400" />
                <h4 className="font-bold text-white">Connected Communities</h4>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                {profile.discord.guilds.map((guild) => (
                  <div 
                    key={guild.id}
                    className="glass-card p-3 hover-lift cursor-pointer group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-xl flex-shrink-0">
                        {guild.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-white text-sm truncate group-hover:text-gradient transition-colors">
                          {guild.name}
                        </div>
                        <div className="text-xs text-gray-500">{guild.members} members</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-4 p-3 rounded-lg bg-purple-600/10 border border-purple-600/30">
                <div className="flex items-start gap-2">
                  <Shield className="w-4 h-4 text-purple-400 mt-0.5 flex-shrink-0" />
                  <div className="text-xs text-purple-200 leading-relaxed">
                    <strong>Rank Boost Active:</strong> Your participation in verified developer 
                    communities adds +142 points to your demigod score. Keep contributing!
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Before State Message */}
          {!showConnected && (
            <div className="mt-6 p-4 rounded-lg bg-yellow-600/10 border border-yellow-600/30">
              <div className="flex items-start gap-2">
                <MessageCircle className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
                <div className="text-xs text-yellow-200 leading-relaxed">
                  <strong>Potential Rank Boost:</strong> Connect Discord to potentially increase 
                  your score by up to 150 points based on your community involvement.
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Comparison Stats */}
      {showConnected && (
        <div className="grid md:grid-cols-3 gap-4">
          <Card className="border-green-500/30 bg-green-950/20 p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center text-white font-bold">
                ⬆
              </div>
              <div>
                <div className="text-sm font-semibold text-green-400">Rank Upgraded</div>
                <div className="text-xs text-gray-400">Rising → Elite</div>
              </div>
            </div>
          </Card>

          <Card className="border-cyan-500/30 bg-cyan-950/20 p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-full bg-cyan-500 flex items-center justify-center text-white font-bold">
                +142
              </div>
              <div>
                <div className="text-sm font-semibold text-cyan-400">Score Increase</div>
                <div className="text-xs text-gray-400">+18.9% boost</div>
              </div>
            </div>
          </Card>

          <Card className="border-purple-500/30 bg-purple-950/20 p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-full bg-purple-500 flex items-center justify-center text-white font-bold">
                4
              </div>
              <div>
                <div className="text-sm font-semibold text-purple-400">Guilds Verified</div>
                <div className="text-xs text-gray-400">Dev communities</div>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}