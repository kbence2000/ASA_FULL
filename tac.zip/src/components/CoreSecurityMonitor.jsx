import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Shield, AlertTriangle, Lock, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { coreAPI } from "./CoreAPIClient";

export default function CoreSecurityMonitor() {
  const [security, setSecurity] = useState(null);
  const [loading, setLoading] = useState(true);
  const [threatId, setThreatId] = useState("");
  const [quarantining, setQuarantining] = useState(false);

  useEffect(() => {
    fetchSecurityStatus();
    const interval = setInterval(fetchSecurityStatus, 10000); // Poll every 10s
    return () => clearInterval(interval);
  }, []);

  const fetchSecurityStatus = async () => {
    try {
      const data = await coreAPI.getSecurityStatus();
      setSecurity(data);
    } catch (error) {
      console.error("Failed to fetch security status:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleQuarantine = async () => {
    if (!threatId.trim()) {
      toast.error("Please enter a threat ID");
      return;
    }

    setQuarantining(true);
    try {
      await coreAPI.quarantineThreat({
        threatId,
        reason: "Manual quarantine from dashboard",
      });
      toast.success("Threat quarantined successfully");
      setThreatId("");
      fetchSecurityStatus();
    } catch (error) {
      console.error("Quarantine failed:", error);
      toast.error("Quarantine failed: " + error.message);
    } finally {
      setQuarantining(false);
    }
  };

  if (loading) {
    return (
      <Card className="border p-6 text-center" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <Loader2 className="w-8 h-8 animate-spin mx-auto mb-3 text-cyan-400" />
        <p className="text-gray-400">Loading security status...</p>
      </Card>
    );
  }

  const threatLevel = security?.threatLevel || "unknown";
  const getThreatColor = (level) => {
    switch (level) {
      case "low": return "text-green-400";
      case "medium": return "text-yellow-400";
      case "high": return "text-orange-400";
      case "critical": return "text-red-400";
      default: return "text-gray-400";
    }
  };

  return (
    <div className="grid md:grid-cols-2 gap-6">
      {/* Security Status */}
      <Card className="border p-6" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <Shield className="w-5 h-5 text-cyan-400" />
          Security Status
        </h3>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 rounded-lg border" style={{
            background: 'rgba(5, 8, 22, 0.9)',
            borderColor: 'rgba(148, 163, 184, 0.2)'
          }}>
            <span className="text-sm text-gray-400">Threat Level:</span>
            <Badge className={`${getThreatColor(threatLevel)} border-current`}>
              {threatLevel.toUpperCase()}
            </Badge>
          </div>

          <div className="flex items-center justify-between p-3 rounded-lg border" style={{
            background: 'rgba(5, 8, 22, 0.9)',
            borderColor: 'rgba(148, 163, 184, 0.2)'
          }}>
            <span className="text-sm text-gray-400">Active Threats:</span>
            <span className="text-white font-semibold">{security?.activeThreats || 0}</span>
          </div>

          <div className="flex items-center justify-between p-3 rounded-lg border" style={{
            background: 'rgba(5, 8, 22, 0.9)',
            borderColor: 'rgba(148, 163, 184, 0.2)'
          }}>
            <span className="text-sm text-gray-400">Quarantined:</span>
            <span className="text-white font-semibold">{security?.quarantined || 0}</span>
          </div>

          <div className="flex items-center justify-between p-3 rounded-lg border" style={{
            background: 'rgba(5, 8, 22, 0.9)',
            borderColor: 'rgba(148, 163, 184, 0.2)'
          }}>
            <span className="text-sm text-gray-400">Last Scan:</span>
            <span className="text-white font-mono text-xs">
              {security?.lastScan || "Never"}
            </span>
          </div>
        </div>
      </Card>

      {/* Quarantine Control */}
      <Card className="border p-6" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <Lock className="w-5 h-5 text-orange-400" />
          Quarantine Control
        </h3>

        <div className="space-y-4">
          <div>
            <label className="text-sm text-gray-300 mb-2 block">Threat ID</label>
            <Input
              value={threatId}
              onChange={(e) => setThreatId(e.target.value)}
              placeholder="Enter threat identifier"
              className="bg-[#0f0a1f] border-[#1a1f2e] text-white"
            />
          </div>

          <Button
            onClick={handleQuarantine}
            disabled={quarantining || !threatId.trim()}
            className="w-full"
            style={{
              background: quarantining ? '#4a5568' : 'linear-gradient(135deg, #f97316, #dc2626)',
              color: 'white'
            }}
          >
            {quarantining ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Quarantining...
              </>
            ) : (
              <>
                <Lock className="w-4 h-4 mr-2" />
                Quarantine Threat
              </>
            )}
          </Button>

          {security?.recentThreats && security.recentThreats.length > 0 && (
            <div className="mt-6">
              <h4 className="text-sm font-semibold text-gray-300 mb-2">Recent Threats:</h4>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {security.recentThreats.map((threat, idx) => (
                  <div
                    key={idx}
                    className="p-2 rounded border text-xs"
                    style={{
                      background: 'rgba(5, 8, 22, 0.9)',
                      borderColor: 'rgba(239, 68, 68, 0.3)'
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-white font-mono">{threat.id}</span>
                      <Badge className="bg-red-600/20 text-red-300 border-red-600/30 text-xs">
                        {threat.severity}
                      </Badge>
                    </div>
                    <p className="text-gray-400 mt-1">{threat.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}