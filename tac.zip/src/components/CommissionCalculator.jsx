import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingDown, Award, Star, Crown } from "lucide-react";

/**
 * Komisszió szint meghatározása eladások száma alapján
 * - Kezdő (0-4): 15%
 * - Haladó (5-19): 12%
 * - Prémium (20+): 8%
 */
export function getCommissionRate(salesCount) {
  if (salesCount >= 20) return 0.08; // Prémium
  if (salesCount >= 5) return 0.12;  // Haladó
  return 0.15; // Kezdő
}

export function getCommissionTier(salesCount) {
  if (salesCount >= 20) return { name: "Prémium", icon: Crown, color: "text-yellow-500", bg: "bg-yellow-500/20" };
  if (salesCount >= 5) return { name: "Haladó", icon: Star, color: "text-blue-500", bg: "bg-blue-500/20" };
  return { name: "Kezdő", icon: Award, color: "text-gray-500", bg: "bg-gray-500/20" };
}

export function calculateSellerNet(amount, commissionRate) {
  const platformFee = Math.round(amount * commissionRate);
  const net = amount - platformFee;
  return { platformFee, net };
}

export default function CommissionCalculator({ amount, salesCount, currency = "HUF" }) {
  const rate = getCommissionRate(salesCount);
  const { platformFee, net } = calculateSellerNet(amount, rate);
  const tier = getCommissionTier(salesCount);
  const Icon = tier.icon;

  return (
    <Card className="border border-[#1a1f2e] bg-[#0f1419] p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <TrendingDown className="w-5 h-5 text-[#00E599]" />
          <h3 className="text-sm font-bold text-white">Bevétel Kalkuláció</h3>
        </div>
        <Badge className={`${tier.bg} ${tier.color} border-0 flex items-center gap-1`}>
          <Icon className="w-3 h-3" />
          {tier.name}
        </Badge>
      </div>

      <div className="space-y-3">
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">Eladási ár</span>
          <span className="text-white font-semibold">{amount.toLocaleString()} {currency}</span>
        </div>

        <div className="flex justify-between text-sm">
          <span className="text-gray-400">Platform jutalék ({Math.round(rate * 100)}%)</span>
          <span className="text-red-400">-{platformFee.toLocaleString()} {currency}</span>
        </div>

        <div className="border-t border-[#1a1f2e] pt-3 flex justify-between">
          <span className="text-white font-bold">Nettó bevétel</span>
          <span className="text-[#00E599] text-lg font-black">{net.toLocaleString()} {currency}</span>
        </div>
      </div>

      <div className="mt-4 p-3 rounded-lg bg-[#141923] border border-[#1a1f2e]">
        <p className="text-xs text-gray-400">
          💡 <span className="text-white font-semibold">Tipp:</span> Érj el {salesCount < 5 ? '5' : '20'} eladást, és csökkentsd a jutalékot {salesCount < 5 ? '12%' : '8%'}-ra!
        </p>
      </div>
    </Card>
  );
}