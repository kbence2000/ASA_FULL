import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Star, Users, Crown } from "lucide-react";
import AppCard from "./AppCard";

/**
 * Demigod Collections - Curated app collections by R6-R7 demigods
 * Integrates with Straight From The Top community
 */
export default function DemigodCollection({ apps }) {
  // Mock demigod collections (in production, fetch from database)
  const collections = [
    {
      id: "nova_favorites",
      demigod: {
        name: "Nova",
        rank: "Demigod",
        avatar: "🜁",
        expertise: ["fullstack", "ai", "infra"]
      },
      title: "Nova's AI-Powered Stack",
      description: "My go-to tools for building intelligent, scalable applications. These apps integrate seamlessly with LLMs and vector databases.",
      appIds: apps.slice(0, 4).map(a => a.id),
      tags: ["ai", "scalable", "production-ready"],
      followers: 234,
      lastUpdated: Date.now() - 1000 * 60 * 60 * 24 * 2 // 2 days ago
    },
    {
      id: "lyra_design",
      demigod: {
        name: "Lyra",
        rank: "Demigod",
        avatar: "✦",
        expertise: ["design", "ui/ux"]
      },
      title: "Lyra's Design Essentials",
      description: "Handpicked apps for designers who code. Beautiful UIs, smooth animations, and pixel-perfect components.",
      appIds: apps.filter(a => a.category === 'design').slice(0, 4).map(a => a.id),
      tags: ["design", "ui/ux", "components"],
      followers: 189,
      lastUpdated: Date.now() - 1000 * 60 * 60 * 24 * 5 // 5 days ago
    }
  ];

  const getAppsForCollection = (collection) => {
    return apps.filter(app => collection.appIds.includes(app.id));
  };

  const formatTimeAgo = (timestamp) => {
    const diff = Date.now() - timestamp;
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    if (days === 0) return "today";
    if (days === 1) return "yesterday";
    return `${days} days ago`;
  };

  return (
    <div className="space-y-8">
      {/* Hero Card */}
      <Card className="border-yellow-600/50 bg-gradient-to-br from-yellow-600/10 to-orange-600/10 p-6">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-yellow-600 to-orange-600 flex items-center justify-center">
            <Crown className="w-8 h-8 text-white" />
          </div>
          <div>
            <h2 className="text-3xl font-black text-white">Demigod Collections</h2>
            <p className="text-sm text-yellow-200">
              Curated by <strong>R6-R7 Elite Demigods</strong> from Straight From The Top
            </p>
          </div>
        </div>
        <p className="text-sm text-gray-300 leading-relaxed">
          Top demigods share their favorite apps, battle-tested in production. These aren't random picks—they're 
          <strong className="text-yellow-300"> proven tools</strong> used by the best developers in the ecosystem.
        </p>
      </Card>

      {/* Collections Grid */}
      {collections.length === 0 ? (
        <div className="text-center py-20">
          <Trophy className="w-16 h-16 text-yellow-500 mx-auto mb-4 opacity-50" />
          <h3 className="text-2xl font-bold text-white mb-2">No Collections Yet</h3>
          <p className="text-gray-400">
            Demigods will start curating app collections soon. Stay tuned!
          </p>
        </div>
      ) : (
        <div className="space-y-8">
          {collections.map(collection => {
            const collectionApps = getAppsForCollection(collection);
            
            return (
              <Card 
                key={collection.id}
                className="border-[#1a1f2e] bg-[#0f1419] p-6"
              >
                {/* Collection Header */}
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-start gap-4 flex-1">
                    {/* Demigod Avatar */}
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center text-2xl flex-shrink-0">
                      {collection.demigod.avatar}
                    </div>

                    {/* Collection Info */}
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="text-xl font-bold text-white">{collection.title}</h3>
                        <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30">
                          <Trophy className="w-3 h-3 mr-1" />
                          {collection.demigod.rank}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm text-gray-400 mb-3">
                        <span>by <strong className="text-purple-400">{collection.demigod.name}</strong></span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Users className="w-3 h-3" />
                          {collection.followers} followers
                        </span>
                        <span>•</span>
                        <span>Updated {formatTimeAgo(collection.lastUpdated)}</span>
                      </div>

                      <p className="text-sm text-gray-300 leading-relaxed mb-3">
                        {collection.description}
                      </p>

                      {/* Tags */}
                      <div className="flex flex-wrap gap-2">
                        {collection.tags.map((tag, idx) => (
                          <Badge 
                            key={idx}
                            className="bg-yellow-600/20 text-yellow-300 border-yellow-600/30 text-xs"
                          >
                            #{tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Collection Apps */}
                {collectionApps.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <p>No apps in this collection yet</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {collectionApps.map(app => (
                      <AppCard key={app.id} app={app} showTryButton={true} />
                    ))}
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}

      {/* Stats Footer */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-[#1a1f2e] bg-[#0f1419] p-4">
          <div className="text-xs text-gray-400 mb-1">Active Curators</div>
          <div className="text-2xl font-bold text-purple-400">2</div>
        </Card>
        <Card className="border-[#1a1f2e] bg-[#0f1419] p-4">
          <div className="text-xs text-gray-400 mb-1">Total Collections</div>
          <div className="text-2xl font-bold text-white">{collections.length}</div>
        </Card>
        <Card className="border-[#1a1f2e] bg-[#0f1419] p-4">
          <div className="text-xs text-gray-400 mb-1">Apps Featured</div>
          <div className="text-2xl font-bold text-cyan-400">
            {collections.reduce((sum, c) => sum + c.appIds.length, 0)}
          </div>
        </Card>
        <Card className="border-[#1a1f2e] bg-[#0f1419] p-4">
          <div className="text-xs text-gray-400 mb-1">Total Followers</div>
          <div className="text-2xl font-bold text-yellow-400">
            {collections.reduce((sum, c) => sum + c.followers, 0)}
          </div>
        </Card>
      </div>
    </div>
  );
}