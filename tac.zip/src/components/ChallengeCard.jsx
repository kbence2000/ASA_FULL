import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Swords, Clock, DollarSign, Code2, Flame } from "lucide-react";

const DIFFICULTY_CONFIG = {
  easy: { color: "text-green-400", bg: "bg-green-600/20", border: "border-green-600/30" },
  medium: { color: "text-yellow-400", bg: "bg-yellow-600/20", border: "border-yellow-600/30" },
  hard: { color: "text-red-400", bg: "bg-red-600/20", border: "border-red-600/30" },
  demigod: { color: "text-purple-400", bg: "bg-purple-600/20", border: "border-purple-600/30" }
};

export default function ChallengeCard({ challenge, onJoin }) {
  const diffCfg = DIFFICULTY_CONFIG[challenge.difficulty] || DIFFICULTY_CONFIG.medium;
  const timeMinutes = Math.round(challenge.timeLimitSec / 60);

  return (
    <Card className="border-[#1a1f2e] bg-[#141923] p-4 hover:border-red-500/50 transition-all">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <h3 className="text-base font-bold text-white mb-1">{challenge.title}</h3>
          <div className="flex items-center gap-2 text-xs text-gray-400">
            <span>by {challenge.createdByCompanyName}</span>
          </div>
        </div>
        <Badge className={`${diffCfg.bg} ${diffCfg.color} border ${diffCfg.border}`}>
          {challenge.difficulty}
        </Badge>
      </div>

      {challenge.description && (
        <p className="text-sm text-gray-300 mb-3 line-clamp-2">
          {challenge.description}
        </p>
      )}

      <div className="flex items-center gap-3 mb-3 flex-wrap">
        <div className="flex items-center gap-1 text-xs text-gray-400">
          <Code2 className="w-3 h-3" />
          <span>{challenge.language}</span>
        </div>

        <div className="flex items-center gap-1 text-xs text-gray-400">
          <Clock className="w-3 h-3" />
          <span>{timeMinutes} min</span>
        </div>

        <div className="flex items-center gap-1 text-xs text-green-400 font-semibold">
          <DollarSign className="w-3 h-3" />
          <span>€{challenge.rewardEUR}</span>
        </div>
      </div>

      <Button
        onClick={onJoin}
        className="w-full bg-gradient-to-r from-red-600 to-orange-600 text-white font-bold"
      >
        <Swords className="w-4 h-4 mr-2" />
        Join Arena
      </Button>
    </Card>
  );
}