import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Brain, Loader2, TrendingUp, Lightbulb } from "lucide-react";
import { toast } from "sonner";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import ReactMarkdown from "react-markdown";

export default function APCInsights() {
  const [generating, setGenerating] = useState(false);
  const [insight, setInsight] = useState(null);

  const { data: patterns } = useQuery({
    queryKey: ['apcPatterns'],
    queryFn: () => base44.entities.APCPattern.list('-seenCount', 30),
    initialData: [],
  });

  const handleGenerateInsights = async () => {
    if (patterns.length === 0) {
      toast.error('No patterns available for analysis');
      return;
    }

    setGenerating(true);
    
    try {
      const sample = patterns.slice(0, 30).map(p => ({
        name: p.name,
        category: p.category,
        language: p.language,
        innovationScore: p.innovationScore,
        usageScore: p.usageScore,
        seenCount: p.seenCount,
        tags: p.tags
      }));

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are APC-INSIGHT, an AI system that analyzes code patterns.

Analyze these patterns and provide insights in the following sections:

1. **Global Trend**: What's the overall direction of development?
2. **Top Patterns**: Which patterns are most significant?
3. **Emerging Ideas**: What new concepts are appearing?
4. **Recommendations**: What should developers focus on?

Be concise, insightful, and actionable.

Patterns:
${JSON.stringify(sample, null, 2)}`
      });

      setInsight(response);
      toast.success('Insights generated!');
    } catch (error) {
      console.error('Insight generation failed:', error);
      toast.error('Failed to generate insights');
    } finally {
      setGenerating(false);
    }
  };

  return (
    <Card className="border p-6" style={{
      background: 'rgba(15, 23, 42, 0.95)',
      borderColor: 'rgba(148, 163, 184, 0.35)'
    }}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <Brain className="w-8 h-8 text-purple-400" />
          <div>
            <h3 className="font-bold text-white text-lg">APC Insights</h3>
            <p className="text-xs text-gray-400">AI analysis of collected patterns</p>
          </div>
        </div>

        <Button
          onClick={handleGenerateInsights}
          disabled={generating || patterns.length === 0}
          className="flex items-center gap-2"
          style={{
            background: generating ? '#4a5568' : 'linear-gradient(135deg, #8b5cff, #24e4ff)',
            color: 'white'
          }}
        >
          {generating ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Analyzing...
            </>
          ) : (
            <>
              <Brain className="w-4 h-4" />
              Generate Insights
            </>
          )}
        </Button>
      </div>

      {insight ? (
        <div className="p-4 rounded-lg border" style={{
          background: 'rgba(5, 8, 22, 0.9)',
          borderColor: 'rgba(139, 92, 255, 0.3)'
        }}>
          <ReactMarkdown 
            className="prose prose-sm prose-invert max-w-none"
            components={{
              h1: ({children}) => <h1 className="text-xl font-bold text-purple-300 mb-3">{children}</h1>,
              h2: ({children}) => <h2 className="text-lg font-bold text-cyan-300 mb-2 mt-4">{children}</h2>,
              h3: ({children}) => <h3 className="text-base font-bold text-white mb-2 mt-3">{children}</h3>,
              p: ({children}) => <p className="text-gray-300 mb-3 leading-relaxed">{children}</p>,
              ul: ({children}) => <ul className="list-disc ml-6 mb-3 text-gray-300">{children}</ul>,
              ol: ({children}) => <ol className="list-decimal ml-6 mb-3 text-gray-300">{children}</ol>,
              li: ({children}) => <li className="mb-1">{children}</li>,
              strong: ({children}) => <strong className="text-white font-semibold">{children}</strong>,
            }}
          >
            {insight}
          </ReactMarkdown>
        </div>
      ) : (
        <div className="text-center py-12">
          <Lightbulb className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400">
            Click "Generate Insights" to get AI analysis of your patterns
          </p>
        </div>
      )}
    </Card>
  );
}