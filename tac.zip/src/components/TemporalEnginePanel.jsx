import React, { useState } from 'react';
import { X, Clock, Rewind } from 'lucide-react';
import { useTriMind } from './TriMindContext';

export default function TemporalEnginePanel({ isOpen, onClose }) {
  const triMind = useTriMind();
  const [temporalAnomaly, setTemporalAnomaly] = useState('No time-based behavior yet.');
  const [temporalWindow, setTemporalWindow] = useState('');

  const windows = [
    "every 15 seconds for 2 seconds",
    "the first 42 seconds after page load",
    "when local time seconds % 10 === 0",
    "during user inactivity longer than 8 seconds",
    "between 2:00 AM and 4:00 AM local time",
    "on page focus after 30 seconds of being backgrounded"
  ];

  const behaviors = [
    "UI slowly rewinds to the last stable layout snapshot.",
    "Neural lines glow brighter as if time were thickening.",
    "Buttons appear to smear forward then snap back.",
    "All animations slow to 20% speed, then overshoot to 200%.",
    "Elements fade in reverse order of their appearance.",
    "The interface briefly shows a 'future state' preview."
  ];

  const generateTemporal = () => {
    const window = windows[Math.floor(Math.random() * windows.length)];
    const behavior = behaviors[Math.floor(Math.random() * behaviors.length)];

    setTemporalAnomaly(behavior);
    setTemporalWindow(window);

    // Update Tri-Mind state
    if (triMind) {
      triMind.setTemporalState({
        windowLabel: window,
        short: behavior.slice(0, 50) + '...',
        behavior
      });
    }
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[200]"
        onClick={onClose}
      />

      {/* Panel */}
      <div 
        className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[460px] max-w-[90vw] h-[540px] max-h-[85vh] z-[201] overflow-y-auto"
        style={{
          background: 'rgba(8, 5, 18, 0.96)',
          borderRadius: '18px',
          border: '1px solid rgba(138, 92, 255, 0.3)',
          backdropFilter: 'blur(16px)',
          boxShadow: '0 0 80px rgba(138, 92, 255, 0.4)',
          padding: '20px',
          animation: 'panelSlideIn 0.35s ease-out'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <style>{`
          @keyframes panelSlideIn {
            from {
              opacity: 0;
              transform: translate(-50%, -50%) scale(0.9);
            }
            to {
              opacity: 1;
              transform: translate(-50%, -50%) scale(1);
            }
          }
        `}</style>

        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <div className="text-[0.9rem] tracking-[0.2em] uppercase" style={{ color: '#b788ff' }}>
            TEMPORAL ENGINE
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Time Anomaly */}
        <div className="mb-6">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-3 font-semibold" style={{ color: '#d4b3ff' }}>
            TIME ANOMALY
          </h3>
          <div 
            className="p-3 rounded-lg text-sm"
            style={{
              background: 'rgba(0, 0, 0, 0.5)',
              border: '1px solid rgba(138, 92, 255, 0.3)',
              color: '#f0e5ff'
            }}
          >
            {temporalAnomaly}
          </div>
        </div>

        {/* Effect Window */}
        <div className="mb-6">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-3 font-semibold" style={{ color: '#d4b3ff' }}>
            EFFECT WINDOW
          </h3>
          <div 
            className="p-3 rounded-lg text-xs"
            style={{
              background: 'rgba(0, 0, 0, 0.5)',
              border: '1px solid rgba(138, 92, 255, 0.3)',
              color: '#f0e5ff'
            }}
          >
            {temporalWindow || 'No time window specified yet.'}
          </div>
        </div>

        {/* Info */}
        <div 
          className="p-3 rounded-lg mb-6"
          style={{
            background: 'rgba(138, 92, 255, 0.1)',
            border: '1px solid rgba(138, 92, 255, 0.3)'
          }}
        >
          <div className="flex items-start gap-2">
            <Rewind className="w-4 h-4 text-purple-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <span className="font-semibold text-white">Temporal Engine:</span> Creates time-based UI mutations that activate during specific windows. The interface can slow down, speed up, rewind, or preview future states based on temporal conditions.
            </div>
          </div>
        </div>

        {/* Action Button */}
        <button 
          onClick={generateTemporal}
          className="w-full py-3 rounded-xl font-semibold text-sm transition-all hover:scale-[1.02]"
          style={{
            background: 'linear-gradient(135deg, rgba(138, 92, 255, 0.6), rgba(183, 136, 255, 0.4))',
            border: '1px solid rgba(138, 92, 255, 0.6)',
            boxShadow: '0 0 20px rgba(138, 92, 255, 0.5)',
            color: '#fff'
          }}
        >
          <Clock className="w-4 h-4 inline mr-2" />
          Generate Time Mutation
        </button>
      </div>
    </>
  );
}