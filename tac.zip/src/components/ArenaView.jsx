import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Swords, Trophy, Clock, Users, 
  Code2, Target, Flame, Zap 
} from "lucide-react";
import LiveScoreboard from "./LiveScoreboard";

const DIFFICULTY_CONFIG = {
  easy: { color: "text-green-400", icon: Target },
  medium: { color: "text-yellow-400", icon: Zap },
  hard: { color: "text-red-400", icon: Flame },
  demigod: { color: "text-purple-400", icon: Trophy }
};

export default function ArenaView({
  currentChallenge,
  currentMatch,
  latestScores,
  remainingMs,
  matchFinishedData,
  codeInput,
  setCodeInput,
  onSubmitCode,
  isRunning,
  isFinished
}) {
  if (!currentChallenge || !currentMatch) {
    return (
      <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
        <div className="text-center py-20">
          <Swords className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-white mb-2">No Active Arena</h3>
          <p className="text-gray-400">
            Join a challenge from the left to enter the arena
          </p>
        </div>
      </Card>
    );
  }

  const diffCfg = DIFFICULTY_CONFIG[currentChallenge.difficulty] || DIFFICULTY_CONFIG.medium;
  const DiffIcon = diffCfg.icon;

  // Timer display
  let timerText = "Waiting for players...";
  let timerColor = "text-gray-400";
  if (remainingMs !== null && !isFinished) {
    const secs = Math.max(0, Math.round(remainingMs / 1000));
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    timerText = `${mins}:${s.toString().padStart(2, '0')}`;
    
    if (secs < 60) {
      timerColor = "text-red-400";
    } else if (secs < 180) {
      timerColor = "text-yellow-400";
    } else {
      timerColor = "text-green-400";
    }
  }
  if (isFinished) {
    timerText = "Match Finished";
    timerColor = "text-gray-400";
  }

  return (
    <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
      <div className="space-y-6">
        {/* Arena Header */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Swords className="w-5 h-5 text-red-500" />
            <h2 className="text-2xl font-black text-white">{currentChallenge.title}</h2>
          </div>
          
          <div className="flex items-center gap-3 flex-wrap mb-3">
            <Badge className={`${diffCfg.color} bg-[#141923] border-[#1a1f2e]`}>
              <DiffIcon className="w-3 h-3 mr-1" />
              {currentChallenge.difficulty}
            </Badge>
            <Badge className="bg-blue-600/20 text-blue-400 border-blue-600/30">
              <Code2 className="w-3 h-3 mr-1" />
              {currentChallenge.language}
            </Badge>
            <Badge className="bg-green-600/20 text-green-400 border-green-600/30">
              €{currentChallenge.rewardEUR} reward
            </Badge>
          </div>

          {currentChallenge.description && (
            <p className="text-sm text-gray-300 mb-3">
              {currentChallenge.description}
            </p>
          )}

          {/* Status Bar */}
          <div className="flex items-center justify-between p-3 rounded-lg bg-[#141923] border border-[#1a1f2e]">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-cyan-400" />
                <span className="text-sm text-white font-semibold">
                  {currentMatch.players?.length || 0} Players
                </span>
              </div>
              
              <div className="flex items-center gap-2">
                <Clock className={`w-4 h-4 ${timerColor}`} />
                <span className={`text-sm font-bold ${timerColor}`}>
                  {timerText}
                </span>
              </div>
            </div>

            <Badge className={
              currentMatch.status === "waiting" 
                ? "bg-yellow-600/20 text-yellow-400 border-yellow-600/30"
                : currentMatch.status === "running"
                ? "bg-green-600/20 text-green-400 border-green-600/30"
                : "bg-gray-600/20 text-gray-400 border-gray-600/30"
            }>
              {currentMatch.status === "waiting" ? "Waiting" : 
               currentMatch.status === "running" ? "LIVE" : "Finished"}
            </Badge>
          </div>
        </div>

        {/* Code Editor */}
        {!isFinished && (
          <div>
            <label className="text-sm font-bold text-white block mb-2">
              Your Solution:
            </label>
            <Textarea
              value={codeInput}
              onChange={(e) => setCodeInput(e.target.value)}
              placeholder="// Write your solution here...&#10;// Submit when ready to score"
              className="bg-[#141923] border-[#1a1f2e] text-white font-mono text-sm h-64 resize-none"
              disabled={!isRunning}
            />
            <Button
              onClick={onSubmitCode}
              disabled={!isRunning || !codeInput}
              className="w-full mt-3 bg-gradient-to-r from-red-600 to-orange-600 text-white font-bold text-lg py-6"
            >
              {!isRunning ? "Wait for match start..." : "Submit Code"}
            </Button>
          </div>
        )}

        {/* Live Scoreboard */}
        <LiveScoreboard
          scores={latestScores}
          matchFinishedData={matchFinishedData}
          isFinished={isFinished}
        />

        {/* Winner Announcement */}
        {isFinished && matchFinishedData && (
          <div className="p-6 rounded-lg border-2 border-yellow-500/50 bg-gradient-to-br from-yellow-600/10 to-orange-600/10">
            <div className="text-center">
              <Trophy className="w-12 h-12 text-yellow-400 mx-auto mb-3" />
              <h3 className="text-2xl font-black text-white mb-2">
                Winner: {matchFinishedData.winnerName}
              </h3>
              <div className="text-3xl font-bold text-yellow-400 mb-2">
                €{matchFinishedData.rewardEUR}
              </div>
              <p className="text-sm text-gray-400">
                Congratulations! Reward will be credited to your account.
              </p>
            </div>
          </div>
        )}

        {/* Info Box */}
        {currentMatch.status === "waiting" && (
          <div className="p-4 rounded-lg bg-blue-600/10 border border-blue-600/30">
            <div className="flex items-start gap-2">
              <Clock className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
              <div className="text-xs text-blue-300">
                <strong>Waiting for players...</strong> Match will start automatically when enough players join. 
                Get ready to code!
              </div>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}